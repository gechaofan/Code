clear all
clc
LaserType=0; % laser by block design
PlotSingleUnitSelectivity=1;
TimeGain=10;
NewBin=1000;%ms
Bin=100;%ms
WaveformLenth = 58;
SampelRate = 40000;
InterpolationNum = 5;

IsUnitWaveProperty = 1;
PlotNormalizedFRForSingleUnit=1;
[tempfilename, pathname]=uigetfile('.mat','multiselect','on');%
filename=tempfilename';
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,1);
end

AllUnitID=[];AllTrialsFR=[];
AllHitTrialsFR=[];AllFATrialsFR=[];AllCRTrialsFR=[];
AllACTrialsFR=[];AllBDTrialsFR=[];AllADTrialsFR=[];AllBCTrialsFR=[];AllPairedTrialsFR=[];AllUnPairedTrialsFR=[];
AllATrialsFR=[];AllBTrialsFR=[];AllCTrialsFR=[];AllDTrialsFR=[];
AllShuffledATrialsFR=[];AllShuffledBTrialsFR=[];
SpikeWaveForm=[];AllTrialIndexForEachUnit=[];
AvergedWaveform=[];
AveragedFR=[];
Trough_to_Peak_Duration = [];%ms
Half_Amplitude_Duration = [];%ms amplitude is caculated from baseline to trough.
AmplitudeRatio=[];
PerformanceForUnits=[];TrialsForUnit=[];
AllUnitNumForEachFile=[];AllUnitWaveformNumForEachFile=[];FRNum=[];
% for itr=1:MainCircleN
for itr=1:MainCircleN
    load(filename{itr});
    %%
    
    if ~isempty(SingleUnitIndex)
        AllUnitNumForEachFile=[AllUnitNumForEachFile;size(SingleUnitIndex,1)];
        AllUnitWaveformNumForEachFile=[AllUnitWaveformNumForEachFile;size(NewSpikes,1)];
        %%
        % get averaged waveform of 4 channels (tetrode)
        tempWaveform = cellfun(@mean, NewSpikes, 'un', 0);
        Waveform = cell2mat(tempWaveform);
        AvergedWaveform =[AvergedWaveform; Waveform(:,4:end)];
        % get averaged firing rate of recording time
        AveragedFR = [AveragedFR; FiringRate];
        FRNum=[FRNum;size(FiringRate,1)];
        % get property of max waveform for 4 channels and max waveform
        if IsUnitWaveProperty == 1
            Trough_to_Peak_Duration_Eachfile = [];
            Half_Amplitude_Duration_Eachfile = [];
            AmplitudeRatio_Eachfile=[];
            [Trough_to_Peak_Duration_Eachfile, Half_Amplitude_Duration_Eachfile, MaxWaveform, AmplitudeRatio_Eachfile] = GetUnitWavePropertyForEachFile(NewSpikes,WaveformLenth,SampelRate,InterpolationNum);
            Trough_to_Peak_Duration = [Trough_to_Peak_Duration; Trough_to_Peak_Duration_Eachfile];
            Half_Amplitude_Duration = [Half_Amplitude_Duration; Half_Amplitude_Duration_Eachfile];
            AmplitudeRatio=[AmplitudeRatio; AmplitudeRatio_Eachfile];
        end
        %%
        tempUnitID={};tempAllTrialsFR=[];
        tempHitTrialsFR=[];tempFATrialsFR=[];tempCRTrialsFR=[];
        tempACTrialsFR=[];tempBDTrialsFR=[];tempADTrialsFR=[];tempBCTrialsFR=[];tempPairedTrialsFR=[];tempUnPairedTrialsFR=[];
        tempATrialsFR=[];tempBTrialsFR=[];tempCTrialsFR=[];tempDTrialsFR=[];tempShuffledATrialsFR=[];tempShuffledBTrialsFR=[];
        tempAllTrialIndex=[];
        
        %% averaged performance of each day and Trial information for individual unit
        tempPerformance=[];tempTrialsForUnit={};
        tempPerformance=ones(size(SingleUnitIndex,1),1)*mean(Data(:,7));
        PerformanceForUnits=[PerformanceForUnits;tempPerformance];
        tempTrialsForUnit=cell(size(SingleUnitIndex,1),1);
        tempTrialsForUnit(:)={SplitData.Trials};
        TrialsForUnit=[TrialsForUnit; tempTrialsForUnit];
        
        
        HitTrialIndex=find(SplitData.Trials(:,4)==1);
        FATrialIndex=find(SplitData.Trials(:,4)==3);
        CRTrialIndex=find(SplitData.Trials(:,4)==4);
        
        ACTrialIndex=find(SplitData.Trials(:,5)==1);
        BDTrialIndex=find(SplitData.Trials(:,5)==2);
        ADTrialIndex=find(SplitData.Trials(:,5)==3);
        BCTrialIndex=find(SplitData.Trials(:,5)==4);
        PairedTrialIndex=find(SplitData.Trials(:,5)==1|SplitData.Trials(:,5)==2);
        UnPairedTrialIndex=find(SplitData.Trials(:,5)==2|SplitData.Trials(:,5)==3);
        
        ShuffledATrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
        ShuffledBTrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
        ATrialIndex=find(SplitData.Trials(:,2)==1);
        BTrialIndex=find(SplitData.Trials(:,2)==2);
        CTrialIndex=find(SplitData.Trials(:,3)==3);
        DTrialIndex=find(SplitData.Trials(:,3)==4);
        if size(SingleUnitIndex,1)~=size(SplitData.SpikeCounts,1)
            display(DataID)
        end
        for itr1=1:size(SingleUnitIndex,1)
            tempUnitID{itr1,1}=[DataID '-Unit' num2str(SingleUnitIndex(itr1,1)*10+SingleUnitIndex(itr1,2))];
            tempHitTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(HitTrialIndex,:);
            tempFATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(FATrialIndex,:);
            tempCRTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(CRTrialIndex,:);
            
            tempAllTrialIndex{itr1,1}=SplitData.Trials;
            tempACTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ACTrialIndex,:);
            tempBDTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BDTrialIndex,:);
            tempADTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ADTrialIndex,:);
            tempBCTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BCTrialIndex,:);
            tempPairedTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(PairedTrialIndex,:);
            tempUnPairedTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(UnPairedTrialIndex,:);
            
            tempATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ATrialIndex,:);
            tempBTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BTrialIndex,:);
            tempCTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(CTrialIndex,:);
            tempDTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(DTrialIndex,:);
            tempShuffledATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ShuffledATrialIndex,:);
            tempShuffledBTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ShuffledBTrialIndex,:);
            
        end
        %AllTrialIndexForEachUnit=[AllTrialIndexForEachUnit;tempAllTrialIndex];
        SpikeWaveForm=[SpikeWaveForm;NewSpikes];
        AllUnitID=[AllUnitID;tempUnitID];
        AllTrialsFR=[AllTrialsFR;SplitData.SpikeCounts];
        
        AllHitTrialsFR=[AllHitTrialsFR;tempHitTrialsFR];
        AllFATrialsFR=[AllFATrialsFR;tempFATrialsFR];
        AllCRTrialsFR=[AllCRTrialsFR;tempCRTrialsFR];
        
        AllACTrialsFR=[AllACTrialsFR;tempACTrialsFR];
        AllBDTrialsFR=[AllBDTrialsFR;tempBDTrialsFR];
        AllADTrialsFR=[AllADTrialsFR;tempADTrialsFR];
        AllBCTrialsFR=[AllBCTrialsFR;tempBCTrialsFR];
        AllPairedTrialsFR=[AllPairedTrialsFR;tempPairedTrialsFR];
        AllUnPairedTrialsFR=[AllUnPairedTrialsFR;tempUnPairedTrialsFR];
        
        AllATrialsFR=[AllATrialsFR;tempATrialsFR];
        AllBTrialsFR=[AllBTrialsFR;tempBTrialsFR];
        AllCTrialsFR=[AllCTrialsFR;tempCTrialsFR];
        AllDTrialsFR=[AllDTrialsFR;tempDTrialsFR];
        AllShuffledATrialsFR=[AllShuffledATrialsFR;tempShuffledATrialsFR];
        AllShuffledBTrialsFR=[AllShuffledBTrialsFR;tempShuffledBTrialsFR];
    end
end

save(['PopulationNeuralActivity-20201118'],'AllUnitID','AllTrialsFR','AllACTrialsFR','AllBDTrialsFR','AllADTrialsFR','AllBCTrialsFR','AllPairedTrialsFR','AllUnPairedTrialsFR',...
    'AllATrialsFR','AllBTrialsFR','AllCTrialsFR','AllDTrialsFR','AllHitTrialsFR','AllFATrialsFR','AllCRTrialsFR','AllShuffledATrialsFR','AllShuffledBTrialsFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain',...
    'AllTrialIndexForEachUnit','AvergedWaveform','AveragedFR','Trough_to_Peak_Duration','AmplitudeRatio','Half_Amplitude_Duration',...
    'PerformanceForUnits','TrialsForUnit')
% save(['AllTrialFRandTrialTypeForAllUnits'],'AllTrialIndexForEachUnit','AllTrialsFR')

%% % get all units normalized FR in specific trials
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_AllTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['CrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitAllTrialNormalizedFR'],'png')
close all
AllUnitsAllTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllACTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_AllACTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex)
saveas(gcf,['CrossUnitACTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitACTrialNormalizedFR'],'png')
close all
AllUnitsACTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllADTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_AllADTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex)
saveas(gcf,['CrossUnitADTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitADTrialNormalizedFR'],'png')
close all
AllUnitsADTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBCTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_AllBCTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex)
saveas(gcf,['CrossUnitBCTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitBCTrialNormalizedFR'],'png')
close all
AllUnitsBCTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBDTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_AllBDTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex)
saveas(gcf,['CrossUnitBDTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitBDTrialNormalizedFR'],'png')
close all
AllUnitsBDTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')
%%
SpecificIndexForDiffFRofSampleAB=GetSortIndex(AllATrialsFR,AllBTrialsFR,TimeGain);
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllATrialsFR,AllUnitID,TimeGain);
SpecificIndex=SpecificIndexForDiffFRofSampleAB;
Index_AllATrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['CrossUnitATrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['CrossUnitATrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
AllUnitsATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_AllATrialFR;
Index_AllBTrialFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['CrossUnitBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['CrossUnitBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
AllUnitsBTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllCTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,[])
saveas(gcf,['CrossUnitCTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitCTrialNormalizedFR'],'png')
close all
AllUnitsCTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllDTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,[])
saveas(gcf,['CrossUnitDTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitDTrialNormalizedFR'],'png')
close all
AllUnitsDTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllHitTrialsFR,AllUnitID,TimeGain);
X=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,[]);
saveas(gcf,['CrossUnitHitTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitHitTrialNormalizedFR'],'png')
close all
AllUnitsHitTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllFATrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitFATrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitFATrialNormalizedFR'],'png')
close all
AllUnitsFATrialsNrmolizedFR=Target;
clear('Target','TargetNum')


[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllCRTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,[])
saveas(gcf,['CrossUnitCRTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitCRTrialNormalizedFR'],'png')
close all
AllUnitsCRTrialsNrmolizedFR=Target;
clear('Target','TargetNum')


[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllPairedTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitPariedTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitPairedTrialNormalizedFR'],'png')
close all
AllUnitsPairedTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllUnPairedTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,X);
saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'png')
close all
AllUnitsUnPairedTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledATrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledATrialsNrmolizedFR=Target;
clear('Target','TargetNum')
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledBTrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledBTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledCTrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledCTrialsNrmolizedFR=Target;
clear('Target','TargetNum')
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledDTrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledDTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

save(['NormalizedPopulationNeuralActivity'],'AllUnitID','AllUnitsAllTrialsNrmolizedFR','AllUnitsACTrialsNrmolizedFR','AllUnitsADTrialsNrmolizedFR','AllUnitsBCTrialsNrmolizedFR',...
    'AllUnitsBDTrialsNrmolizedFR','AllUnitsATrialsNrmolizedFR','AllUnitsBTrialsNrmolizedFR','AllUnitsCTrialsNrmolizedFR','AllUnitsDTrialsNrmolizedFR','AllUnitsHitTrialsNrmolizedFR',...
    'AllUnitsFATrialsNrmolizedFR','AllUnitsCRTrialsNrmolizedFR','AllUnitsShuffledATrialsNrmolizedFR','AllUnitsShuffledBTrialsNrmolizedFR',...
    'AllUnitsShuffledATrialsNrmolizedFR','AllUnitsShuffledBTrialsNrmolizedFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain')

%% plot sample selectivity for each neuron (using neural firing rate)
PlotSelectivity(AllPairedTrialsFR,AllUnPairedTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitPaired&UnPairedTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitPaired&UnPairedTrialSelectivy'],'png')
close all
PlotSelectivity(AllCTrialsFR,AllDTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitTestOdorSelectivy'],'fig')
saveas(gcf,['PopulationUnitTestOdorSelectivy'],'png')
close all
PlotSelectivity(AllATrialsFR,AllBTrialsFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
PlotSelectivity(AllATrialsFR,AllBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)

saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'png')
% print(gcf,'-depsc',['PopulationUnitSampleTrialSelectivyDay4','.eps'])
close all



PlotSelectivity(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOffShuffledAData,LaserOffShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'png')
close all


AllFAAndCRTrialFR=[];
for tempi=1:size(AllUnitID,1)
    AllFAAndCRTrialFR{tempi,1}=[AllFATrialsFR{tempi,1};AllCRTrialsFR{tempi,1}];
end

PlotSelectivity(AllHitTrialsFR,AllFAAndCRTrialFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitRewardTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitRewardTrialSelectivy'],'png')
% print(gcf,'-depsc',['PopulationUnitRewardTrialSelectivyDay4','.eps'])
close all

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PlotSelectivityCurveCrossUnits(AllATrialsFR,AllBTrialsFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'png')
close all
PlotSelectivityCurveCrossUnits(AllHitTrialsFR,AllFAAndCRTrialFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'png')
close all




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PlotPopulationUnitsAverageFRofSpecificTrials(AllTrialsFR,{},FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitAllTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitAllTrialAverageFR'],'png')
close all
% print(gcf,'-depsc',['CrossUnitAllTrialAverageFR','.eps'])
PlotPopulationUnitsAverageFRofSpecificTrials(AllACTrialsFR,AllADTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitAC&ADTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitAC&ADTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllBCTrialsFR,AllBDTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitBC&BDTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitBC&BDTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllATrialsFR,AllBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitDifferentSampleTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitDifferentSampleTrialAverageFR'],'png')
close all
PlotPopulationUnitsAverageFRofSpecificTrials(AllCTrialsFR,AllDTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitDifferentTestTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitDifferentTestTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllPairedTrialsFR,AllUnPairedTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitPaired&UnPairedTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitPaired&UnPairedTrialAverageFR'],'png')
close all
PlotPopulationUnitsAverageFRofSpecificTrials(AllHitTrialsFR,AllFAAndCRTrialFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitHit&FA&CRTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitHit&FA&CRTrialAverageFR'],'png')
close all

%% %%%%%%%%%%%%%%%%%%%%%%%%%%
if PlotSingleUnitSelectivity==1
    pDelayPerSecond=ones(size(AllUnitID,1),1);
    for itr=1:size(AllUnitID,1)
        SelectivityData=abs((mean(AllATrialsFR{itr,1},1)-mean(AllBTrialsFR{itr,1},1)))./(mean(AllATrialsFR{itr,1},1)+mean(AllBTrialsFR{itr,1},1));
        ShuffledData=abs(mean(AllShuffledATrialsFR{itr,1},1)-mean(AllShuffledBTrialsFR{itr,1},1))./(mean(AllShuffledATrialsFR{itr,1},1)+mean(AllShuffledBTrialsFR{itr,1},1));
        
        %         YMAX=max([SelectivityData ShuffledData])*1.5;
        %         %
        %             plot([-2:0.1:floor(DPALen)-2],smooth(SelectivityData,10),'r','LineWidth',1.5)
        %             hold on
        %             plot([-2:0.1:floor(DPALen)-2],smooth(ShuffledData,10),'k','LineWidth',1.5)
        % %             tempx1=smooth(mean(SelectivityData,1)-std(SelectivityData,0,1)/sqrt(size(SelectivityData,1)-1),10);
        %             tempx2=smooth(mean(SelectivityData,1)+std(SelectivityData,0,1)/sqrt(size(SelectivityData,1)-1),10);
        %             X=[-2:0.1:floor(DPALen)-2];
        %             fill([X,fliplr(X)],[tempx1',fliplr(tempx2')],...
        %                 [1 0 0],'edgecolor','none','FaceAlpha',0.3)
        %             tempy1=smooth(mean(ShuffledData,1)-std(ShuffledData,0,1)/sqrt(size(ShuffledData,1)-1),10);
        %             tempy2=smooth(mean(ShuffledData,1)+std(ShuffledData,0,1)/sqrt(size(ShuffledData,1)-1),10);
        %             fill([X,fliplr(X)],[tempy1',fliplr(tempy2')],...
        %                 [0 0 0],'edgecolor','none','FaceAlpha',0.3)
        %             set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2])
        %             h1=area([0 FirstOdorLen],YMAX*[1 1],-1);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
        %             hold on
        %             h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],YMAX*[1 1],-1);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
        %             h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],YMAX*[1 1],-1);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
        %             box off
        %             xlabel('Time (Sec)');% Create xlabel
        %             ylabel('Selectivity');% Create ylabel
        %
        for itrx=1:6% 1s bin; itrx:delay�ĵ�itrx��
            a=SelectivityData(1,(itrx+2)*10+1:(itrx+3)*10);
            b=ShuffledData(1,(itrx+2)*10+1:(itrx+3)*10);
            pDelayPerSecond(itr,itrx)=ranksum(a',b');
            %                     if ps(itr,itrx)<0.05
            %                         plot(itrx+6.5,YMAX,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','*','LineStyle','none');
            %                         hold on
            %                     end
        end
        pDelaySampleSelectivity(itr,1)=ranksum(SelectivityData(1,31:90)',ShuffledData(1,31:90)');
        %             saveas(gcf,[AllUnitID{itr,1} '-SampleSelectivity'],'fig')
        %             saveas(gcf,[AllUnitID{itr,1} '-SampleSelectivity'],'png')
        %             close all
        %
        
    end
    %% neurons averaged FR distribution
    FR=cellfun(@mean,AllTrialsFR,'UniformOutput',false);
    AllFR=10*cell2mat(FR);
    NormolizedFR=(AllFR-mean(mean(AllFR(:,10:19)),2))/std(mean(AllFR(:,10:19),2));
    
    
    
    MeanFR=cellfun(@mean,FR,'UniformOutput',false);
    tempMeanFR=cell2mat(MeanFR);
    AVGFR=10*tempMeanFR;
    FRNum=[];
    for itr=1:10
        FRNum(itr)=length(find(AVGFR<itr*10&AVGFR>=(itr-1)*10));
    end
    ssindex=zeros(178,1);
    for itr=1:178
        if ps(itr)<0.05
            ssindex(itr)=1;
        end
        
    end
    
    NormalizedFR=cellfun(@mean,AllTrialsFR,'UniformOutput',false);
    
    %% %%%%%%%% ���� maximum value of delay activity ����
    tempDecsendNormFRForAllUnits = sortrows([mean(AllUnitsAllTrialsNrmolizedFR(:,31:90),2) AllUnitsAllTrialsNrmolizedFR],-1);
    DecsendNormFRForAllUnits = tempDecsendNormFRForAllUnits(:,2:end);
    
end

%% delay activity, sample, test, reward
AllUnitsMeanFRCrossTrial=cell2mat(cellfun(@mean,AllTrialsFR,'UniformOutput',false));
BaselineActivity=AllUnitsMeanFRCrossTrial(:,9:18);% 1s
DelayActivity=AllUnitsMeanFRCrossTrial(:,30:89);% 1s
AllUnitMeanFRForATrial=cell2mat(cellfun(@mean,AllATrialsFR,'UniformOutput',false));
Sample1MeanFR=AllUnitMeanFRForATrial(:,20:29);
AllUnitMeanFRForBTrial=cell2mat(cellfun(@mean,AllBTrialsFR,'UniformOutput',false));
Sample2MeanFR=AllUnitMeanFRForBTrial(:,20:29);
AllUnitMeanFRForCTrial=cell2mat(cellfun(@mean,AllCTrialsFR,'UniformOutput',false));
Test1MeanFR=AllUnitMeanFRForCTrial(:,90:99);
AllUnitMeanFRForDTrial=cell2mat(cellfun(@mean,AllDTrialsFR,'UniformOutput',false));
Test2MeanFR=AllUnitMeanFRForDTrial(:,90:99);
AllUnitMeanFRForHitTrial=cell2mat(cellfun(@mean,AllHitTrialsFR,'UniformOutput',false));
RewardMeanFR=AllUnitMeanFRForHitTrial(:,110:119);
AllUnitMeanFRForUnpairedTrial=cell2mat(cellfun(@mean,AllUnPairedTrialsFR,'UniformOutput',false));
NoRewardMeanFR=AllUnitMeanFRForUnpairedTrial(:,110:119);
% delay Activity
Delay=6;
pDelay=zeros(size(AllUnitsMeanFRCrossTrial,1),Delay);
pSample=zeros(size(AllUnitsMeanFRCrossTrial,1),1);
pTest=zeros(size(AllUnitsMeanFRCrossTrial,1),1);
pReward=zeros(size(AllUnitsMeanFRCrossTrial,1),1);

for itr3 = 1:size(AllUnitsMeanFRCrossTrial,1)
    pDelay(itr3,1)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,1:10)');
    pDelay(itr3,2)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,11:20)');
    pDelay(itr3,3)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,21:30)');
    pDelay(itr3,4)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,31:40)');
    pDelay(itr3,5)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,41:50)');
    pDelay(itr3,6)=ranksum(BaselineActivity(itr3,:)',DelayActivity(itr3,51:60)');
    pSample(itr3,1)=ranksum(Sample1MeanFR(itr3,:)',Sample2MeanFR(itr3,:)');
    pTest(itr3,1)=ranksum(Test1MeanFR(itr3,:)',Test2MeanFR(itr3,:)');
    pReward(itr3,1)=ranksum(RewardMeanFR(itr3,:)',NoRewardMeanFR(itr3,:)');
    %     pReward(itr3,2)=ranksum(RewardMeanFR(itr3,:)',NoRewardMeanFR(itr3,:)');
end

% plot delay
for itr4=1:Delay
    UnitNumForDelay(1,itr4)=length(find(pDelay(:,itr4)<0.05));
end
UnitNumForSample=length(find(pSample(:,1)<0.05));
UnitNumForTest=length(find(pTest(:,1)<0.05));
UnitNumForReward=length(find(pReward(:,1)<0.05));
save(['PopulationSelectivity'],'pDelay','pSample','pTest','pReward','UnitNumForDelay','UnitNumForSample','UnitNumForTest','UnitNumForReward')

bar(1:6,UnitNumForDelay./size(AllUnitsMeanFRCrossTrial,1))
saveas(gcf,'PercentageofUnitsWithDealyActivity','fig')
saveas(gcf,'PercentageofUnitsWithDealyActivity','png')
close all

bar(1:3,[UnitNumForSample./size(AllUnitsMeanFRCrossTrial,1) UnitNumForTest./size(AllUnitsMeanFRCrossTrial,1) UnitNumForReward./size(AllUnitsMeanFRCrossTrial,1)])
saveas(gcf,'PercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','fig')
saveas(gcf,'PercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','png')
close all


%% %%%%%%%%%%%%%%%%%%
RemoveIndex=find(cell2mat(cellfun(@(x) size(x,1),AllBTrialsFR,'un',0))<70);
AllUnitID(RemoveIndex)=[];AllATrialsFR(RemoveIndex)=[];AllBTrialsFR(RemoveIndex)=[];AllShuffledATrialsFR(RemoveIndex)=[];AllShuffledBTrialsFR(RemoveIndex)=[];
Signifficance=NaN*ones(size(AllUnitID,1),201);
RealData=cellfun(@(x,y) (x(1:70,:)-y(1:70,:)),AllATrialsFR,AllBTrialsFR,'un',0);
% tempRealData=cellfun(@(x) smooth(x,10), RealData,'un',0);
ControlData=cellfun(@(x,y) (x(1:70,:)-y(1:70,:)),AllShuffledATrialsFR,AllShuffledBTrialsFR,'un',0);
% tempControlData=cellfun(@(x) smooth(x,10), ControlData,'un',0);
%%%change bin=100 to Bin=1000,sliding window=100;
tempRealData=[];tempControlData=[];
for i=1:1248%unit
    for j = 1:70%trial
        tempRealData{i,1}(j,:)=10*smooth(RealData{i,1}(j,:),10)';
        tempControlData{i,1}(j,:)=10*smooth(ControlData{i,1}(j,:),10)';
    end
end
%%%%%%p
p=ones(1234,201);
for iUnit= 1:1248
    for iBin =1 : 201
        p(iUnit,iBin)=ranksum(tempRealData{iUnit,1}(:,iBin),tempControlData{iUnit,1}(:,iBin));
    end
end
%%% selctive unit ID, from sample odor start to delay end
SelectiveUnitID=[];
for i =1 :1234
    tempIndex(i,1)=length(find(p(i,21:90)<0.005));% 0.05*10
end
SelectiveUnitIndex=find(tempIndex>0);
SelectiveUnitID=AllUnitID(SelectiveUnitIndex);

SelectiveUnitAllATrialsFR=AllATrialsFR(SelectiveUnitIndex);SelectiveUnitAllBTrialsFR=AllBTrialsFR(SelectiveUnitIndex);
SelectiveDAUnitAllATrialsFR=SelectiveUnitAllATrialsFR(SelectiveDAUnitIndex);SelectiveDAUnitAllBTrialsFR=SelectiveUnitAllBTrialsFR(SelectiveDAUnitIndex);

PlotSelectivityHeatMapForEveryUnit(SelectiveDAUnitAllATrialsFR,SelectiveDAUnitAllBTrialsFR,AllShuffledATrialsFR(SelectiveUnitIndex),AllShuffledBTrialsFR(SelectiveUnitIndex),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,SelectiveDAUnitID,TimeGain);


TaggedDAUnitID=importdata('LaserTaggedDAUnitID.txt');
SelectiveDAUnitID=SelectiveUnitID([43;44;147;151;153;175;181;189;194;214;228;269;171],1);
SelectiveDAUnitIndex=[43;44;147;151;153;175;181;189;194;214;228;269;171];
for i=1:23
    temp=[];
    temp=find(strcmp(SelectiveUnitID, TaggedDAUnitID(i)));
    if isempty(temp)
        SelectiveTaggedDAUnitIndex(i,1)= 0;
    else
        SelectiveTaggedDAUnitIndex(i,1)= temp;
    end
end
temp=find(SelectiveTaggedDAUnitIndex==0);
SelectiveTaggedDAUnitIndex(temp)=[];





h1=area([0 FirstOdorLen],length(1)*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(1)*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(1)*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',1,'LineStyle','none')% plot areas of color %water
box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Firing Rate');% Create ylabel
X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
fill([X,fliplr(X)],[smooth(mean(AllTaggedDAUnitsAllTrialsNrmolizedFR,1)-std(AllTaggedDAUnitsAllTrialsNrmolizedFR,0,1)/sqrt(size(AllTaggedDAUnitsAllTrialsNrmolizedFR,1)-1),3)',smooth(fliplr(mean(AllTaggedDAUnitsAllTrialsNrmolizedFR,1)+std(AllTaggedDAUnitsAllTrialsNrmolizedFR,0,1)/sqrt(size(AllTaggedDAUnitsAllTrialsNrmolizedFR,1)-1)),3)'],...
    'k','edgecolor','none','FaceAlpha',0.5)
hold on
plot(X,smooth(mean(AllTaggedDAUnitsAllTrialsNrmolizedFR,1),3)','k','LineWidth',1.5)
YMin1=floor(min(TimeGain*mean(SpikeCounts,1)))-5;
YMax1=ceil(max(TimeGain*mean(SpikeCounts,1)))+5;
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2],'YLim',[YMin1,YMax1])
