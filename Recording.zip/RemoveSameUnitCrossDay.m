%% This code is used to identify same unit cross day
% get averaged waveforms of all unit

% to get how many mice were record
tempMiceID = cellfun(@(x) x(24:25), AllUnitID, 'un', 0);
tempMiceID = cell2mat(tempMiceID);
tempMiceID = str2num(tempMiceID);
MiceID = unique(tempMiceID);
for MiceNum = 1 : size(MiceID,1)
    UnitIndex{MiceNum,1} = find(tempMiceID==MiceID(MiceNum));
end

tempMeanAllTrialsFR = cellfun(@mean, AllTrialsFR, 'un', 0);
MeanAllTrialsFR = cell2mat(tempMeanAllTrialsFR);

AllCompareUnitID = {};
AllCorrCoeff_FR = {};
AllCorrCoeff_Waveform = {};
AllCorrCoeff_MaxWaveform = {};
for MiceNum = 1: size(MiceID,1)
    CompareUnitID = []; CorrCoeff_FR = []; CorrCoeff_Waveform=[]; CorrCoeff_MaxWaveform=[];
    for i = UnitIndex{MiceNum}(1,1) : UnitIndex{MiceNum}(end-1,1)
        for j = i + 1 :UnitIndex{MiceNum}(end,1)
            tempCompareUnitID = [i j];
            CompareUnitID =[CompareUnitID;tempCompareUnitID];
            tempCorrCoeff_FR = corr2 (MeanAllTrialsFR(i,:), MeanAllTrialsFR(j,:));
            tempCorrCoeff_Waveform = corr2 (AveagedWaveform(i,:), AveagedWaveform(j,:));
            tempCorrCoeff_MaxWaveform = corr2 (AllUnitMaxWaveform(i,:), AllUnitMaxWaveform(j,:));
            CorrCoeff_FR = [CorrCoeff_FR; tempCorrCoeff_FR];
            CorrCoeff_Waveform = [CorrCoeff_Waveform; tempCorrCoeff_Waveform];
            CorrCoeff_MaxWaveform = [CorrCoeff_MaxWaveform; tempCorrCoeff_MaxWaveform];
        end
        
    end
    AllCompareUnitID{MiceNum,1} = CompareUnitID;
    AllCorrCoeff_FR{MiceNum,1} = CorrCoeff_FR;
    AllCorrCoeff_Waveform{MiceNum,1} = CorrCoeff_Waveform;
    AllCorrCoeff_MaxWaveform{MiceNum,1} = CorrCoeff_MaxWaveform;
end


for itr = 1: size(MiceID,1)
    SameUnitIndex=[];
    SameUnitIndex = find(AllCorrCoeff_FR{itr,1}>0.9 & AllCorrCoeff_Waveform{itr,1}>0.9);
    SameUnitPair{itr,1} = AllCompareUnitID{itr,1}(SameUnitIndex,:);
end
tempSameUnitID=cell2mat(SameUnitPair);
SameUnitID = unique(tempSameUnitID(:,2));
%%
%%
UnitWaveproperty.Trough_to_Peak = Trough_to_Peak;
UnitWaveproperty.Half_Amplitude_Duration = Half_Amplitude_Duration;

save(['LaserOn&Off-PopulationNeuralActivity_RemoveRepeatedUnit'],'AllUnitID','AllTrialsFR','LaserOnAllTrialsFR','LaserOffAllTrialsFR','LaserOnAllHitTrialsFR',...
    'LaserOnAllFATrialsFR','LaserOnAllCRTrialsFR','LaserOnAllACTrialsFR','LaserOnAllBDTrialsFR','LaserOnAllADTrialsFR','LaserOnAllBCTrialsFR',...
    'LaserOnAllPairedTrialsFR','LaserOnAllUnPairedTrialsFR','LaserOnAllATrialsFR','LaserOnAllBTrialsFR','LaserOnAllCTrialsFR','LaserOnAllDTrialsFR',...
    'LaserOnAllShuffledATrialsFR','LaserOnAllShuffledBTrialsFR','LaserOffAllHitTrialsFR','LaserOffAllFATrialsFR','LaserOffAllCRTrialsFR',...
    'LaserOffAllACTrialsFR','LaserOffAllBDTrialsFR','LaserOffAllADTrialsFR','LaserOffAllBCTrialsFR','LaserOffAllPairedTrialsFR',...
    'LaserOffAllUnPairedTrialsFR','LaserOffAllATrialsFR','LaserOffAllBTrialsFR','LaserOffAllCTrialsFR','LaserOffAllDTrialsFR',...
    'LaserOffAllShuffledATrialsFR','LaserOffAllShuffledBTrialsFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain','LaserEffect',...
    'UnitWaveproperty','AveragedFR','AveagedWaveform','AllUnitMaxWaveform')




