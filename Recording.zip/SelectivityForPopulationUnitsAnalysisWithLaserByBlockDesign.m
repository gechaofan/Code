%% delay activity, sample, test, reward
%%%%%%%%%%%%%%%%%%%%%%%%%%Laser On Trials
LaserOnAllUnitsMeanFRCrossTrial=cell2mat(cellfun(@mean,LaserOnAllTrialsFR,'UniformOutput',false));
LaserOnBaselineActivity=LaserOnAllUnitsMeanFRCrossTrial(:,9:18);% 1s
LaserOnDelayActivity=LaserOnAllUnitsMeanFRCrossTrial(:,30:89);% 1s
LaserOnAllUnitMeanFRForATrial=cell2mat(cellfun(@mean,LaserOnAllATrialsFR,'UniformOutput',false));
LaserOnSample1MeanFR=LaserOnAllUnitMeanFRForATrial(:,20:29);
LaserOnAllUnitMeanFRForBTrial=cell2mat(cellfun(@mean,LaserOnAllBTrialsFR,'UniformOutput',false));
LaserOnSample2MeanFR=LaserOnAllUnitMeanFRForBTrial(:,20:29);
LaserOnAllUnitMeanFRForCTrial=cell2mat(cellfun(@mean,LaserOnAllCTrialsFR,'UniformOutput',false));
LaserOnTest1MeanFR=LaserOnAllUnitMeanFRForCTrial(:,90:99);
LaserOnAllUnitMeanFRForDTrial=cell2mat(cellfun(@mean,LaserOnAllDTrialsFR,'UniformOutput',false));
LaserOnTest2MeanFR=LaserOnAllUnitMeanFRForDTrial(:,90:99);
LaserOnAllUnitMeanFRForHitTrial=cell2mat(cellfun(@mean,LaserOnAllHitTrialsFR,'UniformOutput',false));
LaserOnRewardMeanFR=LaserOnAllUnitMeanFRForHitTrial(:,110:119);
LaserOnAllUnitMeanFRForUnpairedTrial=cell2mat(cellfun(@mean,LaserOnAllUnPairedTrialsFR,'UniformOutput',false));
LaserOnNoRewardMeanFR=LaserOnAllUnitMeanFRForUnpairedTrial(:,110:119);
%%%%%%%% Laser Off Trials
LaserOffAllUnitsMeanFRCrossTrial=cell2mat(cellfun(@mean,LaserOffAllTrialsFR,'UniformOutput',false));
LaserOffBaselineActivity=LaserOffAllUnitsMeanFRCrossTrial(:,9:18);% 1s
LaserOffDelayActivity=LaserOffAllUnitsMeanFRCrossTrial(:,30:89);% 1s
LaserOffAllUnitMeanFRForATrial=cell2mat(cellfun(@mean,LaserOffAllATrialsFR,'UniformOutput',false));
LaserOffSample1MeanFR=LaserOffAllUnitMeanFRForATrial(:,20:29);
LaserOffAllUnitMeanFRForBTrial=cell2mat(cellfun(@mean,LaserOffAllBTrialsFR,'UniformOutput',false));
LaserOffSample2MeanFR=LaserOffAllUnitMeanFRForBTrial(:,20:29);
LaserOffAllUnitMeanFRForCTrial=cell2mat(cellfun(@mean,LaserOffAllCTrialsFR,'UniformOutput',false));
LaserOffTest1MeanFR=LaserOffAllUnitMeanFRForCTrial(:,90:99);
LaserOffAllUnitMeanFRForDTrial=cell2mat(cellfun(@mean,LaserOffAllDTrialsFR,'UniformOutput',false));
LaserOffTest2MeanFR=LaserOffAllUnitMeanFRForDTrial(:,90:99);
LaserOffAllUnitMeanFRForHitTrial=cell2mat(cellfun(@mean,LaserOffAllHitTrialsFR,'UniformOutput',false));
LaserOffRewardMeanFR=LaserOffAllUnitMeanFRForHitTrial(:,110:119);
LaserOffAllUnitMeanFRForUnpairedTrial=cell2mat(cellfun(@mean,LaserOffAllUnPairedTrialsFR,'UniformOutput',false));
LaserOffNoRewardMeanFR=LaserOffAllUnitMeanFRForUnpairedTrial(:,110:119);

Delay=6;
LaserOnpDelay=zeros(size(LaserOnAllUnitsMeanFRCrossTrial,1),Delay);
LaserOnpSample=zeros(size(LaserOnAllUnitsMeanFRCrossTrial,1),1);
LaserOnpTest=zeros(size(LaserOnAllUnitsMeanFRCrossTrial,1),1);
LaserOnpReward=zeros(size(LaserOnAllUnitsMeanFRCrossTrial,1),1);
LaserOffpDelay=zeros(size(LaserOffAllUnitsMeanFRCrossTrial,1),Delay);
LaserOffpSample=zeros(size(LaserOffAllUnitsMeanFRCrossTrial,1),1);
LaserOffpTest=zeros(size(LaserOffAllUnitsMeanFRCrossTrial,1),1);
LaserOffpReward=zeros(size(LaserOffAllUnitsMeanFRCrossTrial,1),1);

for itr3 = 1:size(AllUnitID,1)
    LaserOnpDelay(itr3,1)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,1:10)');
    LaserOnpDelay(itr3,2)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,11:20)');
    LaserOnpDelay(itr3,3)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,21:30)');
    LaserOnpDelay(itr3,4)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,31:40)');
    LaserOnpDelay(itr3,5)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,41:50)');
    LaserOnpDelay(itr3,6)=ranksum(LaserOnBaselineActivity(itr3,:)',LaserOnDelayActivity(itr3,51:60)');
    LaserOnpSample(itr3,1)=ranksum(LaserOnSample1MeanFR(itr3,:)',LaserOnSample2MeanFR(itr3,:)');
    LaserOnpTest(itr3,1)=ranksum(LaserOnTest1MeanFR(itr3,:)',LaserOnTest2MeanFR(itr3,:)');
    LaserOnpReward(itr3,1)=ranksum(LaserOnRewardMeanFR(itr3,:)',LaserOnNoRewardMeanFR(itr3,:)');
   
    LaserOffpDelay(itr3,1)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,1:10)');
    LaserOffpDelay(itr3,2)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,11:20)');
    LaserOffpDelay(itr3,3)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,21:30)');
    LaserOffpDelay(itr3,4)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,31:40)');
    LaserOffpDelay(itr3,5)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,41:50)');
    LaserOffpDelay(itr3,6)=ranksum(LaserOffBaselineActivity(itr3,:)',LaserOffDelayActivity(itr3,51:60)');
    LaserOffpSample(itr3,1)=ranksum(LaserOffSample1MeanFR(itr3,:)',LaserOffSample2MeanFR(itr3,:)');
    LaserOffpTest(itr3,1)=ranksum(LaserOffTest1MeanFR(itr3,:)',LaserOffTest2MeanFR(itr3,:)');
    LaserOffpReward(itr3,1)=ranksum(LaserOffRewardMeanFR(itr3,:)',LaserOffNoRewardMeanFR(itr3,:)');
end

% plot delay
for itr4=1:Delay
    LaserOnUnitNumForDelay(1,itr4)=length(find(LaserOnpDelay(:,itr4)<0.05));
    LaserOffUnitNumForDelay(1,itr4)=length(find(LaserOffpDelay(:,itr4)<0.05));
end
LaserOnUnitNumForSample=length(find(LaserOnpSample(:,1)<0.05));
LaserOnUnitNumForTest=length(find(LaserOnpTest(:,1)<0.05));
LaserOnUnitNumForReward=length(find(LaserOnpReward(:,1)<0.05));
LaserOffUnitNumForSample=length(find(LaserOffpSample(:,1)<0.05));
LaserOffUnitNumForTest=length(find(LaserOffpTest(:,1)<0.05));
LaserOffUnitNumForReward=length(find(LaserOffpReward(:,1)<0.05));
%% persisitant delay activity
LaserOnUnitNumForDelay_Constant(1,1)=length(find(LaserOnpDelay(:,1)<=0.05));
LaserOnUnitNumForDelay_Constant(2,1)=length(find(LaserOnpDelay(:,1)<=0.05&LaserOnpDelay(:,2)<=0.05));
LaserOnUnitNumForDelay_Constant(3,1)=length(find(LaserOnpDelay(:,1)<=0.05&LaserOnpDelay(:,2)<=0.05&LaserOnpDelay(:,3)<=0.05));
LaserOnUnitNumForDelay_Constant(4,1)=length(find(LaserOnpDelay(:,1)<=0.05&LaserOnpDelay(:,2)<=0.05&LaserOnpDelay(:,3)<=0.05&LaserOnpDelay(:,4)<=0.05));
LaserOnUnitNumForDelay_Constant(5,1)=length(find(LaserOnpDelay(:,1)<=0.05&LaserOnpDelay(:,2)<=0.05&LaserOnpDelay(:,3)<=0.05&LaserOnpDelay(:,4)<=0.05&LaserOnpDelay(:,5)<=0.05));
LaserOnUnitNumForDelay_Constant(6,1)=length(find(LaserOnpDelay(:,1)<=0.05&LaserOnpDelay(:,2)<=0.05&LaserOnpDelay(:,3)<=0.05&LaserOnpDelay(:,4)<=0.05&LaserOnpDelay(:,5)<=0.05&LaserOnpDelay(:,6)<=0.05));

LaserOffUnitNumForDelay_Constant(1,1)=length(find(LaserOffpDelay(:,1)<=0.05));
LaserOffUnitNumForDelay_Constant(2,1)=length(find(LaserOffpDelay(:,1)<=0.05&LaserOffpDelay(:,2)<=0.05));
LaserOffUnitNumForDelay_Constant(3,1)=length(find(LaserOffpDelay(:,1)<=0.05&LaserOffpDelay(:,2)<=0.05&LaserOffpDelay(:,3)<=0.05));
LaserOffUnitNumForDelay_Constant(4,1)=length(find(LaserOffpDelay(:,1)<=0.05&LaserOffpDelay(:,2)<=0.05&LaserOffpDelay(:,3)<=0.05&LaserOffpDelay(:,4)<=0.05));
LaserOffUnitNumForDelay_Constant(5,1)=length(find(LaserOffpDelay(:,1)<=0.05&LaserOffpDelay(:,2)<=0.05&LaserOffpDelay(:,3)<=0.05&LaserOffpDelay(:,4)<=0.05&LaserOffpDelay(:,5)<=0.05));
LaserOffUnitNumForDelay_Constant(6,1)=length(find(LaserOffpDelay(:,1)<=0.05&LaserOffpDelay(:,2)<=0.05&LaserOffpDelay(:,3)<=0.05&LaserOffpDelay(:,4)<=0.05&LaserOffpDelay(:,5)<=0.05&LaserOffpDelay(:,6)<=0.05));

save(['LaserOn&OffPopulationSelectivity'],'LaserOnpDelay','LaserOnpSample','LaserOnpTest','LaserOnpReward','LaserOnUnitNumForDelay',...
    'LaserOnUnitNumForSample','LaserOnUnitNumForTest','LaserOnUnitNumForReward','LaserOnUnitNumForDelay_Constant',...
    'LaserOffpDelay','LaserOffpSample','LaserOffpTest','LaserOffpReward','LaserOffUnitNumForDelay','LaserOffUnitNumForSample',...
    'LaserOffUnitNumForTest','LaserOffUnitNumForReward','LaserOffUnitNumForDelay_Constant')

LaserOffUnitsPercentage_EverySec=LaserOffUnitNumForDelay./size(LaserOffAllUnitsMeanFRCrossTrial,1);
LaserOnUnitsPercentage_EverySec=LaserOnUnitNumForDelay./size(LaserOnAllUnitsMeanFRCrossTrial,1);
LaserOffUnitsPercentage_ConstantSec=LaserOffUnitNumForDelay_Constant./size(LaserOffAllUnitsMeanFRCrossTrial,1);
LaserOnUnitsPercentage_ConstantSec=LaserOnUnitNumForDelay_Constant./size(LaserOnAllUnitsMeanFRCrossTrial,1);

bar1=bar([LaserOffUnitsPercentage_EverySec' LaserOnUnitsPercentage_EverySec']);
box off
set(bar1(2),'FaceColor',[0 0 1]);
set(bar1(1),'FaceColor',[0 0 0]);
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','fig')
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','png')
close all

bar2=bar([LaserOffUnitsPercentage_ConstantSec LaserOnUnitsPercentage_ConstantSec]);
box off
set(bar2(2),'FaceColor',[0 0 1]);
set(bar2(1),'FaceColor',[0 0 0]);
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForConstantSecond','fig')
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForConstantSecond','png')
close all



bar(1:3,[LaserOnUnitNumForSample./size(LaserOnAllUnitsMeanFRCrossTrial,1) LaserOnUnitNumForTest./size(LaserOnAllUnitsMeanFRCrossTrial,1) LaserOnUnitNumForReward./size(LaserOnAllUnitsMeanFRCrossTrial,1)])
saveas(gcf,'LaserOnPercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','fig')
saveas(gcf,'LaserOnPercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','png')
close all
bar(1:3,[LaserOffUnitNumForSample./size(LaserOffAllUnitsMeanFRCrossTrial,1) LaserOffUnitNumForTest./size(LaserOffAllUnitsMeanFRCrossTrial,1) LaserOffUnitNumForReward./size(LaserOffAllUnitsMeanFRCrossTrial,1)])
saveas(gcf,'LaserOnPercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','fig')
saveas(gcf,'LaserOnPercentageofUnitsWithSelectivityForTaskEvent-Hit&UnPaired','png')
close all
%% %%%% Laser effect 
for itri = 1:size(AllUnitID,1)
   for itrj = 1: Delay-1 
%        LaserOnOverLaserOffFR(itri, itrj) = mean(mean(LaserOnAllTrialsFR{itri,1}(:,30+(itrj-1)*10:30+itrj*10),1))/mean(mean(LaserOffAllTrialsFR{itri,1}(:,30+(itrj-1)*10:30+itrj*10),1));  
       MeanLaserOnFR(itri, itrj)=10*mean(mean(LaserOnAllTrialsFR{itri,1}(:,35+(itrj-1)*10:35+itrj*10),1));
       MeanLaserOffFR(itri, itrj)=10*mean(mean(LaserOffAllTrialsFR{itri,1}(:,35+(itrj-1)*10:35+itrj*10),1));
   end    
end

for i=1 : 5
    figure ('color', [1 1 1])
    color(jet);
    x=[0:70];y=x;plot(x,y,'k')
    hold on
    scatter(MeanLaserOffFR(:,i),MeanLaserOnFR(:,i),'b')
    xlabel('Laser Off FR (Hz)');ylabel('Laser On FR (Hz)');
    box off
    Title=num2str(i);
    saveas(gcf,['LaserEffectOnFiringRate_Delay' Title],'fig')
    saveas(gcf,['LaserEffectOnFiringRate_Delay' Title],'png')
    close all
end 
