%%%%%%%% this code is for split recording data of many mice in one file;
%% refer to offline sorter
% TETSPK : 1~32;
% TETSPKC : 33~ 48; 
% TETFP : 49~64; 
%%
CurrentPath=pwd;
% WaveFormSampleNum=58;%TDT=34,Plexon=58, HuPlexon=54;waveform length 1450um,325us prethreshold
% TrialNumPerBlock=20;%define the trial number in one session0..
TimeGain=10;%define the bin size
% SplitRawData=1;
% TimestampFrequency=40000;
DataType=1;%1 for .pl2 file; 2 for .plx file;
MouseNo=1;


%% %% construct task event and split spike information

SpikeFileName=ls ('*txt');% get file name of spike data
data=importdata(SpikeFileName);
if isstruct(data)
    data=data.data;
end

if DataType==1  %%%%%%%%%%%.pl2 file
    RawdataFileName=ls ('*.pl2');% get file name of Raw recording data;
    pl2 = PL2GetFileIndex(RawdataFileName);% list pl2 file information
    % PL2Print(pl2.EventChannels);% Print Information of EventChannels
    %TimestampFrequency=pl2.TimestampFrequency;% Plexon,40000
    [event.Laser] = PL2EventTs(RawdataFileName,'EVT09');
%     event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts
    [event.Lick] = PL2EventTs(RawdataFileName,'EVT06');
    [event.OdorAC] = PL2EventTs(RawdataFileName,'EVT07');
    [event.OdorBD] = PL2EventTs(RawdataFileName,'EVT08');
    RawSpikes=data(data(:,2)>0,:);
else %%%%%%%%%%%%% .plx file
    EventFileName=ls ('*nex');
    [nexFile]=readNexFile(EventFileName);
    if MouseNo==1
        Lick=nexFile.events{1,1}.timestamps;%lick event
        OdorAC=nexFile.events{2,1}.timestamps;%odorant A/C
        OdorBD=nexFile.events{3,1}.timestamps;%odorant B/D
        if strcmp('EVT04',nexFile.events{4,1}.name)
            Laser=nexFile.events{4,1}.timestamps;
        else
            Laser=[];
        end
        RawSpikes=data(data(:,1)<=8&data(:,2)>0,:);  %%% the first mouse data
        %     FP1=nexFile.contvars{1,1}.data';FP2=nexFile.contvars{2,1}.data';FP3=nexFile.contvars{3,1}.data';FP4=nexFile.contvars{4,1}.data';
        %     FP5=nexFile.contvars{5,1}.data';FP6=nexFile.contvars{6,1}.data';FP7=nexFile.contvars{7,1}.data';FP8=nexFile.contvars{8,1}.data';
        %     FP=[FP1;FP2;FP3;FP4;FP5;FP6;FP7;FP8];
    else
        if strcmp('EVT04',nexFile.events{4,1}.name) % strcmp(s1,s2), compares two string for equality, size and content of each strings are the same.
            Lick=nexFile.events{5,1}.timestamps;%lick event
            OdorAC=nexFile.events{6,1}.timestamps;%odorant A/C
            OdorBD=nexFile.events{7,1}.timestamps;%odorant B/D
            if strcmp('EVT09',nexFile.events{8,1}.name)
                Laser=nexFile.events{8,1}.timestamps;
            else
                Laser=[];
            end
        else
            Lick=nexFile.events{4,1}.timestamps;%lick event
            OdorAC=nexFile.events{5,1}.timestamps;%odorant A/C
            OdorBD=nexFile.events{6,1}.timestamps;%odorant B/D
            if strcmp('EVT09',nexFile.events{7,1}.name)
                Laser=nexFile.events{7,1}.timestamps;
            else
                Laser=[];
            end
        end
        RawSpikes=data(data(:,1)>8&data(:,2)>0,:);  %%% the first mouse data
        %     FP1=nexFile.contvars{1,1}.data';FP2=nexFile.contvars{2,1}.data';FP3=nexFile.contvars{3,1}.data';FP4=nexFile.contvars{4,1}.data';
        %     FP5=nexFile.contvars{5,1}.data';FP6=nexFile.contvars{6,1}.data';FP7=nexFile.contvars{7,1}.data';FP8=nexFile.contvars{8,1}.data';
        %     FP=[FP1;FP2;FP3;FP4;FP5;FP6;FP7;FP8];
    end
end

DataID='20160613_VTA_TH_Cre_Ai32_4335_1_32';
save(['RawData-' DataID],'DataID','Lick','OdorAC','OdorBD','Laser','RawSpikes','nexFile')




%% split spike of every single unit

% %% laser effect
%     %%%%%%%%%% raster plot for laser
%
%     for itr4=1:size(SingleUnitIndex,1)
%         tempSpikeStamp=[];
%         tempSpikeStamp=SingleUnits{itr4,1}(:,3);
%         figure('color',[1 1 1])
%      for itr5=1:10%%% laser trial No.
%          temp1=tempSpikeStamp(Laser(itr5)-0.5<=tempSpikeStamp&tempSpikeStamp<Laser(itr5)+0.5);
%          temp1=(temp1-Laser(itr5));
%          subplot(3,2,1)
%          plot([temp1'; temp1'],[(itr5)*ones(1,length(temp1))-0.5;(itr5)*ones(1,length(temp1))+0.5],'color',[0.5 0.5 0.5])
%          hold on
%          subplot(3,2,2)
%          temp2=tempSpikeStamp(Laser(itr5+10)-0.1<=tempSpikeStamp&tempSpikeStamp<Laser(itr5+10)+0.1);
%          temp2=(temp2-Laser(itr5+10));
%          plot([temp2'; temp2'],[(itr5)*ones(1,length(temp2))-0.5;(itr5)*ones(1,length(temp2))+0.5],'color',[0.5 0.5 0.5])
%          hold on
%          subplot(3,2,3)
%          temp3=tempSpikeStamp(Laser(itr5+20)-0.05<=tempSpikeStamp&tempSpikeStamp<Laser(itr5+20)+0.05);
%          temp3=(temp3-Laser(itr5+20));
%          plot([temp3'; temp3'],[(itr5)*ones(1,length(temp3))-0.5;(itr5)*ones(1,length(temp3))+0.5],'color',[0.5 0.5 0.5])
%          hold on
%          subplot(3,2,4)
%          temp4=tempSpikeStamp(Laser(itr5+30)-0.025<=tempSpikeStamp&tempSpikeStamp<Laser(itr5+30)+0.025);
%          temp4=(temp4-Laser(itr5+30));
%          plot([temp4'; temp4'],[(itr5)*ones(1,length(temp4))-0.8;(itr5)*ones(1,length(temp4))+0.5],'color',[0.5 0.5 0.5])
%          hold on
%          subplot(3,2,5)
%          temp5=tempSpikeStamp(Laser(itr5+40)-0.01<=tempSpikeStamp&tempSpikeStamp<Laser(itr5+40)+0.01);
%          temp5=(temp5-Laser(itr5+40));
%          plot([temp5'; temp5'],[(itr5)*ones(1,length(temp5))-0.5;(itr5)*ones(1,length(temp5))+0.5],'color',[0.5 0.5 0.5])
%          hold on
%      end
% %          plot([0 0],[0 10.5],'b','LineWidth',2)
%     end
%
%
%
%
