%% this code used to summerized all units data and save summaried data for template-matching analysis
clear all;clc;close all;

LaserType=3; % laser by bloack design
LaserDurition=2; % 5 seconds in 6s-delay
TimeGain=10;
NewBin=1000;%ms
Bin=100;%ms
WaveformLenth = 58;
SampelRate = 40000;
InterpolationNum = 5;
GetLaserEffectOnUnit=0;
GetUnitTypeByLaserpulse=1;
GetUnitTypeByWaveForm=1;

IsUnitWaveProperty = 1;
RemoveSameUnitCrossDay=1;

[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end

AllUnitID=[];AveragedFR=[];
Trough_to_Peak=[];Half_Amplitude_Duration=[];AllUnitMaxWaveform=[];AveagedWaveform=[];
Laser_Effect=[];AllTrialsFR=[];
BehavioralPer=[];TrialsJudgement=[];LaserTrialJudgement=[];TrialNum=[];
AllSequentialTrialAllSP=[];SpikeTimestamp=[];FirstOdor=[];SecondOdor=[];


for itr=1:MainCircleN
    NewSpikes=[];
    BehavioralPer_LaserOn=[];BehavioralPer_LaserOff=[];BehavioralPerOnDay=[];
    SplitData=[];FiringRate=[];UnitID_SplitData=[];
    BehavioralPer_SplitData= [];Trials_SplitData=[];LaserTrial_SplitData=[];
    AllSequentialTrialAllSP_SplitData = [];LaserTimeStamp_SplitData=[];LaserType_SplitData=[];
    %%
    load(filename{itr});
    %% get Waveform information
    if IsUnitWaveProperty == 1
        % get averaged waveform of 4 channels (tetrode)
        Waveform = cellfun(@(x) mean(x(:,4:end)), NewSpikes, 'un', 0);
        %     Waveform = cell2mat(tempWaveform);
        AveagedWaveform =[AveagedWaveform; Waveform];
        % get property of max waveform for 4 channels and max waveform
        Trough_to_Peak_Eachfile = [];
        Half_Amplitude_Duration_Eachfile = [];
        [Trough_to_Peak_Eachfile, Half_Amplitude_Duration_Eachfile, MaxWaveform] = GetUnitWavePropertyForEachFile(NewSpikes,WaveformLenth,SampelRate,InterpolationNum);
        Trough_to_Peak = [Trough_to_Peak; Trough_to_Peak_Eachfile];
        Half_Amplitude_Duration = [Half_Amplitude_Duration; Half_Amplitude_Duration_Eachfile];
        AllUnitMaxWaveform = [AllUnitMaxWaveform; mat2cell(MaxWaveform,ones(size(MaxWaveform,1),1),size(MaxWaveform,2))];
    end
    %% get behavior performance
    if size(unique(LaserTrial),1)==1 && unique(LaserTrial)==0
        BehavioralPer_LaserOn = 0;
        BehavioralPer_LaserOff = sum(SplitData.Trials(:,4)==1 | SplitData.Trials(:,4)==4)/size(SplitData.Trials,1);
        BehavioralPerOnDay = [BehavioralPer_LaserOff  BehavioralPer_LaserOff BehavioralPer_LaserOn];
    elseif size(unique(LaserTrial),1)==1 && unique(LaserTrial)==1
        BehavioralPer_LaserOn = sum(SplitData.Trials(:,4)==1 | SplitData.Trials(:,4)==4)/size(SplitData.Trials,1);
        BehavioralPer_LaserOff = 0;
        BehavioralPerOnDay = [BehavioralPer_LaserOn  BehavioralPer_LaserOff BehavioralPer_LaserOn];
    elseif size(unique(LaserTrial),1)==2 % laser on and laser off
        BehavioralPer_LaserOn = sum(LaserTrial==1&SplitData.Trials(:,4)==1 |LaserTrial==1&SplitData.Trials(:,4)==4)/sum(LaserTrial==1);
        BehavioralPer_LaserOff = sum(LaserTrial==0&SplitData.Trials(:,4)==1 |LaserTrial==0&SplitData.Trials(:,4)==4)/sum(LaserTrial==0);
        BehavioralPerOnDay = [mean([BehavioralPer_LaserOff BehavioralPer_LaserOn]) BehavioralPer_LaserOff BehavioralPer_LaserOn];
    end
    %%
    AllTrialsFR = [AllTrialsFR; SplitData.SpikeCounts];
    
    %% get unit activity in task through each trial
    if ~isempty(SingleUnitIndex)
        if size(SingleUnitIndex,1)~=size(SplitData.SpikeCounts,1)
            display(DataID)
        end
        % get averaged firing rate of recording time
        AveragedFR = [AveragedFR; FiringRate];
        for itr2=1:size(SingleUnitIndex,1)
            UnitID_SplitData{itr2,1}=[DataID '-Unit' num2str(SingleUnitIndex(itr2,1)*10+SingleUnitIndex(itr2,2))];
        end
        AllUnitID=[AllUnitID;UnitID_SplitData];
        
        BehavioralPer_SplitData= repmat({BehavioralPerOnDay},size(SingleUnitIndex,1),1);
        LaserTimeStamp_SplitData=repmat({Laser},size(SingleUnitIndex,1),1);
        Trials_SplitData=repmat({SplitData.Trials},size(SingleUnitIndex,1),1);
        LaserTrial_SplitData=repmat({LaserTrial},size(SingleUnitIndex,1),1);
        LaserType_SplitData=LaserType*ones(size(SingleUnitIndex,1),1);
        AllSequentialTrialAllSP_SplitData = cellfun(@(x) mat2cell(x,ones(size(SplitData.SpikeCounts{1,1},1),1),size(SplitData.SpikeCounts{1,1},2))',SplitData.SpikeCounts,'un',0);
        if length(fieldnames(SplitData))==4
            tempAllTrialSpikeTimestamp=cell(size(SplitData.Trials,1),1);
            SpikeTimestamp =[SpikeTimestamp;repmat({tempAllTrialSpikeTimestamp},size(SplitData.SpikeCounts,1),1)];
        else 
            SpikeTimestamp =[SpikeTimestamp;SplitData.SpikeTimestamp];
        end
        AllSequentialTrialAllSP=[AllSequentialTrialAllSP;AllSequentialTrialAllSP_SplitData];
        %% get trial information in task
        BehavioralPer=[BehavioralPer;BehavioralPer_SplitData];
        TrialsJudgement=[TrialsJudgement;Trials_SplitData];
        LaserTrialJudgement=[LaserTrialJudgement;LaserTrial_SplitData];
        LaserTimeStamp=[LaserTimeStamp;LaserTimeStamp_SplitData];
        LaserTypeForUnit=[LaserTypeForUnit;LaserType_SplitData];
        
        FirstOdor=[FirstOdor;repmat({Odor1'},size(SingleUnitIndex,1),1)];
        SecondOdor=[SecondOdor;repmat({Odor2'},size(SingleUnitIndex,1),1)];
        TrialNum=[TrialNum;repmat({size(SplitData.Trials,1)},size(SingleUnitIndex,1),1)];
        %%  get laser effect on unit during task
        if GetLaserEffectOnUnit==1% with optogentic perterbation during task
            if LaserType~=0 && LaserType~=9 % LaserTypr=9, laser pulse for tagging
                Laser_Effect_Delay=[];
                [Laser_Effect_Delay]= GetLaserEffectInTask(SplitData.SpikeCounts,LaserTrial,Bin,36,85,NewBin,1);
            else
                [Laser_Effect_Delay]=NaN*ones(size(SingleUnitIndex,1),1);
            end
            Laser_Effect=[Laser_Effect; Laser_Effect_Delay];
        end
        %%  optogenetic tagging unit with laser pulse
        if GetUnitTypeByLaserpulse ==1
            if LaserType == 9 %% laser pulse identified unit
                LaserPulseTaggedUnitIndex_SplitData=IdentifyUnitByLaserPulse(Laser,NewSpikes);
            else
                LaserPulseTaggedUnitIndex_SplitData=NaN*ones(size(SingleUnitIndex,1),1);
            end
        end
        %%  get cell type by waveform property
%         if GetUnitTypeByWaveForm==1
%             
%         end
    end
end
%% remove same unit cross days
if RemoveSameUnitCrossDay==1
    [RemoveUnitID] = GetSameUnitID(AllUnitID,AllTrialsFR,AveagedWaveform,AllUnitMaxWaveform);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    AllUnitID(RemoveUnitID)=[];
    AllSequentialTrialAllSP(RemoveUnitID)=[];
    SpikeTimestamp(RemoveUnitID)=[];
    AveragedFR(RemoveUnitID)=[];
    AveagedWaveform(RemoveUnitID)=[];
    Trough_to_Peak(RemoveUnitID)=[];
    Half_Amplitude_Duration(RemoveUnitID)=[];
    AllUnitMaxWaveform(RemoveUnitID)=[];
    TrialsJudgement(RemoveUnitID)=[];
    TrialNum(RemoveUnitID)=[];
    FirstOdor(RemoveUnitID)=[];
    SecondOdor(RemoveUnitID)=[];
    LaserTrialJudgement(RemoveUnitID)=[];
    BehavioralPer(RemoveUnitID)=[];
    AllTrialsFR(RemoveUnitID)=[];
end

%%
TotalUnitSplitData.AllUnitID=AllUnitID;
TotalUnitSplitData.AllSequentialAllSP=AllSequentialTrialAllSP;
TotalUnitSplitData.SpikeTime=SpikeTimestamp;
% TotalUnitSplitData.FiringRate,
TotalUnitSplitData.MeanFR=AveragedFR;
TotalUnitSplitData.WaveForm=AveagedWaveform;
TotalUnitSplitData.Trough_to_Peak = Trough_to_Peak;
TotalUnitSplitData.Half_Amplitude_Duration = Half_Amplitude_Duration;
TotalUnitSplitData.AllUnitMaxWaveform = AllUnitMaxWaveform;
TotalUnitSplitData.TrialLaserDelay=repmat({LaserDurition},size(AllSequentialTrialAllSP,1),1);
TotalUnitSplitData.TrialsJudgement=TrialsJudgement;
TotalUnitSplitData.TrialSplit=TrialNum;
% TotalUnitSplitData.GNGTrialType,
% TotalUnitSplitData.TetrodeList,
% TotalUnitSplitData.SingleUnitTetrodeList,
TotalUnitSplitData.ShortSPlen=repmat({201},size(AllSequentialTrialAllSP,1),1);
% TotalUnitSplitData.RuleSequence,
% TotalUnitSplitData.AutoCorr,
TotalUnitSplitData.TimeGain=10;
TotalUnitSplitData.FirstOdor=FirstOdor;
TotalUnitSplitData.SecondOdor=SecondOdor;
TotalUnitSplitData.DelayMeanTrialLenMN=repmat({[6,20.1]},size(AllSequentialTrialAllSP,1),1);
TotalUnitSplitData.Laser=LaserTrialJudgement;
TotalUnitSplitData.BehavioralPer=BehavioralPer;
TotalUnitSplitData.TaskType='DPAL';

WaterMN=WaterLen;
DelayMN=Delay;
% DelaySelectivityDirection;
ITIMN=ITILen;
OdorMN=FirstOdorLen;
ResponseMN=Response;
% TotalSingleUnitNum;
% TotalUnitNum;

save(['VTA-DPA-AllUnitsSummary-NL-RemoveSameUnit'],'WaterMN', 'DelayMN',...
    'ITIMN', 'OdorMN', 'ResponseMN','TotalUnitSplitData','AllTrialsFR','-v7.3')


