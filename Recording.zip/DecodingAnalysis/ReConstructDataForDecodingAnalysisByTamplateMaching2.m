% recostruct daa for decoding analysis by tamplate matching
LaserDuration=2;
TrialNum=300;
BinNum=201;

SammaryDataName=ls('PopulationNeuralActivity*-2.mat');
load(SammaryDataName);

DelayMN=Delay;
ITIMN=ITILen;
OdorMN=FirstOdorLen;
%OdorMN=SecondOdorLen;
ResponseMN=Response;
WaterMN=WaterLen;

TotalUnitSplitData.AllUnitID=AllUnitID;
TotalUnitSplitData.AllSequentialAllSP=cellfun(@(x) mat2cell(x,ones(size(x,1),1),size(x,2))',AllTrialsFR,'un',0);
TotalUnitSplitData.SpikeTime=AllUnitSplitSpikeTime;
TotalUnitSplitData.MeanFR=AveragedFR;
TotalUnitSplitData.WaveForm=mat2cell(AveagedWaveform,ones(size(AveagedWaveform,1),1));
TotalUnitSplitData.Trough_to_Peak=UnitWaveproperty.Trough_to_Peak;
TotalUnitSplitData.Half_Amplitude_Duration=UnitWaveproperty.Half_Amplitude_Duration;
TotalUnitSplitData.AllUnitMaxWaveform=mat2cell(AllUnitMaxWaveform,ones(size(AllUnitMaxWaveform,1),1));
TotalUnitSplitData.TrialLaserDelay=mat2cell(LaserDuration*ones(size(AllUnitID,1),1),ones(size(AllUnitID,1),1));
TotalUnitSplitData.TrialsJudgement=AllTrials;
TotalUnitSplitData.TrialSplit=mat2cell(TrialNum*ones(size(AllUnitID,1),1),ones(size(AllUnitID,1),1));
TotalUnitSplitData.ShortSPlen=mat2cell(BinNum*ones(size(AllUnitID,1),1),ones(size(AllUnitID,1),1));
TotalUnitSplitData.TimeGain=10;
TotalUnitSplitData.FirstOdor=AllUnitOdor1;
TotalUnitSplitData.SecondOdor=AllUnitOdor2;
TotalUnitSplitData.DelayMeanTrialLenMN=repmat({[6,20.1]},size(AllUnitID,1),1);
TotalUnitSplitData.Laser=AllLaserTrialsID;
TotalUnitSplitData.BehavioralPer=cellfun(@(x) [mean(x(1:3:end,end)) mean(x(2:3:end,end)) mean(x(3:3:end,end))],AllPerformance,'un',0);
TotalUnitSplitData.BehavioralPer_Block=AllPerformance;
TotalUnitSplitData.TaskType='DPAL-LaserOn&OffBlockDesign-LaserinEarly&LateDelay';
TotalUnitSplitData.BehavioralPerInfo=['LaserInEaryDelay' 'LaserOff' 'LaserInLateDelay'];

save(['VTAtomPFC-DPA-AllUnitsSummary'],'WaterMN', 'DelayMN',...
    'ITIMN', 'OdorMN', 'ResponseMN','TotalUnitSplitData','AllTrialsFR','-v7.3')




