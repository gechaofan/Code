%% PCA Trajactory
% laser off 
LaserOffAllATrialsFR200=ReDefineBinSize(NormATrialsFR_LaserOff,200,100);% with binsize= 500ms
LaserOffAllBTrialsFR200=ReDefineBinSize(NormBTrialsFR_LaserOff,200,100);

tempLaserOffAllATrials_MeanFR=cellfun(@(x) mean(x(1:40,:),1),LaserOffAllATrialsFR200,'un',0);
LaserOffAllATrials_MeanFR=cell2mat(tempLaserOffAllATrials_MeanFR)';
tempLaserOffAllBTrials_MeanFR=cellfun(@(x) mean(x(1:40,:),1),LaserOffAllBTrialsFR200,'un',0);
LaserOffAllBTrials_MeanFR=cell2mat(tempLaserOffAllBTrials_MeanFR)';

% laser on in early delay
LaserOnAllATrialsFR200=ReDefineBinSize(NormATrialsFR_LaserOnEarlyDelay,200,100);
LaserOnAllBTrialsFR200=ReDefineBinSize(NormBTrialsFR_LaserOnEarlyDelay,200,100);
tempLaserOnAllATrials_MeanFR=cellfun(@(x) mean(x(11:50,:),1),LaserOnAllATrialsFR200,'un',0);
LaserOnAllATrials_MeanFR=cell2mat(tempLaserOnAllATrials_MeanFR)';
tempLaserOnAllBTrials_MeanFR=cellfun(@(x) mean(x(11:50,:),1),LaserOnAllBTrialsFR200,'un',0);
LaserOnAllBTrials_MeanFR=cell2mat(tempLaserOnAllBTrials_MeanFR)';

% laser on in late delay
LaserOnAllATrialsFR200_Late=ReDefineBinSize(NormATrialsFR_LaserOnLateDelay,200,100);
LaserOnAllBTrialsFR200_Late=ReDefineBinSize(NormBTrialsFR_LaserOnLateDelay,200,100);
tempLaserOnAllATrials_MeanFR_Late=cellfun(@(x) mean(x(1:40,:),1),LaserOnAllATrialsFR200_Late,'un',0);
LaserOnAllATrials_MeanFR_Late=cell2mat(tempLaserOnAllATrials_MeanFR_Late)';
tempLaserOnAllBTrials_MeanFR_Late=cellfun(@(x) mean(x(1:40,:),1),LaserOnAllBTrialsFR200_Late,'un',0);
LaserOnAllBTrials_MeanFR_Late=cell2mat(tempLaserOnAllBTrials_MeanFR_Late)';

Data_LaserEarlyIncreasedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Ealry_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Ealry_CLE);LaserOnAllATrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Ealry_CLE);LaserOnAllBTrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Ealry_CLE)];
% [~,bootsam_EarlyIncreasedIndex]=bootstrp(200,@(x) pca(x),Learn_FRIncreasedUnitIndex_Ealry);
Data_LaserEarlyDecreasedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Ealry_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Ealry_CLE);LaserOnAllATrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Ealry_CLE);LaserOnAllBTrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Ealry_CLE)];
% [~,bootsam_EarlyDecreasedIndex]=bootstrp(200,@(x) pca(x),Learn_FRDecreasedUnitIndex_Ealry);
Data_LaserLateIncreasedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Late_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRIncreasedUnitIndex_Late_CLE);LaserOnAllATrials_MeanFR_Late(:,Learn_FRIncreasedUnitIndex_Late_CLE);LaserOnAllBTrials_MeanFR_Late(:,Learn_FRIncreasedUnitIndex_Late_CLE)];
% [~,bootsam_LateIncreasedIndex]=bootstrp(200,@(x) pca(x),Learn_FRIncreasedUnitIndex_Late);
Data_LaserLateDecreasedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Late_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRDecreasedUnitIndex_Late_CLE);LaserOnAllATrials_MeanFR_Late(:,Learn_FRDecreasedUnitIndex_Late_CLE);LaserOnAllBTrials_MeanFR_Late(:,Learn_FRDecreasedUnitIndex_Late_CLE)];
% [~,bootsam_LateDecreasedIndex]=bootstrp(200,@(x) pca(x),Learn_FRDecreasedUnitIndex_Late);
Learn_FRChangedUnitIndex_Early_CLE=[Learn_FRIncreasedUnitIndex_Ealry_CLE;Learn_FRDecreasedUnitIndex_Ealry_CLE];
Learn_FRChangedUnitIndex_Late_CLE=[Learn_FRIncreasedUnitIndex_Late_CLE;Learn_FRDecreasedUnitIndex_Late_CLE];
Data_LaserEarlyChangedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRChangedUnitIndex_Ealry_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRChangedUnitIndex_Ealry_CLE);LaserOnAllATrials_MeanFR(:,Learn_FRChangedUnitIndex_Ealry_CLE);LaserOnAllBTrials_MeanFR(:,Learn_FRChangedUnitIndex_Ealry_CLE)];
Data_LaserLateChangedUnit=[LaserOffAllATrials_MeanFR(:,Learn_FRChangedUnitIndex_Late_CLE);LaserOffAllBTrials_MeanFR(:,Learn_FRChangedUnitIndex_Late_CLE);LaserOnAllATrials_MeanFR(:,Learn_FRChangedUnitIndex_Late_CLE);LaserOnAllBTrials_MeanFR(:,Learn_FRChangedUnitIndex_Late_CLE)];

clear('LaserEarlyIncreasedUnitPCA','LaserEarlyDecreasedUnitPCA','LaserLateIncreasedUnitPCA','LaserLateDecreasedUnitPCA')
ReSampleNum=200;ReSampleUnit=90;
for i = 1:ReSampleNum
    bootsam_EarlyIncreasedIndex=[];bootsam_EarlyDecreasedIndex=[];bootsam_LateIncreasedIndex=[];bootsam_LateDecreasedIndex=[];
    bootsam_EarlyIncreasedIndex=randperm(size(Learn_FRIncreasedUnitIndex_Ealry_CLE,1),round(ReSampleUnit/100*size(Learn_FRIncreasedUnitIndex_Ealry_CLE,1)));
    bootsam_EarlyDecreasedIndex=randperm(size(Learn_FRDecreasedUnitIndex_Ealry_CLE,1),round(ReSampleUnit/100*size(Learn_FRDecreasedUnitIndex_Ealry_CLE,1)));
    bootsam_LateIncreasedIndex=randperm(size(Learn_FRIncreasedUnitIndex_Late_CLE,1),round(ReSampleUnit/100*size(Learn_FRIncreasedUnitIndex_Late_CLE,1)));
    bootsam_LateDecreasedIndex=randperm(size(Learn_FRDecreasedUnitIndex_Late_CLE,1),round(ReSampleUnit/100*size(Learn_FRDecreasedUnitIndex_Late_CLE,1)));

    bootsam_EarlyChangedIndex=randperm(size(Learn_FRChangedUnitIndex_Early_CLE,1),round(ReSampleUnit/100*size(Learn_FRChangedUnitIndex_Early_CLE,1)));
    bootsam_LateChangedIndex=randperm(size(Learn_FRChangedUnitIndex_Late_CLE,1),round(ReSampleUnit/100*size(Learn_FRChangedUnitIndex_Late_CLE,1)));
    [LaserEarlyChangedUnitPCA.coeff(:,:,i),LaserEarlyChangedUnitPCA.score(:,:,i),LaserEarlyChangedUnitPCA.latent(:,:,i),LaserEarlyChangedUnitPCA.tsquared(:,:,i),LaserEarlyChangedUnitPCA.explained(:,:,i),LaserEarlyChangedUnitPCA.mu(:,:,i)]=pca(Data_LaserEarlyChangedUnit(:,bootsam_EarlyChangedIndex));
    [LaserLateChangedUnitPCA.coeff(:,:,i),LaserLateChangedUnitPCA.score(:,:,i),LaserLateChangedUnitPCA.latent(:,:,i),LaserLateChangedUnitPCA.tsquared(:,:,i),LaserLateChangedUnitPCA.explained(:,:,i),LaserLateChangedUnitPCA.mu(:,:,i)]=pca(Data_LaserLateChangedUnit(:,bootsam_LateChangedIndex));
%     bootsam_EarlyIncreasedIndex=randperm(size(Learn_FRIncreasedUnitIndex_Ealry_CLE,1),60);
%     bootsam_EarlyDecreasedIndex=randperm(size(Learn_FRDecreasedUnitIndex_Ealry_CLE,1),60);
%     bootsam_LateIncreasedIndex=randperm(size(Learn_FRIncreasedUnitIndex_Late_CLE,1),60);
%     bootsam_LateDecreasedIndex=randperm(size(Learn_FRDecreasedUnitIndex_Late_CLE,1),60);
%     
    [LaserEarlyIncreasedUnitPCA.coeff(:,:,i),LaserEarlyIncreasedUnitPCA.score(:,:,i),LaserEarlyIncreasedUnitPCA.latent(:,:,i),LaserEarlyIncreasedUnitPCA.tsquared(:,:,i),LaserEarlyIncreasedUnitPCA.explained(:,:,i),LaserEarlyIncreasedUnitPCA.mu(:,:,i)]=pca(Data_LaserEarlyIncreasedUnit(:,bootsam_EarlyIncreasedIndex));
    [LaserEarlyDecreasedUnitPCA.coeff(:,:,i),LaserEarlyDecreasedUnitPCA.score(:,:,i),LaserEarlyDecreasedUnitPCA.latent(:,:,i),LaserEarlyDecreasedUnitPCA.tsquared(:,:,i),LaserEarlyDecreasedUnitPCA.explained(:,:,i),LaserEarlyDecreasedUnitPCA.mu(:,:,i)]=pca(Data_LaserEarlyDecreasedUnit(:,bootsam_EarlyDecreasedIndex));
    [LaserLateIncreasedUnitPCA.coeff(:,:,i),LaserLateIncreasedUnitPCA.score(:,:,i),LaserLateIncreasedUnitPCA.latent(:,:,i),LaserLateIncreasedUnitPCA.tsquared(:,:,i),LaserLateIncreasedUnitPCA.explained(:,:,i),LaserLateIncreasedUnitPCA.mu(:,:,i)]=pca(Data_LaserLateIncreasedUnit(:,bootsam_LateIncreasedIndex));
    [LaserLateDecreasedUnitPCA.coeff(:,:,i),LaserLateDecreasedUnitPCA.score(:,:,i),LaserLateDecreasedUnitPCA.latent(:,:,i),LaserLateDecreasedUnitPCA.tsquared(:,:,i),LaserLateDecreasedUnitPCA.explained(:,:,i),LaserLateDecreasedUnitPCA.mu(:,:,i)]=pca(Data_LaserLateDecreasedUnit(:,bootsam_LateDecreasedIndex));
end

%% plot 3D-Distance of ample odor and test odor 
SampleDistance_LaserOff_4Conditions=cell(2,1);% earlyIncreasedUnit;earlyDecreasedUnit;LateIncreasedUnit;lateDecreasedUnit;
SampleDistance_LaserOn_4Conditions=cell(2,1);
Distance_LaserOff_Square=[] ;Distance_LaserOn_Square=[] ;Distance_LaserOff=[];Distance_LaserOn=[];
for n = 1 : 2
    switch n
        case 1
%             score=LaserEarlyIncreasedUnitPCA.score;
            score=LaserEarlyChangedUnitPCA.score;
        case 2
%             score=LaserEarlyDecreasedUnitPCA.score;
            score=LaserLateChangedUnitPCA.score;
        case 3
            score=LaserLateIncreasedUnitPCA.score;
        case 4
            score=LaserLateDecreasedUnitPCA.score;
        otherwise
    end
    Distance_LaserOff=zeros(ReSampleNum,100);Distance_LaserOn=zeros(ReSampleNum,100);
    for j = 1: ReSampleNum
        for D = 1: 10%first 10 componants
        Distance_LaserOff_Square(:,D,j) = (score(1:100,D,j)-score(101:200,D,j)).^2 ;
        Distance_LaserOn_Square(:,D,j) = (score(201:300,D,j)-score(301:400,D,j)).^2 ;
        end
        Distance_LaserOff(j,:)=sqrt(sum(Distance_LaserOff_Square(:,:,j),2))';
        Distance_LaserOn(j,:)=sqrt(sum(Distance_LaserOn_Square(:,:,j),2))';
    end
    SampleDistance_LaserOff_4Conditions{n,1}=Distance_LaserOff;
    SampleDistance_LaserOn_4Conditions{n,1}=Distance_LaserOn;
end
%% Normalized distance and 95% confidence range
    NormDistance_LaserOff= cellfun(@(x) (x-mean(x(:,6:10),2))./std(x(:,6:10),0,2),SampleDistance_LaserOff_4Conditions,'UniformOutput',false);
    NormDistance_LaserOn= cellfun(@(x) (x-mean(x(:,6:10),2))./std(x(:,6:10),0,2),SampleDistance_LaserOn_4Conditions,'UniformOutput',false);    % 95% confidence interval
    [mu_LaserOff,sigma_LaserOff,muci_LaserOff,sigmaci_LaserOff]=cellfun(@(x) normfit(x,0.05),NormDistance_LaserOff,'un',0);
    [mu_LaserOn,sigma_LaserOn,muci_LaserOn,sigmaci_LaserOn]=cellfun(@(x) normfit(x,0.05),NormDistance_LaserOn,'un',0);
%%
 X=[-1.9:0.2:17.9];
pIndex=cell(4,1);p=zeros(4,100);
for i = 1:2
    figure('color',[1 1 1])
    h1=area([0 1],10*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
    hold on
    h2=area([7 8],10*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
    h3=area([9 10],10*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
    box off
    for j=1:100
        p(i,j)=(length(find(NormDistance_LaserOff{i,1}(:,j)>muci_LaserOn{i,1}(1,j)&NormDistance_LaserOff{i,1}(:,j)<muci_LaserOn{i,1}(2,j)))...
            +length(find(NormDistance_LaserOn{i,1}(:,j)>muci_LaserOff{i,1}(1,j)&NormDistance_LaserOn{i,1}(:,j)<muci_LaserOff{i,1}(2,j))))/ReSampleNum/2;
    end
    pIndex{i}=find(p(i,:)<0.05);
    
    plot(X,smooth(mu_LaserOff{i,1},'moving',3)','k')
    fill([X,fliplr(X)],[smooth(muci_LaserOff{i,1}(1,:),'moving',3)',fliplr(smooth(muci_LaserOff{i,1}(2,:),'moving',3)')],...
        [0 0 0],'edgecolor','none','FaceAlpha',0.3)
    plot(X,smooth(mu_LaserOn{i,1},'moving',3)','b')
    fill([X,fliplr(X)],[smooth(muci_LaserOn{i,1}(1,:),'moving',3)',fliplr(smooth(muci_LaserOn{i,1}(2,:),'moving',5)')],...
        [0 0 1],'edgecolor','none','FaceAlpha',0.3)
%     plot(pIndex{i}/10-2,2*ones(1,length(pIndex{i})),'LineStyle','none','Marker','.','Color',[0 0 0])
%     Title=['10components-PCADistance-' num2str(ReSampleNum) 'times-' num2str(ReSampleUnit) 'percentUnits-' num2str(i)'];
%     saveas(gcf,Title,'fig')
%     saveas(gcf,Title,'png')
%     close all
end
close all
%%  multidimentional distance%%%%%%%%%%%%%%%%
tempLaserOffAllTrials_MeanFR=cellfun(@mean,LaserOffAllTrialsFR,'un',0);
LaserOffAllTrials_MeanFR=10*cell2mat(tempLaserOffAllTrials_MeanFR);
tempLaserOnAllTrials_MeanFR=cellfun(@mean,LaserOnAllTrialsFR_EarlyDelay,'un',0);
LaserOnAllTrials_MeanFR=10*cell2mat(tempLaserOnAllTrials_MeanFR);



    figure('color',[1 1 1])
    h1=area([0 1],10*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
    hold on
    h2=area([7 8],10*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
    h3=area([9 10],10*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
    box off
    
    fill([X,fliplr(X)],[mean(LaserOffAllTrials_MeanFR,1)-std(LaserOffAllTrials_MeanFR,0,1)/sqrt(size(LaserOffAllTrials_MeanFR,1)-1),fliplr(mean(LaserOffAllTrials_MeanFR,1)+std(LaserOffAllTrials_MeanFR,0,1)/sqrt(size(LaserOffAllTrials_MeanFR,1)-1))],...
        [0 0 0],'edgecolor','none','FaceAlpha',0.3)
     hold on
    fill([X,fliplr(X)],[mean(LaserOnAllTrials_MeanFR,1)-std(LaserOnAllTrials_MeanFR,0,1)/sqrt(size(LaserOnAllTrials_MeanFR,1)-1),fliplr(mean(LaserOnAllTrials_MeanFR,1)+std(LaserOnAllTrials_MeanFR,0,1)/sqrt(size(LaserOnAllTrials_MeanFR,1)-1))],...
        [0 0 1],'edgecolor','none','FaceAlpha',0.3) 
  

plot(X,smooth(mean(LaserOffAllTrials_MeanFR,1))','k')

hold on
plot(X,smooth(mean(LaserOnAllTrials_MeanFR,1))','b')

%%  2D-plot%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(1,2,1)
plot(score(11:20,1),score(11:20,2),'Color',[0 0 0],'LineWidth',2)
hold on
plot(score(20:30,1),score(20:30,2),'Color',[1 0 0],'LineWidth',2)
plot(score(30:90,1),score(30:90,2),'Color',[0.5 0.2 0.2],'LineWidth',2)
% plot3(score(90:170,1),score(90:170,2),score(90:170,3),'Color',[0 1 0],'LineWidth',2)

plot(score(201+11:201+20,1),score(201+11:201+20,2),'Color',[0 0 0],'LineWidth',2)
hold on
plot(score(201+20:201+30,1),score(201+20:201+30,2),'Color',[0 0 1],'LineWidth',2)
plot(score(201+30:201+90,1),score(201+30:201+90,2),'Color',[0.2 0.2 0.5],'LineWidth',2)
% plot3(score(201+90:201+170,1),score(201+90:201+170,2),score(201+90:201+170,3),'Color',[0 1 0],'LineWidth',2)

subplot(1,2,2)
plot(score(402+11:402+20,1),score(402+11:402+20,2),'Color',[0 0 0],'LineWidth',2,'LineStyle','--')
hold on
plot(score(402+20:402+30,1),score(402+20:402+30,2),'Color',[1 0 0],'LineWidth',2,'LineStyle','--')
plot(score(402+30:402+90,1),score(402+30:402+90,2),'Color',[0.5 0.2 0.2],'LineWidth',2,'LineStyle','--')
% plot3(score(402+90:402+170,1),score(402+90:402+170,2),score(402+90:402+170,3),'Color',[0 1 0],'LineWidth',2,'LineStyle','--')

plot(score(603+11:603+20,1),score(603+11:603+20,2),'Color',[0 0 0],'LineWidth',2,'LineStyle','--')
hold on
plot(score(603+20:603+30,1),score(603+20:603+30,2),'Color',[0 0 1],'LineWidth',2,'LineStyle','--')
plot(score(603+30:603+90,1),score(603+30:603+90,2),'Color',[0.2 0.2 0.8],'LineWidth',2,'LineStyle','--')
% plot3(score(603+90:603+170,1),score(603+90:603+170,2),score(603+90:603+170,3),'Color',[0 1 0],'LineWidth',2,'LineStyle','--')
%% 3D-plot%%%%%%%%%%%%%%%%%%%%%%%%%%
Data1=[LaserOffAllATrials_MeanFR;LaserOffAllBTrials_MeanFR;LaserOnAllATrials_MeanFR;LaserOnAllBTrials_MeanFR;];
Data2=[LaserOffAllATrials_MeanFR;LaserOffAllBTrials_MeanFR;LaserOnAllATrials_MeanFR_Late;LaserOnAllBTrials_MeanFR_Late];
Data3=[LaserOffAllATrials_MeanFR;LaserOffAllBTrials_MeanFR;LaserOnAllATrials_MeanFR;LaserOnAllBTrials_MeanFR;LaserOffAllBTrials_MeanFR;LaserOnAllATrials_MeanFR_Late;LaserOnAllBTrials_MeanFR_Late];

 [AllUnitPCA_Early.coeff,AllUnitPCA_Early.score(:,:,i),AllUnitPCA_Early.latent(:,:,i),AllUnitPCA_Early.tsquared(:,:,i),AllUnitPCA_Early.explained(:,:,i),AllUnitPCA_Early.mu(:,:,i)]=pca(Data1);
% subplot(1,3,1)
figure('color',[1 1 1])
plot3(score(6:10,1),score(6:10,2),score(6:10,3),'Color',[0 0 0],'LineWidth',2)
hold on
plot3(score(11:15,1),score(11:15,2),score(11:15,3),'Color',[1 0 0],'LineWidth',2)
plot3(score(16:45,1),score(16:45,2),score(16:45,3),'Color',[1 0.7 0.7],'LineWidth',2)
% plot3(score(90:170,1),score(90:170,2),score(90:170,3),'Color',[0 1 0],'LineWidth',2)

plot3(score(100+6:100+10,1),score(100+6:100+10,2),score(100+6:100+10,3),'Color',[0 0 0],'LineWidth',2)
hold on
plot3(score(100+11:100+15,1),score(100+11:100+15,2),score(100+11:100+15,3),'Color',[0 0 1],'LineWidth',2)
plot3(score(100+16:100+45,1),score(100+16:100+45,2),score(100+16:100+45,3),'Color',[0.7 0.7 1],'LineWidth',2)
% plot3(score(201+90:201+170,1),score(201+90:201+170,2),score(201+90:201+170,3),'Color',[0 1 0],'LineWidth',2)
saveas(gcf,['AllUnit-PCATrajectory-3D_LaserOff'],'fig')
saveas(gcf,['AllUnit-PCATrajectory-3D_LaserOff'],'png')

% subplot(1,3,2)
figure('color',[1 1 1])
plot3(score(200+6:200+10,1),score(200+6:200+10,2),score(200+6:200+10,3),'Color',[0 0 0],'LineWidth',2,'LineStyle','-')
hold on
plot3(score(200+11:200+15,1),score(200+11:200+15,2),score(200+11:200+15,3),'Color',[1 0 0],'LineWidth',2,'LineStyle','-')
plot3(score(200+16:200+45,1),score(200+16:200+45,2),score(200+16:200+45,3),'Color',[1 0.7 0.7],'LineWidth',2,'LineStyle','-')
% plot3(score(402+90:402+170,1),score(402+90:402+170,2),score(402+90:402+170,3),'Color',[0 1 0],'LineWidth',2,'LineStyle','--')

plot3(score(300+6:300+10,1),score(300+6:300+10,2),score(300+6:300+10,3),'Color',[0 0 0],'LineWidth',2,'LineStyle','-')
hold on
plot3(score(300+11:300+15,1),score(300+11:300+15,2),score(300+11:300+15,3),'Color',[0 0 1],'LineWidth',2,'LineStyle','-')
plot3(score(300+16:300+45,1),score(300+16:300+45,2),score(300+16:300+45,3),'Color',[0.7 0.7 1],'LineWidth',2,'LineStyle','-')
% plot3(score(603+90:603+170,1),score(603+90:603+170,2),score(603+90:603+170,3),'Color',[0 1 0],'LineWidth',2,'LineStyle','--')
saveas(gcf,['AllUnit-PCATrajectory-3D_LaserEarlyDelay'],'fig')
saveas(gcf,['AllUnit-PCATrajectory-3D_LaserEarlyDelay'],'png')
close all
% subplot(1,3,3)
figure('Color',[1 1 1])
plot3(score(400+6:400+10,1),score(400+6:400+10,2),score(400+6:400+10,3),'Color',[0 0 0],'LineWidth',2,'LineStyle','-')
hold on
plot3(score(400+11:400+15,1),score(400+11:400+15,2),score(400+11:400+15,3),'Color',[1 0 0],'LineWidth',2,'LineStyle','-')
plot3(score(400+16:400+45,1),score(400+16:400+45,2),score(400+16:400+45,3),'Color',[1 0.7 0.7],'LineWidth',2,'LineStyle','-')
% plot3(score(402+90:402+170,1),score(402+90:402+170,2),score(402+90:402+170,3),'Color',[0 1 0],'LineWidth',2,'LineStyle','--')

plot3(score(500+6:500+10,1),score(500+6:500+10,2),score(500+6:500+10,3),'Color',[0 0 0],'LineWidth',2,'LineStyle','-')
hold on
plot3(score(500+11:500+15,1),score(500+11:500+15,2),score(500+11:500+15,3),'Color',[0 0 1],'LineWidth',2,'LineStyle','-')
plot3(score(500+16:500+45,1),score(500+16:500+45,2),score(500+16:500+45,3),'Color',[0.7 0.7 1],'LineWidth',2,'LineStyle','-')
saveas(gcf,['AllUnits-PCATrajectory-3D_LaserLateDelay'],'fig')
saveas(gcf,['AllUnits-PCATrajectory-3D_LaserLateDelay'],'png')

