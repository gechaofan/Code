function [Index_EachBin,Index_Sig_EachBin]=CalculateUnitIndexInEachBinForSplitPeriod(ODI,Significance,BinSize,PeriodNum)
% BinSize = 100ms
% ODI Odor discremination index; for our olfactory task, 
BinNum=1000/BinSize; % number in 1s

for i = 1 : PeriodNum
    for iBin = 1:BinNum+1
        Index_EachBin{i,iBin}=find(ODI(:,i)<0.1*iBin-0.05 & ODI(:,i)>=(iBin-1)*0.1-0.05);
        Index_Sig_EachBin{i,iBin}=Index_EachBin{i,iBin}(Significance(Index_EachBin{i,iBin},i)<0.05);    
    end  
end