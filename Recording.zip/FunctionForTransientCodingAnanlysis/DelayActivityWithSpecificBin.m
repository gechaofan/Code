function [p,sign,NewFR]= DelayActivityWithSpecificBin(FR,NewBin,Bin,Period,PairTest,NormData)
if NormData==1
NewFR=ReDefineBinSize(FR,NewBin,Bin,1);
elseif NormDate==0
    NewFR=ReDefineBinSize(FR,NewBin,Bin);
end
BinNum=size(NewFR{1,1},2);
p=NaN*ones(size(FR,1),BinNum);sign=NaN*ones(size(FR,1),BinNum);
for iNeu = 1: size(FR,1)
    for iBin = 1:BinNum
        [p(iNeu,iBin),sign(iNeu,iBin)]=ranksumTest(NewFR{iNeu,1}(:,iBin),mean(NewFR{iNeu,1}(:,Period),2),PairTest);       
    end
end
end