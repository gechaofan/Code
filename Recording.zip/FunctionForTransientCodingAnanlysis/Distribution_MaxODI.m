function [Index_Bin,Index_Sig_Bin]=Distribution_MaxODI(ODI,Significance,ODIBin,ODIRange,Title)
BinNum=diff(ODIRange)/ODIBin+1;% selecitivity range: [0 1], bin = 0.1; saperate into 11 bin

for iPeriod = 1 : size(ODI,2)
    Sig_Index=[];
    Sig_Index=find(Significance(:,iPeriod)<0.05);
    for iBin = 1 : BinNum % 100ms step in 2s
        Index_Bin{iPeriod,iBin}=find(ODI(:,iPeriod)>(iBin-1)*ODIBin-ODIBin/2 & ODI(:,iPeriod)<iBin*ODIBin-ODIBin/2);
        Index_Sig_Bin{iPeriod,iBin}=intersect(Sig_Index,Index_Bin{iPeriod,iBin});
    end
end

Num_Bin=cellfun(@(x) length(x),Index_Bin);
Num_Sig_Bin=cellfun(@(x) length(x),Index_Sig_Bin);
Num_NonSig_Bin=Num_Bin-Num_Sig_Bin;

for i =1 : size(ODI,2)
    Index_AllBin=[];Index_Sig_AllBin=[];
    Index_AllBin=cell2mat(Index_Bin(i,:)');
    Index_Sig_AllBin=cell2mat(Index_Sig_Bin(i,:)');
    
    figure
    colormap(jet)
    
    bar1 = bar([0:0.1:1]',[Num_Sig_Bin(i,:);Num_NonSig_Bin(i,:)]','BarLayout','stacked');
    set(bar1(2),'FaceColor',[1 1 1]);
    hold on
    plot(mean(ODI(Index_AllBin,i)),100,'MarkerSize',8,'Marker','v','LineStyle','none','Color',[0 0 0])
    plot(mean(ODI(Index_Sig_AllBin,i)),105,'MarkerSize',8,'Marker','o','LineStyle','none','Color',[0 0 0])
    title([num2str(mean(ODI(Index_AllBin,i))) num2str(mean(ODI(Index_Sig_AllBin,i)))]);
    box off
    saveas(gcf,[Title '-' num2str(i)],'fig')
    saveas(gcf,[Title '-' num2str(i)],'png')
end


end
