function [Num_Sig_Bin,Num_NonSig_Bin]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR,Index,Index_Sig,BinSize,Title)
 
PeriodNum=size(Index,1);% number of specific time period
BinNum=size(Index,2); % bin number of histogram

Num_Bin=cellfun(@(x) length(x),Index);
Num_Sig_Bin=cellfun(@(x) length(x),Index_Sig);
Num_NonSig_Bin=Num_Bin-Num_Sig_Bin;

for iPeriod = 1 : PeriodNum
    temp_Index_All=[];temp_Index_Sig_All=[];
    temp_Index_All=cell2mat(Index(iPeriod,:)');
    temp_Index_Sig_All=cell2mat(Index_Sig(iPeriod,:)');
    
    figure
    bar1 = bar([1:1:BinNum]*BinSize',[Num_Sig_Bin(iPeriod,:);Num_NonSig_Bin(iPeriod,:)]','stacked');
    set(bar1(2),'FaceColor',[1 1 1]);
    hold on
    plot(mean(Mean_NormFR(temp_Index_All,iPeriod)),100,'MarkerSize',8,'Marker','v','LineStyle','none','Color',[0 0 0])    
    plot(mean(Mean_NormFR(temp_Index_Sig_All,iPeriod)),105,'MarkerSize',8,'Marker','o','LineStyle','none','Color',[0 0 0])        
    title([num2str(mean(Mean_NormFR(temp_Index_All,iPeriod))) num2str(mean(Mean_NormFR(temp_Index_Sig_All,iPeriod)))]);
    box off
    saveas(gcf,[Title '-' num2str(iPeriod)],'fig')
    saveas(gcf,[Title '-' num2str(iPeriod)],'png')    
    
end
    
end