function [Index_Increase,Index_Sig_Increase,Index_Decrease,Index_Sig_Decrease]=Distribution_NormFR(FR,stat,Start,End,StepSize,Range)
Intercept=Start-1;
Section=End-Start+1;
StepNum=Range/StepSize+1;

for i=1:Section%from sample odor onset to delay end
    SigIndex{i,1}=find(stat(:,i+Intercept)<0.05);
    for iStep = 1:StepNum% 0.2 stepsize
        if iStep <StepNum
            Index_Increase{i,iStep}=find(FR(:,i+Intercept)>0.2*(iStep-1)&FR(:,i+Intercept)<=0.2*iStep);
            Index_Sig_Increase{i,iStep}=intersect(Index_Increase{i,iStep},SigIndex{i,1});
            
            Index_Decrease{i,iStep}=find(FR(:,i+Intercept)<=-0.2*(iStep-1)&FR(:,i+Intercept)>-0.2*iStep);
            Index_Sig_Decrease{i,iStep}=intersect(Index_Decrease{i,iStep},SigIndex{i,1});
        elseif iStep==StepNum
            Index_Increase{i,iStep}=find(FR(:,i+Intercept)>0.2*(iStep-1));
            Index_Sig_Increase{i,iStep}=intersect(Index_Increase{i,iStep},SigIndex{i,1});
            
            Index_Decrease{i,iStep}=find(FR(:,i+Intercept)<=-0.2*(iStep-1));
            Index_Sig_Decrease{i,iStep}=intersect(Index_Decrease{i,iStep},SigIndex{i,1});
        end
    end
end
