function [Num_Sig_Step,Num_NonSig_Step]=PlotMaxODITimeStepDistribution(ODI_StepIndex,Index_Step,Index_Sig_Step,Title)
StepNum=size(Index_Step,2);
Num_Step=cellfun(@(x) length(x),Index_Step);
Num_Sig_Step=cellfun(@(x) length(x),Index_Sig_Step);
Num_NonSig_Step=Num_Step-Num_Sig_Step;
for i =1 : size(Index_Step,1)
    Index_Sig{i,1}=cell2mat(Index_Sig_Step(i,:)');
    figure
    bar1 = bar([1:1:StepNum]',[Num_Sig_Step(i,:);Num_NonSig_Step(i,:)]','stacked');
    set(bar1(2),'FaceColor',[1 1 1]);
    hold on
    plot(mean(ODI_StepIndex(:,i)),100,'MarkerSize',8,'Marker','v','LineStyle','none','Color',[0 0 0])
    plot(mean(ODI_StepIndex(Index_Step{i,1}(Index_Sig{i,1},i))),105,'MarkerSize',8,'Marker','o','LineStyle','none','Color',[0 0 0])
    title([num2str(mean(ODI_StepIndex(:,i))) num2str(mean(ODI_StepIndex(Index_Sig{i,1},i)))]);
    box off
    saveas(gcf,[Title '-' num2str(i)],'fig')
    saveas(gcf,[Title '-' num2str(i)],'png')
end
end