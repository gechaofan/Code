LaserOffTrialIndex=find(LaserTrial==0);
LaserOnTrialIndex_1=find(LaserTrial==1);
LaserOnTrialIndex_2=find(LaserTrial==2);

% 100ms
SpikeCounts_LaserOff = cellfun(@(x) x(LaserOffTrialIndex,:), SplitData.SpikeCounts,'un', 0);
SpikeCounts_LaserEarlyDelay = cellfun(@(x) x(LaserOnTrialIndex_1,:), SplitData.SpikeCounts,'un', 0);
SpikeCounts_LaserLateDelay = cellfun(@(x) x(LaserOnTrialIndex_2,:), SplitData.SpikeCounts,'un', 0);

%200ms
SpikeCounts_LaserOff1=ReDefineBinSize(SpikeCounts_LaserOff,200,100);
SpikeCounts_LaserEarlyDelay1=ReDefineBinSize(SpikeCounts_LaserEarlyDelay,200,100);
SpikeCounts_LaserLateDelay1=ReDefineBinSize(SpikeCounts_LaserLateDelay,200,100);
%500ms
SpikeCounts_LaserOff2=ReDefineBinSize(SpikeCounts_LaserOff,500,100);
SpikeCounts_LaserEarlyDelay2=ReDefineBinSize(SpikeCounts_LaserEarlyDelay,500,100);
SpikeCounts_LaserLateDelay2=ReDefineBinSize(SpikeCounts_LaserLateDelay,500,100);
%1000ms
SpikeCounts_LaserOff3=ReDefineBinSize(SpikeCounts_LaserOff,1000,100);
SpikeCounts_LaserEarlyDelay3=ReDefineBinSize(SpikeCounts_LaserEarlyDelay,1000,100);
SpikeCounts_LaserLateDelay3=ReDefineBinSize(SpikeCounts_LaserLateDelay,1000,100);

p_LaserOff_100=cell(size(SingleUnitIndex,1),1);Sign_LaserOff_100=cell(size(SingleUnitIndex,1),1);
p_LaserOff_200=cell(size(SingleUnitIndex,1),1);Sign_LaserOff_200=cell(size(SingleUnitIndex,1),1);
p_LaserOff_500=cell(size(SingleUnitIndex,1),1);Sign_LaserOff_500=cell(size(SingleUnitIndex,1),1);
p_LaserOff_1000=cell(size(SingleUnitIndex,1),1);Sign_LaserOff_1000=cell(size(SingleUnitIndex,1),1);

p_LaserEarlyDelay_100=cell(size(SingleUnitIndex,1),1);Sign_LaserEarlyDelay_100=cell(size(SingleUnitIndex,1),1);
p_LaserEarlyDelay_200=cell(size(SingleUnitIndex,1),1);Sign_LaserEarlyDelay_200=cell(size(SingleUnitIndex,1),1);
p_LaserEarlyDelay_500=cell(size(SingleUnitIndex,1),1);Sign_LaserEarlyDelay_500=cell(size(SingleUnitIndex,1),1);
p_LaserEarlyDelay_1000=cell(size(SingleUnitIndex,1),1);Sign_LaserEarlyDelay_1000=cell(size(SingleUnitIndex,1),1);

p_LaserLateDelay_100=cell(size(SingleUnitIndex,1),1);Sign_LaserLateDelay_100=cell(size(SingleUnitIndex,1),1);
p_LaserLateDelay_200=cell(size(SingleUnitIndex,1),1);Sign_LaserLateDelay_200=cell(size(SingleUnitIndex,1),1);
p_LaserLateDelay_500=cell(size(SingleUnitIndex,1),1);Sign_LaserLateDelay_500=cell(size(SingleUnitIndex,1),1);
p_LaserLateDelay_1000=cell(size(SingleUnitIndex,1),1);Sign_LaserLateDelay_1000=cell(size(SingleUnitIndex,1),1);

for iNeuron = 1: size(SingleUnitIndex,1)
    % 100ms bin
    for iBin = 1: 201
        [p_LaserEarlyDelay_100{iNeuron,1}(1,iBin),Sign_LaserEarlyDelay_100{iNeuron,1}(1,iBin)]=ranksumTest(SpikeCounts_LaserOff{iNeuron,1}(:,iBin),SpikeCounts_LaserEarlyDelay{iNeuron,1}(:,iBin),0);
        [p_LaserLateDelay_100{iNeuron,1}(1,iBin),Sign_LaserLateDelay_100{iNeuron,1}(1,iBin)]=ranksumTest(SpikeCounts_LaserOff{iNeuron,1}(:,iBin),SpikeCounts_LaserLateDelay{iNeuron,1}(:,iBin),0);
    end
    % 200ms bin
    

    for iBin1= 1:100
        [p_LaserEarlyDelay_200{iNeuron,1}(1,iBin),Sign_LaserEarlyDelay_200{iNeuron,1}(1,iBin)]=ranksumTest(SpikeCounts_LaserOff{iNeuron,1}(:,iBin1),SpikeCounts_LaserEarlyDelay{iNeuron,1}(:,iBin1),0);
        [p_LaserLateDelay_200{iNeuron,1}(1,iBin),Sign_LaserLateDelay_200{iNeuron,1}(1,iBin)]=ranksumTest(SpikeCounts_LaserOff{iNeuron,1}(:,iBin1),SpikeCounts_LaserLateDelay{iNeuron,1}(:,iBin1),0);
    end
    
    % 500ms bin
    for iBin2= 1:40
        
        
    end
    % 1s
    for iBin3= 1:20
        
    end
    
end