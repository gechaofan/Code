function PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,DelayIncreasedUnitIndex_LaserOn...
    ,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
figure('color',[1 1 1])
Max=2;
h1=area([0 FirstOdorLen],Max*[1 1],-2);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],Max*[1 1],-2);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],Max*[1 1],-2);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
box off
X=[-2+0.1:0.1:20-2+0.1];

tempx1=smooth(mean(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1)-std(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),0,1)/sqrt(length(DelayIncreasedUnitIndex_LaserOn)-1),1,'moving')';
tempx2=smooth(mean(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1)+std(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),0,1)/sqrt(length(DelayIncreasedUnitIndex_LaserOn)-1),1,'moving')';
fill([X,fliplr(X)],[tempx1,fliplr(tempx2)],[0 0 0],'edgecolor','none','facealpha',0.3)

tempy1=smooth(mean(LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1)-std(LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),0,1)/sqrt(length(DelayIncreasedUnitIndex_LaserOn)-1),1,'moving')';
tempy2=smooth(mean(LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1)+std(LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),0,1)/sqrt(length(DelayIncreasedUnitIndex_LaserOn)-1),1,'moving')';
fill([X,fliplr(X)],[tempy1,fliplr(tempy2)],...
    [0 0 1],'edgecolor','none','facealpha',0.3)
plot(X,smooth(mean(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1),1,'moving'),'k','LineWidth',1.5)
hold on
plot(X,smooth(mean(LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,:),1),1,'moving'),'b','LineWidth',1.5)
plot(X,zeros(1,size(X,2)),'LineStyle','--','col',[0 0 0])
for i = 1 : size(LaserOff_MeanFR,2)
    p(i) = signrank(LaserOff_MeanFR(DelayIncreasedUnitIndex_LaserOn,i),LaserOn_MeanFR(DelayIncreasedUnitIndex_LaserOn,i));
    if (p(i)< 0.05)
        plot(-2+0.1*i,1.2,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','.','LineStyle','none');
        hold on
    end
end
end