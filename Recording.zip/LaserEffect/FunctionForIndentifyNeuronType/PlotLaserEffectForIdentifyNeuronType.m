function PlotReMapLaserEffectForIdentifyNeuronType(UnitSpikes,ReMapLaser,CycleNum)
ReMapLaserTimeStamp= ReMapLaser(:,1)-ReMapLaser(1,1);
plot([ReMapLaserTimeStamp';ReMapLaserTimeStamp'],[(CycleNum+1)*ones(1,length(ReMapLaserTimeStamp))-0.3;(CycleNum+1)*ones(1,length(ReMapLaserTimeStamp))+0.3],'color',[0 0 1], 'LineWidth',1);
hold on
for Cycle = 1 : CycleNum
    SpikeTimeStamp=[];
    SpikeTimeStamp=UnitSpikes(UnitSpikes>ReMapLaser(1,Cycle)-0.5&UnitSpikes<ReMapLaser(end,Cycle)+0.5)...
        -ReMapLaser(1,Cycle);
    plot([SpikeTimeStamp'; SpikeTimeStamp'],...
        [ Cycle*ones(1,length(SpikeTimeStamp))-0.3; Cycle*ones(1,length(SpikeTimeStamp))+0.3],'color',[0 0 0])
    hold on
end
xlabel('Time (Sec)');% Create xlabel
ylabel('TrialIndex');% Create ylabel