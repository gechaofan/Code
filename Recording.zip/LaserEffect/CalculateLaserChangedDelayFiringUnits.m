%% %% calculate delay activity unit
load('LaserOn&Off-PopulationNeuralActivity_RemoveRepeatedUnit');
%%% Laser off Delay-activity Unit
LaserOffFR_1s=ReDefineBinSize(LaserOffAllTrialsFR,1000,100);
LaserOnFR_1s=ReDefineBinSize(LaserOnAllTrialsFR,1000,100);
p_LaserOff=NaN*ones(size(AllUnitID,1),20);Larger_LaserOff=NaN*ones(size(AllUnitID,1),20);Reults_LaserOff=NaN*ones(size(AllUnitID,1),20);
p_LaserOn=NaN*ones(size(AllUnitID,1),20);Larger_LaserOn=NaN*ones(size(AllUnitID,1),20);Reults_LaserOn=NaN*ones(size(AllUnitID,1),20);
for i = 1 : size(AllUnitID,1)
    for j = 1:20
        p_LaserOff(i,j) = ranksum(LaserOffFR_1s{i,:}(:,2),LaserOffFR_1s{i,:}(:,j));
        Larger_LaserOff(i,j) = mean(LaserOffFR_1s{i,:}(:,2))-mean(LaserOffFR_1s{i,:}(:,j));
        if p_LaserOff(i,j)<0.05&&Larger_LaserOff(i,j)<0
            Reults_LaserOff(i,j)=1;
        elseif p_LaserOff(i,j)<0.05&&Larger_LaserOff(i,j)>0
            Reults_LaserOff(i,j)=-1;
        else
            Reults_LaserOff(i,j)=0;
        end
        p_LaserOn(i,j) = ranksum(LaserOnFR_1s{i,:}(:,2),LaserOnFR_1s{i,:}(:,j));
        Larger_LaserOn(i,j) = mean(LaserOnFR_1s{i,:}(:,2))-mean(LaserOnFR_1s{i,:}(:,j));
        if p_LaserOn(i,j)<0.05&&Larger_LaserOn(i,j)<0
            Reults_LaserOn(i,j)=1;
        elseif p_LaserOn(i,j)<0.05&&Larger_LaserOn(i,j)>0
            Reults_LaserOn(i,j)=-1;
        else
            Reults_LaserOn(i,j)=0;
        end
    end
end


%%% Laser on Delay-activity Unit
DelayDecreasedUnitIndex_LaserOff=find(mean(Reults_LaserOff(:,4:9),2)<0);
DelayIncreasedUnitIndex_LaserOff=find(mean(Reults_LaserOff(:,4:9),2)>0);
DelayUnchangedUnitIndex_LaserOff=[1:1:size(AllUnitID,1)]';
DelayUnchangedUnitIndex_LaserOff([DelayDecreasedUnitIndex_LaserOff;DelayIncreasedUnitIndex_LaserOff])=[];

DelayDecreasedUnitIndex_LaserOn=find(mean(Reults_LaserOn(:,4:9),2)<0);
DelayIncreasedUnitIndex_LaserOn=find(mean(Reults_LaserOn(:,4:9),2)>0);
DelayUnchangedUnitIndex_LaserOn=[1:1:size(AllUnitID,1)]';
DelayUnchangedUnitIndex_LaserOn([DelayDecreasedUnitIndex_LaserOn;DelayIncreasedUnitIndex_LaserOn])=[];

LaserOff_MeanFR=[];LaserOn_MeanFR=[];
for i =1 : size(AllUnitID,1)
    LaserOff_MeanFR(i,:)=mean((LaserOffAllTrialsFR{i,1}-mean(mean(LaserOffAllTrialsFR{i,1}(:,10:19),2)))/std(mean(LaserOffAllTrialsFR{i,1}(:,10:19),2),0,1),1);
    LaserOn_MeanFR(i,:)=mean((LaserOnAllTrialsFR{i,1}-mean(mean(LaserOnAllTrialsFR{i,1}(:,10:19),2)))/std(mean(LaserOnAllTrialsFR{i,1}(:,10:19),2),0,1),1);
end

%%
PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,[1:1:size(AllUnitID,1)]',FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-AllUnit-' num2str(size(AllUnitID,1))],'fig')
saveas(gcf,['NormalizedFR-AllUnit-' num2str(size(AllUnitID,1))],'png')
close all
PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,FRChangedUnitID,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-LaserChangedUnit-' num2str(length(FRChangedUnitID))],'fig')
saveas(gcf,['NormalizedFR-LaserChangedUnit-' num2str(length(FRChangedUnitID))],'png')
close all

PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,FRDncreasedID,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-LaserDecreasedUnit-' num2str(length(FRDncreasedID))],'fig')
saveas(gcf,['NormalizedFR-LaserDecreasedUnit-' num2str(length(FRDncreasedID))],'png')
close all
PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,FRIncreasedID,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-LaserIncreasedUnit-' num2str(length(FRIncreasedID))],'fig')
saveas(gcf,['NormalizedFR-LaserIncreasedUnit-' num2str(length(FRIncreasedID))],'png')
close all


PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,DelayDecreasedUnitIndex_LaserOff,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-DelayDecreasedUnit-LaserOff-' num2str(length(DelayDecreasedUnitIndex_LaserOff))],'fig')
saveas(gcf,['NormalizedFR-DelayDecreasedUnit-LaserOff-' num2str(length(DelayDecreasedUnitIndex_LaserOff))],'png')
close all

PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,DelayDecreasedUnitIndex_LaserOn,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-DelayDecreasedUnit-LaserOn-' num2str(length(DelayDecreasedUnitIndex_LaserOn))],'fig')
saveas(gcf,['NormalizedFR-DelayDecreasedUnit-LaserOn-' num2str(length(DelayDecreasedUnitIndex_LaserOn))],'png')
close all
PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,DelayIncreasedUnitIndex_LaserOff,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-DelayIncreasedUnit-LaserOff-' num2str(length(DelayIncreasedUnitIndex_LaserOff))],'fig')
saveas(gcf,['NormalizedFR-DelayIncreasedUnit-LaserOff-' num2str(length(DelayIncreasedUnitIndex_LaserOff))],'png')
close all
PlotMeanFiringRateOfLaserChangeUnit(LaserOff_MeanFR,LaserOn_MeanFR,DelayIncreasedUnitIndex_LaserOn,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen)
saveas(gcf,['NormalizedFR-DelayIncreasedUnit-LaserOn-' num2str(length(DelayIncreasedUnitIndex_LaserOn))],'fig')
saveas(gcf,['NormalizedFR-DelayIncreasedUnit-LaserOn-' num2str(length(DelayIncreasedUnitIndex_LaserOn))],'png')
close all
%% 
bar([1 5],[153 45]/475,'FaceColor','k','BarWidth',0.2)
hold on
bar([2 6],[142 148]/475,'FaceColor','r','BarWidth',0.2)
bar([3 7],[180 282]/475,'FaceColor','b','BarWidth',0.2)

  