% modulation index of optogenetic excitation
% FR-LaserOn / FR-LaserOff
idx_E_Changed;idx_E_Inc;idx_E_Dec;
idx_L_Changed;idx_L_Inc;idx_L_Dec;


FR_Off_1s = ReDefineBinSize(LaserOffAllTrialsFR,1000,100);% laser off
FR_Early_1s = ReDefineBinSize(LaserOnAllTrialsFR_EarlyDelay,1000,100);
FR_Late_1s = ReDefineBinSize(LaserOnAllTrialsFR_LateDelay,1000,100);
M_FR_Off_1s = cell2mat(cellfun(@(x) mean(x,1),FR_Off_1s, 'un', 0));
M_FR_Early_1s = cell2mat(cellfun(@(x) mean(x,1),FR_Early_1s, 'un', 0));
M_FR_Late_1s = cell2mat(cellfun(@(x) mean(x,1),FR_Late_1s, 'un', 0));
ModulationIndex_Early = M_FR_Early_1s./M_FR_Off_1s;
ModulationIndex_Late = M_FR_Late_1s./M_FR_Off_1s;
figure

plot(mean(ModulationIndex_Early(idx_E_Inc,:)-1,1))
hold on
plot(mean(ModulationIndex_Early(idx_E_Dec,:)-1,1))
plot(mean(ModulationIndex_Late(idx_L_Inc,:)-1,1),'--')
plot(mean(ModulationIndex_Late(idx_L_Dec,:)-1,1),'--')




FR_Off_05s = ReDefineBinSize(LaserOffAllTrialsFR,500,100);% laser off
FR_Early_05s = ReDefineBinSize(LaserOnAllTrialsFR_EarlyDelay,500,100);
FR_Late_05s = ReDefineBinSize(LaserOnAllTrialsFR_LateDelay,500,100);
M_FR_Off_05s = cell2mat(cellfun(@(x) mean(x,1),FR_Off_05s, 'un', 0));
M_FR_Early_05s = cell2mat(cellfun(@(x) mean(x,1),FR_Early_05s, 'un', 0));
M_FR_Late_05s = cell2mat(cellfun(@(x) mean(x,1),FR_Late_05s, 'un', 0));
ModulationIndex_Early_1 = M_FR_Early_05s./M_FR_Off_05s-1;
ModulationIndex_Late_1 = M_FR_Late_05s./M_FR_Off_05s-1;



Error_Inc_E = std(ModulationIndex_Early_1(idx_E_Inc,:),0,1)/sqrt(size(idx_E_Inc,1)-1);
Error_Dec_E = std(ModulationIndex_Early_1(idx_E_Dec,:),0,1)/sqrt(size(idx_E_Dec,1)-1);
Error_Non_E = std(ModulationIndex_Early_1(setdiff(Learn_UnitIndex_CLE,idx_E_Changed),:),0,1)/sqrt(size(setdiff(Learn_UnitIndex_CLE,idx_E_Changed),1)-1);
Error_Inc_L = std(ModulationIndex_Late_1(idx_L_Inc,:),0,1)/sqrt(size(idx_L_Inc,1)-1);
Error_Dec_L = std(ModulationIndex_Late_1(idx_L_Dec,:),0,1)/sqrt(size(idx_L_Dec,1)-1);
Error_Non_L = std(ModulationIndex_Late_1(setdiff(Learn_UnitIndex_CLE,idx_L_Changed),:),0,1)/sqrt(size(setdiff(Learn_UnitIndex_CLE,idx_L_Changed),1)-1);

figure
% plot(mean(ModulationIndex_Early_1(idx_E_Inc,7:10)-1,1))
% hold on
% plot(mean(ModulationIndex_Early_1(idx_E_Dec,7:10)-1,1))
errorbar([1:1:4],mean(ModulationIndex_Late_1(idx_L_Inc,15:18),1),Error_Inc_L(15:18),'-b')
hold on
errorbar([1:1:4],mean(ModulationIndex_Late_1(idx_L_Dec,15:18),1),Error_Dec_L(15:18),'--b')
errorbar([1:1:4],mean(ModulationIndex_Late_1(setdiff(Learn_UnitIndex_CLE,idx_L_Changed),15:18),1),Error_Non_L(15:18),'--k')
plot([0.5 4.5],[0 0],'--k')
set(gca,'Xlim',[0.5,4.5],'XTickLabel',{'1','2','3','4'},'XTick',[0,1,2,3,4],'YLim',[-0.3,0.6],'YTickLabel',{'-0.3','0','0.3','0.6'},'YTick',[-.3,0,0.3,0.6])
xlabel('Bin ');ylabel('Modulation index')
saveas(gcf, ['ModulationIndex_Late' DateID],'fig')
saveas(gcf, ['ModulationIndex_Late' DateID],'png')
for i = 1 : 40
    [~,p_Inc_E(1,i),~,~] = ttest(ModulationIndex_Early_1(idx_E_Inc,i));
    [~,p_Dec_E(1,i),~,~] = ttest(ModulationIndex_Early_1(idx_E_Dec,i));
    [~,p_Non_E(1,i),~,~] = ttest(ModulationIndex_Early_1(setdiff(Learn_UnitIndex_CLE,idx_E_Changed),i));
    
    [~,p_Inc_L(1,i),~,~] = ttest(ModulationIndex_Late_1(idx_L_Inc,i));
    [~,p_Dec_L(1,i),~,~] = ttest(ModulationIndex_Late_1(idx_L_Dec,i));
    [~,p_Non_L(1,i),~,~] = ttest(ModulationIndex_Late_1(setdiff(Learn_UnitIndex_CLE,idx_L_Changed),i));
end
Stat_LaserModulation.p_Early =  [p_Inc_E;p_Dec_E;p_Non_E];
Stat_LaserModulation.p_Late =  [p_Inc_L;p_Dec_L;p_Non_L];

%% firing rate for correct and error trials
idx_hit_1 = cellfun(@(x) find(x(:,4)==1), Trials1,'un',0);
idx_miss_1 = cellfun(@(x) find(x(:,4)==2), Trials1,'un',0);
idx_fa_1 = cellfun(@(x) find(x(:,4)==3), Trials1,'un',0);
idx_cr_1 = cellfun(@(x) find(x(:,4)==4), Trials1,'un',0);

idx_hit_2 = cellfun(@(x) find(x(:,4)==1), Trials2,'un',0);
idx_miss_2 = cellfun(@(x) find(x(:,4)==2), Trials2,'un',0);
idx_fa_2 = cellfun(@(x) find(x(:,4)==3), Trials2,'un',0);
idx_cr_2 = cellfun(@(x) find(x(:,4)==4), Trials2,'un',0);

idx_hit_3 = cellfun(@(x) find(x(:,4)==1), Trials2,'un',0);
idx_miss_3 = cellfun(@(x) find(x(:,4)==2), Trials2,'un',0);
idx_fa_3 = cellfun(@(x) find(x(:,4)==3), Trials2,'un',0);
idx_cr_3 = cellfun(@(x) find(x(:,4)==4), Trials2,'un',0);

fr_hit_1 = cellfun(@(x,y) x(y,:), LaserOffAllTrialsFR,idx_hit_1,'un',0);
fr_miss_1 = cellfun(@(x,y) x(y,:), LaserOffAllTrialsFR,idx_miss_1,'un',0);
fr_fa_1 = cellfun(@(x,y) x(y,:), LaserOffAllTrialsFR,idx_fa_1,'un',0);
fr_cr_1 = cellfun(@(x,y) x(y,:), LaserOffAllTrialsFR,idx_cr_1,'un',0);

fr_hit_2 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_EarlyDelay,idx_hit_2,'un',0);
fr_miss_2 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_EarlyDelay,idx_miss_2,'un',0);
fr_fa_2 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_EarlyDelay,idx_fa_2,'un',0);
fr_cr_2 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_EarlyDelay,idx_cr_2,'un',0);

fr_hit_3 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_LateDelay,idx_hit_3,'un',0);
fr_miss_3 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_LateDelay,idx_miss_3,'un',0);
fr_fa_3 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_LateDelay,idx_fa_3,'un',0);
fr_cr_3 = cellfun(@(x,y) x(y,:), LaserOnAllTrialsFR_LateDelay,idx_cr_3,'un',0);

CompareFRForSpecificTrialsCrossNeuron(fr_hit_1(idx_E_Inc,:),fr_fa_1(idx_E_Inc,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[1 0 0]);
saveas(gcf, ['NormFR-NegativeDelayActivity-LaserOffandOn-Late_Learn'],'png')
saveas(gcf, ['NormFR-NegativeDelayActivity-LaserOffandOn-Late_Learn'],'fig')


NormFR_Off_05s = ReDefineBinSize(NormAllTrialsFR_LaserOff,500,100);% laser off
NormFR_Early_05s = ReDefineBinSize(NormAllTrialsFR_LaserOnEarlyDelay,500,100);
NormFR_Late_05s = ReDefineBinSize(NormAllTrialsFR_LaserOnLateDelay,500,100);
M_NormFR_Off_05s = cell2mat(cellfun(@(x) mean(x,1),NormFR_Off_05s, 'un', 0));
M_NormFR_Early_05s = cell2mat(cellfun(@(x) mean(x,1),NormFR_Early_05s, 'un', 0));
M_NormFR_Late_05s = cell2mat(cellfun(@(x) mean(x,1),NormFR_Late_05s, 'un', 0));
clear('ConDayPer','ExpDayPer','X','temp1','temp2','temp3','temp4')
ConDayPer= M_NormFR_Off_05s(idx_E_Inc,7:10);ExpDayPer= M_NormFR_Off_05s(idx_E_Dec,7:10);

ConDayPer= M_NormFR_Off_05s(idx_L_Inc,15:18);ExpDayPer= M_NormFR_Off_05s(idx_L_Dec,15:18);

temp1=[ConDayPer' ExpDayPer'];
    temp2=[ones(size(ConDayPer')) 2*ones(size(ExpDayPer'))];
    temp3=[1:1:4]'*ones(1,size([ConDayPer' ExpDayPer'],2));
    temp4=ones(size([ConDayPer' ExpDayPer'],1),1)*[1:1:size([ConDayPer' ExpDayPer'],2)];
    X(:,1)=reshape(temp1,[],1);
    X(:,2)=reshape(temp2,[],1);
    X(:,3)=reshape(temp3,[],1);
    X(:,4)=reshape(temp4,[],1);
    suppress_output=0;
    [~, ~, ~, ~, Ps]=mixed_between_within_anova(X,suppress_output,'Early-Inc_Dec')

ranksum(nanmean(ConDayPer,1),nanmean(ExpDayPer,1))
ranksum(nanmean(ConDayPer,1),nanmean(ExpDayPer,1))



