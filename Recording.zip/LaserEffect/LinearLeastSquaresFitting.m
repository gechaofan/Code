function [fitresult, gof]= LinearLeastSquaresFitting(xData,yData,Title)  
figure ('color', [1 1 1])
%     color(jet);    
    ft = fittype( 'poly1' );% Set up fittype and options.
    opts = fitoptions( 'Method', 'LinearLeastSquares' );
    opts.Robust = 'OFF';
    [fitresult, gof] = fit( xData, yData, ft, opts );% Fit model to data.
%     figure( 'Name', 'untitled fit 1' );
    h = plot( fitresult, xData, yData );% Plot fit with data.
    legend( h, 'xData vs. yData', 'untitled fit 1', 'Location', 'NorthEast' );
    hold on
     x=[-20:20];y=x;plot(x,y,'LineStyle','--','color',[0 0 0]);  
    xlabel('xData');% Label axes
    ylabel ('yData');
%     Title=num2str(i);
%     saveas(gcf,['NormFR-DelayActivity' Title],'fig')
%     saveas(gcf,['NormFR-DelayActivity' Title],'png')
%     close all