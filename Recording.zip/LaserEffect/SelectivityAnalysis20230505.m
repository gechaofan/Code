
SelectIndex_Off_1s=zeros(750,40); SelectIndex_E_1s=zeros(750,40); SelectIndex_L_1s=zeros(750,40);
SelectIndex_Off_1s(find(Selectivity.Laseroff{1,2}<0.05/2))=1;
SelectIndex_E_1s(find( Selectivity.LaserEarly{1,2}<0.05/2))=1; 
SelectIndex_L_1s(find( Selectivity.LaserLate{1,2}<0.05/2))=1;

tempSig_Off_1s=mat2cell(SelectIndex_Off_1s(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Sig_Off_1s=cellfun(@sum,tempSig_Off_1s);
tempSig_E_1s=mat2cell(SelectIndex_E_1s(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Sig_E_1s=cellfun(@sum,tempSig_E_1s);
tempSig_L_1s=mat2cell(SelectIndex_L_1s(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Sig_L_1s=cellfun(@sum,tempSig_L_1s);

tempSelc_Off_1s=mat2cell(Selectivity.Laseroff{1,1}(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Selc_Off_1s=cellfun(@mean,tempSelc_Off_1s);
tempSelc_E_1s=mat2cell(Selectivity.LaserEarly{1,1}(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Selc_E_1s=cellfun(@mean,tempSelc_E_1s);
tempSelc_L_1s=mat2cell(Selectivity.LaserLate{1,1}(:,1:40),ones(1,750),2*ones(1,40/2));% sig
Selc_L_1s=cellfun(@mean,tempSelc_L_1s);
%% 2s
SelectIndex_Off_2s=zeros(750,40); SelectIndex_E_2s=zeros(750,40); SelectIndex_L_2s=zeros(750,40);
SelectIndex_Off_2s(find(Selectivity.Laseroff{1,2}<0.05/4))=1;
SelectIndex_E_2s(find( Selectivity.LaserEarly{1,2}<0.05/4))=1; 
SelectIndex_L_2s(find( Selectivity.LaserLate{1,2}<0.05/4))=1;

tempSig_Off_2s=mat2cell(SelectIndex_Off_1s(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Sig_Off_2s=cellfun(@sum,tempSig_Off_2s);
tempSig_E_2s=mat2cell(SelectIndex_E_2s(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Sig_E_2s=cellfun(@sum,tempSig_E_2s);
tempSig_L_2s=mat2cell(SelectIndex_L_2s(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Sig_L_2s=cellfun(@sum,tempSig_L_2s);

tempSelc_Off_2s=mat2cell(Selectivity.Laseroff{1,1}(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Selc_Off_2s=cellfun(@mean,tempSelc_Off_2s);
tempSelc_E_2s=mat2cell(Selectivity.LaserEarly{1,1}(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Selc_E_2s=cellfun(@mean,tempSelc_E_2s);
tempSelc_L_2s=mat2cell(Selectivity.LaserLate{1,1}(:,7:18),ones(1,750),4*ones(1,12/4));% sig
Selc_L_2s=cellfun(@mean,tempSelc_L_2s);

% for laser changed units
Sig_Off_2s_changed_E=Sig_Off_2s(idx_changed_early,:);% significant or not 1/0
Sig_E_2s_changed_E=Sig_E_2s(idx_changed_early,:);
Selc_Off_2s_changed_E=Selc_Off_2s(idx_changed_early,:);%  selectivity value
Selc_E_2s_changed_E=Selc_E_2s(idx_changed_early,:);

Sig_Off_2s_changed_L=Sig_Off_2s(idx_changed_late,:);% significant or not 1/0
Sig_L_2s_changed_L=Sig_L_2s(idx_changed_late,:);
Selc_Off_2s_changed_L=Selc_Off_2s(idx_changed_late,:);%  selectivity value
Selc_L_2s_changed_L=Selc_L_2s(idx_changed_late,:);
for iBin = 1 : 3
    for iStep = 1:20
        tempIndex1=[];tempIndex2=[];tempIndex11=[];tempIndex3=[];
        tempIndex1=find(Selc_Off_2s_changed_E(:,iBin)>0.1*(iStep-1)-1 & Selc_Off_2s_changed_E(:,iBin)<=0.1*iStep-1);
        tempIndex2=find(Selc_E_2s_changed_E(:,iBin)>0.1*(iStep-1)-1 & Selc_E_2s_changed_E(:,iBin)<=0.1*iStep-1);
        tempIndex11=find(Selc_Off_2s_changed_L(:,iBin)>0.1*(iStep-1)-1 & Selc_Off_2s_changed_L(:,iBin)<=0.1*iStep-1);
        tempIndex3=find(Selc_L_2s_changed_L(:,iBin)>0.1*(iStep-1)-1 & Selc_L_2s_changed_L(:,iBin)<=0.1*iStep-1);
        
        Num_Sig_Off_E(iStep,iBin)=sum(Sig_Off_2s_changed_E(tempIndex1,iBin));
        Num_Sig_E(iStep,iBin)=sum(Sig_E_2s_changed_E(tempIndex2,iBin));
        Num_Sig_Off_L(iStep,iBin)=sum(Sig_Off_2s_changed_L(tempIndex11,iBin));
        Num_Sig_L(iStep,iBin)=sum(Sig_L_2s_changed_L(tempIndex3,iBin));
        
        Num_nonSig_Off_E(iStep,iBin)=length(tempIndex1)-sum(Sig_Off_2s_changed_E(tempIndex1,iBin));
        Num_nonSig_E(iStep,iBin)=length(tempIndex2)-sum(Sig_E_2s_changed_E(tempIndex2,iBin));
        Num_nonSig_Off_L(iStep,iBin)=length(tempIndex11)-sum(Sig_Off_2s_changed_L(tempIndex11,iBin));
        Num_nonSig_L(iStep,iBin)=length(tempIndex3)-sum(Sig_L_2s_changed_L(tempIndex3,iBin));
    end 
end
for i = 1:3
    figure
    bar([-0.95:0.1:0.95]',[Num_Sig_E(:,i) Num_nonSig_E(:,i)]/232*100,'stack')
    xlabel('Selective index');% Create xlabel
    ylabel('Fraction of neurons (%)');% Create ylabel
    box off
    set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1'},'XTick',[-1,-0.5,0,0.5,1],'YLim',[0,60])
    saveas(gcf, ['DistributionForSelectivity-EarlyChangedUnits-LaserOn-Delay-' num2str(i)],'fig')
    saveas(gcf, ['DistributionForSelectivity-EarlyChangedUnits-LaserOn-Delay-' num2str(i)],'png')    
end


for i = 1:3
    [idx_sig_off_E,idx_sig_E,idx_sig_both,idx_nonsig_both] = deal([]);
    idx_sig_off_E=find(Sig_Off_2s_changed_E(:,i)>0);
    idx_sig_E = find(Sig_E_2s_changed_E(:,i)>0);
    idx_sig_both = intersect(idx_sig_off_E,idx_sig_E);
    idx_nonsig_both = intersect(setdiff([1:1:232]',idx_sig_off_E),setdiff([1:1:232]',idx_sig_E));
   figure
% plot(x,y,'LineStyle','--','Color',[0.7 0.7 0.7])
% hold on
% plot(x,[0 0],'LineStyle','-','Color',[0 0 0])
% plot([0 0],y,'LineStyle','-','Color',[0 0 0])
scatter(Selc_Off_2s_changed_E(idx_nonsig_both,i),Selc_E_2s_changed_E(idx_nonsig_both,i),'MarkerEdgeColor',[0.5 0.5 0.5],'Marker','.')
hold on
scatter(Selc_Off_2s_changed_E(setdiff(idx_sig_off_E,idx_sig_both),i),Selc_E_2s_changed_E(setdiff(idx_sig_off_E,idx_sig_both),i),'MarkerEdgeColor',[0 0 0],'Marker','.')
scatter(Selc_Off_2s_changed_E(setdiff(idx_sig_E,idx_sig_both),i),Selc_E_2s_changed_E(setdiff(idx_sig_E,idx_sig_both),i),'MarkerEdgeColor',[1 0 0],'Marker','.')
scatter(Selc_Off_2s_changed_E(idx_sig_both,i),Selc_E_2s_changed_E(idx_sig_both,i),'MarkerEdgeColor',[0.5 0 0],'Marker','diamond')
title(['201-22-6-3'])
box off
set(gca,'Xlim',[0,5],'Ylim',[0,5])
xlabel('Selectivity-laseroff');% Create xlabel
ylabel('selelctivity-laserEarly');% Create Xlabel
saveas(gcf, ['Selectivity-for-Each-FRChangedunit-Early-' num2str(i)],'fig')
saveas(gcf, ['Selectivity-for-Each-FRChangedunit-Early-' num2str(i)],'png') 
    
end

%% bootstrap selectivity by mean
% for learn units
Sig_Off_1s_learn=Sig_Off_1s(Learn_UnitIndex_CLE,:);% significant or not 1/0
Sig_E_1s_learn=Sig_E_1s(Learn_UnitIndex_CLE,:);
Sig_L_1s_learn=Sig_L_1s(Learn_UnitIndex_CLE,:);

Selc_Off_1s_learn=Selc_Off_1s(Learn_UnitIndex_CLE,:);%  selectivity value
Selc_E_1s_learn=Selc_E_1s(Learn_UnitIndex_CLE,:);
Selc_L_1s_learn=Selc_L_1s(Learn_UnitIndex_CLE,:);


for iBin = 1 : 20
    for iStep = 1:20
        tempIndex1=[];tempIndex2=[];tempIndex3=[];
        tempIndex1=find(Selc_Off_1s_learn(:,iBin)>0.1*(iStep-1)-1 & Selc_Off_1s_learn(:,iBin)<=0.1*iStep-1);
        tempIndex2=find(Selc_E_1s_learn(:,iBin)>0.1*(iStep-1)-1 & Selc_E_1s_learn(:,iBin)<=0.1*iStep-1);
        tempIndex3=find(Selc_L_1s_learn(:,iBin)>0.1*(iStep-1)-1 & Selc_L_1s_learn(:,iBin)<=0.1*iStep-1);
        Num_Sig_Off(iStep,iBin)=sum(Sig_Off_1s_learn(tempIndex1,iBin));
        Num_Sig_E(iStep,iBin)=sum(Sig_Off_1s_learn(tempIndex2,iBin));
        Num_Sig_L(iStep,iBin)=sum(Sig_Off_1s_learn(tempIndex3,iBin));
        Num_nonSig_Off(iStep,iBin)=length(tempIndex1)-sum(Sig_Off_1s_learn(tempIndex1,iBin));
        Num_nonSig_E(iStep,iBin)=length(tempIndex2)-sum(Sig_Off_1s_learn(tempIndex2,iBin));
        Num_nonSig_L(iStep,iBin)=length(tempIndex3)-sum(Sig_Off_1s_learn(tempIndex3,iBin));
    end 
end
for i = 3:9
    figure
    bar([-0.95:0.1:0.95]',[Num_Sig_L(:,i) Num_nonSig_L(:,i)]/471*100,'stack')
    xlabel('Selective index');% Create xlabel
    ylabel('Fraction of neurons (%)');% Create ylabel
    box off
    set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1'},'XTick',[-1,-0.5,0,0.5,1],'YLim',[0,40])
    saveas(gcf, ['DistributionForSelectivity-LaserLate-' num2str(i)],'fig')
    saveas(gcf, ['DistributionForSelectivity-LaserLate-' num2str(i)],'png')    
end


% bootstrapping the selectivity by the mean
clear('bootsam_Off','bootsam_E','bootsam_L');
for iBin = 1 : 20
    [~,bootsam_Off{1,iBin}]=bootstrp(1000,@mean,Selc_Off_1s_learn(:,iBin));
    [~,bootsam_E{1,iBin}]=bootstrp(1000,@mean,Selc_E_1s_learn(:,iBin));
    [~,bootsam_L{1,iBin}]=bootstrp(1000,@mean,Selc_L_1s_learn(:,iBin));
end
for iBin = 1 : 20
    for iBoot = 1 : 1000
        Sig_Off_boot{1,iBin}(:,iBoot)=Sig_Off_1s_learn(bootsam_Off{1,iBin}(:,iBoot),iBin);
        Sig_E_boot{1,iBin}(:,iBoot)=Sig_E_1s_learn(bootsam_E{1,iBin}(:,iBoot),iBin);
        Sig_L_boot{1,iBin}(:,iBoot)=Sig_L_1s_learn(bootsam_E{1,iBin}(:,iBoot),iBin);
    end
end
Num_Sig_Off_boot=cellfun(@(x) sum(x,1),Sig_Off_boot,'un',0);
Num_Sig_E_boot=cellfun(@(x) sum(x,1),Sig_E_boot,'un',0);
Num_Sig_L_boot=cellfun(@(x) sum(x,1),Sig_L_boot,'un',0);

[muHat_Off,~,muCI_Off,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_Off_boot,'un',0);
[muHat_E,~,muCI_E,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_E_boot,'un',0);
[muHat_L,~,muCI_L,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_L_boot,'un',0);
SigFraction_Off=cell2mat(muHat_Off)/471*100;
SigFraction_E=cell2mat(muHat_E)/471*100;
SigFraction_L=cell2mat(muHat_E)/471*100;
CI_Off=cell2mat(muCI_Off)/471*100;
CI_E=cell2mat(muCI_E)/471*100;
CI_L=cell2mat(muCI_L)/471*100;
figure
plot(cell2mat(muHat)/471)

%%
% SelectIndex_Off_1s(find(Selectivity.Laseroff{1,2}<0.05/2))=1;
% SelectIndex_E_1s(find( Selectivity.LaserEarly{1,2}<0.05/2))=1; 
% SelectIndex_L_1s(find( Selectivity.LaserLate{1,2}<0.05/2))=1;



%% bootstrap selectivity by mean within 500ms bin with correction; statistics for 1s
% for learn units
Sig_Off_05s_learn=SelectIndex_Off_1s(Learn_UnitIndex_CLE,:);% significant or not 1/0
Sig_E_05s_learn=SelectIndex_E_1s(Learn_UnitIndex_CLE,:);
Sig_L_05s_learn=SelectIndex_L_1s(Learn_UnitIndex_CLE,:);

Selc_Off_05s_learn=Selectivity.Laseroff{1,1}(Learn_UnitIndex_CLE,:);%  selectivity value
Selc_E_05s_learn=Selectivity.LaserEarly{1,1}(Learn_UnitIndex_CLE,:);
Selc_L_05s_learn=Selectivity.LaserLate{1,1}(Learn_UnitIndex_CLE,:);
% bootstrapping the selectivity by the mean
clear('bootsam_Off','bootsam_E','bootsam_L');
for iBin = 1 : 40
    [~,bootsam_Off_05{1,iBin}]=bootstrp(1000,@mean,Selc_Off_05s_learn(:,iBin));
    [~,bootsam_E_05{1,iBin}]=bootstrp(1000,@mean,Selc_E_05s_learn(:,iBin));
    [~,bootsam_L_05{1,iBin}]=bootstrp(1000,@mean,Selc_L_05s_learn(:,iBin));
end
clear('Sig_Off_boot_05','Sig_E_boot_05','Sig_L_boot_05');
for iBin = 1 : 40
    for iBoot = 1 : 1000
        Sig_Off_boot_05{1,iBin}(:,iBoot)=Sig_Off_05s_learn(bootsam_Off_05{1,iBin}(:,iBoot),iBin);
        Sig_E_boot_05{1,iBin}(:,iBoot)=Sig_E_05s_learn(bootsam_E_05{1,iBin}(:,iBoot),iBin);
        Sig_L_boot_05{1,iBin}(:,iBoot)=Sig_L_05s_learn(bootsam_E_05{1,iBin}(:,iBoot),iBin);
    end
end
Num_Sig_Off_boot_05=cellfun(@(x) sum(x,1),Sig_Off_boot_05,'un',0);
Num_Sig_E_boot_05=cellfun(@(x) sum(x,1),Sig_E_boot_05,'un',0);
Num_Sig_L_boot_05=cellfun(@(x) sum(x,1),Sig_L_boot_05,'un',0);

[muHat_Off_05,~,muCI_Off_05,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_Off_boot_05,'un',0);
[muHat_E_05,~,muCI_E_05,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_E_boot_05,'un',0);
[muHat_L_05,~,muCI_L_05,~]=cellfun(@(x) normfit(x,0.05),Num_Sig_L_boot_05,'un',0);
SigFraction_Off_05=cell2mat(muHat_Off_05)/471*100;
SigFraction_E_05=cell2mat(muHat_E_05)/471*100;
SigFraction_L_05=cell2mat(muHat_L_05)/471*100;
CI_Off_05=cell2mat(muCI_Off_05)/471*100;
CI_E_05=cell2mat(muCI_E_05)/471*100;
CI_L_05=cell2mat(muCI_L_05)/471*100;
X=[-1.5:0.5:18];
figure
plot(X,SigFraction_Off_05,'-k')
hold on
fill([X,fliplr(X)],[CI_Off_05(1,:),fliplr(CI_Off_05(2,:))],...
    [0 0 0],'edgecolor','none','FaceAlpha',0.3)
plot(X,SigFraction_E_05,'-r')
fill([X,fliplr(X)],[CI_E_05(1,:),fliplr(CI_E_05(2,:))],...
    [1 0 0],'edgecolor','none','FaceAlpha',0.3)
plot(X,SigFraction_L_05,'-b')
fill([X,fliplr(X)],[CI_L_05(1,:),fliplr(CI_L_05(2,:))],...
    [0 0 1],'edgecolor','none','FaceAlpha',0.3)
plot([0 1 7 8 9 10;0 1 7 8 9 10],[0 0 0 0 0 0;100 100 100 100 100 100],'--k')
xlabel('Time( s )');% Create xlabel
ylabel('Fraction of Selec. Units (%)');% Create ylabel
box off
set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[0,2,4,6,8],'YLim',[0,30],'linewidth',1)
saveas(gcf, ['FractionForSelectiveNeurons-500ms'],'fig')
saveas(gcf, ['FractionForSelectiveNeurons-500ms'],'png')








