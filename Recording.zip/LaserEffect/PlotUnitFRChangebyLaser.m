
%% plot laser changed firing rate of significant units

FRDncreasedID=find(LaserEffect.Laser_Effect_Delay<0);FRIncreasedID=find(LaserEffect.Laser_Effect_Delay>0);
Index=[FRDncreasedID;FRIncreasedID];
LaserOff_MeanFR=cell2mat(cellfun(@mean,LaserOffAllTrialsFR,'un',0));
LaserOn_MeanFR=cell2mat(cellfun(@mean,LaserOnAllTrialsFR,'un',0));

x=10*mean(LaserOff_MeanFR(Index,31:90),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y=10*mean(LaserOn_MeanFR(Index,31:90),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);
[fitresult, gof] = polyfit(x,y,1);
cftool(x,y)
hold on
plot([-10 20],[-10,20],'k')
x1=10*mean(LaserOff_MeanFR(Index,31:40),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y1=10*mean(LaserOn_MeanFR(Index,31:40),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);

x2=10*mean(LaserOff_MeanFR(Index,41:50),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y2=10*mean(LaserOn_MeanFR(Index,41:50),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);

x3=10*mean(LaserOff_MeanFR(Index,51:60),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y3=10*mean(LaserOn_MeanFR(Index,51:60),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);

x4=10*mean(LaserOff_MeanFR(Index,61:70),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y4=10*mean(LaserOn_MeanFR(Index,61:70),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);

x5=10*mean(LaserOff_MeanFR(Index,71:80),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y5=10*mean(LaserOn_MeanFR(Index,71:80),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);

x6=10*mean(LaserOff_MeanFR(Index,81:90),2)-10*mean(LaserOff_MeanFR(Index,10:19),2);
y6=10*mean(LaserOn_MeanFR(Index,81:90),2)-10*mean(LaserOn_MeanFR(Index,10:19),2);


