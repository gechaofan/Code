

idx_cor_A_1 = cellfun(@(x) find(x(1:80,2)==1& x(1:80,4)==1 | x(1:80,2)==1& x(1:80,4)==4),Trials1,'un',0);
idx_cor_B_1 = cellfun(@(x) find(x(1:80,2)==2& x(1:80,4)==1 | x(1:80,2)==2& x(1:80,4)==4),Trials1,'un',0);

idx_cor_A_2 = cellfun(@(x) find(x(1:80,2)==1& x(1:80,4)==1 | x(1:80,2)==1& x(1:80,4)==4),Trials2,'un',0);
idx_cor_B_2 = cellfun(@(x) find(x(1:80,2)==2& x(1:80,4)==1 | x(1:80,2)==2& x(1:80,4)==4),Trials2,'un',0);

idx_cor_A_3 = cellfun(@(x) find(x(1:80,2)==1& x(1:80,4)==1 | x(1:80,2)==1& x(1:80,4)==4),Trials3,'un',0);
idx_cor_B_3 = cellfun(@(x) find(x(1:80,2)==2& x(1:80,4)==1 | x(1:80,2)==2& x(1:80,4)==4),Trials3,'un',0);

fr_A_cor_1 = cellfun(@(x,y) x(y,31:90),LaserOffAllTrialsFR,idx_cor_A_1,'un',0);
fr_B_cor_1 = cellfun(@(x,y) x(y,31:90),LaserOffAllTrialsFR,idx_cor_B_1,'un',0);

fr_A_cor_2 = cellfun(@(x,y) x(y,31:90),LaserOnAllTrialsFR_EarlyDelay,idx_cor_A_2,'un',0);
fr_B_cor_2 = cellfun(@(x,y) x(y,31:90),LaserOnAllTrialsFR_EarlyDelay,idx_cor_B_2,'un',0);

fr_A_cor_3 = cellfun(@(x,y) x(y,31:90),LaserOnAllTrialsFR_LateDelay,idx_cor_A_3,'un',0);
fr_B_cor_3 = cellfun(@(x,y) x(y,31:90),LaserOnAllTrialsFR_LateDelay,idx_cor_B_3,'un',0);

A_FR_Delay_2s_off=ReDefineBinSize(fr_A_cor_1,2000,100);% laser off
B_FR_Delay_2s_off=ReDefineBinSize(fr_B_cor_1,2000,100);% laser off
A_FR_Delay_2s_early=ReDefineBinSize(fr_A_cor_2,2000,100);% laser off
B_FR_Delay_2s_early=ReDefineBinSize(fr_B_cor_2,2000,100);% laser off
A_FR_Delay_2s_late=ReDefineBinSize(fr_A_cor_3,2000,100);% laser off
B_FR_Delay_2s_late=ReDefineBinSize(fr_B_cor_3,2000,100);% laser off

% FR_ATrials_1_80_delay=cellfun(@(x) x(1:40,31:90),LaserOffAllATrialsFR,'un',0);
% FR_BTrials_1_80_delay=cellfun(@(x) x(1:40,31:90),LaserOffAllBTrialsFR,'un',0);
% FR_ATrials_2_80_delay=cellfun(@(x) x(11:50,31:90),LaserOnAllATrialsFR_EarlyDelay,'un',0);
% FR_BTrials_2_80_delay=cellfun(@(x) x(11:50,31:90),LaserOnAllBTrialsFR_EarlyDelay,'un',0);
% FR_ATrials_3_80_delay=cellfun(@(x) x(1:40,31:90),LaserOnAllATrialsFR_LateDelay,'un',0);
% FR_BTrials_3_80_delay=cellfun(@(x) x(1:40,31:90),LaserOnAllBTrialsFR_LateDelay,'un',0);
% A_FR_Delay_2s_off=ReDefineBinSize(FR_ATrials_1_80_delay,2000,100);% laser off
% B_FR_Delay_2s_off=ReDefineBinSize(FR_BTrials_1_80_delay,2000,100);% laser off
% A_FR_Delay_2s_early=ReDefineBinSize(FR_ATrials_2_80_delay,2000,100);% laser off
% B_FR_Delay_2s_early=ReDefineBinSize(FR_BTrials_2_80_delay,2000,100);% laser off
% A_FR_Delay_2s_late=ReDefineBinSize(FR_ATrials_3_80_delay,2000,100);% laser off
% B_FR_Delay_2s_late=ReDefineBinSize(FR_BTrials_3_80_delay,2000,100);% laser off
for iNeu = 1 : 750
    [Selectivity_delay_1(iNeu,:),p_delay_1(iNeu,:)]=CalculateSelectivityWithPermTest(A_FR_Delay_2s_off{iNeu,1},B_FR_Delay_2s_off{iNeu,1});
    [Selectivity_delay_2(iNeu,:),p_delay_2(iNeu,:)]=CalculateSelectivityWithPermTest(A_FR_Delay_2s_early{iNeu,1},B_FR_Delay_2s_early{iNeu,1});
    [Selectivity_delay_3(iNeu,:),p_delay_3(iNeu,:)]=CalculateSelectivityWithPermTest(A_FR_Delay_2s_late{iNeu,1},B_FR_Delay_2s_late{iNeu,1});
end
clc
for i = 1 : 3
    Sig_Sel_idx_off{1,i}=find(p_delay_1(:,i)<0.05);
    Sig_Sel_idx_early{1,i}=find(p_delay_2(:,i)<0.05);
    Sig_Sel_idx_late{1,i}=find(p_delay_3(:,i)<0.05);
end
LearnEarlyChangedUnit_idx=[Learn_E_Inc_idxs;Learn_E_Dec_idxs];
LearnLateChangedUnit_idx=[Learn_L_Inc_idxs;Learn_L_Dec_idxs];
%%
clear('both1','only1','only2','both2')
[both1,only1,only2,both2]=CaculateOverlapIndexBetween2Group(Sig_Sel_idx_off{1,1},Sig_Sel_idx_early{1,1},LearnEarlyChangedUnit_idx);
figure
scatter(abs(Selectivity_delay_1(both2,1)),abs(Selectivity_delay_2(both2,1)),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[.7 .7 .7])
hold on
scatter(abs(Selectivity_delay_1(only1,1)),abs(Selectivity_delay_2(only1,1)),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[0 0 0])
scatter(abs(Selectivity_delay_1(only2,1)),abs(Selectivity_delay_2(only2,1)),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[1 0 0])
scatter(abs(Selectivity_delay_1(both1,1)),abs(Selectivity_delay_2(both1,1)),'Marker','d','MarkerEdgeColor','none','MarkerFaceColor',[0.5 0 0])
xlabel('Laser-off selectivity');% Create xlabel
ylabel('Laser-early selectivity');% Create Xlabel
legend on
saveas(gcf, ['Selectivity_latedelay_EarlyChangedUnits'],'fig')
saveas(gcf, ['Selectivity_latedelay_EarlyChangedUnits'],'png')
%
figure
scatter(Selectivity_delay_1(both2,3),Selectivity_delay_2(both2,3),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[.7 .7 .7])
hold on
scatter(Selectivity_delay_1(only1,3),Selectivity_delay_2(only1,3),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[0 0 0])
scatter(Selectivity_delay_1(only2,3),Selectivity_delay_2(only2,3),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[1 0 0])
scatter(Selectivity_delay_1(both1,3),Selectivity_delay_2(both1,3),'Marker','d','MarkerEdgeColor','none','MarkerFaceColor',[0.5 0 0])
plot([-1 -1 0;1 1 0],[-1 0 -1;1 0 1])
xlabel('Laser-off selectivity');% Create xlabel
ylabel('Laser-early selectivity');% Create Xlabel
legend on
saveas(gcf, ['Distribution_Selectivity_latedelay_EarlyChangedUnits'],'fig')
saveas(gcf, ['Distribution_Selectivity_latedelay_EarlyChangedUnits'],'png')
%
clear('both1','only1','only2','both2')
I=3;
[both1,only1,only2,both2]=CaculateOverlapIndexBetween2Group(Sig_Sel_idx_off{1,I},Sig_Sel_idx_early{1,I},LearnEarlyChangedUnit_idx);
tempIdxs=[both1;only1;only2];
[counts,centers]=hist(abs(Selectivity_delay_2(tempIdxs,I))-abs(Selectivity_delay_1(tempIdxs,I)),30);
[~,pE,~,~]=ttest(abs(Selectivity_delay_2(tempIdxs,I))-abs(Selectivity_delay_1(tempIdxs,I)));
figure
bar(centers,counts)
hold on
plot([0 0],[0 max(counts)+2],'--k')
plot(mean(abs(Selectivity_delay_2(tempIdxs,I))-abs(Selectivity_delay_1(tempIdxs,I)),1),max(counts)+1,'Marker','v')
title(['m=' num2str(round(mean(abs(Selectivity_delay_2(tempIdxs,I))-abs(Selectivity_delay_1(tempIdxs,I)),1),6)) 'p=' num2str(round(pE,6))])
xlabel('��selectivity (on-off)');% Create xlabel
ylabel('Counts');% Create Xlabel
saveas(gcf, ['DiffSelectivity-LaserchangedUnits-earlylaser-latedelay-226'],'fig')
saveas(gcf, ['DiffSelectivity-LaserchangedUnits-earlylaser-latedelay-226'],'png')
%%
clear('both1','only1','only2','both2')
[both1,only1,only2,both2]=CaculateOverlapIndexBetween2Group(Sig_Sel_idx_off{1,1},Sig_Sel_idx_late{1,1},LearnLateChangedUnit_idx);
figure
scatter(abs(Selectivity_delay_1(both2,1)),abs(Selectivity_delay_3(both2,1)),'Marker','o','MarkerEdgeColor',[.7 .7 .7])
hold on
scatter(abs(Selectivity_delay_1(only1,1)),abs(Selectivity_delay_3(only1,1)),'Marker','o','MarkerEdgeColor',[0 0 0])
scatter(abs(Selectivity_delay_1(only2,1)),abs(Selectivity_delay_3(only2,1)),'Marker','o','MarkerEdgeColor',[0 0 1])
scatter(abs(Selectivity_delay_1(both1,1)),abs(Selectivity_delay_3(both1,1)),'Marker','d','MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 1])
plot([0 1],[0 1],'--k')
set(gca,'Xlim',[0,1],'YLim',[0 1])
xlabel('Laser-off selectivity');% Create xlabel
ylabel('Laser-Late selectivity');% Create Xlabel
saveas(gcf, ['Selectivity_middelay_LateChangedUnits-1'],'fig')
saveas(gcf, ['Selectivity_middelay_LateChangedUnits-1'],'png')
%
figure
scatter(Selectivity_delay_1(both2,1),Selectivity_delay_3(both2,1),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[.7 .7 .7])
hold on
scatter(Selectivity_delay_1(only1,1),Selectivity_delay_3(only1,1),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[0 0 0])
scatter(Selectivity_delay_1(only2,1),Selectivity_delay_3(only2,1),'Marker','o','MarkerEdgeColor','none','MarkerFaceColor',[0 0 1])
scatter(Selectivity_delay_1(both1,1),Selectivity_delay_3(both1,1),'Marker','d','MarkerEdgeColor','none','MarkerFaceColor',[0 0 0.5])
plot([-1 -1 0;1 1 0],[-1 0 -1;1 0 1])
xlabel('Laser-off selectivity');% Create xlabel
ylabel('Laser-late selectivity');% Create Xlabel
legend on
saveas(gcf, ['Distribution_Selectivity_earlydelay_LateChangedUnits'],'fig')
saveas(gcf, ['Distribution_Selectivity_earlydelay_LateChangedUnits'],'png')
%
tempIdxs=LearnLateChangedUnit_idx;
[counts,centers]=hist(abs(Selectivity_delay_3(tempIdxs,3))-abs(Selectivity_delay_1(tempIdxs,3)),30);
[~,pE,~,~]=ttest(abs(Selectivity_delay_3(tempIdxs,3))-abs(Selectivity_delay_1(tempIdxs,3)));
figure
bar(centers,counts)
hold on
plot([0 0],[0 max(counts)+2],'--k')
plot(mean(abs(Selectivity_delay_3(tempIdxs,3))-abs(Selectivity_delay_1(tempIdxs,3)),1),max(counts)+1,'Marker','v')
title(['m=' num2str(round(mean(abs(Selectivity_delay_3(tempIdxs,3))-abs(Selectivity_delay_1(tempIdxs,3)),1),6)) 'p=' num2str(round(pE,6))])
xlabel('��selectivity (on-off)');% Create xlabel
ylabel('Counts');% Create Xlabel
saveas(gcf, ['DiffSelectivity-laserchangedUnits-latelaser-middelay-260'],'fig')
saveas(gcf, ['DiffSelectivity-laserchangedUnits-latelaser-middelay-260'],'png')





