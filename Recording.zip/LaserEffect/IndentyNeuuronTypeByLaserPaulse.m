% IndentyNeuuronTypeByLaserPaulse(Laser,UnitSpikes,DataID,UnitID)
% 1Hz, 5Hz, 10Hz, 20Hz, 40Hz, duration 5ms or 10ms
% 10 paulses per block

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};
    %%
    %change the directory to the file of DataID
    cd(Path);
    %%  get Data,Trials,FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,DPALen   %%%% ITI was given as 10s
    RawDataName=ls('RawData*.mat');
    if  ~isempty(RawDataName)
        load(RawDataName);
        TaskEventName=who('event*',RawDataName);
        n =str2num(TaskEventName{1,1}(1,end));
        switch n
            case 1
                RawSpikes=RawSpikes1;
                Laser=event1.Laser.Ts;
            case 2
                RawSpikes=RawSpikes2;
                Laser=event2.Laser.Ts;
            otherwise
                RawSpikes=RawSpikes2;
                Laser=event.Laser.Ts;
        end
        DiffLaser=diff(Laser);
        tempIndex=find(DiffLaser<0.02)+1;
        Laser(tempIndex)=[];
        
        tempLaser1HzIndex=find(DiffLaser>0.9&DiffLaser<1.1)+1;
        tempLaser5HzIndex=find(DiffLaser>0.19&DiffLaser<0.21)+1;
        tempLaser10HzIndex=find(DiffLaser>0.09&DiffLaser<0.11)+1;
        tempLaser20HzIndex=find(DiffLaser>0.04&DiffLaser<0.06)+1;
        tempLaser40HzIndex=find(DiffLaser>0.02&DiffLaser<0.03)+1;
        
        CycleNum=floor(length(tempLaser1HzIndex)/9);
        Laser1Hz=zeros(10,CycleNum);
        Laser5Hz=zeros(10,CycleNum);
        Laser10Hz=zeros(10,CycleNum);
        Laser20Hz=zeros(10,CycleNum);
        Laser40Hz=zeros(10,CycleNum);
        for itr = 1: CycleNum
            Laser1HzIndex=[(itr-1)*50+1;tempLaser1HzIndex((itr-1)*9+1:itr*9,1)];
            Laser1Hz(:,itr)=Laser(Laser1HzIndex,1);
            Laser5HzIndex=[(itr-1)*50+11;tempLaser5HzIndex((itr-1)*9+1:itr*9,1)];
            Laser5Hz(:,itr)=Laser(Laser5HzIndex,1);
            Laser10HzIndex=[(itr-1)*50+21;tempLaser10HzIndex((itr-1)*9+1:itr*9,1)];
            Laser10Hz(:,itr)=Laser(Laser10HzIndex,1);
            Laser20HzIndex=[(itr-1)*50+31;tempLaser20HzIndex((itr-1)*9+1:itr*9,1)];
            Laser20Hz(:,itr)=Laser(Laser20HzIndex,1);
            Laser40HzIndex=[(itr-1)*50+41;tempLaser40HzIndex((itr-1)*9+1:itr*9,1)];
            Laser40Hz(:,itr)=Laser(Laser40HzIndex,1);
        end
        
        %% split spikes during Laser
        % plot Laser Bar
        UnitIndex=unique(RawSpikes(:,1:2),'rows');%%% RawSpikes exclude unsorted spikes; tetrode-index and number but include multiunits
        UnitNum=size(UnitIndex,1);
        for itr1=1:UnitNum
            UnitSpikes=[];
            UnitSpikes=RawSpikes(RawSpikes(:,1)==UnitIndex(itr1,1)&RawSpikes(:,2)==UnitIndex(itr1,2),3);
            UnitID=num2str(UnitIndex(itr1,1)*10+UnitIndex(itr1,2));
            PlotLaserEffectForIdentifyNeuronType(UnitSpikes,Laser1Hz,CycleNum)
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse1Hz'],'fig')
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse1Hz'],'png')
            close all
            
            PlotLaserEffectForIdentifyNeuronType(UnitSpikes,Laser5Hz,CycleNum)
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse5Hz'],'fig')
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse5Hz'],'png')
            close all
            
            PlotLaserEffectForIdentifyNeuronType(UnitSpikes,Laser10Hz,CycleNum)
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse10Hz'],'fig')
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse10Hz'],'png')
            close all
            
            PlotLaserEffectForIdentifyNeuronType(UnitSpikes,Laser20Hz,CycleNum)
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse20Hz'],'fig')
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse20Hz'],'png')
            close all
            
            PlotLaserEffectForIdentifyNeuronType(UnitSpikes,Laser40Hz,CycleNum)
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse40Hz'],'fig')
            saveas(gcf,[DataID 'Unit' UnitID '-RasterForLaserPaulse40Hz'],'png')
            close all
        end
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end
