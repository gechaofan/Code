%%% this code is used for analize laser effect for each unit%%%%%%%%%%%%%
clc;close all;clear all;
LaserFreq=20;%20Hz
LaserOutTaskDuraion=2; %Second
LaserDuration=5;%ms
LaserInTaskDuration=2;%sec
LaserITI=10;% laser train inter trial interval ,10s
LaserOutTaskInf={'LaserAfterTask'};% manually input laser condition

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};
    %%
    %change the directory to the file of DataID
    cd(Path);
    %%  get Data,Trials,FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,DPALen   %%%% ITI was given as 10s
    SplitDataName=ls('SplitData*.mat');
    if ~isempty(SplitDataName)
        load(SplitDataName);
        if length(LaserTrial)==size(SplitData.Trials,1)
            SingleUnitNum=size(SingleUnitIndex,1);
            %% laser effect out task
            LaserEffectOutTask=zeros(SingleUnitNum,1);
            LaserOutTaskInf={};
            if ~isempty(Laser) && LaserOutTaskDuraion~=0
                TaskStartPoint=min([Odor1(:,1);Odor2(:,1)]);% laser befor task start
                TaskEndPoint=max([Odor1(:,1);Odor2(:,1)])+SecondOdorLen+Response+ITILen;% laser after task end
                
                Laser1=Laser(Laser<TaskStartPoint | Laser>TaskEndPoint);
                Laser1StartIndex=[1;find(diff(Laser1)>LaserITI&diff(Laser1)<LaserITI+1)+1];
                Laser1EndIndex=Laser1StartIndex+LaserFreq*LaserOutTaskDuraion-1;% 20Hz,2s
                %%%%%%%%%campare firing during 2s laser period and 2s befor laser,
                %%%%%%%%%for 1s bin
                SpikeTimeStamp=cellfun(@(x) x(:,3), NewSpikes,'un',0);
                for itr1=1:SingleUnitNum% go through each unit
                    for itr2 = 1: size(Laser1StartIndex,1) % gothrough each laser trial
                        SpikeNumLaserOnOutTask(itr1,itr2)=length(find(SpikeTimeStamp{itr1,1}>Laser(Laser1StartIndex(itr2,1))&SpikeTimeStamp{itr1,1}<Laser(Laser1EndIndex(itr2,1))));
                        SpikeNumLaserOffOutTask(itr1,itr2)=length(find(SpikeTimeStamp{itr1,1}<Laser(Laser1StartIndex(itr2,1))&SpikeTimeStamp{itr1,1}>Laser(Laser1StartIndex(itr2,1))-2));
                    end
                    %%% test significance of laser effect
                    [p_LaserOut(itr1),larger_LaserOut(itr1)]=signrankTest(SpikeNumLaserOnOutTask(itr1,:),SpikeNumLaserOffOutTask(itr1,:));
                    %% plot raster for each unit,4 s before laser frequence start and 6s after laser end
                    for iLaser = 1 : size(Laser1StartIndex,1)
                        temp=SpikeTimeStamp{itr1,1}(SpikeTimeStamp{itr1,1}>Laser1(Laser1StartIndex(iLaser))-4 & SpikeTimeStamp{itr1,1}<Laser1(Laser1EndIndex(iLaser))+6)-Laser1(Laser1StartIndex(iLaser));
                        plot([temp'; temp'],[(iLaser)*ones(1,length(temp))-0.5;(iLaser)*ones(1,length(temp))+0.5],'color',[0.5 0.5 0.5],'LineWidth',0.5)
                        hold on
                    end
                    LaserPoint=[0:0.05:2-0.05];
                    plot([LaserPoint;LaserPoint],[(iLaser+1)*ones(1,length(LaserPoint))-0.5;(iLaser+1)*ones(1,length(LaserPoint))+0.5],'color',[0 0 1],'LineWidth',0.5)
                    saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr1,1)*10+SingleUnitIndex(itr1,2)) '-RasterLaserOutTask'],'fig')
                    saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr1,1)*10+SingleUnitIndex(itr1,2)) '-RasterLaserOutTask'],'png')
                    close all
                    tempIndex1=find(p_LaserOut<0.05&larger_LaserOut==1);% laser increased firing
                    tempIndex2=find(p_LaserOut<0.05&larger_LaserOut==2);% laser decreased firing
                    LaserEffectOutTask(tempIndex1)=1;
                    LaserEffectOutTask(tempIndex2)=-1;
                end
            end
            %% laser effect in task
            LaserCondition=unique(LaserTrial);
            LaserTypeNum=length(setdiff(LaserCondition,0)); % 0 for laser off; 1 for laser on in condition1; 2 for condition2
            Laser2=setdiff(Laser,Laser1);
            LaserEffectInTask=zeros(SingleUnitNum,LaserTypeNum);
            if LaserType > 1
                switch LaserTypeNum
                    case 0
                        % Laser off: LaserType=0   ;All trial Laser on: LaserType=1;
                        
                    case 1%  laser by block design
                        LaserInTaskInf={'LaserInDelay'};
                        LaserOnTrialIndex=find(LaserTrial~=0);
                        LaserOnTrialNum=length(find(LaserTrial~=0));
                        LaserOffTrialIndex=find(LaserTrial==0);
                        LaserOffTrialNum=length(find(LaserTrial==0));
                        for iUnit = 1: SingleUnitNum
                            for iLaserOnTrial = 1:LaserOnTrialNum
                                SpikeNumLaserOn(iUnit,iLaserOnTrial)=length(find(SpikeTimeStamp{iUnit,1}>Odor1(LaserOnTrialIndex(iLaserOnTrial),1)+1 & SpikeTimeStamp{iUnit,1}<Odor1(LaserOnTrialIndex(iLaserOnTrial),1)+3));
                            end
                            for iLaserOffTrial = 1:LaserOffTrialNum% same time befor laser period for control
                                SpikeNumLaserOff(iUnit,iLaserOffTrial)=length(find(SpikeTimeStamp{iUnit,1}>Odor1(LaserOffTrialIndex(iLaserOffTrial),1)+1 & SpikeTimeStamp{iUnit,1}<Odor1(LaserOffTrialIndex(iLaserOffTrial),1)+3));
                            end
                            %test significance
                            [p_Laser(iUnit),larger_LaserOut(iUnit)]=signrankTest(SpikeNumLaserOn(iUnit,:),SpikeNumLaserOff(iUnit,:));
                        end
                        tempIndex1=find(p_Laser<0.05&larger_LaserOut==1);
                        tempIndex2=find(p_Laser<0.05&larger_LaserOut==2);
                        LaserEffectInTask(tempIndex1)=1;
                        LaserEffectInTask(tempIndex2)=-1;
                    case 2%  laser block design with 2 laser on conditions and laser off condition
                        LaserInTaskInf={'LaserInEarlyDelay' 'LaserInLateDelay'};
                        LaserOnTrialIndex_Con1=find(LaserTrial==1);
                        LaserOnTrialNum_Con1=length(find(LaserTrial==1));
                        LaserOnTrialIndex_Con2=find(LaserTrial==2);
                        LaserOnTrialNum_Con2=length(find(LaserTrial==2));
                        LaserOffTrialIndex=find(LaserTrial==0);
                        LaserOffTrialNum=length(find(LaserTrial==0));
                        for iUnit = 1: SingleUnitNum
                            for iLaserOnTrial_Con1 = 1:LaserOnTrialNum_Con1% laser in first 2s of delay
                                SpikeNumLaserOn_Con1(iUnit,iLaserOnTrial_Con1)=length(find(SpikeTimeStamp{iUnit,1}>Odor1(LaserOnTrialIndex_Con1(iLaserOnTrial_Con1),1)+1 & SpikeTimeStamp{iUnit,1}<Odor1(LaserOnTrialIndex_Con1(iLaserOnTrial_Con1),1)+3));
                            end
                            for iLaserOnTrial_Con2 = 1:LaserOnTrialNum_Con2% laser in last 2s of delay
                                SpikeNumLaserOn_Con2(iUnit,iLaserOnTrial_Con2)=length(find(SpikeTimeStamp{iUnit,1}>Odor2(LaserOnTrialIndex_Con2(iLaserOnTrial_Con2),1)-2 & SpikeTimeStamp{iUnit,1}<Odor2(LaserOnTrialIndex_Con2(iLaserOnTrial_Con2),1)));
                            end
                            for iLaserOffTrial = 1: LaserOffTrialNum
                                SpikeNumLaserOff_Con1(iUnit,iLaserOffTrial)=length(find(SpikeTimeStamp{iUnit,1}>Odor1(LaserOffTrialIndex(iLaserOffTrial),1)+1 & SpikeTimeStamp{iUnit,1}<Odor1(LaserOffTrialIndex(iLaserOffTrial),1)+3));
                                SpikeNumLaserOff_Con2(iUnit,iLaserOffTrial)=length(find(SpikeTimeStamp{iUnit,1}>Odor2(LaserOffTrialIndex(iLaserOffTrial),1)-2 & SpikeTimeStamp{iUnit,1}<Odor2(LaserOffTrialIndex(iLaserOffTrial),1)));
                            end
                            [p_Laser_Con1(iUnit),larger_LaserOut_Con1(iUnit)]=signrankTest(SpikeNumLaserOn_Con1(iUnit,:),SpikeNumLaserOff_Con1(iUnit,:));
                            [p_Laser_Con2(iUnit),larger_LaserOut_Con2(iUnit)]=signrankTest(SpikeNumLaserOn_Con2(iUnit,:),SpikeNumLaserOff_Con2(iUnit,:));
                        end
                        tempIndex1_Con1=find(p_Laser_Con1<0.05&larger_LaserOut_Con1==1);
                        tempIndex2_Con1=find(p_Laser_Con1<0.05&larger_LaserOut_Con1==2);
                        LaserEffectInTask(tempIndex1_Con1,1)=1;
                        LaserEffectInTask(tempIndex2_Con1,1)=-1;
                        tempIndex1_Con2=find(p_Laser_Con2<0.05&larger_LaserOut_Con2==1);
                        tempIndex2_Con2=find(p_Laser_Con2<0.05&larger_LaserOut_Con2==2);
                        LaserEffectInTask(tempIndex1_Con2,2)=1;
                        LaserEffectInTask(tempIndex2_Con2,2)=-1;
                    otherwise
                        disp('other laser condition');
                end
            end
            save(['LaserEffect-' DataID],'DataID','SingleUnitIndex',...
                'LaserOutTaskInf','LaserInTaskInf','LaserEffectOutTask','LaserEffectInTask','-v7.3')
        else
            disp(SplitDataName);
        end
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end















