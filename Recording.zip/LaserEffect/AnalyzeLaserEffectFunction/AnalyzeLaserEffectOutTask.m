function LaserEffectOutTask=AnalyzeLaserEffectOutTask(DataID,Laser,SingleUnitIndex,Odor1,Odor2,NewSpikes,LaserFreq,LaserOutTaskDuraion,LaserOutTaskITI,SecondOdorLen,Response,ITILen,PlotFigure)

SingleUnitNum=size(SingleUnitIndex,1);
%% laser effect out task
LaserEffectOutTask=zeros(SingleUnitNum,1);
if ~isempty(Laser) && LaserOutTaskDuraion~=0
    TaskStartPoint=min([Odor1(:,1);Odor2(:,1)]);% laser befor task start
    TaskEndPoint=max([Odor1(:,1);Odor2(:,1)])+SecondOdorLen+Response+ITILen;% laser after task end
    
    Laser1=Laser(Laser<TaskStartPoint | Laser>TaskEndPoint);
    Laser1StartIndex=[1;find(diff(Laser1)>LaserOutTaskITI&diff(Laser1)<LaserOutTaskITI+1)+1];
    Laser1EndIndex=Laser1StartIndex+LaserFreq*LaserOutTaskDuraion-1;% 20Hz,2s
    %%%%%%%%%campare firing during 2s laser period and 2s befor laser,
    %%%%%%%%%for 1s bin
    SpikeTimeStamp=cellfun(@(x) x(:,3), NewSpikes,'un',0);
    SpikeCounts=cell(SingleUnitNum,1);% 100ms bin
    p_LaserOut=NaN*ones(SingleUnitNum,1);larger_LaserOut=NaN*ones(SingleUnitNum,1);
    SpikeNumLaserOnOutTask=zeros(SingleUnitNum,size(Laser1StartIndex,1));
    SpikeNumLaserOffOutTask=zeros(SingleUnitNum,size(Laser1StartIndex,1));
    for itr1=1:SingleUnitNum% go through each unit
        SpikeCounts{itr1,1}=zeros(1,120);
        for itr2 = 1: size(Laser1StartIndex,1) % gothrough each laser trial
            tempLaserDuration=Laser1(Laser1EndIndex(itr2,1))-Laser1(Laser1StartIndex(itr2,1));%laser duration a little longer than 2s in fact
            SpikeNumLaserOnOutTask(itr1,itr2)=sum(SpikeTimeStamp{itr1,1}>Laser1(Laser1StartIndex(itr2,1))&SpikeTimeStamp{itr1,1}<Laser1(Laser1EndIndex(itr2,1)));
            SpikeNumLaserOffOutTask(itr1,itr2)=sum(SpikeTimeStamp{itr1,1}<Laser1(Laser1StartIndex(itr2,1))-0.2&SpikeTimeStamp{itr1,1}>Laser1(Laser1StartIndex(itr2,1))-0.2-tempLaserDuration);
            % plot raster for each unit,5 s before laser frequence start and 5s after laser end
            for itr3 =1 : 120 %laser duration 2s, 5s before laser pulse train and 5s after laser pulse end, 20hz laser pulse
                SpikeCounts{itr1,1}(itr2,itr3)=sum(SpikeTimeStamp{itr1,1}>Laser1(Laser1StartIndex(itr2,1))-5+0.1*(itr3-1)&SpikeTimeStamp{itr1,1}<Laser1(Laser1StartIndex(itr2,1))-5+0.1*itr3);% spike num in 100ms bin
            end
        end
        [p_LaserOut(itr1,1),larger_LaserOut(itr1,1)]=signrankTest(SpikeNumLaserOnOutTask(itr1,:),SpikeNumLaserOffOutTask(itr1,:));
    end
    %% % test significance of laser effect
    LaserEffectOutTask=zeros(SingleUnitNum,1);
    tempIndex1=find(p_LaserOut<0.05&larger_LaserOut==1);% laser increased firing
    tempIndex2=find(p_LaserOut<0.05&larger_LaserOut==2);% laser decreased firing
    LaserEffectOutTask(tempIndex1)=1;
    LaserEffectOutTask(tempIndex2)=-1;
    %     SignificantIndex=find(abs(LaserEffectOutTask)>0);
    SignificantIndex=find(abs(LaserEffectOutTask)==0);
    %% plot raster for significant laser effect unit
    if PlotFigure ==1
        % 4 s before laser frequence start and 6s after laser end
        if ~isempty(SignificantIndex)
            
            for itr4 = 1: length(SignificantIndex)%
                UnitFR=mean(sum(SpikeCounts{SignificantIndex(itr4),1}(:,51:70),2))/2;
                if UnitFR<20% FR<20,plot raster
                    figure('Color',[1 1 1])
                    %subplot(2,1,1)% raster plot
                    for itr5 = 1: length(Laser1StartIndex)
                        temp=SpikeTimeStamp{SignificantIndex(itr4),1}(SpikeTimeStamp{SignificantIndex(itr4),1}>Laser1(Laser1StartIndex(itr5))-5 & SpikeTimeStamp{SignificantIndex(itr4),1}<Laser1(Laser1EndIndex(itr5))+5)-Laser1(Laser1StartIndex(itr5));
                        plot([temp'; temp'],[(itr5)*ones(1,length(temp))-0.5;(itr5)*ones(1,length(temp))+0.5],'color',[0.5 0.5 0.5],'LineWidth',0.5)
                        hold on
                    end
                else% FR>20,plot heatmap
                    figure1=figure('color',[1 1 1]);
                    colormap(jet)
                    axes1 = axes('Parent',figure1);
                    hold(axes1,'on');
                    X=[-4.95:0.1:6.95];
                    Y=[1:1:50];
                    PlotData=smooth2(10*SpikeCounts{SignificantIndex(itr4),1},'moving',3);
                    imagesc(X,Y,PlotData);
                    box(axes1,'on');
                    % axis(axes1,'ij'); % y axes reverse
                    hold(axes1,'off');
                    colorbar;
                    hold on
                end
                LaserPoint=[0:0.05:2-0.05];
                plot([LaserPoint;LaserPoint],[(50+1)*ones(1,length(LaserPoint))-0.5;(50+1)*ones(1,length(LaserPoint))+0.5],'color',[0 0 1],'LineWidth',0.5)
                xlabel('Time (Sec)');% Create xlabel
                ylabel('TrialID');% Create ylabel
                saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(SignificantIndex(itr4),1)*10+SingleUnitIndex(SignificantIndex(itr4),2)) '-RasterLaserOutTask'],'fig')
                saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(SignificantIndex(itr4),1)*10+SingleUnitIndex(SignificantIndex(itr4),2)) '-RasterLaserOutTask'],'png')
                close all
                %             figure('Color',[1 1 1])
                % subplot(2,1,2)% PSTH plot
                figure('Color',[1 1 1])
                Y=10*mean(SpikeCounts{SignificantIndex(itr4),1},1);
                Error=std(10*SpikeCounts{SignificantIndex(itr4),1},0,1)/sqrt(size(SpikeCounts{SignificantIndex(itr4),1},1)-1);
                plot([-4.95:0.1:6.95],smooth(10*mean(SpikeCounts{SignificantIndex(itr4),1},1))','k')
                hold on
                fill([[-4.95:0.1:6.95],fliplr([-4.95:0.1:6.95])],[smooth(Y-Error,'moving',3)',fliplr(smooth(Y+Error,'moving',3)')],...
                    [0 0 0],'edgecolor','none','FaceAlpha',0.3)
                saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(SignificantIndex(itr4),1)*10+SingleUnitIndex(SignificantIndex(itr4),2)) '-CurveLaserOutTask'],'fig')
                saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(SignificantIndex(itr4),1)*10+SingleUnitIndex(SignificantIndex(itr4),2)) '-CurveLaserOutTask'],'png')
                close all
            end
        end
    end
end
end