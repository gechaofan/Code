function [Laser_Effect]= GetLaserEffectInTask(SpikeCounts_SplitData,LaserTrial,Bin,LaserStart,LaserEnd,NewBin,n)
LaserOffTrialIndex=find(LaserTrial==0);
LaserOnTrialIndex=find(LaserTrial==1);
switch n
    case 0
        NewSpikeCounts= ReDefineBinSize(SpikeCounts_SplitData,NewBin,100); % the Whole trial Bin=1000ms
        [p_LaserEffect_AllTrials_SplitData, Larger_LaserEffect_AllTrials_SplitData, Laser_Effect_SplitData] = GetLaserEffect_EcahSpiltData(NewSpikeCounts,LaserOffTrialIndex,LaserOnTrialIndex);
        Laser_Effect=Laser_Effect_SplitData;
    case 1
        %the whole delay period
        %         SpikeCounts_Delay = cellfun(@(x) (x(:,36:85)), SplitData.SpikeCounts, 'un', 0);
        SpikeCounts_Delay = cellfun(@(x) (x(:,LaserStart:LaserEnd)), SpikeCounts_SplitData, 'un', 0);
        NewSpikeCounts_Dealy= ReDefineBinSize(SpikeCounts_Delay,(LaserEnd-LaserStart)*Bin,100);
        [p_LaserEffect_AllTrials_SplitData_Delay, Larger_LaserEffect_AllTrials_SplitData_Delay,Laser_Effect_SplitData_Delay] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Dealy,LaserOffTrialIndex,LaserOnTrialIndex);
        Laser_Effect=Laser_Effect_SplitData_Delay;
    case 2
        %  laser effect for the baseline (2 seconds before sample odor)
        SpikeCounts_Baseline = cellfun(@(x) (x(:,1:20)), SpikeCounts_SplitData, 'un', 0);
        NewSpikeCounts_Baseline= ReDefineBinSize(SpikeCounts_Baseline,2000,100);
        [p_LaserEffect_AllTrials_SplitData_Baseline, Larger_LaserEffect_AllTrials_SplitData_Baseline, Laser_Effect_SplitData_Baseline] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Baseline,LaserOffTrialIndex,LaserOnTrialIndex);
        Laser_Effect=Laser_Effect_SplitData_Baseline;
    case 3
        % laser effect for Sample
        SpikeCounts_Sample = cellfun(@(x) (x(:,21:30)), SpikeCounts_SplitData, 'un', 0);
        NewSpikeCounts_Sample= ReDefineBinSize(SpikeCounts_Sample,1000,100);
        [p_LaserEffect_AllTrials_SplitData_Sample, Larger_LaserEffect_AllTrials_SplitData_Sample, Laser_Effect_SplitData_Sample] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Sample,LaserOffTrialIndex,LaserOnTrialIndex);
        Laser_Effect=Laser_Effect_SplitData_Sample;
        
    otherwise
        disp('error in lasereffect');
end


end
