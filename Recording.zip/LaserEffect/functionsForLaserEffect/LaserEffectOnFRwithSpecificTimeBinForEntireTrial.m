function [effect1,effect2]=LaserEffectOnFRwithSpecificTimeBinForEntireTrial(SpikeCount1,SpikeCount2,SpikeCount3,NewBin,Bin)
if NewBin==Bin
    NewSpikeCount1=SpikeCount1;
    NewSpikeCount2=SpikeCount2;
    NewSpikeCount3=SpikeCount3;
else
    NewSpikeCount1=ReDefineBinSize(SpikeCount1,NewBin,Bin);
    NewSpikeCount2=ReDefineBinSize(SpikeCount2,NewBin,Bin);
    NewSpikeCount3=ReDefineBinSize(SpikeCount3,NewBin,Bin);
end
BinNum=size(NewSpikeCount1{1,1},2);
UnitNum=size(NewSpikeCount1,1);
effect1=zeros(UnitNum,BinNum);effect2=zeros(UnitNum,BinNum);
for iNeuron = 1: UnitNum
    for iBin= 1:BinNum
        [p1(iNeuron,iBin),sign1(iNeuron,iBin)]=ranksumTest(NewSpikeCount1{iNeuron,1}(:,iBin),NewSpikeCount2{iNeuron,1}(:,iBin),0);
        [p2(iNeuron,iBin),sign2(iNeuron,iBin)]=ranksumTest(NewSpikeCount1{iNeuron,1}(:,iBin),NewSpikeCount3{iNeuron,1}(:,iBin),0);
        if p1(iNeuron,iBin) < 0.05 && sign1(iNeuron,iBin) ==1
            effect1(iNeuron,iBin)=-1;
        elseif p1(iNeuron,iBin) < 0.05 && sign1(iNeuron,iBin) ==2
            effect1(iNeuron,iBin)=1;
        end
        if p2(iNeuron,iBin) < 0.05 && sign2(iNeuron,iBin) ==1
            effect2(iNeuron,iBin)=-1;
        elseif p2(iNeuron,iBin) < 0.05 && sign2(iNeuron,iBin) ==2
            effect2(iNeuron,iBin)=1;
        end
    end
end

end