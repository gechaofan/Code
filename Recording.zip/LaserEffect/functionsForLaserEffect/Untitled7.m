NewLaserOffAllTrialsFR=cellfun(@(x) x(1:80,:),LaserOffAllTrialsFR,'un',0);
NewLaserOnAllTrialsFR_EarlyDelay=cellfun(@(x) x(21:100,:),LaserOnAllTrialsFR_EarlyDelay,'un',0);
NewLaserOnAllTrialsFR_LateDelay=cellfun(@(x) x(1:80,:),LaserOnAllTrialsFR_LateDelay,'un',0);
NewLaserOffAllTrialsFR_s=ReDefineBinSize(NewLaserOffAllTrialsFR,1000,100);
NewLaserOnAllTrialsFR_EarlyDelay_s=ReDefineBinSize(NewLaserOnAllTrialsFR_EarlyDelay,1000,100);
NewLaserOnAllTrialsFR_LateDelay_s=ReDefineBinSize(NewLaserOnAllTrialsFR_LateDelay,1000,100);
% second base modulation index

Trials1 = cellfun(@(x,y) x(y(:,1)==0,:),AllTrials,AllLaserTrialsID,'un',0);% laser off
Trials2 = cellfun(@(x,y) x(y(:,1)==1,:),AllTrials,AllLaserTrialsID,'un',0);% laser on in early delay
Trials3 = cellfun(@(x,y) x(y(:,1)==2,:),AllTrials,AllLaserTrialsID,'un',0);% laser on in late delay

ErrorIndex1 = cellfun(@(x) find(x(:,4)==2 | x(:,4)==3),Trials1,'un',0);
CorrectIndex1 = cellfun(@(x) find(x(:,4)==1 | x(:,4)==4),Trials1,'un',0);
MissIndex1 = cellfun(@(x) find(x(:,4)==2),Trials1,'un',0);
HitIndex1 = cellfun(@(x) find(x(:,4)==1),Trials1,'un',0);
A_Index_1 = cellfun(@(x) find(x(:,2)==1), Trials1,'un',0);
B_Index_1 = cellfun(@(x) find(x(:,2)==2), Trials1,'un',0);
Correct_A_Index_1=cellfun(@(x,y) intersect(x,y),A_Index_1,CorrectIndex1,'un',0);
Correct_B_Index_1=cellfun(@(x,y) intersect(x,y),B_Index_1,CorrectIndex1,'un',0);
Error_A_Index_1=cellfun(@(x,y) intersect(x,y),A_Index_1,ErrorIndex1,'un',0);
Error_B_Index_1=cellfun(@(x,y) intersect(x,y),B_Index_1,ErrorIndex1,'un',0);

ErrorIndex2 = cellfun(@(x) find(x(:,4)==2 | x(:,4)==3),Trials2,'un',0);
CorrectIndex2 = cellfun(@(x) find(x(:,4)==1 | x(:,4)==4),Trials2,'un',0);
MissIndex2 = cellfun(@(x) find(x(:,4)==2),Trials2,'un',0);
HitIndex2 = cellfun(@(x) find(x(:,4)==1),Trials2,'un',0);
A_Index_2 = cellfun(@(x) find(x(:,2)==1), Trials2,'un',0);
B_Index_2 = cellfun(@(x) find(x(:,2)==2), Trials2,'un',0);
Correct_A_Index_2=cellfun(@(x,y) intersect(x,y),A_Index_2,CorrectIndex2,'un',0);
Correct_B_Index_2=cellfun(@(x,y) intersect(x,y),B_Index_2,CorrectIndex2,'un',0);
Error_A_Index_2=cellfun(@(x,y) intersect(x,y),A_Index_2,ErrorIndex2,'un',0);
Error_B_Index_2=cellfun(@(x,y) intersect(x,y),B_Index_2,ErrorIndex2,'un',0);

ErrorIndex3 = cellfun(@(x) find(x(:,4)==2 | x(:,4)==3),Trials3,'un',0);
CorrectIndex3 = cellfun(@(x) find(x(:,4)==1 | x(:,4)==4),Trials3,'un',0);
MissIndex3 = cellfun(@(x) find(x(:,4)==2),Trials3,'un',0);
HitIndex3 = cellfun(@(x) find(x(:,4)==1),Trials3,'un',0);
A_Index_3 = cellfun(@(x) find(x(:,2)==1), Trials3,'un',0);
B_Index_3 = cellfun(@(x) find(x(:,2)==2), Trials3,'un',0);
Correct_A_Index_3=cellfun(@(x,y) intersect(x,y),A_Index_3,CorrectIndex3,'un',0);
Correct_B_Index_3=cellfun(@(x,y) intersect(x,y),B_Index_3,CorrectIndex3,'un',0);
Error_A_Index_3=cellfun(@(x,y) intersect(x,y),A_Index_3,ErrorIndex3,'un',0);
Error_B_Index_3=cellfun(@(x,y) intersect(x,y),B_Index_3,ErrorIndex3,'un',0);

DeltaFRtoBaseline_Off=cell2mat(cellfun(@(x) mean(x,1)-mean(x(:,2)),NewLaserOffAllTrialsFR_s,'un',0));
DeltaFRtoBaseline_Early=cell2mat(cellfun(@(x) mean(x,1)-mean(x(:,2)),NewLaserOnAllTrialsFR_EarlyDelay_s,'un',0));
DeltaFRtoBaseline_Late=cell2mat(cellfun(@(x) mean(x,1)-mean(x(:,2)),NewLaserOnAllTrialsFR_LateDelay_s,'un',0));
figure
scatter(DeltaFRtoBaseline_Off([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],4),DeltaFRtoBaseline_Early([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],4))
hold on
plot([-15 15],[-15 15],'-','Color',[0.6  0.6  0.6])
plot([0 0],[-15 15],'--','Color',[0.6  0.6  0.6])
plot([-15 15],[0 0],'--','Color',[0.6  0.6  0.6])


%% firing change compared with the before second substracted baseline (FRt+1+1)/(FRt+1),+1 to avoid 0
NormFR_Off=cell2mat(cellfun(@(x) (mean(x,1)-mean(x(:,2)))/std(x(:,2),0,1),NewLaserOffAllTrialsFR_s,'un',0));
NormFR_Early=cell2mat(cellfun(@(x) (mean(x,1)-mean(x(:,2)))/std(x(:,2),0,1),NewLaserOnAllTrialsFR_EarlyDelay_s,'un',0));
NormFR_Late=cell2mat(cellfun(@(x) (mean(x,1)-mean(x(:,2)))/std(x(:,2),0,1),NewLaserOnAllTrialsFR_LateDelay_s,'un',0));


Ratio_Off_Delay_Pro= (NormFR_Off(:,4:9)+1)./(NormFR_Off(:,3:8)+1);
Ratio_E_Delay_Pro= (NormFR_Early(:,4:9)+1)./(NormFR_Early(:,3:8)+1);
Ratio_L_Delay_Pro= (NormFR_Late(:,4:9)+1)./(NormFR_Late(:,3:8)+1);

Ratio_Off_Delay_Retro= (NormFR_Off(:,4:9)+1)./(NormFR_Off(:,5:10)+1);
Ratio_E_Delay_Retro= (NormFR_Early(:,4:9)+1)./(NormFR_Early(:,5:10)+1);
Ratio_L_Delay_Retro= (NormFR_Late(:,4:9)+1)./(NormFR_Late(:,5:10)+1);

for j = 1 : 6
    for i = 1 
        n_Off_Pro(i,j)= length(find(Ratio_Off_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05));
        n_E_Pro(i,j)= length(find(Ratio_E_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05));
        n_L_Pro(i,j)= length(find(Ratio_L_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05));
        
        n_Off_Retro(i,j)= length(find(Ratio_Off_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05));
        n_E_Retro(i,j)= length(find(Ratio_E_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05));
        n_L_Retro(i,j)= length(find(Ratio_L_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05));
    end
    for i = 2 : 42 
        n_Off_Pro(i,j)= length(find(Ratio_Off_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_Off_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        n_E_Pro(i,j)= length(find(Ratio_E_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_E_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        n_L_Pro(i,j)= length(find(Ratio_L_Delay_Pro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_L_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        
        n_Off_Retro(i,j)= length(find(Ratio_Off_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_Off_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
        n_E_Retro(i,j)= length(find(Ratio_E_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_E_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
        n_L_Retro(i,j)= length(find(Ratio_L_Delay_Retro(:,j)<-2+(i-1)*0.1-0.05 & Ratio_L_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
    end
    for i = 43
        n_Off_Pro(i,j)= length(find(Ratio_Off_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        n_E_Pro(i,j)= length(find(Ratio_E_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        n_L_Pro(i,j)= length(find(Ratio_L_Delay_Pro(:,j)>=-2+(i-2)*0.1-0.05));
        
        n_Off_Retro(i,j)= length(find(Ratio_Off_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
        n_E_Retro(i,j)= length(find(Ratio_E_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
        n_L_Retro(i,j)= length(find(Ratio_L_Delay_Retro(:,j)>=-2+(i-2)*0.1-0.05));
    end
end

figure
hist(Ratio_Off_Delay_Pro([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE]),[-2:0.1:2])

%%
NewLaserOffAllATrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllATrialsFR,'un',0);
NewLaserOffAllBTrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllBTrialsFR,'un',0);
NewLaserOnAllATrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllATrialsFR_EarlyDelay,'un',0);
NewLaserOnAllBTrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllBTrialsFR_EarlyDelay,'un',0);
NewLaserOnAllATrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllATrialsFR_LateDelay,'un',0);
NewLaserOnAllBTrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllBTrialsFR_LateDelay,'un',0);

NewLaserOffAllATrialsFR_s=ReDefineBinSize(NewLaserOffAllATrialsFR,1000,100);
NewLaserOffAllBTrialsFR_s=ReDefineBinSize(NewLaserOffAllBTrialsFR,1000,100);
NewLaserOnAllATrialsFR_EarlyDelay_s=ReDefineBinSize(NewLaserOnAllATrialsFR_EarlyDelay,1000,100);
NewLaserOnAllBTrialsFR_EarlyDelay_s=ReDefineBinSize(NewLaserOnAllBTrialsFR_EarlyDelay,1000,100);
NewLaserOnAllATrialsFR_LateDelay_s=ReDefineBinSize(NewLaserOnAllATrialsFR_LateDelay,1000,100);
NewLaserOnAllBTrialsFR_LateDelay_s=ReDefineBinSize(NewLaserOnAllBTrialsFR_LateDelay,1000,100);


for iNeu = 1 : 750
    [Sele_LaserOff_s(iNeu,:),p_LaserOff_s(iNeu,:)]=CalculateSelectivityWithPermTest(NewLaserOffAllATrialsFR_s{iNeu,1},NewLaserOffAllBTrialsFR_s{iNeu,1});
    [Sele_LaserOn_Early_s(iNeu,:),p_LaserOn_Early_s(iNeu,:)]=CalculateSelectivityWithPermTest(NewLaserOnAllATrialsFR_EarlyDelay_s{iNeu,1},NewLaserOnAllBTrialsFR_EarlyDelay_s{iNeu,1});
    [Sele_LaserOn_Late_s(iNeu,:),p_LaserOn_Late_s(iNeu,:)]=CalculateSelectivityWithPermTest(NewLaserOnAllATrialsFR_LateDelay_s{iNeu,1},NewLaserOnAllBTrialsFR_LateDelay_s{iNeu,1});    
end

Sig_Sele_LaserOff_s=zeros(750,20);Sig_Sele_LaserOff_s(p_LaserOff_s<0.05)=1;
Sig_Sele_LaserOn_Early_s_s=zeros(750,20);Sig_Sele_LaserOn_Early_s_s(p_LaserOn_Early_s<0.05)=1;
Sig_Sele_LaserOn_Late_s_s=zeros(750,20);Sig_Sele_LaserOn_Late_s_s(p_LaserOn_Late_s<0.05)=1;
Learn_Num_Sig_Sele_LaserOff_EarlyChangedUnit=sum(Sig_Sele_LaserOff_s([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),1);
Learn_Num_Sig_Sele_LaserOnEarly_EarlyChangedUnit=sum(Sig_Sele_LaserOn_Early_s_s([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),1);
Learn_Num_Sig_Sele_LaserOff_LateChangedUnit=sum(Sig_Sele_LaserOff_s([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),1);
Learn_Num_Sig_Sele_LaserOnLate_LateChangedUnit=sum(Sig_Sele_LaserOn_Late_s_s([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),1);
x=sum(Sig_Sele_LaserOff_s(:,4:5),2);y=sum(Sig_Sele_LaserOn_Early_s_s(:,4:5),2);
x1=sum(Sig_Sele_LaserOff_s(:,8:9),2);z=sum(Sig_Sele_LaserOn_Late_s_s(:,8:9),2);

FRUnchangedUnitIndex_Early=setdiff(Learn_UnitIndex_CLE,[Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE]);
FRUnchangedUnitIndex_Late=setdiff(Learn_UnitIndex_CLE,[Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE]);

clear('Index1','Index2','Index12')
Index1=intersect(find(x1>0),[Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE]);
Index2=intersect(find(z>0),[Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE]);
Index12=intersect(Index1,Index2);
pie([20 75 20 20])
OdorSelUnitID_LaserOffOnly = setdiff(Index1,Index12);Index_OdorSelUnitID_LaserOffOnly=AllUnitID(OdorSelUnitID_LaserOffOnly);
OdorSelUnitID_LaserOff_Early=Index12; Index_OdorSelUnitID_LaserOff_Early=AllUnitID(OdorSelUnitID_LaserOff_Early);
OdorSelUnitID_LaserLateOnly = setdiff(Index2,Index12); Index_OdorSelUnitID_LaserLateOnly=AllUnitID(OdorSelUnitID_LaserLateOnly);
OdorSelUnitID_LaserOff_Late=Index12; Index_OdorSelUnitID_LaserOff_Late=AllUnitID(OdorSelUnitID_LaserOff_Late);

clear('Index1','Index2','Index12')
Index1=intersect(find(x1>0),FRUnchangedUnitIndex_Late);
Index2=intersect(find(z>0),FRUnchangedUnitIndex_Late);
Index12=intersect(Index1,Index2);
pie([110 180 106 60])

Learn_SelectUnitIndex_LaserOff_EarlyDelay=intersect(Learn_UnitIndex_CLE,x);
Learn_SelectUnitIndex_LaserOn_EarlyDelay=intersect(Learn_UnitIndex_CLE,y);
Learn_SelectUnitIndex_LaserOff_LateDelay=intersect(Learn_UnitIndex_CLE,x1);
Learn_SelectUnitIndex_LaserOn_LateDelay=intersect(Learn_UnitIndex_CLE,z);


[Norm_NewLaserOffAllATrialsFR,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOffAllATrialsFR,AllUnitID,TimeGain);
[Norm_NewLaserOffAllBTrialsFR,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOffAllBTrialsFR,AllUnitID,TimeGain);
[Norm_NewLaserOnAllATrialsFR_EarlyDelay,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOnAllATrialsFR_EarlyDelay,AllUnitID,TimeGain);
[Norm_NewLaserOnAllBTrialsFR_EarlyDelay,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOnAllBTrialsFR_EarlyDelay,AllUnitID,TimeGain);
[Norm_NewLaserOnAllATrialsFR_LateDelay,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOnAllATrialsFR_LateDelay,AllUnitID,TimeGain);
[Norm_NewLaserOnAllBTrialsFR_LateDelay,~]=GetAllUnitsNormalizedFRinSpecificTrials(NewLaserOnAllBTrialsFR_LateDelay,AllUnitID,TimeGain);

Norm_NewLaserOffAllATrialsFR_s=ReDefineBinSize(Norm_NewLaserOffAllATrialsFR,1000,100,1);
Norm_NewLaserOffAllBTrialsFR_s=ReDefineBinSize(Norm_NewLaserOffAllBTrialsFR,1000,100,1);
Norm_NewLaserOnAllATrialsFR_EarlyDelay_s=ReDefineBinSize(Norm_NewLaserOnAllATrialsFR_EarlyDelay,1000,100,1);
Norm_NewLaserOnAllBTrialsFR_EarlyDelay_s=ReDefineBinSize(Norm_NewLaserOnAllBTrialsFR_EarlyDelay,1000,100,1);
Norm_NewLaserOnAllATrialsFR_LateDelay_s=ReDefineBinSize(Norm_NewLaserOnAllATrialsFR_LateDelay,1000,100,1);
Norm_NewLaserOnAllBTrialsFR_LateDelay_s=ReDefineBinSize(Norm_NewLaserOnAllBTrialsFR_LateDelay,1000,100,1);
MeanNormFR_A_LaserOff=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOffAllATrialsFR_s,'un',0));
MeanNormFR_B_LaserOff=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOffAllBTrialsFR_s,'un',0));
MeanNormFR_A_EarlyDelay=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOnAllATrialsFR_EarlyDelay_s,'un',0));
MeanNormFR_B_EarlyDelay=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOnAllBTrialsFR_EarlyDelay_s,'un',0));
MeanNormFR_A_LateDelay=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOnAllATrialsFR_LateDelay_s,'un',0));
MeanNormFR_B_LateDelay=cell2mat(cellfun(@(x) mean(x,1),Norm_NewLaserOnAllBTrialsFR_LateDelay_s,'un',0));

% saperate foe different odor
for iNeu = 1: 750
    for iBin = 1:20
    [p_A_LaserOff(iNeu,iBin),sign_A_LaserOff(iNeu,iBin)]=ranksumTest(Norm_NewLaserOffAllATrialsFR_s{iNeu,1}(:,iBin),Norm_NewLaserOffAllATrialsFR_s{iNeu,1}(:,2),0);
    [p_B_LaserOff(iNeu,iBin),sign_B_LaserOff(iNeu,iBin)]=ranksumTest(Norm_NewLaserOffAllBTrialsFR_s{iNeu,1}(:,iBin),Norm_NewLaserOffAllBTrialsFR_s{iNeu,1}(:,2),0);
    [p_A_LaserOn_EarlyDelay(iNeu,iBin),sign_A_LaserOn_EarlyDelay(iNeu,iBin)]=ranksumTest(Norm_NewLaserOnAllATrialsFR_EarlyDelay_s{iNeu,1}(:,iBin),Norm_NewLaserOnAllATrialsFR_EarlyDelay_s{iNeu,1}(:,2),0);
    [p_B_LaserOn_EarlyDelay(iNeu,iBin),sign_B_LaserOn_EarlyDelay(iNeu,iBin)]=ranksumTest(Norm_NewLaserOnAllBTrialsFR_EarlyDelay_s{iNeu,1}(:,iBin),Norm_NewLaserOnAllBTrialsFR_EarlyDelay_s{iNeu,1}(:,2),0);
    [p_A_LaserOn_LateDelay(iNeu,iBin),sign_A_LaserOn_LateDelay(iNeu,iBin)]=ranksumTest(Norm_NewLaserOnAllATrialsFR_LateDelay_s{iNeu,1}(:,iBin),Norm_NewLaserOnAllATrialsFR_LateDelay_s{iNeu,1}(:,2),0);
    [p_B_LaserOn_LateDelay(iNeu,iBin),sign_B_LaserOn_LateDelay(iNeu,iBin)]=ranksumTest(Norm_NewLaserOnAllBTrialsFR_LateDelay_s{iNeu,1}(:,iBin),Norm_NewLaserOnAllBTrialsFR_LateDelay_s{iNeu,1}(:,2),0);
    end 
end
Sig_A_LaserOff=p_A_LaserOff;Sig_A_LaserOff(p_A_LaserOff<0.05)=1;Sig_A_LaserOff(p_A_LaserOff>0.05)=0;
Sig_B_LaserOff=p_B_LaserOff;Sig_B_LaserOff(p_B_LaserOff<0.05)=1;Sig_B_LaserOff(p_B_LaserOff>0.05)=0;

Sig_A_LaserOn_EarlyDelay=p_A_LaserOn_EarlyDelay;Sig_A_LaserOn_EarlyDelay(p_A_LaserOn_EarlyDelay<0.05)=1;Sig_A_LaserOn_EarlyDelay(p_A_LaserOn_EarlyDelay>0.05)=0;
Sig_B_LaserOn_EarlyDelay=p_B_LaserOn_EarlyDelay;Sig_B_LaserOn_EarlyDelay(p_B_LaserOn_EarlyDelay<0.05)=1;Sig_B_LaserOn_EarlyDelay(p_B_LaserOn_EarlyDelay>0.05)=0;

Sig_A_LaserOn_LateDelay=p_A_LaserOn_LateDelay;Sig_A_LaserOn_LateDelay(p_A_LaserOn_LateDelay<0.05)=1;Sig_A_LaserOn_LateDelay(p_A_LaserOn_LateDelay>0.05)=0;
Sig_B_LaserOn_LateDelay=p_B_LaserOn_LateDelay;Sig_B_LaserOn_LateDelay(p_B_LaserOn_LateDelay<0.05)=1;Sig_B_LaserOn_LateDelay(p_B_LaserOn_LateDelay>0.05)=0;


% modulaitin 
figure('color',[1 1 1])
bar([0.8:1:6.8],sum(Sig_A_LaserOff(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[0.7 0.7 0.7])
hold on
bar([1:1:7],sum(Sig_A_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[1 0 0])
bar([1.2:1:7.2],sum(Sig_A_LaserOn_LateDelay(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[0 0 1])
box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Proportion');% Create ylabel
saveas(gcf, ['Fraction-Sig-modulated-Units-Sample1_Learn_CLE'],'fig')
saveas(gcf, ['Fraction-Sig-modulated-Units-Sample1_Learn_CLE'],'png')


figure('color',[1 1 1])
bar([0.8:1:6.8],sum(Sig_B_LaserOff(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[0.7 0.7 0.7])
hold on
bar([1:1:7],sum(Sig_B_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[1 0 0])
bar([1.2:1:7.2],sum(Sig_B_LaserOn_LateDelay(Learn_UnitIndex_CLE,3:9),1)/471,'BarWidth',0.2,'FaceColor',[0 0 1])
box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Proportion');% Create ylabel
saveas(gcf, ['Fraction-Sig-modulated-Units-Sample2_Learn_CLE'],'fig')
saveas(gcf, ['Fraction-Sig-modulated-Units-Sample2_Learn_CLE'],'png')
% statistics
Num_Sig_A_LaserOff=sum(Sig_A_LaserOff(Learn_UnitIndex_CLE,3:9),1);
Num_Sig_B_LaserOff=sum(Sig_B_LaserOff(Learn_UnitIndex_CLE,3:9),1);

Num_Sig_A_LaserOn_EarlyDelay=sum(Sig_A_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,3:9),1);
Num_Sig_B_LaserOn_EarlyDelay=sum(Sig_B_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,3:9),1);
Num_Sig_A_LaserOn_LateDelay=sum(Sig_A_LaserOn_LateDelay(Learn_UnitIndex_CLE,3:9),1);
Num_Sig_B_LaserOn_LateDelay=sum(Sig_B_LaserOn_LateDelay(Learn_UnitIndex_CLE,3:9),1);

for i = 1:7 % sample + 6s delay
    [~,p_A_Off_Early(1,i),~,~]=prop_test([Num_Sig_A_LaserOff(1,i) Num_Sig_A_LaserOn_EarlyDelay(1,i)],[471 471],'correct');
    [~,p_A_Off_Late(1,i),~,~]=prop_test([Num_Sig_A_LaserOff(1,i) Num_Sig_A_LaserOn_LateDelay(1,i)],[471 471],'correct');
    [~,p_A_Early_Late(1,i),~,~]=prop_test([Num_Sig_A_LaserOn_EarlyDelay(1,i) Num_Sig_A_LaserOn_LateDelay(1,i)],[471 471],'correct');
    [~,p_B_Off_Early(1,i),~,~]=prop_test([Num_Sig_B_LaserOff(1,i) Num_Sig_B_LaserOn_EarlyDelay(1,i)],[471 471],'correct');
    [~,p_B_Off_Late(1,i),~,~]=prop_test([Num_Sig_B_LaserOff(1,i) Num_Sig_B_LaserOn_LateDelay(1,i)],[471 471],'correct');
    [~,p_B_Early_Late(1,i),~,~]=prop_test([Num_Sig_B_LaserOn_EarlyDelay(1,i) Num_Sig_B_LaserOn_LateDelay(1,i)],[471 471],'correct');
end
% Laser effect
Index1=find(p_A_LaserOff(:,4)<0.05&sign_A_LaserOff(:,4)==1);
temp1=intersect(Index1,Learn_UnitIndex_CLE);
Index11=find(p_B_LaserOff(:,4)<0.05&sign_B_LaserOff(:,4)==1);
temp11=intersect(Index11,Learn_UnitIndex_CLE);
Index2=find(p_A_LaserOff(:,4)<0.05&sign_A_LaserOff(:,4)==2);
temp2=intersect(Index2,Learn_UnitIndex_CLE);
Index22=find(p_B_LaserOff(:,4)<0.05&sign_B_LaserOff(:,4)==2);
temp22=intersect(Index22,Learn_UnitIndex_CLE);

Index3=find(p_A_LaserOn_EarlyDelay(:,4)<0.05&sign_A_LaserOn_EarlyDelay(:,4)==1);
temp3=intersect(Index3,Learn_UnitIndex_CLE);
Index33=find(p_B_LaserOn_EarlyDelay(:,4)<0.05&sign_B_LaserOn_EarlyDelay(:,4)==1);
temp33=intersect(Index33,Learn_UnitIndex_CLE);
Index4=find(p_A_LaserOn_EarlyDelay(:,4)<0.05&sign_A_LaserOn_EarlyDelay(:,4)==2);
temp4=intersect(Index4,Learn_UnitIndex_CLE);
Index44=find(p_B_LaserOn_EarlyDelay(:,4)<0.05&sign_B_LaserOn_EarlyDelay(:,4)==2);
temp44=intersect(Index44,Learn_UnitIndex_CLE);
figure
bar(sum(MeanNormFR_A_LaserOff(temp1,4),1))
hold on
bar(sum(MeanNormFR_A_LaserOff(temp2,4),1))
bar(2,sum(MeanNormFR_A_EarlyDelay(temp3,4),1))
bar(2,sum(MeanNormFR_A_EarlyDelay(temp4,4),1))




