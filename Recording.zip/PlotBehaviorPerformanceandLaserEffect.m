%% plot behavioral performance and laser effect of task free period

TrialNumPerBlock=20;%define the trial number in one session0..
TimeGain=10;%define the bin size
DataType=1;%1 for .pl2 file; 2 for .plx file;
TaskType=3;%%% PAL=3;
TrainingType = 2; % For Plexon Recording Using Code form GXW
OdorPairs=1234;

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};
    %%
    %change the directory to the file of DataID
    cd(Path);
     JAVAFileName=ls ('*ser');
     SplitDataName=ls('SplitData*.mat');
    if ~isempty(JAVAFileName) && ~isempty(SplitDataName)
        
        SerialData=ser2mat(JAVAFileName);
        SerialData=double(SerialData);
        [Lick,Laser,FirstOdor,FirstOdorStart,SecondOdor,SecondOdorStart,WaterTime,TrialNum,Data,Trials, LaserTrial,...
            FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,PALLen,ReactionTime,HitTimeStamp,FATimeStamp]=SerialEventForPALWithVaryingDelay(SerialData, OdorPairs, TaskType,TrainingType);
        LaserInTask=find(Laser>FirstOdor(1,1)&Laser<FirstOdor(end,1));
        clear('Lick','Laser','FirstOdor','FirstOdorStart','SecondOdor','SecondOdorStart','WaterTime','TrialNum',...
            'FirstOdorLen','SecondOdorLen','Delay','Response','WaterLen','ITILen','PALLen','ReactionTime','HitTimeStamp','FATimeStamp')
        SplitDataName=ls('SplitData*.mat');
        load(SplitDataName);
        FirstOdorLen=1.0;SecondOdorLen=1.0;Delay=6.0;Response=1.0;WaterLen=1.0;ITILen=10.0;DPALen=20.0;
        %%
        PlotPerformanceForPAL(Data,LaserInTask)
        saveas(gcf,[DataID '-Performance'],'fig')
        saveas(gcf,[DataID '-Performance'],'png')
        close all
        
        SplitLicking=[SplitData.Trials(:,[1 4 5]) SplitData.LickCounts];
        LaserOnIndex=find(LaserTrial==1);LaserOffIndex=find(LaserTrial==0);
        PlotDifferentTypeLicking(LaserOnIndex,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,Lick,Odor1,SplitLicking,TrainingType);
        saveas(gcf,[DataID '-LaserOnTrialLicking'],'fig')
        saveas(gcf,[DataID '-LaserOnTrialLicking'],'png')
        close all
        PlotDifferentTypeLicking(LaserOffIndex,FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,DPALen,Lick,Odor1,SplitLicking);
        saveas(gcf,[DataID '-LaserOffTrialLicking'],'fig')
        saveas(gcf,[DataID '-LaserOffTrialLicking'],'png')
        close all
        
        for itr=1:size(SingleUnitIndex,1)
           ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(BTrialIndex,:),...
               SplitData.SpikeCounts{itr8,1}(ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(BTrialIndex,:),...
                            FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.85 0.35 1],[0.46 0.67 0.18]);
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntSampleTrialsFRCurve'],'fig')
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntSampleTrialsFRCurve'],'png')
                        close all 
            
        end
        
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end