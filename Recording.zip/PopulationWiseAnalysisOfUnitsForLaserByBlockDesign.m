clear all;clc;close all;

LaserType=2; % 0 for laser off in all trials, 1 for laser on; 2 for 2 type of laser condition during trials; 3 for 3 conditions laser by bloack design
TimeGain=10;
NewBin=1000;%ms
Bin=100;%ms
WaveformLenth = 58;
SampelRate = 40000;
InterpolationNum = 5;

IsUnitWaveProperty = 1;
PlotSingleUnitSelectivity=1;
PlotNormalizedFRForSingleUnit=1;
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
AveragedFR=[];
AllUnitID=[];                                     AllTrialsFR=[];
LaserOnAllTrialsFR=[];                            LaserOffAllTrialsFR=[];
LaserOnAllHitTrialsFR=[];                         LaserOffAllHitTrialsFR=[];
LaserOnAllFATrialsFR=[];                          LaserOffAllFATrialsFR=[];
LaserOnAllCRTrialsFR=[];                          LaserOffAllCRTrialsFR=[];
LaserOnAllACTrialsFR=[];                          LaserOffAllACTrialsFR=[];
LaserOnAllBDTrialsFR=[];                          LaserOffAllBDTrialsFR=[];
LaserOnAllADTrialsFR=[];                          LaserOffAllADTrialsFR=[];
LaserOnAllBCTrialsFR=[];                          LaserOffAllBCTrialsFR=[];
LaserOnAllPairedTrialsFR=[];                      LaserOffAllPairedTrialsFR=[];
LaserOnAllUnPairedTrialsFR=[];                    LaserOffAllUnPairedTrialsFR=[];
LaserOnAllATrialsFR=[];                           LaserOffAllATrialsFR=[];
LaserOnAllBTrialsFR=[];                           LaserOffAllBTrialsFR=[];
LaserOnAllCTrialsFR=[];                           LaserOffAllCTrialsFR=[];
LaserOnAllDTrialsFR=[];                           LaserOffAllDTrialsFR=[];
LaserOnAllShuffledATrialsFR=[];                   LaserOffAllShuffledATrialsFR=[];
LaserOnAllShuffledBTrialsFR=[];                   LaserOffAllShuffledBTrialsFR=[];
% % end
Trough_to_Peak = [];%ms
Half_Amplitude_Duration = [];%ms amplitude is caculated from baseline to trough.

p_LaserEffect_AllTrials = [];                       Larger_LaserEffect_AllTrials = [];                    Laser_Effect_AllTrial = [];
p_LaserEffect_AllTrials_Delay = [];                 Larger_LaserEffect_AllTrials_Delay = [];              Laser_Effect_Delay = [];
p_LaserEffect_AllTrials_Baseline = [];              Larger_LaserEffect_AllTrials_Baseline = [];           Laser_Effect_Baseline = [];
p_LaserEffect_AllTrials_Sample = [];                Larger_LaserEffect_AllTrials_Sample = [];             Laser_Effect_Sample = [];
AveagedWaveform =[]; AllUnitMaxWaveform=[];

% if LaserType==2 % bloack design
% % end

for itr=1:MainCircleN
    load(filename{itr});
    %% get averaged waveform of 4 channels (tetrode)
    tempWaveform = cellfun(@mean, NewSpikes, 'un', 0);
    Waveform = cell2mat(tempWaveform);
    AveagedWaveform =[AveagedWaveform; Waveform(:,4:end)];
    %% get averaged firing rate of recording time
    AveragedFR = [AveragedFR; FiringRate];
    %% get property of max waveform for 4 channels and max waveform
    if IsUnitWaveProperty == 1
        Trough_to_Peak_Eachfile = [];
        Half_Amplitude_Duration_Eachfile = [];
        [Trough_to_Peak_Eachfile, Half_Amplitude_Duration_Eachfile, MaxWaveform] = GetUnitWavePropertyForEachFile(NewSpikes,WaveformLenth,SampelRate,InterpolationNum);
        Trough_to_Peak = [Trough_to_Peak; Trough_to_Peak_Eachfile];
        Half_Amplitude_Duration = [Half_Amplitude_Duration; Half_Amplitude_Duration_Eachfile];
    end
    AllUnitMaxWaveform = [AllUnitMaxWaveform; MaxWaveform];
    %% 
    if ~isempty(SingleUnitIndex)
        UnitID_SplitData={};
        if size(SingleUnitIndex,1)~=size(SplitData.SpikeCounts,1)
            display(DataID)
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        LaserOnTrialIndex=find(LaserTrial(:,1)==1);
        LaserOnHitTrialIndex=find(SplitData.Trials(:,4)==1&LaserTrial==1);
        LaserOnFATrialIndex=find(SplitData.Trials(:,4)==3&LaserTrial==1);
        LaserOnCRTrialIndex=find(SplitData.Trials(:,4)==4&LaserTrial==1);
        LaserOnACTrialIndex=find(SplitData.Trials(:,5)==1&LaserTrial==1);
        LaserOnBDTrialIndex=find(SplitData.Trials(:,5)==2&LaserTrial==1);
        LaserOnADTrialIndex=find(SplitData.Trials(:,5)==3&LaserTrial==1);
        LaserOnBCTrialIndex=find(SplitData.Trials(:,5)==4&LaserTrial==1);
        LaserOnPairedTrialIndex=find(SplitData.Trials(:,5)==1&LaserTrial==1|SplitData.Trials(:,5)==2&LaserTrial==1);
        LaserOnUnPairedTrialIndex=find(SplitData.Trials(:,5)==2&LaserTrial==1|SplitData.Trials(:,5)==3&LaserTrial==1);
        LaserOnShuffledATrialIndex=randi(size(find(LaserTrial==1),1),floor(size(find(LaserTrial==1),1)/2),1);
        LaserOnShuffledBTrialIndex=randi(size(find(LaserTrial==1),1),floor(size(find(LaserTrial==1),1)/2),1);
        LaserOnATrialIndex=find(SplitData.Trials(:,2)==1&LaserTrial(:,1)==1);
        LaserOnBTrialIndex=find(SplitData.Trials(:,2)==2&LaserTrial(:,1)==1);
        LaserOnCTrialIndex=find(SplitData.Trials(:,3)==3&LaserTrial(:,1)==1);
        LaserOnDTrialIndex=find(SplitData.Trials(:,3)==4&LaserTrial(:,1)==1);
        
        LaserOffTrialIndex=find(LaserTrial(:,1)==0);
        LaserOffHitTrialIndex=find(SplitData.Trials(:,4)==1&LaserTrial==0);
        LaserOffFATrialIndex=find(SplitData.Trials(:,4)==3&LaserTrial==0);
        LaserOffCRTrialIndex=find(SplitData.Trials(:,4)==4&LaserTrial==0);
        LaserOffACTrialIndex=find(SplitData.Trials(:,5)==1&LaserTrial==0);
        LaserOffBDTrialIndex=find(SplitData.Trials(:,5)==2&LaserTrial==0);
        LaserOffADTrialIndex=find(SplitData.Trials(:,5)==3&LaserTrial==0);
        LaserOffBCTrialIndex=find(SplitData.Trials(:,5)==4&LaserTrial==0);
        LaserOffPairedTrialIndex=find(SplitData.Trials(:,5)==1&LaserTrial==0|SplitData.Trials(:,5)==2&LaserTrial==0);
        LaserOffUnPairedTrialIndex=find(SplitData.Trials(:,5)==2&LaserTrial==0|SplitData.Trials(:,5)==3&LaserTrial==0);
        LaserOffShuffledATrialIndex=randi(size(find(LaserTrial==0),1),floor(size(find(LaserTrial==0),1)/2),1);
        LaserOffShuffledBTrialIndex=randi(size(find(LaserTrial==0),1),floor(size(find(LaserTrial==0),1)/2),1);
        LaserOffATrialIndex=find(SplitData.Trials(:,2)==1&LaserTrial(:,1)==0);
        LaserOffBTrialIndex=find(SplitData.Trials(:,2)==2&LaserTrial(:,1)==0);
        LaserOffCTrialIndex=find(SplitData.Trials(:,3)==3&LaserTrial(:,1)==0);
        LaserOffDTrialIndex=find(SplitData.Trials(:,3)==4&LaserTrial(:,1)==0);
        %% LASER EFFECT FOR EVERY UNIT
        % the whole trial with 1000ms bin
        NewSpikeCounts= ReDefineBinSize(SplitData.SpikeCounts,1000,100); % the Whole trial Bin=1000ms
        [p_LaserEffect_AllTrials_SplitData, Larger_LaserEffect_AllTrials_SplitData, Laser_Effect_SplitData] = GetLaserEffect_EcahSpiltData(NewSpikeCounts,LaserOffTrialIndex,LaserOnTrialIndex);
        p_LaserEffect_AllTrials = [p_LaserEffect_AllTrials; p_LaserEffect_AllTrials_SplitData];
        Larger_LaserEffect_AllTrials = [Larger_LaserEffect_AllTrials; Larger_LaserEffect_AllTrials_SplitData];
        Laser_Effect_AllTrial = [Laser_Effect_AllTrial; Laser_Effect_SplitData];
        % the whole delay period
        SpikeCounts_Delay = cellfun(@(x) (x(:,36:85)), SplitData.SpikeCounts, 'un', 0);
        NewSpikeCounts_Dealy= ReDefineBinSize(SpikeCounts_Delay,5000,100);
        [p_LaserEffect_AllTrials_SplitData_Delay, Larger_LaserEffect_AllTrials_SplitData_Delay,Laser_Effect_SplitData_Delay] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Dealy,LaserOffTrialIndex,LaserOnTrialIndex);
        p_LaserEffect_AllTrials_Delay = [p_LaserEffect_AllTrials_Delay; p_LaserEffect_AllTrials_SplitData_Delay];
        Larger_LaserEffect_AllTrials_Delay = [Larger_LaserEffect_AllTrials_Delay; Larger_LaserEffect_AllTrials_SplitData_Delay];
        Laser_Effect_Delay = [Laser_Effect_Delay; Laser_Effect_SplitData_Delay];
        
        %  laser effect for the baseline (2 seconds before sample odor)
        SpikeCounts_Baseline = cellfun(@(x) (x(:,1:20)), SplitData.SpikeCounts, 'un', 0);
        NewSpikeCounts_Baseline= ReDefineBinSize(SpikeCounts_Baseline,2000,100);
        [p_LaserEffect_AllTrials_SplitData_Baseline, Larger_LaserEffect_AllTrials_SplitData_Baseline, Laser_Effect_SplitData_Baseline] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Baseline,LaserOffTrialIndex,LaserOnTrialIndex);
        p_LaserEffect_AllTrials_Baseline = [p_LaserEffect_AllTrials_Baseline; p_LaserEffect_AllTrials_SplitData_Baseline];
        Larger_LaserEffect_AllTrials_Baseline = [Larger_LaserEffect_AllTrials_Baseline; Larger_LaserEffect_AllTrials_SplitData_Baseline];
        Laser_Effect_Baseline = [Laser_Effect_Baseline; Laser_Effect_SplitData_Baseline];
        
        % laser effect for Sample
        SpikeCounts_Sample = cellfun(@(x) (x(:,21:30)), SplitData.SpikeCounts, 'un', 0);
        NewSpikeCounts_Sample= ReDefineBinSize(SpikeCounts_Sample,1000,100);
        [p_LaserEffect_AllTrials_SplitData_Sample, Larger_LaserEffect_AllTrials_SplitData_Sample, Laser_Effect_SplitData_Sample] = GetLaserEffect_EcahSpiltData(NewSpikeCounts_Sample,LaserOffTrialIndex,LaserOnTrialIndex);
        p_LaserEffect_AllTrials_Sample = [p_LaserEffect_AllTrials_Sample; p_LaserEffect_AllTrials_SplitData_Sample];
        Larger_LaserEffect_AllTrials_Sample = [Larger_LaserEffect_AllTrials_Sample; Larger_LaserEffect_AllTrials_SplitData_Sample];
        Laser_Effect_Sample = [Laser_Effect_Sample; Laser_Effect_SplitData_Sample];
        
        %%
        for itr2=1:size(SingleUnitIndex,1)
            UnitID_SplitData{itr2,1}=[DataID '-Unit' num2str(SingleUnitIndex(itr2,1)*10+SingleUnitIndex(itr2,2))];
        end
        
        LaserOnAllTrialFR_SplitData=cellfun(@(x) (x(LaserOnTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnHitTrialsFR_SplitData=cellfun(@(x) (x(LaserOnHitTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnFATrialsFR_SplitData=cellfun(@(x) (x(LaserOnFATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnCRTrialsFR_SplitData=cellfun(@(x) (x(LaserOnCRTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        LaserOnACTrialsFR_SplitData=cellfun(@(x) (x(LaserOnACTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnBDTrialsFR_SplitData=cellfun(@(x) (x(LaserOnBDTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnADTrialsFR_SplitData=cellfun(@(x) (x(LaserOnADTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnBCTrialsFR_SplitData=cellfun(@(x) (x(LaserOnBCTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnPairedTrialsFR_SplitData=cellfun(@(x) (x(LaserOnPairedTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnUnPairedTrialsFR_SplitData=cellfun(@(x) (x(LaserOnUnPairedTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        LaserOnATrialsFR_SplitData=cellfun(@(x) (x(LaserOnATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnBTrialsFR_SplitData=cellfun(@(x) (x(LaserOnBTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnCTrialsFR_SplitData=cellfun(@(x) (x(LaserOnCTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnDTrialsFR_SplitData=cellfun(@(x) (x(LaserOnDTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnShuffledATrialsFR_SplitData=cellfun(@(x) (x(LaserOnShuffledATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOnShuffledBTrialsFR_SplitData=cellfun(@(x) (x(LaserOnShuffledBTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        LaserOffAllTrialFR_SplitData=cellfun(@(x) (x(LaserOffTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        LaserOffHitTrialsFR_SplitData=cellfun(@(x) (x(LaserOffHitTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffFATrialsFR_SplitData=cellfun(@(x) (x(LaserOffFATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffCRTrialsFR_SplitData=cellfun(@(x) (x(LaserOffCRTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        
        LaserOffACTrialsFR_SplitData=cellfun(@(x) (x(LaserOffACTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffBDTrialsFR_SplitData=cellfun(@(x) (x(LaserOffBDTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffADTrialsFR_SplitData=cellfun(@(x) (x(LaserOffADTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffBCTrialsFR_SplitData=cellfun(@(x) (x(LaserOffBCTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffPairedTrialsFR_SplitData=cellfun(@(x) (x(LaserOffPairedTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffUnPairedTrialsFR_SplitData=cellfun(@(x) (x(LaserOffUnPairedTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        LaserOffATrialsFR_SplitData=cellfun(@(x) (x(LaserOffATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffBTrialsFR_SplitData=cellfun(@(x) (x(LaserOffBTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffCTrialsFR_SplitData=cellfun(@(x) (x(LaserOffCTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffDTrialsFR_SplitData=cellfun(@(x) (x(LaserOffDTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffShuffledATrialsFR_SplitData=cellfun(@(x) (x(LaserOffShuffledATrialIndex,:)),SplitData.SpikeCounts,'un',0);
        LaserOffShuffledBTrialsFR_SplitData=cellfun(@(x) (x(LaserOffShuffledBTrialIndex,:)),SplitData.SpikeCounts,'un',0);
        
        
        AllUnitID=[AllUnitID;UnitID_SplitData];
        AllTrialsFR=[AllTrialsFR;SplitData.SpikeCounts];
        LaserOnAllTrialsFR=[LaserOnAllTrialsFR;LaserOnAllTrialFR_SplitData];
        LaserOnAllHitTrialsFR=[LaserOnAllHitTrialsFR;LaserOnHitTrialsFR_SplitData];
        LaserOnAllFATrialsFR=[LaserOnAllFATrialsFR;LaserOnFATrialsFR_SplitData];
        LaserOnAllCRTrialsFR=[LaserOnAllCRTrialsFR;LaserOnCRTrialsFR_SplitData];
        LaserOnAllACTrialsFR=[LaserOnAllACTrialsFR;LaserOnACTrialsFR_SplitData];
        LaserOnAllBDTrialsFR=[LaserOnAllBDTrialsFR;LaserOnBDTrialsFR_SplitData];
        LaserOnAllADTrialsFR=[LaserOnAllADTrialsFR;LaserOnADTrialsFR_SplitData];
        LaserOnAllBCTrialsFR=[LaserOnAllBCTrialsFR;LaserOnBCTrialsFR_SplitData];
        LaserOnAllPairedTrialsFR=[LaserOnAllPairedTrialsFR;LaserOnPairedTrialsFR_SplitData];
        LaserOnAllUnPairedTrialsFR=[LaserOnAllUnPairedTrialsFR;LaserOnUnPairedTrialsFR_SplitData];
        LaserOnAllATrialsFR=[LaserOnAllATrialsFR;LaserOnATrialsFR_SplitData];
        LaserOnAllBTrialsFR=[LaserOnAllBTrialsFR;LaserOnBTrialsFR_SplitData];
        LaserOnAllCTrialsFR=[LaserOnAllCTrialsFR;LaserOnCTrialsFR_SplitData];
        LaserOnAllDTrialsFR=[LaserOnAllDTrialsFR;LaserOnDTrialsFR_SplitData];
        LaserOnAllShuffledATrialsFR=[LaserOnAllShuffledATrialsFR;LaserOnShuffledATrialsFR_SplitData];
        LaserOnAllShuffledBTrialsFR=[LaserOnAllShuffledBTrialsFR;LaserOnShuffledBTrialsFR_SplitData];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        LaserOffAllTrialsFR=[LaserOffAllTrialsFR;LaserOffAllTrialFR_SplitData];
        LaserOffAllHitTrialsFR=[LaserOffAllHitTrialsFR;LaserOffHitTrialsFR_SplitData];
        LaserOffAllFATrialsFR=[LaserOffAllFATrialsFR;LaserOffFATrialsFR_SplitData];
        LaserOffAllCRTrialsFR=[LaserOffAllCRTrialsFR;LaserOffCRTrialsFR_SplitData];
        LaserOffAllACTrialsFR=[LaserOffAllACTrialsFR;LaserOffACTrialsFR_SplitData];
        LaserOffAllBDTrialsFR=[LaserOffAllBDTrialsFR;LaserOffBDTrialsFR_SplitData];
        LaserOffAllADTrialsFR=[LaserOffAllADTrialsFR;LaserOffADTrialsFR_SplitData];
        LaserOffAllBCTrialsFR=[LaserOffAllBCTrialsFR;LaserOffBCTrialsFR_SplitData];
        LaserOffAllPairedTrialsFR=[LaserOffAllPairedTrialsFR;LaserOffPairedTrialsFR_SplitData];
        LaserOffAllUnPairedTrialsFR=[LaserOffAllUnPairedTrialsFR;LaserOffUnPairedTrialsFR_SplitData];
        LaserOffAllATrialsFR=[LaserOffAllATrialsFR;LaserOffATrialsFR_SplitData];
        LaserOffAllBTrialsFR=[LaserOffAllBTrialsFR;LaserOffBTrialsFR_SplitData];
        LaserOffAllCTrialsFR=[LaserOffAllCTrialsFR;LaserOffCTrialsFR_SplitData];
        LaserOffAllDTrialsFR=[LaserOffAllDTrialsFR;LaserOffDTrialsFR_SplitData];
        LaserOffAllShuffledATrialsFR=[LaserOffAllShuffledATrialsFR;LaserOffShuffledATrialsFR_SplitData];
        LaserOffAllShuffledBTrialsFR=[LaserOffAllShuffledBTrialsFR;LaserOffShuffledBTrialsFR_SplitData];
        
    end
end

UnitWaveproperty.Trough_to_Peak = Trough_to_Peak;
UnitWaveproperty.Half_Amplitude_Duration = Half_Amplitude_Duration;

LaserEffect.p_LaserEffect_AllTrials = p_LaserEffect_AllTrials;                                          
LaserEffect.p_LaserEffect_AllTrials_Delay = p_LaserEffect_AllTrials_Delay;                              
LaserEffect.p_LaserEffect_AllTrials_Baseline = p_LaserEffect_AllTrials_Baseline;                        
LaserEffect.p_LaserEffect_AllTrials_Sample = p_LaserEffect_AllTrials_Sample;                             

LaserEffect.Larger_LaserEffect_AllTrials = Larger_LaserEffect_AllTrials; 
LaserEffect.Larger_LaserEffect_AllTrials_Delay = Larger_LaserEffect_AllTrials_Delay; 
LaserEffect.Larger_LaserEffect_AllTrials_Baseline = Larger_LaserEffect_AllTrials_Baseline; 
LaserEffect.Larger_LaserEffect_AllTrials_Sample = Larger_LaserEffect_AllTrials_Sample;

LaserEffect.Laser_Effect_AllTrial = Laser_Effect_AllTrial;
LaserEffect.Laser_Effect_Delay = Laser_Effect_Delay;
LaserEffect.Laser_Effect_Baseline = Laser_Effect_Baseline;
LaserEffect.Laser_Effect_Sample = Laser_Effect_Sample;

save(['LaserOn&Off-PopulationNeuralActivity-20190717'],'AllUnitID','AllTrialsFR','LaserOnAllTrialsFR','LaserOffAllTrialsFR','LaserOnAllHitTrialsFR',...
    'LaserOnAllFATrialsFR','LaserOnAllCRTrialsFR','LaserOnAllACTrialsFR','LaserOnAllBDTrialsFR','LaserOnAllADTrialsFR','LaserOnAllBCTrialsFR',...
    'LaserOnAllPairedTrialsFR','LaserOnAllUnPairedTrialsFR','LaserOnAllATrialsFR','LaserOnAllBTrialsFR','LaserOnAllCTrialsFR','LaserOnAllDTrialsFR',...
    'LaserOnAllShuffledATrialsFR','LaserOnAllShuffledBTrialsFR','LaserOffAllHitTrialsFR','LaserOffAllFATrialsFR','LaserOffAllCRTrialsFR',...
    'LaserOffAllACTrialsFR','LaserOffAllBDTrialsFR','LaserOffAllADTrialsFR','LaserOffAllBCTrialsFR','LaserOffAllPairedTrialsFR',...
    'LaserOffAllUnPairedTrialsFR','LaserOffAllATrialsFR','LaserOffAllBTrialsFR','LaserOffAllCTrialsFR','LaserOffAllDTrialsFR',...
    'LaserOffAllShuffledATrialsFR','LaserOffAllShuffledBTrialsFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain','LaserEffect',...
    'UnitWaveproperty','AveragedFR','AveagedWaveform','AllUnitMaxWaveform','SameUnitID')

%%
DotPlotUnitWaveProperty(Half_Amplitude_Duration,Trough_to_Peak);
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'png')
close all

BinSize=100;Boundary=0.35;
HistPlotUnitDistribution(Trough_to_Peak,BinSize,Boundary);
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'png')
close all

NS_Index = find(Trough_to_Peak<0.35); % narrow spike Units
BS_Index = find(Trough_to_Peak>=0.35);  % broad spike units
UnitType = NaN * ones(size(AllUnitID,1),1);
UnitType(NS_Index) = 1;% 1 for Narrow spike neurons or GABAergic neurons
UnitType(BS_Index) = 2;% 2 for Narrow spike neurons or GABAergic neurons

DotPlotUnitWith2PrametersFor2Groups(Trough_to_Peak(NS_Index),AveragedFR(NS_Index),Trough_to_Peak(BS_Index),AveragedFR(BS_Index))
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'fig')
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'png')
close all

%% plot cross trial normalized neural activity for each unit
%%%plot each unit Normalized FR
% if PlotNormalizedFRForSingleUnit==1
%     for itr3=1:size(AllUnitID,1)
%         tempLaserOffTrialsFR=LaserOffAllTrialsFR{itr3,1}*10;TrialNum=size(tempLaserOffTrialsFR,1);
%         tempNormlizedLaserOffTrialsFR{itr3,1}=(tempLaserOffTrialsFR-mean(mean(tempLaserOffTrialsFR(:,10:19),2)))./std(mean(tempLaserOffTrialsFR(:,10:19),2),0,1);
%         PlotCrossSpecificTrialsNormalizedFRforEachUnit(tempNormlizedLaserOffTrialsFR{itr3,1},TrialNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
%         saveas(gcf,[AllUnitID{itr3,1} 'LaserOffCrossAllTrialNormalizedFR'],'fig')
%         saveas(gcf,[AllUnitID{itr3,1} 'LaserOffCrossAllTrialNormalizedFR'],'png')
%         close all
%         tempLaserOnTrialsFR=LaserOnAllTrialsFR{itr3,1}*10;TrialNum=size(tempLaserOnTrialsFR,1);
%         tempNormlizedLaserOnTrialsFR{itr3,1}=(tempLaserOnTrialsFR-mean(mean(tempLaserOnTrialsFR(:,10:19),2)))./std(mean(tempLaserOnTrialsFR(:,10:19),2),0,1);
%         PlotCrossSpecificTrialsNormalizedFRforEachUnit(tempNormlizedLaserOnTrialsFR{itr3,1},TrialNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
%         saveas(gcf,[AllUnitID{itr3,1} 'LaserOnCrossAllTrialNormalizedFR'],'fig')
%         saveas(gcf,[AllUnitID{itr3,1} 'LaserOnCrossAllTrialNormalizedFR'],'png')
%         close all
%
%         FRVarianceofLaserEffect()
%     end
% end

%% % get all units normalized FR in specific trials
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'png')
close all
LaserOffAllUnitsAllTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllTrialsFR;
Index_LaserOnAllTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR'],'png')
close all
LaserOnAllUnitsAllTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

%%
SpecificIndexForDiffFRofSampleAB=GetSortIndex(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,TimeGain);

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllATrialsFR,AllUnitID,TimeGain);
Index_LaserOffAllATrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOffAllUnitsAllATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllBTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOffAllUnitsAllBTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllATrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOnAllATrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOnCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllBTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOnAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOnCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllBTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')
%%

SpecificIndexForDiffFRofTestCD=GetSortIndex(LaserOffAllCTrialsFR,LaserOffAllDTrialsFR,TimeGain);
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllCTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllCTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofTestCD);
saveas(gcf,['LaserOffCrossUnitCTrialNormalizedFR-DiffFRofTestCD'],'fig')
saveas(gcf,['LaserOffCrossUnitCTrialNormalizedFR-DiffFRofTestCD'],'png')
close all
LaserOffAllUnitsCTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllCTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllCTrialsFR;
Index_LaserOnAllCTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitCTrialNormalizedFR-DiffFRofTestCD'],'fig')
saveas(gcf,['LaserOnCrossUnitCTrialNormalizedFR-DiffFRofTestCD'],'png')
close all
LaserOnAllUnitsCTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllDTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllCTrialsFR;
Index_LaserOffAllDTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitDTrialNormalizedFR-DiffFRofTestCD'],'fig')
saveas(gcf,['LaserOffCrossUnitDTrialNormalizedFR-DiffFRofTestCD'],'png')
close all
LaserOffAllUnitsDTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllDTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllCTrialsFR;
Index_LaserOnAllDTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitDTrialNormalizedFR-DiffFRofTestCD'],'fig')
saveas(gcf,['LaserOnCrossUnitDTrialNormalizedFR-DiffFRofTestCD'],'png')
close all
LaserOnAllUnitsDTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')
%%
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllHitTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllHitTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitHitTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOffCrossUnitHitTrialNormalizedFR'],'png')
close all
LaserOffAllUnitsHitTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllHitTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOnAllHitTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitHitTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOnCrossUnitHitTrialNormalizedFR'],'png')
close all
LaserOnAllUnitsHitTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllFATrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllFATrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitFATrialNormalizedFR'],'fig')
saveas(gcf,['LaserOffCrossUnitFATrialNormalizedFR'],'png')
close all
LaserOffAllUnitsFATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllFATrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOnAllFATrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitFATrialNormalizedFR'],'fig')
saveas(gcf,['LaserOnCrossUnitFATrialNormalizedFR'],'png')
close all
LaserOnAllUnitsFATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')



% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllPairedTrialsFR,AllUnitID,TimeGain);
% PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
% saveas(gcf,['CrossUnitPariedTrialNormalizedFR'],'fig')
% saveas(gcf,['CrossUnitPairedTrialNormalizedFR'],'png')
% close all
% AllUnitsPairedTrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
%
% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllUnPairedTrialsFR,AllUnitID,TimeGain);
% PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
% saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'fig')
% saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'png')
% close all
% AllUnitsUnPairedTrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
%
% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledATrialsFR,AllUnitID,TimeGain);
% AllUnitsShuffledATrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledBTrialsFR,AllUnitID,TimeGain);
% AllUnitsShuffledBTrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
%
% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledCTrialsFR,AllUnitID,TimeGain);
% AllUnitsShuffledCTrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
% [Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledDTrialsFR,AllUnitID,TimeGain);
% AllUnitsShuffledDTrialsNrmolizedFR=Target;
% clear('Target','TargetNum')
%%   plot sample selectivity for each neuron (using neural firing rate)
tempLaserOnShuffledAData = [cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOnAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOnAllBTrialsFR, 'un',0)];
tempLaserOnShuffledBData = [cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOnAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOnAllBTrialsFR, 'un',0)];
tempLaserOffShuffledAData = [cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOffAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOffAllBTrialsFR, 'un',0)];
tempLaserOffShuffledBData = [cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOffAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(40,[25 1]),:)), LaserOffAllBTrialsFR, 'un',0)];


for i = 1: 475
    LaserOnShuffledAData{i,1}=[tempLaserOnShuffledAData{i,1};tempLaserOnShuffledAData{i,2}];
    LaserOnShuffledBData{i,1}=[tempLaserOnShuffledBData{i,1};tempLaserOnShuffledBData{i,2}];
    LaserOffShuffledAData{i,1}=[tempLaserOffShuffledAData{i,1};tempLaserOffShuffledAData{i,2}];
    LaserOffShuffledBData{i,1}=[tempLaserOffShuffledBData{i,1};tempLaserOffShuffledBData{i,2}];
    
end
PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOffShuffledAData,LaserOffShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR,LaserOnAllBTrialsFR,LaserOnShuffledAData,LaserOnShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOffAllCTrialsFR,LaserOffAllDTrialsFR,LaserOffShuffledAData,LaserOffShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOffPopulationUnitTestTrialSelectivy'],'fig')
saveas(gcf,['LaserOffPopulationUnitTestTrialSelectivy'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllCTrialsFR,LaserOnAllDTrialsFR,LaserOnShuffledAData,LaserOnShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOnPopulationUnitTestTrialSelectivy'],'fig')
saveas(gcf,['LaserOnPopulationUnitTestTrialSelectivy'],'png')
close all

LaserOnAllFAAndCRTrialFR=[];           LaserOffAllFAAndCRTrialFR=[];
for tempi=1:size(AllUnitID,1)
    LaserOnAllFAAndCRTrialFR{tempi,1}=[LaserOnAllFATrialsFR{tempi,1};LaserOnAllCRTrialsFR{tempi,1}];
    LaserOffAllFAAndCRTrialFR{tempi,1}=[LaserOffAllFATrialsFR{tempi,1};LaserOffAllCRTrialsFR{tempi,1}];
end
PlotSelectivityCurveCrossUnits(LaserOnAllHitTrialsFR,LaserOnAllFAAndCRTrialFR,LaserOnAllShuffledATrialsFR,LaserOnAllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOnPopulationUnitRewardTrialSelectivy'],'fig')
saveas(gcf,['LaserOnPopulationUnitRewardTrialSelectivy'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOffAllHitTrialsFR,LaserOffAllFAAndCRTrialFR,LaserOffAllShuffledATrialsFR,LaserOffAllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOffPopulationUnitRewardTrialSelectivy'],'fig')
saveas(gcf,['LaserOffPopulationUnitRewardTrialSelectivy'],'png')
% print(gcf,'-depsc',['PopulationUnitRewardTrialSelectivyDay4','.eps'])
close all

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR,LaserOnAllBTrialsFR,LaserOffAllATrialsFR,LaserOffAllBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(DelayDecreasedUnitIndex_LaserOff),LaserOnAllBTrialsFR(DelayDecreasedUnitIndex_LaserOff),LaserOffAllATrialsFR(DelayDecreasedUnitIndex_LaserOff),LaserOffAllBTrialsFR(DelayDecreasedUnitIndex_LaserOff),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DelayDecreasedUnitIndex_LaserOff,201)

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(DelayIncreasedUnitIndex_LaserOff),LaserOnAllBTrialsFR(DelayIncreasedUnitIndex_LaserOff),LaserOffAllATrialsFR(DelayIncreasedUnitIndex_LaserOff),LaserOffAllBTrialsFR(DelayIncreasedUnitIndex_LaserOff),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DelayIncreasedUnitIndex_LaserOff,201)
%%
[SelectiveIndex1,SelectiveIndex2]=PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOnAllATrialsFR,LaserOnAllBTrialsFR,...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllNeuronID,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-FRChangedUnit'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-FRChangedUnit'],'png')
close all


LaserOff_MeanFR=cell2mat(cellfun(@(x) mean(x,1),LaserOffAllTrialsFR , 'un',0));
LaserOn_MeanFR=cell2mat(cellfun(@(x) mean(x,1),LaserOnAllTrialsFR , 'un',0));


PlotPopulationUnitsAverageFRofSpecificTrials(LaserOffAllTrialsFR,LaserOnAllTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['LaserOff&LaserOnAllUnitMeanFR'],'fig')
saveas(gcf,['LaserOff&LaserOnAllUnitMeanFR'],'png')
close all


 PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(FRDncreasedID),LaserOnAllBTrialsFR(FRDncreasedID)...
     ,LaserOffAllATrialsFR(FRDncreasedID),LaserOffAllBTrialsFR(FRDncreasedID),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,FRDncreasedID,201)
 PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(FRIncreasedID),LaserOnAllBTrialsFR(FRIncreasedID)...
     ,LaserOffAllATrialsFR(FRIncreasedID),LaserOffAllBTrialsFR(FRIncreasedID),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,FRIncreasedID,201)
