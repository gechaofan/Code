function [omega_square]=CalculatePartialPEV(input_data,input_tag,stim_type,resl_type,Shuffle)
%  calculate ��2 PEV (percentage of explained variance)
% fomula :��2 = (SS-between - df*MSE)/(SStotal + MSE)
% a random subset of trials was drawn (equal to the minimum trial number across group) and the stastics was calculated. this process was repeated
% 25 times and the overall statistic was taken to be the mean of the strtified value. chance : randomization  test: randomly shuffled and this process was repeating 500 times .
% ref. Buschman, T.J., Siegel, M., Roy, J.E. & Miller, E.K. Neural substrates of cognitive capacity limitations. Proc. Natl. Acad. Sci. USA 108, 11252�C11255 (2011).

% if stim_type ==2
%     lbl_1 = 'Sample';% sample ,column 2 in trials
% elseif stim_type ==3
%     lbl_1 = 'Test'; % sample ,column 2 in trials
% end
% if resl_type == 1
%     lbl_2 = 'Cor'; % all trials
% elseif resl_type == 2
%     lbl_2 = 'Er';% correct trials
% elseif resl_tye == 3
%     lbl_2 = 'All'; % error trials
% end

% formatSpec = '%s_%s_%d';

Repetition = 25; % repeat 25 times
shuf_times = 500;

stim = unique(input_tag{1,1}(:,stim_type));
switch resl_type
    case 1% correct trials
        for iStim = 1 : size(stim,1)
            idx=[];
            idxs = cellfun(@(x) find(x(:,stim_type)==stim(iStim)&x(:,4)==1 | x(:,stim_type)==stim(iStim)&x(:,4)==4),input_tag,'un',0);
            group_data(:,iStim) = cellfun(@(x,y) x(y,:), input_data, idxs,'un',0);
        end
    case 2 % error trials
        for iStim = 1 : size(stim,1)
            idx=[];
            idxs = cellfun(@(x) find(x(:,stim_type)==stim(iStim)&x(:,4)==2 | x(:,stim_type)==stim(iStim)&x(:,4)==3),input_tag,'un',0);
            group_data(:,iStim) = cellfun(@(x,y) x(y,:), input_data, idxs,'un',0);
        end
    case 3 % all trials including correct and error trials
        for iStim = 1 : size(stim,1)
            idx=[];
            idxs = cellfun(@(x) find(x(:,stim_type)==stim(iStim)&x(:,4)==2 | x(:,stim_type)==stim(iStim)&x(:,4)==3),input_tag,'un',0);
            group_data(:,iStim) = cellfun(@(x,y) x(y,:), input_data, idxs,'un',0);
        end
    otherwise
        disp('Wrong results type input !')
        
end
%% ��2 calculat PEV
num_data= cellfun(@(x) size(x,1),group_data,'un',0);
min_num = min(cellfun(@(x) size(x,1),group_data),[],2);
recons_min_num=mat2cell(min_num*ones(1,size(group_data,2)),ones(size(group_data,1),1),ones(1,size(group_data,2)));
if Shuffle == 0
    omega_square=NaN*ones(size(input_data,1),Repetition);
    for iRep = 1 : Repetition
        % sampling data the same num from groups
        sampled_data = cellfun(@(x,y,z) x(randperm(y,z)',:),group_data, num_data,recons_min_num,'un',0);
        for iNeu = 1 : size(group_data,1)
            test_data=cell2mat(sampled_data(iNeu,:));
            test_data_1=reshape(test_data,[],1);
            g=reshape(ones(size(test_data,1),1)*[1:1:size(test_data,2)],[],1);
            [~,tbl]=anova1(test_data_1,g,'off');
            %         df = tbl{2,3};
            %         SSb = tbl{2,2};
            %         MSE = tbl{3,4};
            %         SSt = tbl{4,2};
            omega_square(iNeu,iRep)=(tbl{2,2}-tbl{2,3}*tbl{3,4})/(tbl{4,2}+tbl{3,4});
        end
    end
    %     omega_square.(sprintf('%s_%s',lbl_1,lbl_2))=mean(omega_square,2);
    omega_square=mean(omega_square,2);
else
    omega_square=NaN*ones(size(input_data,1),shuf_times);
    for iShuf = 1 : shuf_times
        % sampling data the same num from groups
        sampled_data = cellfun(@(x,y,z) x(randperm(y,z)',:),group_data, num_data,recons_min_num,'un',0);
        for iNeu = 1 : size(group_data,1)
            test_data=cell2mat(sampled_data(iNeu,:));
            test_data_1=reshape(test_data,[],1);
            g=reshape(ones(size(test_data,1),1)*[1:1:size(test_data,2)],[],1);
            ShuffleType=randperm(size(g));
            shuf_g = g(ShuffleType');
            [~,tbl]=anova1(test_data_1,shuf_g,'off');
            %         df = tbl{2,3};
            %         SSb = tbl{2,2};
            %         MSE = tbl{3,4};
            %         SSt = tbl{4,2};
            omega_square(iNeu,iShuf)=(tbl{2,2}-tbl{2,3}*tbl{3,4})/(tbl{4,2}+tbl{3,4});
        end
    end
    omega_square=mean(omega_square,2);
end







