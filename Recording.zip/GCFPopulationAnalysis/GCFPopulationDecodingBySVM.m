% SVM (liner) decoding for all units
load('TempData.mat');% laod  summary data
load('Selectivity20230417.mat');
load('SpecificUnitIdex20230415.mat');
load('SVMDecodingData-20230415.mat');
load('UnitID-LaserEffectandSelective-20230608');
DateID = datestr(datetime, 'yyyymmdd');
% criterion
Num_C = 40;% minimum num for correct trials for each stim
Num_E = 0; % minimum num for error trials for each stim
RepeatTimes = 1000;
Num_Train_C = 36;% minimum number for each group for training set for correct trials
Num_Test_C = 4;% trial number for test of correct trials
Num_Test_E = 0; % trial number for test of error trials

%
Num_S1_Off_c=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4)),Trials_Off);
Num_S2_Off_c=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4)),Trials_Off);
Num_S1_Off_e=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3)),Trials_Off);
Num_S2_Off_e=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3)),Trials_Off);
idx_Off_exclue = unique([find(Num_S1_Off_c<15);find(Num_S2_Off_c<15);find(Num_S1_Off_e<2);find(Num_S1_Off_e<2)]);
Num_S1_E_c=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4)),Trials_Early);
Num_S2_E_c=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4)),Trials_Early);
Num_S1_E_e=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3)),Trials_Early);
Num_S2_E_e=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3)),Trials_Early);
idx_E_exclue = unique([find(Num_S1_E_c<15);find(Num_S2_E_c<15);find(Num_S1_E_e<2);find(Num_S1_E_e<2)]);
Num_S1_L_c=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4)),Trials_Late);
Num_S2_L_c=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4)),Trials_Late);
Num_S1_L_e=cellfun(@(x) length(find(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3)),Trials_Late);
Num_S2_L_e=cellfun(@(x) length(find(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3)),Trials_Late);
idx_L_exclue = unique([find(Num_S1_L_c<15);find(Num_S2_L_c<15);find(Num_S1_L_e<2);find(Num_S1_L_e<2)]);
% idx_criterion = setdiff([1:1:750]',[idx_Off_exclue;idx_E_exclue;idx_L_exclue]);
% all trials
idx_criterion=[1:1:750]';
%% index for specific units
temp=sum(LaserEffect_E(:,7:10),2);
idx_E_Inc=find(temp>0);
idx_E_Dec=find(temp<0);
idx_E_Inc_Learn=intersect(Learn_UnitIndex_CLE,find(temp>0));
idx_E_Dec_Learn=intersect(Learn_UnitIndex_CLE,find(temp<0));
idx_E_Changed=[idx_E_Inc;idx_E_Dec];
idx_E_Changed_Learn=[idx_E_Inc_Learn;idx_E_Dec_Learn];

temp1=sum(LaserEffect_L(:,15:18),2);
idx_L_Inc=find(temp1>0);
idx_L_Dec=find(temp1<0);
idx_L_Inc_Learn=intersect(Learn_UnitIndex_CLE,find(temp1>0));
idx_L_Dec_Learn=intersect(Learn_UnitIndex_CLE,find(temp1<0));
idx_L_Changed=[idx_L_Inc;idx_L_Dec];
idx_L_Changed_Learn=[idx_L_Inc_Learn;idx_L_Dec_Learn];
 for i = 1 : 40
     idx_Inc_E{1,i}=find(LaserEffect_E(:,i)>0);
     idx_Dec_E{1,i}=find(LaserEffect_E(:,i)<0);
     idx_Inc_L{1,i}=find(LaserEffect_L(:,i)>0);
     idx_Dec_L{1,i}=find(LaserEffect_L(:,i)<0); 
%      Num_Inc_E(1,i)=length(find(LaserEffect_E(:,i)>0));
%      Num_Dec_E(1,i)=length(find(LaserEffect_E(:,i)<0));
%      Num_Inc_L(1,i)=length(find(LaserEffect_L(:,i)>0));
%      Num_Dec_L(1,i)=length(find(LaserEffect_L(:,i)<0)); 
 end
figure
bar([0.85:1:3.85]',[Num_Inc_E(1,7:10);Num_Dec_E(1,7:10)]'/750,'stacked','BarWidth',0.2)
hold on
bar([1.15:1:4.15]',[Num_Inc_L(1,15:18);Num_Dec_L(1,15:18)]'/750,'stacked','BarWidth',0.2)
 
BS_Idxs = find(UnitWaveproperty.Trough_to_Peak>=0.35);
NS_Idxs = find(UnitWaveproperty.Trough_to_Peak<0.35);
% clear('idx_overlap')
% idx_overlap=intersect(idx_E_Dec,idx_L_Inc);
% figure
% venn([length(idx_E_Dec) length(idx_L_Inc)],[length(idx_overlap)])
% title('165-26-243')
% saveas(gcf, ['Overlap_EarlyDec-LateInc-Units_Train_Early-Late'],'fig')
% saveas(gcf, ['Overlap_EarlyDec-LateInc-Units_Train_Early-Late'],'png')
% LaserEffect_E;
% idx_e1 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,7)==1));
% idx_e2 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,8)==1));
% idx_e3 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,9)==1));
% idx_e4 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,10)==1));
% idx_e11 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,7)==-1));
% idx_e21 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,8)==-1));
% idx_e31 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,9)==-1));
% idx_e41 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_E(:,10)==-1));
% idx_increase_early = unique([idx_e1;idx_e2;idx_e3;idx_e4]);
% idx_decrease_early = unique([idx_e11;idx_e21;idx_e31;idx_e41]);
% idx_reversed=intersect(idx_increase_early,idx_decrease_early);
% idx_increase_early_1 = setdiff(idx_increase_early,idx_reversed);
% idx_decrease_early_1 = setdiff(idx_decrease_early,idx_reversed);
idx_changed_early=[idx_increase_early_1;idx_decrease_early_1;idx_r eversed];
% temp_E=[deltaFR_Off_delay(idx_changed_early,1) deltaFR_Early_delay(idx_changed_early,1) idx_changed_early];
Index_I_E =temp_E(temp_E(:,1)>0 & temp_E(:,2)>0,3);
Index_II_E =temp_E(temp_E(:,1)>0 & temp_E(:,2)<0,3);
Index_III_E =temp_E(temp_E(:,1)<0 & temp_E(:,2)<0,3);
Index_IV_E =temp_E(temp_E(:,1)<0 & temp_E(:,2)>0,3);
Index_V_E =temp_E(temp_E(:,1)<0 ,3);Index_V_E1 =temp_E(temp_E(:,2)<0 ,3);
Index_VI_E =temp_E(temp_E(:,1)>0,3);Index_VI_E1 =temp_E(temp_E(:,2)>0,3);
% LaserEffect_L;
% idx_l1 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,15)==1));
% idx_l2 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,16)==1));
% idx_l3 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,17)==1));
% idx_l4 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,18)==1));
% idx_l11 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,15)==-1));
% idx_l21 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,16)==-1));
% idx_l31 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,17)==-1));
% idx_l41 = intersect(Learn_UnitIndex_CLE,find(LaserEffect_L(:,18)==-1));
% idx_increase_late = unique([idx_l1;idx_l2;idx_l3;idx_l4]);
% idx_decrease_late = unique([idx_l11;idx_l21;idx_l31;idx_l41]);
% idx_reversed_l=intersect(idx_increase_late,idx_decrease_late);
% idx_increase_late_1 = setdiff(idx_increase_late,idx_reversed_l);
% idx_decrease_late_1 = setdiff(idx_decrease_late,idx_reversed_l);
idx_changed_late=[idx_increase_late_1;idx_decrease_late_1;idx_reversed_l];
% temp_L=[deltaFR_Off_delay(idx_changed_late,3) deltaFR_Late_delay(idx_changed_late,3) idx_changed_late];
Index_I_L =temp_L(temp_L(:,1)>0 & temp_L(:,2)>0,3);
Index_II_L =temp_L(temp_L(:,1)>0 & temp_L(:,2)<0,3);
Index_III_L =temp_L(temp_L(:,1)<0 & temp_L(:,2)<0,3);
Index_IV_L =temp_L(temp_L(:,1)<0 & temp_L(:,2)>0,3);
Index_V_L =temp_L(temp_L(:,1)<0 ,3);Index_V_L1 =temp_L(temp_L(:,2)<0 ,3);
Index_VI_L =temp_L(temp_L(:,1)>0,3);Index_VI_L1 =temp_L(temp_L(:,2)>0,3);


FR_Off_80 = cellfun(@(x) x(1:80,:),NormAllTrialsFR_LaserOff,'un',0);
FR_Early_80 = cellfun(@(x) x(21:100,:),NormAllTrialsFR_LaserOnEarlyDelay, 'un',0);
FR_Late_80 = cellfun(@(x) x(1:80,:),NormAllTrialsFR_LaserOnLateDelay, 'un',0);
Trials_Off = cellfun(@(x) x(1:80,:),Trials1,'un',0);
Trials_Early = cellfun(@(x) x(21:100,:),Trials2,'un',0);
Trials_Late = cellfun(@(x) x(1:80,:),Trials3,'un',0);
% rebined fr to 500ms with 100ms step
NewFR_Off =cellfun(@(x) smooth2(x,'moving',5),FR_Off_80,'un',0);
NewFR_Early =cellfun(@(x) smooth2(x,'moving',5),FR_Early_80,'un',0);
NewFR_Late =cellfun(@(x) smooth2(x,'moving',5),FR_Late_80,'un',0);

NewFR_1 = cellfun(@(x) x(:,10:130),NewFR_Off,'un',0);
NewFR_2 = cellfun(@(x) x(:,10:130),NewFR_Early,'un',0);
NewFR_3 = cellfun(@(x) x(:,10:130),NewFR_Late,'un',0);
% DateID = datestr(datetime, 'yyyymmdd');
save(['SVMDecodingData-' DataID],'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','-v7.3')
save(['SpecificUnitIdex' DataID],'idx_increase_early_1','idx_decrease_early_1','idx_reversed','temp_E',...
    'idx_increase_late_1','idx_decrease_late_1','idx_reversed_l','temp_L',...
    'idx_criterion','-v7.3')
% NormFR.LaserOff = cellfun(@(x) x(:,10:150),NewFR_Off,'un',0);
% NormFR.LaserEarly = cellfun(@(x) x(:,10:150),NewFR_Early,'un',0);
% NormFR.LaserLate = cellfun(@(x) x(:,10:150),NewFR_Late,'un',0);
% Trials.LaserOff = Trials_Off;
% Trials.LaserEarly = Trials_Early;
% Trials.LaserLate = Trials_Late;
% Trial_Info = [{'Rule'} {'Sample'} {'Test'} {'Result'} {'TrialType'}];
% NormFR_Info = [{'row-Trial'} {'column-bin'}];
% save(['DataForSVM-' DataID],'NormFR','NormFR_Info','Trials','Trial_Info','-v7.3')
% �����̳߳�

if isempty(gcp('nocreate')) %���֮ǰû�п���parpool������
%     parpool(maxNumCompThreads);  %��Ϊ����ʹ�ú���
 parpool(2);  %��Ϊ����ʹ�ú���
end
% fr changed and kept endogenous proporty
% both positive delay activity
%%
clear('Index')
Index = intersect(idx_criterion,Index_I_E);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
% DataID = datestr(datetime, 'yyyymmdd');
Title='BothPositiveDelayActivity-Early';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc
% both negative delay activity
clear('Index')
tic
Index = intersect(idx_criterion,Index_III_E);
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
Title='BothNegativeDelayActivity-Early';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc

% both positive and negative delay activity for early activation
tic
Index = intersect(idx_criterion,[Index_I_E;Index_III_E]);
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
Title='BothPositiveANDNegativeDelayActivity-Early';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc
%%
% both positive and negative delay activity for late activation
clear('Index')
Index = intersect(idx_criterion,Index_I_L);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
DataID = datestr(datetime, 'yyyymmdd');
Title='BothPositiveDelayActivity-Late';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc
% both negative delay activity
tic
Index = intersect(idx_criterion,Index_III_L);
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='BothNegativeDelayActivity-Late';
save(['SVMResults-Alltrials-' Title, DataID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc

% both positive and negative delay activity for late activation
tic
Index = intersect(idx_criterion,[Index_I_L;Index_III_L]);
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='BothPositiveANDNegativeDelayActivity-Late';
save(['SVMResults-Alltrials-' Title, DataID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc
%%
for i = 1 : 3
    FR1_Delay(:,i)=cellfun(@(x) mean(x(:,i*20+1:(i+1)*20),2),NewFR_1,'un',0);
    FR2_Delay(:,i)=cellfun(@(x) mean(x(:,i*20+1:(i+1)*20),2),NewFR_2,'un',0);
    FR3_Delay(:,i)=cellfun(@(x) mean(x(:,i*20+1:(i+1)*20),2),NewFR_3,'un',0);
end
x=FR1_Delay;y=FR2_Delay;z=FR3_Delay;
for i = 1:750
    FR1_2s_delay{i,1}=cat(2,x{i,1},x{i,2},x{i,3});
    FR2_2s_delay{i,1}=cat(2,y{i,1},y{i,2},y{i,3});
    FR3_2s_delay{i,1}=cat(2,z{i,1},z{i,2},z{i,3});
end
% BS-LaserChanged Units for early activation
repeat=1000;
clear('Index','tempIndex')
Index=intersect(idx_E_Changed,BS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='FRChanged-BS-Early_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% NS-LaserChanged Units for early activation
clear('Index','tempIndex')
Index=intersect(idx_E_Changed,NS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='FRChanged-NS-Early_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc

% BS-LaserChanged Units for late activation
clear('Index','tempIndex')
Index=intersect(idx_L_Changed,BS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='FRChanged-BS-Late_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% NS-LaserChanged Units for early activation
clear('Index','tempIndex')
Index=intersect(idx_L_Changed,NS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='FRChanged-NS-Late_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
%% idx_E_Inc
% Early-increased Units for early activation
clear('Index','tempIndex')
Index=idx_E_Inc;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='Early-Increased_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=idx_E_Dec;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='Early-Decreased_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=idx_L_Inc;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='Late-Increased_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=idx_L_Dec;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='Late-Decreased_Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
%% svm for selective units
Sele_Inc_Off_LaserEarly= intersect(idx_E_Inc,idx_sele_Off_Earlydelay);
Sele_Dec_Off_LaserEarly= intersect(idx_E_Dec,idx_sele_Off_Earlydelay);
NSel_Inc_Off_LaserEarly= setdiff(idx_E_Inc,Sele_Inc_Off_LaserEarly);
NSel_Dec_Off_LaserEarly= setdiff(idx_E_Dec,Sele_Dec_Off_LaserEarly);

Sele_Inc_On_LaserEarly= intersect(idx_E_Inc,idx_sele_On_Earlydelay);
Sele_Dec_On_LaserEarly= intersect(idx_E_Dec,idx_sele_On_Earlydelay);
NSel_Inc_On_LaserEarly= setdiff(idx_E_Inc,Sele_Inc_On_LaserEarly);
NSel_Dec_On_LaserEarly= setdiff(idx_E_Dec,Sele_Dec_On_LaserEarly);

Sele_Inc_Off_LaserLate= intersect(idx_L_Inc,idx_sele_Off_Latedelay);
Sele_Dec_Off_LaserLate= intersect(idx_L_Dec,idx_sele_Off_Latedelay);
NSel_Inc_Off_LaserLate= setdiff(idx_L_Inc,Sele_Inc_Off_LaserLate);
NSel_Dec_Off_LaserLate= setdiff(idx_L_Dec,Sele_Dec_Off_LaserLate);

Sele_Inc_On_LaserLate= intersect(idx_L_Inc,idx_sele_On_Latedelay);
Sele_Dec_On_LaserLate= intersect(idx_L_Dec,idx_sele_On_Latedelay);
NSel_Inc_On_LaserLate= setdiff(idx_L_Inc,Sele_Inc_On_LaserLate);
NSel_Dec_On_LaserLate= setdiff(idx_L_Dec,Sele_Dec_On_LaserLate);
% selective units and firing changed units
clear('Index1','Index2','Index11','Index3');
Index1=[Sele_Inc_Off_LaserEarly;Sele_Dec_Off_LaserEarly];
Index2=[Sele_Inc_On_LaserEarly;Sele_Dec_On_LaserEarly];
Index11=[Sele_Inc_Off_LaserLate;Sele_Dec_Off_LaserLate];
Index3=[Sele_Inc_On_LaserLate;Sele_Dec_On_LaserLate];
tic
[Acc_LaserOff_EarlyChangeSelective] = svm_decoding_correct_error_new(NewFR_1(Index1),Trials_Off(Index1),1000,3,1,36,4,0);
[Acc_LaserOn_EarlyChangeSelective] = svm_decoding_correct_error_new(NewFR_2(Index2),Trials_Early(Index2),1000,3,1,36,4,0);
[Acc_LaserOff_LateChangeSelective] = svm_decoding_correct_error_new(NewFR_1(Index11),Trials_Off(Index11),1000,3,1,36,4,0);
[Acc_LaserOn_LateChangeSelective] = svm_decoding_correct_error_new(NewFR_3(Index3),Trials_Late(Index3),1000,3,1,36,4,0);
Title='FRChangeANDSelectiveUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index1','Index2','Index11','Index3','Acc_LaserOff_EarlyChangeSelective',...
    'Acc_LaserOn_EarlyChangeSelective','Acc_LaserOff_LateChangeSelective','Acc_LaserOn_LateChangeSelective',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc

% nonselective but firing changed units
clear('Index1','Index2','Index11','Index3');
Index1=[NSel_Inc_Off_LaserEarly;NSel_Dec_Off_LaserEarly];
Index2=[NSel_Inc_On_LaserEarly;NSel_Dec_On_LaserEarly];
Index11=[NSel_Inc_Off_LaserLate;NSel_Dec_Off_LaserLate];
Index3=[NSel_Inc_On_LaserLate;NSel_Dec_On_LaserLate];
tic
[Acc_LaserOff_EarlyChangeNSelective] = svm_decoding_correct_error_new(NewFR_1(Index1),Trials_Off(Index1),1000,3,1,36,4,0);
[Acc_LaserOn_EarlyChangeNSelective] = svm_decoding_correct_error_new(NewFR_2(Index2),Trials_Early(Index2),1000,3,1,36,4,0);
[Acc_LaserOff_LateChangeNSelective] = svm_decoding_correct_error_new(NewFR_1(Index11),Trials_Off(Index11),1000,3,1,36,4,0);
[Acc_LaserOn_LateChangeNSelective] = svm_decoding_correct_error_new(NewFR_3(Index3),Trials_Late(Index3),1000,3,1,36,4,0);
Title='FRChangeANDNSelectiveUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index1','Index2','Index11','Index3','Acc_LaserOff_EarlyChangeNSelective',...
    'Acc_LaserOn_EarlyChangeNSelective','Acc_LaserOff_LateChangeNSelective','Acc_LaserOn_LateChangeNSelective',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% selective units with laser changed firing rate
tempIndex1=intersect(idx_changed_early,idx_criterion);
Index1=intersect(tempIndex1,Idx_DelaySel_Off);
Index2=intersect(tempIndex1,Idx_DelaySel_Early);
tempIndex2=intersect(idx_changed_late,idx_criterion);
Index11=intersect(tempIndex2,Idx_DelaySel_Off);
Index3=intersect(tempIndex2,Idx_DelaySel_Late);
tic
[Acc_Off_Sel_E] = svm_decoding_correct_error_new(NewFR_1(Index1),Trials_Off(Index1),500,3,1,36,4,0);
[Acc_Early_Sel_E] = svm_decoding_correct_error_new(NewFR_2(Index2),Trials_Early(Index2),500,3,1,36,4,0);
[Acc_Off_Sel_L] = svm_decoding_correct_error_new(NewFR_1(Index11),Trials_Off(Index11),500,3,1,36,4,0);
[Acc_Late_Sel_L] = svm_decoding_correct_error_new(NewFR_3(Index3),Trials_Late(Index3),500,3,1,36,4,0);
Title='FRChangedAndSelectiveUnitsForEachCondition';
save(['SVMResults-Alltrials-' Title, DateID],'Index1','Index2','Index11','Index3',...
    'Acc_LaserOff','Acc_Off_Sel_E','Acc_Early_Sel_E','Acc_Off_Sel_L','Acc_Late_Sel_L',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
toc
%% overlapped firing changed units
% both increased units
clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
tempIndex=intersect(idx_increase_early_1,idx_increase_late_1);
Index = intersect(tempIndex,idx_criterion);
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_Early] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
[Acc_Late] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='BothIncreasedUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Early','Acc_Late',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')
% both decreased units 
clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
tempIndex=intersect(idx_decrease_early_1,idx_decrease_late_1);
Index = intersect(tempIndex,idx_criterion);
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_Early] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
[Acc_Late] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='BothDecreasedUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Early','Acc_Late',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')

% both firing changed units 

clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
tempIndex=intersect(idx_changed_early,idx_changed_late);
Index = intersect(tempIndex,idx_criterion);
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_Early] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
[Acc_Late] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='BothChangedUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Early','Acc_Late',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')

clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
Index = Learn_UnitIndex_CLE;
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),500,3,1,36,4,0);
[Acc_Early] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),500,3,1,36,4,0);
[Acc_Late] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),500,3,1,36,4,0);
Title='AllUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Early','Acc_Late',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','-v7.3')

% early changed units 


clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
Index = idx_E_Changed;
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_Early] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='EarlyChangedUnits-Training-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Early',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
% late changed units 
clear('tempIndex','Index','Acc_Off','Acc_Early','Acc_Late')
Index = idx_L_Changed;
[Acc_Off] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_Late] = svm_decoding_correct_error_new(NewFR_3(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='LateChangedUnits-Training-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_Off','Acc_Late',...
    'NewFR_1','NewFR_2','NewFR_3','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
%% plot svm decoding results
clear all;close all;clc;
[STATISTICS]=PlotSVMResults(Acc_LaserOff,Acc_LaserOn,1,12,100,[0 0 0],[0 0 1]);
title(['n = ' num2str(length(Index))]);
saveas(gcf, ['SVMDecAcc-' Title '-1000-AllTrials-0529'],'fig')
saveas(gcf, ['SVMDecAcc-' Title '-1000-AllTrials-0529'],'png')

[STATISTICS]=PlotSVMResults(Acc_Off_Sel_E,Acc_Early_Sel_E,1,12,100,[0 0 0],[1 0 0]);
title(['n = ' num2str(length(Index1)) '&' num2str(length(Index2))]);
saveas(gcf, ['SVMDecAcc-FRChangedANDSelectiveUnits-Early-CorrectTrials'],'fig')
saveas(gcf, ['SVMDecAcc-FRChangedANDSelectiveUnits-Early-CorrectTrials'],'png')

[STATISTICS]=PlotSVMResults(Acc_Off_Sel_L,Acc_Late_Sel_L,1,12,100,[0 0 0],[0 0 1]);
title(['n = ' num2str(length(Index11)) '&' num2str(length(Index3))]);
saveas(gcf, ['SVMDecAcc-FRChangedANDSelectiveUnits-Late-CorrectTrials'],'fig')
saveas(gcf, ['SVMDecAcc-FRChangedANDSelectiveUnits-Late-CorrectTrials'],'png')

[STATISTICS]=PlotSVMResults(Acc_LaserOff,Acc_LaserOn_Late,1,12,100,[0 0 0],[0 0 1]);
title(['n = ' num2str(length(Index1)) '&' num2str(length(Index2))]);
saveas(gcf, ['SVMDecAcc-SelectiveUnits-Early'],'fig')
saveas(gcf, ['SVMDecAcc-SelectiveUnits-Early'],'png')

[STATISTICS]=PlotSVMResults(Acc_Off,Acc_Late,1,12,100,[0 0 0],[0 0 1]);
title(['n = ' num2str(length(Index))]);
saveas(gcf, ['SVMDecAcc-' Title '-1000-AllTrials-0524'],'fig')
saveas(gcf, ['SVMDecAcc-' Title '-1000-AllTrials-0524'],'png')

% clear('a','b','p_500')
% for i = 1 : 120/5
% %    a=reshape(Acc_Late.Correct(:,(i-1)*5+1:i*5),[],1);
% %    b=reshape(Acc_Off.Correct(:,(i-1)*5+1:i*5),[],1);
%    a=mean(Acc_LaserOff.Correct(:,(i-1)*5+1:i*5),1);
%    b=mean(Acc_LaserOn.Correct(:,(i-1)*5+1:i*5),1);
%    p_500(1,i)=ranksum(a,b);
% end

%%
NewFR_1_EarlyDelay = cellfun(@(x) mean(x(:,31:50),2),NewFR_Off,'un',0);
NewFR_2_EarlyDelay = cellfun(@(x) mean(x(:,31:50),2),NewFR_Early,'un',0);
NewFR_1_LateDelay = cellfun(@(x) mean(x(:,71:90),2),NewFR_Off,'un',0);
NewFR_3_LateDelay = cellfun(@(x) mean(x(:,71:90),2),NewFR_Late,'un',0);

%%
% BS-LaserChanged Units for early activation
repeat=1000;
clear('Index','tempIndex')
Index=intersect(idx_E_Changed,BS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_EarlyDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2_EarlyDelay(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='FRChanged-BS-LaserPeriod-EarlyUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% NS-LaserChanged Units for early activation
clear('Index','tempIndex')
Index=intersect(idx_E_Changed,NS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_EarlyDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2_EarlyDelay(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='FRChanged-NS-LaserPeriod-EarlyUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc

% BS-LaserChanged Units for late activation
clear('Index','tempIndex')
Index=intersect(idx_L_Changed,BS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_LateDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3_LateDelay(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='FRChanged-BS-LaserPeriod-LateUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% NS-LaserChanged Units for early activation
clear('Index','tempIndex')
Index=intersect(idx_L_Changed,NS_Idxs);
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_LateDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3_LateDelay(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='FRChanged-NS-LaserPeriod-LateUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% LaserChanged Units for early activation
clear('Index','tempIndex')
Index=idx_E_Changed;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_EarlyDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2_EarlyDelay(Index),Trials_Early(Index),1000,3,1,36,4,0);
Title='FRChanged-LaserPeriod-EarlyUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% LaserChanged Units for late activation
clear('Index','tempIndex')
Index=idx_L_Changed;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_LateDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_3_LateDelay(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='FRChanged-LaserPeriod-LateUnits-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc
% allunits Units for late activation
clear('Index','tempIndex')
Index=[1:1:750]';
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1_LateDelay(Index),Trials_Off(Index),1000,3,1,36,4,0);
[Acc_LaserOnEarly] = svm_decoding_correct_error_new(NewFR_2_EarlyDelay(Index),Trials_Early(Index),1000,3,1,36,4,0);
[Acc_LaserOnLate] = svm_decoding_correct_error_new(NewFR_3_LateDelay(Index),Trials_Late(Index),1000,3,1,36,4,0);
Title='AllUnits-LaserPeriod-';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOnEarly','Acc_LaserOnLate','Trials_Off','Trials_Early','Trials_Late','Title','repeat','-v7.3')
toc


Acc_BS_E_Off=Acc_LaserOff.Correct;
Acc_BS_E_On=Acc_LaserOn.Correct;
Acc_BS_E_Off_shf=Acc_LaserOff.Shuffle;
Acc_BS_E_On_shf=Acc_LaserOn.Shuffle;
Acc_NS_E_Off=Acc_LaserOff.Correct;
Acc_NS_E_On=Acc_LaserOn.Correct;
Acc_NS_E_Off_shf=Acc_LaserOff.Shuffle;
Acc_NS_E_On_shf=Acc_LaserOn.Shuffle;
Acc_BS_L_Off=Acc_LaserOff.Correct;
Acc_BS_L_On=Acc_LaserOn.Correct;
Acc_BS_L_Off_shf=Acc_LaserOff.Shuffle;
Acc_BS_L_On_shf=Acc_LaserOn.Shuffle;
Acc_NS_L_Off=Acc_LaserOff.Correct;
Acc_NS_L_On=Acc_LaserOn.Correct;
Acc_NS_L_Off_shf=Acc_LaserOff.Shuffle;
Acc_NS_L_On_shf=Acc_LaserOn.Shuffle;


[muHat_E,~,muCI_E,~]=normfit([Acc_BS_E_Off Acc_BS_E_On Acc_BS_E_Off_shf Acc_BS_E_On_shf]);
[muHat_E_shf,~,muCI_E_shf,~]=normfit([Acc_BS_E_Off Acc_BS_E_On Acc_BS_E_Off_shf Acc_BS_E_On_shf]);
figure
bar([1 2 5 6],muHat_E(:,[1 4 7 10]),'BarWidth',0.8)
hold on
errorbar([1 2 5 6],muHat_E(:,[1 4 7 10]),diff(muCI_E(:,[1 4 7 10]))*0.5,'LineStyle','none')
set(gca,'Xlim',[0,7],'XTick',[1,2,5,6],'XTickLabel',{'Off-BS','On-BS','Off-Shf','On-Shf'},'YLim',[0.4,1.0],'YTick',[0.4,0.6,0.8 1.0],'YTickLabel',{'40','60','80','100'})
ylabel('Decoding Acc. (%)')
text([1.5 5.5],[0.98 0.7],['***' 'n.s.'])
saveas(gcf, ['SVMDecodingAcc-EarlyDelay-LaserChangedBSUnits-20230827'],'fig')
saveas(gcf, ['SVMDecodingAcc-EarlyDelay-LaserChangedBSUnits-20230827'],'png')
figure
bar([1 2 5 6],muHat_E_shf,'BarWidth',0.8)
hold on
errorbar([1 2 5 6],muHat_E_shf,diff(muCI_E_shf)*0.5,'LineStyle','none')
set(gca,'Xlim',[0,7],'XTick',[1,2,5,6],'XTickLabel',{'Off-BS','On-BS','Off-NS','On-NS'},'YLim',[0.4,0.6],'YTick',[0.4,0.5,0.6],'YTickLabel',{'40','50','60'})
ylabel('Decoding Acc. (%)')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Early-LaserChangedBS-NSUnits_Shuffle'],'fig')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Early-LaserChangedBS-NSUnits_Shuffle'],'png')

[muHat_L,~,muCI_L,~]=normfit([Acc_BS_L_Off Acc_BS_L_On Acc_NS_L_Off Acc_NS_L_On]);
[muHat_L_shf,~,muCI_L_shf,~]=normfit([Acc_BS_L_Off_shf Acc_BS_L_On_shf Acc_NS_L_Off_shf Acc_NS_L_On_shf]);
figure
bar([1 2 5 6],muHat_L,'BarWidth',0.8)
hold on
errorbar([1 2 5 6],muHat_L,diff(muCI_L)*0.5,'LineStyle','none')
set(gca,'Xlim',[0,7],'XTick',[1,2,5,6],'XTickLabel',{'Off-BS','On-BS','Off-NS','On-NS'},'YLim',[0.4,1.0],'YTick',[0.4,0.6,0.8 1.0],'YTickLabel',{'40','60','80','100'})
ylabel('Decoding Acc. (%)')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Late-LaserChangedBS-NSUnits'],'fig')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Late-LaserChangedBS-NSUnits'],'png')
figure
bar([1 2 5 6],muHat_L_shf,'BarWidth',0.8)
hold on
errorbar([1 2 5 6],muHat_L_shf,diff(muCI_L_shf)*0.5,'LineStyle','none')
set(gca,'Xlim',[0,7],'XTick',[1,2,5,6],'XTickLabel',{'Off-BS','On-BS','Off-NS','On-NS'},'YLim',[0.4,0.6],'YTick',[0.4,0.5,0.6],'YTickLabel',{'40','50','60'})
ylabel('Decoding Acc. (%)')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Late-LaserChangedBS-NSUnits_Shuffle'],'fig')
saveas(gcf, ['SVMDecodingAcc-LaserPeriod-Late-LaserChangedBS-NSUnits_Shuffle'],'png')

p.SVM_BS_EarlyChangedUnits = ranksum(Acc_BS_E_On,Acc_BS_E_Off);
p.SVM_NS_EarlyChangedUnits = ranksum(Acc_NS_E_On,Acc_NS_E_Off);
p.SVM_BS_LateChangedUnits = ranksum(Acc_BS_L_On,Acc_BS_L_Off);
p.SVM_NS_LateChangedUnits = ranksum(Acc_NS_L_On,Acc_NS_L_Off);
p.SVM_BS_EarlyChangedUnits_shf = ranksum(Acc_BS_E_On_shf,Acc_BS_E_Off_shf);
p.SVM_NS_EarlyChangedUnits_shf = ranksum(Acc_NS_E_On_shf,Acc_NS_E_Off_shf);
p.SVM_BS_LateChangedUnits_shf = ranksum(Acc_BS_L_On_shf,Acc_BS_L_Off_shf);
p.SVM_NS_LateChangedUnits_shf = ranksum(Acc_NS_L_On_shf,Acc_NS_L_Off_shf);
save(['Statistics-SVM-' DateID],'p');

Acc_E_Off=Acc_LaserOff.Correct;
Acc_E_On=Acc_LaserOn.Correct;
Acc_L_Off=Acc_LaserOff.Correct;
Acc_L_On=Acc_LaserOn.Correct;

[muHat_E,~,muCI_E,~]=normfit([Acc_E_Off Acc_E_On Acc_L_Off Acc_L_On]);


for nBin = 1 : 50
    num_Dec_L(1,nBin) = length(find(UnitWaveproperty.Trough_to_Peak(idx_L_Dec)>=(nBin-1)*0.025&UnitWaveproperty.Trough_to_Peak(idx_L_Dec)<nBin*0.025));
    num_Inc_L(1,nBin) = length(find(UnitWaveproperty.Trough_to_Peak(idx_L_Inc)>=(nBin-1)*0.025&UnitWaveproperty.Trough_to_Peak(idx_L_Inc)<nBin*0.025));
    num_Dec_E(1,nBin) = length(find(UnitWaveproperty.Trough_to_Peak(idx_E_Dec)>=(nBin-1)*0.025&UnitWaveproperty.Trough_to_Peak(idx_E_Dec)<nBin*0.025));
    num_Inc_E(1,nBin) = length(find(UnitWaveproperty.Trough_to_Peak(idx_E_Inc)>=(nBin-1)*0.025&UnitWaveproperty.Trough_to_Peak(idx_E_Inc)<nBin*0.025));
    
    
end





