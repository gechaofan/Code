%% organize data for svm decoding
filename=ls('VTAtomPFC-*.mat');
load(filename);
DateID = datestr(datetime, 'yyyymmdd');

for i = 1 : 475
    temp=[];
    temp= TotalUnitSplitData.AllSequentialAllSP{i,1}';
    RawFR{i,1}=cell2mat(temp); 
end
Trials_Off= cellfun(@(x,y) x(y==0,:),TotalUnitSplitData.TrialsJudgement,TotalUnitSplitData.Laser,'un',0);
FR_Off = cellfun(@(x, y) x(y==0,:), RawFR,TotalUnitSplitData.Laser,'un',0);
Trials_On= cellfun(@(x,y) x(y==1,:),TotalUnitSplitData.TrialsJudgement,TotalUnitSplitData.Laser,'un',0);
FR_On = cellfun(@(x, y) x(y==1,:), RawFR,TotalUnitSplitData.Laser,'un',0);

[NormFR_Off,~]=GetAllUnitsNormalizedFRinSpecificTrials(FR_Off,TotalUnitSplitData.AllUnitID,TotalUnitSplitData.TimeGain);
[NormFR_On,~]=GetAllUnitsNormalizedFRinSpecificTrials(FR_On,TotalUnitSplitData.AllUnitID,TotalUnitSplitData.TimeGain);

Mean_NormRF_Off = cell2mat(cellfun(@(x) mean(x,1),NormFR_Off,'un',0));
Mean_NormRF_On = cell2mat(cellfun(@(x) mean(x,1),NormFR_On,'un',0));

% rebined fr to 500ms with 100ms step
NewFR_Off =cellfun(@(x) smooth2(x,'moving',5),NormFR_Off,'un',0);
NewFR_On =cellfun(@(x) smooth2(x,'moving',5),NormFR_On,'un',0);
%% 1s
FR_Off_1s = ReDefineBinSize(FR_Off,1000,100);% laser off
FR_On_1s = ReDefineBinSize(FR_On,1000,100);
M_FR_Off_1s = cell2mat(cellfun(@(x) mean(x,1),FR_Off_1s, 'un', 0));
M_FR_On_1s = cell2mat(cellfun(@(x) mean(x,1),FR_On_1s, 'un', 0));

%% laser effect second base

for iNeu = 1 : 475
    for iBin = 1 : 20
        % all trials
        [p(iNeu,iBin),large(iNeu,iBin)]=ranksumTest(FR_On_1s{iNeu,1}(:,iBin),FR_Off_1s{iNeu,1}(:,iBin),1);
    end 
end
LaserEffect=zeros(475,20);
LaserEffect(find(p<0.05&large==1))=1;LaserEffect(find(p<0.05&large==2))=-1;
idx_Dec = find(sum(LaserEffect(:,4:9),2)<0);
idx_Inc = find(sum(LaserEffect(:,4:9),2)>0);
CompareFRForSpecificTrialsCrossNeuron(NormFR_Off(idx_Dec,:),NormFR_On(idx_Dec,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['NormFR-FRDecreasedUnits'],'png')
saveas(gcf, ['NormFR-FRDecreasedUnits'],'fig')
save(['VTA-ChR2-mPFC-Recoding_LaserEffect' DateID],'LaserEffect','idx_Dec','idx_Inc','NormFR_Off','NormFR_On','FR_Off','FR_On','Trials_Off','Trials_On','-v7.3')
%% selectivity, second base
A_FR_Off_1s = cellfun(@(x,y) x(y(:,2)==1,:),FR_Off_1s,Trials_Off,'un',0);
B_FR_Off_1s = cellfun(@(x,y) x(y(:,2)==2,:),FR_Off_1s,Trials_Off,'un',0);
A_FR_On_1s = cellfun(@(x,y) x(y(:,2)==1,:),FR_On_1s,Trials_On,'un',0);
B_FR_On_1s = cellfun(@(x,y) x(y(:,2)==2,:),FR_On_1s,Trials_On,'un',0);
for iNeu = 1 : 475
    [Selectivity_Off(iNeu,:),p_Selec_Off(iNeu,:)]=CalculateSelectivityWithPermTest(A_FR_Off_1s{iNeu,1},B_FR_Off_1s{iNeu,1});
    [Selectivity_On(iNeu,:),p_Selec_On(iNeu,:)]=CalculateSelectivityWithPermTest(A_FR_On_1s{iNeu,1},B_FR_On_1s{iNeu,1});
end
SelectIndex_Off=zeros(793,20); SelectIndex_On=zeros(793,20);
SelectIndex_Off(find(Selectivity_Off>0 & p_Selec_Off<0.05))=1; % select sample A
SelectIndex_Off(find(Selectivity_Off<0 & p_Selec_Off<0.05))=-1; % select sample B
SelectIndex_On(find(Selectivity_On>0 & p_Selec_On<0.05))=1; % select sample A
SelectIndex_On(find(Selectivity_On<0 & p_Selec_On<0.05))=-1; % select sample B

%% SVM decoding
DateID = datestr(datetime, 'yyyymmdd');
repeat=1000;
NewFR_1 = cellfun(@(x) x(:,10:130),NewFR_Off,'un',0);
NewFR_2 = cellfun(@(x) x(:,10:130),NewFR_On,'un',0);
clear('Index','tempIndex')
Index=[idx_Dec;idx_Inc];
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);% all trials
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_On(Index),1000,3,1,36,4,0);
Title='FRChanged-Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','Trials_Off','Trials_On','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=[1:1:475]';
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);% all trials
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_On(Index),1000,3,1,36,4,0);
Title='AllUnits-Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','Trials_Off','Trials_On','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=idx_Dec;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);% all trials
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_On(Index),1000,3,1,36,4,0);
Title='FRDecUnits-Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','Trials_Off','Trials_On','Title','repeat','-v7.3')
toc
clear('Index','tempIndex')
Index=idx_Inc;
tic
[Acc_LaserOff] = svm_decoding_correct_error_new(NewFR_1(Index),Trials_Off(Index),1000,3,1,36,4,0);% all trials
[Acc_LaserOn] = svm_decoding_correct_error_new(NewFR_2(Index),Trials_On(Index),1000,3,1,36,4,0);
Title='FRIncUnits-Training';
save(['SVMResults-Alltrials-' Title, DateID],'Index','Acc_LaserOff','Acc_LaserOn','NewFR_1','NewFR_2','Trials_Off','Trials_On','Title','repeat','-v7.3')
toc

clear('Acc_LaserOff','Acc_LaserOn','Index')
[STATISTICS]=PlotSVMResults(Acc_LaserOff,Acc_LaserOn,1,12,100,[0 0 0],[0 0 1]);
saveas(gcf, ['SVMDecodingForAlltrials-AllUnits'],'png')
saveas(gcf, ['SVMDecodingForAlltrials-AllUnits'],'fig')

for i = 1 : 6
    Acc_Off_1s_delay(:,i) = mean(Acc_LaserOff.Correct(:,(i+2)*10+1:(i+3)*10),2);
    Acc_On_1s_delay(:,i) = mean(Acc_LaserOn.Correct(:,(i+2)*10+1:(i+3)*10),2);
end
%%

LaserOffIndex=cellfun(@(x) find(x==0),AllLaserTrialsID,'un',0);
LaserOffAllTrialsFR=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOffIndex,'un',0);
[NormAllTrialsFR_LaserOff,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllTrialsFR=PlotHeatMap(NormAllTrialsFR_LaserOff,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'png')
close all




