%% this code is used for template-matching decoding analysis using CQ-type data 
clc; clear all; close all;
num_neuron_ForDecoding=105;% if IsCorrectOrErrorOrAllTrials=4, NL-430; ChR-380; NpHR-340
num_trial_ForEachCondition=40;
IsCorrectOrErrorOrAllTrials=3;%1 for correct trials, 2 for error trials , 3 for all trials, 4 for correct trials as template, error trials as test
GroupNum=2;
NullDistributionNum=10;
num_resample_runs=10;%define the decoding times
Normalization=1;%1 fir normalize firing rate to baseline    
IsShffleDecoding=0;
IsCalculateTCTDecodingResults=1;
AddSustainedNeuronWithSigBinNum=[6]; % add selective neurons to non-selective pools with target bin number having sustained
OnlyWithOrAddTargetSigBinNum=1; % 1 for only with target neurons with specific sig bins, 2 for add  target neurons to non-selective neurons

TargetDayID=[{['All']}];
% TargetPerformanceID=[{['-Early']} {['-Late']}];
% TargetPerformanceID=[{['-Early']} {['-Mid']} {['-Late']}];
TargetBrainID='VTAtomPFC';%define the brain area for summary
UnitSummaryFile=dir(['*' TargetBrainID '-DPA-AllUnitsSummary*.mat']);
WorkerNumber=10;
for iFile=[1]%go through each group of data
    Filename=UnitSummaryFile(iFile).name(1:end-4);
    LaserEffectFileName=ls('LaserChangedUnitIndex.mat');
    load(LaserEffectFileName);
    disp(Filename)
%     num_neuron_ForDecoding=475;% if IsCorrectOrErrorOrAllTrials=4, NL-430; ChR-380; NpHR-340
%     num_trial_ForEachCondition=50;
%     IsCorrectOrErrorOrAllTrials=3;%1 for correct trials, 2 for error trials , 3 for all trials, 4 for correct trials as template, error trials as test
%     GroupNum=2;
%     NullDistributionNum=10;
%     num_resample_runs=100;%define the decoding times
%     
%     IsShffleDecoding=0;
%     IsCalculateTCTDecodingResults=1;
%     AddSustainedNeuronWithSigBinNum=[7]; % add selective neurons to non-selective pools with target bin number having sustained
%     OnlyWithOrAddTargetSigBinNum=1; % 1 for only with target neurons with specific sig bins, 2 for add  target neurons to non-selective neurons
    for ExcludeTransientSustainedNeu=[0]
        ExcludeNeuronWithReversedOdorSelectivity=0; %1 delay reversed selec neu; 2 sample-delay reversed selec neu; 3 both 1 and 2;4 for only with reversed neurons
        PairOrNonPairTrials=3;%1 for pairing trials, 2 for non-pairing trials,3 for all trials
        
        bin_width=500;%define the bin width for each sliding window
        step_size=100;%ms
        StartTime=0;%start from 2 second baseline(which means 2s before the sample odor)
        NotComputeLastSecondNum=0;
        CellType=1;% 1 for all neurons, 2 for pyramidal neurons, 3 for interneurons
        DecodingForSamTestDecisionTrialType=1;% Decoding for 1-sample odor,2-test odor, 3-decision(FC or CR in nonpair trials), 4-trial type(Pair-Nonpair)
        IsNormalizedData=1;
        GroupID='-NL';
        IsChR=regexpi(Filename,'ChR');
        if ~isempty(IsChR)
            GroupID='-ChR';
        end
        IsNpHR=regexpi(Filename,'NpHR');
        if ~isempty(IsNpHR)
            GroupID='-NpHR';
        end
        load(Filename);
        TimeGain=TotalUnitSplitData.TimeGain;
        
        %% get performace based unit ID
        switch size(TargetDayID,2)
            case 2
                UnitID_PerLargerthan70= find(TotalUnitSplitData.BehavioralPer(:,1)>=0.70);
                UnitID_PerSmallerthan70= find(TotalUnitSplitData.BehavioralPer(:,1)<0.70);
                UnitID_SpecificCondition=[{UnitID_PerSmallerthan70} {UnitID_PerLargerthan70}];
            case 3
                UnitID_PerLargerthan75= find(TotalUnitSplitData.BehavioralPer(:,1)>=0.75);
                UnitID_PerinMid= find(TotalUnitSplitData.BehavioralPer(:,1)>=0.60&TotalUnitSplitData.BehavioralPer(:,1)<0.75);
                UnitID_PerSmallerthan60= find(TotalUnitSplitData.BehavioralPer(:,1)<0.60);
                UnitID_SpecificCondition=[{UnitID_PerSmallerthan60} {UnitID_PerinMid} {UnitID_PerLargerthan75}];
            case 1
%                 UnitID_SpecificCondition={[1:1:size(TotalUnitSplitData.AllUnitID,1)]'};
                  UnitID_SpecificCondition=FRIncreasedID;
        end
        %%
        for iTargetDay = 1:size(TargetDayID,2)            
            TrainingDayID=TargetDayID{iTargetDay};
                        
%             TargetNeuronID=UnitID_SpecificCondition(1,iTargetDay);
            TargetNeuronID=UnitID_SpecificCondition;
%             tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,vertcat(TargetNeuronID{:}),[]);
            
            if length(TargetNeuronID)>=0
                LaserPhase=unique(TotalUnitSplitData.Laser{1});%2 for laser in block design
                
                for IsLaser=1:size(LaserPhase,1)
                    IsLaserTrial=LaserPhase(IsLaser);
%                     TargetNeuronID=UnitID_SpecificCondition(1,iTargetDay);%%%%%%%%%%%%%%%%%%%%%%%%%
                    if(size(LaserPhase,1)==1) %% no laser of Laser on for all trials
                       tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,vertcat(TargetNeuronID{:}),[]); 
                    else
%                         tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,vertcat(TargetNeuronID{:}),IsLaserTrial);
                      tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,TargetNeuronID,IsLaserTrial);
                    end

                    TimeGain=tempTotalUnitSplitData.TimeGain;
                    SPlen=min(vertcat(tempTotalUnitSplitData.ShortSPlen{:}));
                    MeanTrialLength=SPlen/TimeGain;
                    if ExcludeNeuronWithReversedOdorSelectivity>0||ExcludeTransientSustainedNeu>0
                        [NeuronIDWithDelayReversedOdorSelectivity,NonSelectiveNeuID,SampleDelayReversedSelectivityNeuID,DelaySigBinNum]...
                            =FilterNeuronIDWithReversedOdorSelectivity(tempTotalUnitSplitData,TimeGain,OdorMN,DelayMN);
                        BothSwithNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                        
                        if ExcludeNeuronWithReversedOdorSelectivity==1
                            tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,NeuronIDWithDelayReversedOdorSelectivity);
                            disp(['---- Excluded Neurons With reversed odor selectivity-' num2str(length(NeuronIDWithDelayReversedOdorSelectivity)) '----'])
                        elseif ExcludeNeuronWithReversedOdorSelectivity==2
                            tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,SampleDelayReversedSelectivityNeuID);
                            disp(['---- Excluded Neurons With sample-delay reversed odor selectivity-' num2str(length(SampleDelayReversedSelectivityNeuID)) '----'])
                        elseif ExcludeNeuronWithReversedOdorSelectivity==3
                            AllReversedSelecNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                            tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,AllReversedSelecNeuID);
                            AllReversedSelectiveNeuNum=length(AllReversedSelecNeuID);
                            disp(['---- Excluded delay reversed selec and sample-delay reversed selec neu-' num2str(AllReversedSelectiveNeuNum) '----'])
                        elseif ExcludeNeuronWithReversedOdorSelectivity==4
                            AllReversedSelecNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                            tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,AllReversedSelecNeuID);
                            disp(['---- Decoding only With reversed odor selectivity-' num2str(length(AllReversedSelecNeuID)) '----'])
                        end
                        %%%%%%%%
                        if ExcludeTransientSustainedNeu==1%exclude transient selective neurons
                            tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,TransientNeuID);
                            disp(['-----Exclude transient selective neurons-' num2str(length(TransientNeuID)) '-----'])
                        elseif ExcludeTransientSustainedNeu==2%exclude sustained selective neurons
                            tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,SustainedNeuID);
                            disp(['-----Exclude sustained selective neurons-' num2str(length(SustainedNeuID)) '-----'])
                        elseif ExcludeTransientSustainedNeu==3%Only with transient selective neurons
                            tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,TransientNeuID);
                            disp(['-----Only With transient selective neurons-' num2str(length(TransientNeuID)) '-----'])
                        elseif ExcludeTransientSustainedNeu==4%Only with sustained selective neurons
                            tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,SustainedNeuID);
                            disp(['-----Only With SustainedNeuID selective neurons-' num2str(length(SustainedNeuID)) '-----'])
                        end
                    end
                    %% %%%%%%%%%%
                    if CellType>1%identify the cell type with the waveform,1 for all neurons, 2 for pyramidal neurons, 3 for interneurons
                        AllWaveForm=tempTotalUnitSplitData.WaveForm;
                        Threshold=350;%threshold seperate fast spiking interneuron and pyramidal neurons
                        [AllPeakTroughDuration,FSIID,PCID]=IdentifyCellTypeBasedOnWaveform(AllWaveForm,Threshold);
                        if CellType==2%2 for pyramidal neurons
                            tempTotalUnitSplitData=FilterTotalUnitSplitData(tempTotalUnitSplitData,PCID);
                        elseif CellType==3%3 for interneurons
                            tempTotalUnitSplitData=FilterTotalUnitSplitData(tempTotalUnitSplitData,FSIID);
                        end
                    end
                    %% add neurons with sustained odor selectivty to no selective neurons
                    TotalSingleUnitNum=length(tempTotalUnitSplitData.AllSequentialAllSP);
                    IsSustainedOdorSelectiveNeuron=zeros(TotalSingleUnitNum,6);
                    TargetNeuronIDWithSpecificSigBin=[];
                    if min(AddSustainedNeuronWithSigBinNum)>=0&&max(AddSustainedNeuronWithSigBinNum)<=5
                        disp('-----Pre-processing the odor selectivity for each neuron -----')
                        
                        NonSelectiveNeuID=find(DelaySigBinNum_Pemu==0);
                        TargetNeuronIDWithSpecificSigBin=[];
                        for i=1:length(AddSustainedNeuronWithSigBinNum)
                            TargetNeuronIDWithSpecificSigBin=[TargetNeuronIDWithSpecificSigBin;find(DelaySigBinNum_Pemu==AddSustainedNeuronWithSigBinNum(i))];
                        end
                        TargetNeuronIDWithSpecificSigBin=setdiff(TargetNeuronIDWithSpecificSigBin,BothSwithNeuID_Pemu);
                        TargetNeuronID=[TargetNeuronIDWithSpecificSigBin;NonSelectiveNeuID];
                        TargetNeuronID=unique(TargetNeuronID);
                        disp(['-----Target sig neuron number-' num2str(length(TargetNeuronIDWithSpecificSigBin)) '-----'])
                        
                        if OnlyWithOrAddTargetSigBinNum==1% only with neurons with specific sig bin during delay
                            TargetNeuronID=TargetNeuronIDWithSpecificSigBin;
                        elseif OnlyWithOrAddTargetSigBinNum==2% target sig neurons with non-selective neurons
                            TargetNeuronID=TargetNeuronID;
                        end
                    else
                        TargetNeuronID=1:TotalSingleUnitNum;
                    end
                    TotalSingleUnitNum=length(TargetNeuronID);
                    disp(['---- GroupNum-' num2str(GroupNum) '-TotalNullDistributionNum-' num2str(NullDistributionNum) '----'] )
                    TitleName=ConstructDecodingTitle(TargetBrainID,DecodingForSamTestDecisionTrialType,IsLaserTrial,IsShffleDecoding...
                        ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,num_trial_ForEachCondition,num_trial_ForEachCondition,[],0,0,GroupID...
                        ,0,TrainingDayID,bin_width,IsCorrectOrErrorOrAllTrials,CellType,AddSustainedNeuronWithSigBinNum...
                        ,ExcludeTransientSustainedNeu,ExcludeNeuronWithReversedOdorSelectivity,IsCalculateTCTDecodingResults);
                    disp(TitleName)
                    %% Construct the raw trial matrix
                    disp(['-----Step 1 Construct raw data Total Neuron Number-' num2str(TotalSingleUnitNum) '-----'])
                    TrialBinnedFR=cell(1,TotalSingleUnitNum);
                    AllNeuronTrialNumber=zeros(2,TotalSingleUnitNum);
                    AllNeuSampleTrialID=cell(2,TotalSingleUnitNum);
                    for iNeuron = 1:TotalSingleUnitNum% go through each neuron
                        tempNeuronID=TargetNeuronID(iNeuron);
                        SequentialAllSP=tempTotalUnitSplitData.AllSequentialAllSP{tempNeuronID};
                        if size(SequentialAllSP,2)<=200
                            TrialsJudgement=tempTotalUnitSplitData.TrialsJudgement{tempNeuronID}(1:size(SequentialAllSP,2),:);
                        else
                            TrialsJudgement=tempTotalUnitSplitData.TrialsJudgement{tempNeuronID}(1:200,:);
                        end
%                     TrialLaserDelay=tempTotalUnitSplitData.TrialLaserDelay{tempNeuronID}(1:size(SequentialAllSP,2),:);
                        
                        %if IsLaserTrial==0%no laser trials
                            %SequentialAllSP=SequentialAllSP(:,TrialLaserDelay(:,2)==0);
                            %TrialsJudgement=TrialsJudgement(TrialLaserDelay(:,2)==0,:);
                        %else
                            %SequentialAllSP=SequentialAllSP(:,TrialLaserDelay(:,2)~=0);
                            %TrialsJudgement=TrialsJudgement(TrialLaserDelay(:,2)~=0,:);
                        %end
                        [TrialIndex1,TrialIndex2,tempTrialBinnedFR] =ConstrucSingleNeuForDecoding...
                            (DecodingForSamTestDecisionTrialType,TrialsJudgement,IsCorrectOrErrorOrAllTrials...
                            ,SequentialAllSP,bin_width,step_size,MeanTrialLength,1,NotComputeLastSecondNum,StartTime,Normalization);
                        
                        TrialBinnedFR{1,iNeuron}=tempTrialBinnedFR;
                        AllNeuSampleTrialID(:,iNeuron)=[{TrialIndex1};{TrialIndex2}];
                        AllNeuronTrialNumber(:,iNeuron)=[length(TrialIndex1);length(TrialIndex2)];
                    end
                    [~,TooFewTrialNeuronIndex]=find(min(AllNeuronTrialNumber)<num_trial_ForEachCondition);
                    TrialBinnedFR(:,TooFewTrialNeuronIndex)=[];
                    AllNeuSampleTrialID(:,TooFewTrialNeuronIndex)=[];
                    
                    disp(['-----Neuron Number With Enough Trial-' num2str(length(TrialBinnedFR)) '->=' num2str(num_trial_ForEachCondition) '-----'])
                    %% calculate the decoding accuracy by using correct tirals
                    if WorkerNumber>1
                        poolobj = gcp('nocreate'); % If no pool, do not create new one.
                        if isempty(poolobj)
                            myCluster=parcluster('local'); myCluster.NumWorkers=WorkerNumber; parpool(myCluster,WorkerNumber);
                        end
                        disp('-----Step 2 Start decoding analysis-----')
%                         disp(datetime)
                        for iNullDis=1:NullDistributionNum
                            f(iNullDis) = parfeval(@CQCrossValidationTest,1,TrialBinnedFR,AllNeuSampleTrialID,num_trial_ForEachCondition...
                                ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,IsShffleDecoding,IsCalculateTCTDecodingResults);
                        end
                        for iNullDis=1:NullDistributionNum
                            [~,DECODING_RESULTS] = fetchNext(f);  % Collect the results as they become available.
                            save(['GCFCV-DelaySelectiveUnit' TitleName '-' num2str(GroupNum) '-' num2str(iNullDis)], 'DECODING_RESULTS','-v7.3');
                        end
                    else
                        for iNullDis=1:NullDistributionNum
                            DECODING_RESULTS = CQCrossValidationTest(TrialBinnedFR,AllNeuSampleTrialID,num_trial_ForEachCondition...
                                ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,IsShffleDecoding,IsCalculateTCTDecodingResults);
                            save(['GCFCV' TitleName '-' num2str(GroupNum) '-' num2str(iNullDis)], 'DECODING_RESULTS','-v7.3');
                        end
                    end
                    BinNum=size(TrialBinnedFR{1},2);
                    ProceedingBinNum=bin_width/step_size;
                    X=-(2-StartTime):step_size/1000:(BinNum*step_size/1000-(2-StartTime))-step_size/1000;
                    X=X+ProceedingBinNum*step_size/1000+step_size/1000/2;
                    save(['GCFCV-LaserIncreasedFRUnit' TitleName '-All Parameters'],'TitleName','DECODING_RESULTS','TrialBinnedFR','AllNeuSampleTrialID','AllNeuronTrialNumber'...
                        ,'num_trial_ForEachCondition','TimeGain','OdorMN','DelayMN','ResponseMN','WaterMN','ITIMN','num_resample_runs'...
                        ,'num_trial_ForEachCondition','SPlen','bin_width','step_size','Filename','num_neuron_ForDecoding','NotComputeLastSecondNum'...
                        ,'StartTime','X','AddSustainedNeuronWithSigBinNum','ExcludeNeuronWithReversedOdorSelectivity','IsLaserTrial')

                end
            end
        end
    end
end
%% plot decoding acuracy
%% 
DecodingData_Condition1=[];
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
for itr1 =1:MainCircleN
    load(filename{itr1});
    DecodingData_Condition1=[DecodingData_Condition1;DECODING_RESULTS];
end

DecodingData_Condition2=[];
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
for itr1 =1:MainCircleN
    load(filename{itr1});
    DecodingData_Condition2=[DecodingData_Condition2;DECODING_RESULTS];
end
 p=nan(1,201);larger=nan(1,201);
for itr0=1:201
%         [p(1,itr0),larger(1,itr0)]=permTest(DecodingData_Condition2(:,itr0),DecodingData_Condition1(:,itr0));
    p(itr0)=signrank(DecodingData_Condition1(:,itr0),DecodingData_Condition2(:,itr0));
end
Significance=find(p<0.05/10/6);
    Temp=Significance/10-2;
   X=[-2+0.1:0.1:20-2+0.1];

    figure('color',[1 1 1])
    h1=area([0 1],[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
    hold on
    h2=area([7 8],[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
    h3=area([9 10],[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
    box off
    
    fill([X,fliplr(X)],[smooth(mean(DecodingData_Condition1,1)-std(DecodingData_Condition1,0,1)/sqrt(size(DecodingData_Condition1,1)-1))',smooth(fliplr(mean(DecodingData_Condition1,1)+std(DecodingData_Condition1,0,1)/sqrt(size(DecodingData_Condition1,1)-1)))'],...
        [0 0 0],'edgecolor','none','FaceAlpha',0.3)
     hold on
    fill([X,fliplr(X)],[smooth(mean(DecodingData_Condition2,1)-std(DecodingData_Condition1,0,1)/sqrt(size(DecodingData_Condition2,1)-1))',smooth(fliplr(mean(DecodingData_Condition2,1)+std(DecodingData_Condition2,0,1)/sqrt(size(DecodingData_Condition2,1)-1)))'],...
        [1 0 0],'edgecolor','none','FaceAlpha',0.3) 
    plot(X,smooth(mean(DecodingData_Condition1,1),5,'moving')','k','LineWidth',2)
    plot(X,smooth(mean(DecodingData_Condition2,1),5,'moving')','r','LineWidth',2)
    plot(Temp,ones(1,length(Temp)),'Marker','.','LineStyle','none','Color',[0 0 0])
    %%%
%     fill([X,fliplr(X)],[mean(data1,1)-std(data1,0,1)/sqrt(size(data1,1)-1),fliplr(mean(data2,1)+std(data1,0,1)/sqrt(size(data1,1)-1))],...
%         [0 0 0],'edgecolor','none','FaceAlpha',0.3)
%      hold on
%     fill([X,fliplr(X)],[mean(data2,1)-std(data2,0,1)/sqrt(size(data2,1)-1),fliplr(mean(data2,1)+std(data2,0,1)/sqrt(size(data2,1)-1))],...
%         [1 0 0],'edgecolor','none','FaceAlpha',0.3) 
%     plot(X,mean(data1,1),'k','LineWidth',2)
%     plot(X,mean(data2,1),'r','LineWidth',2)
%     plot(Temp,ones(1,length(Temp)),'Marker','.','LineStyle','none','Color',[0 0 0])
   
    %% %% CTD plot
    
DecodingData_Condition1=[];
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
for itr1 =1:MainCircleN
    load(filename{itr1});
    DecodingData_Condition1=[DecodingData_Condition1;DECODING_RESULTS];
end

DecodingData_Condition2=[];
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
for itr1 =1:MainCircleN
    load(filename{itr1});
    DecodingData_Condition2=[DecodingData_Condition2;DECODING_RESULTS];
end

Data1=mean(DecodingData_Condition1,1);
tempData1=reshape(Data1,201,201);
Data2=mean(DecodingData_Condition2,1);
tempData2=reshape(Data2,201,201);
subplot(1,2,1)
imagesc(flipud(tempData1));
hold on
plot([20 20],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2);
plot([30 30],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([90 90],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([100 100],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[180 180],'color',[0 0 0],'LineStyle','--','LineWidth',2);
plot([0 200],[170 170],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[110 110],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[100 100],'color',[0 0 0],'LineStyle','--','LineWidth',2)
subplot(1,2,2)
imagesc(flipud(tempData2));
hold on
plot([20 20],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2);
plot([30 30],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([90 90],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([100 100],[0 200],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[180 180],'color',[0 0 0],'LineStyle','--','LineWidth',2);
plot([0 200],[170 170],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[110 110],'color',[0 0 0],'LineStyle','--','LineWidth',2)
plot([0 200],[100 100],'color',[0 0 0],'LineStyle','--','LineWidth',2)


