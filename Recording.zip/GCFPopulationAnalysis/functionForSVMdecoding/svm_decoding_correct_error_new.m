function [Result] = svm_decoding_correct_error_new(FR,Trials,Times,opt,shuffle,trainNum,testNum_c,testNum_e)
% FR, firing rate of all trials for all neurons
% Trials, all trials information for each neuron
% Times, repeat times
% shuffle, caculate shuffle results or not
 % construct data
%  min_group_c = Criterion(1);% minimun number of correct trials for each group
%  min_group_e = Criterion(2);% minimun number of error trials for each group
 BinNum = size(FR{1,1},2);
 % 
 switch opt
     case 1 % for sample odor && correct trials
         % lable of trials
         group_1 = cellfun(@(x) x(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4,2), Trials, 'un',0);% s1 & correct trials
         group_2 = cellfun(@(x) x(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4,2), Trials, 'un',0);% s2 & correct trials
         group_3 = cellfun(@(x) x(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3,2), Trials, 'un',0);% s1 & error trials
         group_4 = cellfun(@(x) x(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3,2), Trials, 'un',0);% s2 & error trials
%          idx_g1 = cellfun(@(x) find(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4), Trials, 'un',0);% s1 & correct trials
%          idx_g2 = cellfun(@(x) find(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4), Trials, 'un',0);% s2 & correct trials
%          idx_g3 = cellfun(@(x) find(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3), Trials, 'un',0);% s1 & error trials
%          idx_g4 = cellfun(@(x) find(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3), Trials, 'un',0);% s2 & error trials
         % fr 
%          fr_1 = cellfun(@(x,y)  y(x,:),idx_g1, FR,'un',0);
%          fr_2 = cellfun(@(x,y)  y(x,:),idx_g2, FR,'un',0);
%          fr_3 = cellfun(@(x,y)  y(x,:),idx_g3, FR,'un',0);
%          fr_4 = cellfun(@(x,y)  y(x,:),idx_g4, FR,'un',0);
         fr_1 = cellfun(@(x,y)  y(x(:,2)==1&x(:,4)==1 | x(:,2)==1&x(:,4)==4,:),Trials, FR,'un',0);
         fr_2 = cellfun(@(x,y)  y(x(:,2)==2&x(:,4)==1 | x(:,2)==2&x(:,4)==4,:),Trials, FR,'un',0);
         fr_3 = cellfun(@(x,y)  y(x(:,2)==1&x(:,4)==2 | x(:,2)==1&x(:,4)==3,:),Trials, FR,'un',0);
         fr_4 = cellfun(@(x,y)  y(x(:,2)==2&x(:,4)==2 | x(:,2)==2&x(:,4)==3,:),Trials, FR,'un',0);
%          
     case 2 % for test odor
         group_1 = cellfun(@(x) x(x(:,3)==3&x(:,4)==1 | x(:,3)==3&x(:,4)==4,3), Trials, 'un',0);% t1 & correct trials
         group_2 = cellfun(@(x) x(x(:,3)==4&x(:,4)==1 | x(:,3)==4&x(:,4)==4,3), Trials, 'un',0);% t2 & correct trials
         group_3 = cellfun(@(x) x(x(:,3)==3&x(:,4)==2 | x(:,3)==3&x(:,4)==3,3), Trials, 'un',0);% t1 & error trials
         group_4 = cellfun(@(x) x(x(:,3)==4&x(:,4)==2 | x(:,3)==4&x(:,4)==3,3), Trials, 'un',0);% t2 & error trials  
         %fr
         fr_1 = cellfun(@(x) y(x(:,3)==3&x(:,4)==1 | x(:,3)==3&x(:,4)==4,:), Trials, FR, 'un',0);% t1 & correct trials
         fr_2 = cellfun(@(x) y(x(:,3)==4&x(:,4)==1 | x(:,3)==4&x(:,4)==4,:), Trials, FR, 'un',0);% t2 & correct trials
         fr_3 = cellfun(@(x) y(x(:,3)==3&x(:,4)==2 | x(:,3)==3&x(:,4)==3,:), Trials, FR, 'un',0);% t1 & error trials
         fr_4 = cellfun(@(x) y(x(:,3)==4&x(:,4)==2 | x(:,3)==4&x(:,4)==3,:), Trials, FR, 'un',0);% t2 & error trials  
     case 3 % all trials for sample
         group_1 = cellfun(@(x) find(x(:,2)==1), Trials, 'un',0);% s1 & correct trials
         group_2 = cellfun(@(x) find(x(:,2)==2), Trials, 'un',0);% s2 & correct trials
         % fr 
         fr_1 = cellfun(@(x,y)  y(x,:),group_1, FR,'un',0);
         fr_2 = cellfun(@(x,y)  y(x,:),group_2, FR,'un',0);
         
     otherwise
         disp('wrong category definition');
 end
 %criterion
 
%  Num_group_1 = cellfun(@length,group_1); Num_group_2 = cellfun(@length,group_2);
%  Num_group_3 = cellfun(@length,group_3); Num_group_4 = cellfun(@length,group_4);
%  Idx_exclude = unique([find(Num_group_1<min_group_c);find(Num_group_2<min_group_c);find(Num_group_3<min_group_e);find(Num_group_4<min_group_e)]);
 %
%  group_1(Idx_exclude)=[]; group_2(Idx_exclude)=[]; group_3(Idx_exclude)=[]; group_4(Idx_exclude)=[];
%  fr_1(Idx_exclude)=[]; fr_2(Idx_exclude)=[]; fr_3(Idx_exclude)=[]; fr_4(Idx_exclude)=[];

 [c_results,e_results,shuf_results]=deal([]);
 for iRep = 1 : Times % repeatiton
     if opt~=3
         % rand choose
         Idx_group1 = cellfun(@(x) randperm(size(x,1))', group_1,'un',0);
         Idx_group2 = cellfun(@(x) randperm(size(x,1))', group_2,'un',0);
         Idx_group3 = cellfun(@(x) randperm(size(x,1))', group_3,'un',0);
         Idx_group4 = cellfun(@(x) randperm(size(x,1))', group_4,'un',0);
         
         
         train_lbl = [ones(trainNum,1); 2*ones(trainNum,1)];
         test_lbl_c = [ones(testNum_c,1); 2*ones(testNum_c,1)];
         test_lbl_e = [ones(testNum_e,1); 2*ones(testNum_e,1)];
         for iBin = 1 : BinNum
             train_FR_1 = cellfun(@(x,y) y(x(1:trainNum,1),iBin),Idx_group1,fr_1,'un',0);
             train_FR_2 = cellfun(@(x,y) y(x(1:trainNum,1),iBin),Idx_group2,fr_2,'un',0);
             test_FR_1 = cellfun(@(x,y) y(x(trainNum+1:trainNum+testNum_c,1),iBin),Idx_group1,fr_1,'un',0);
             test_FR_2 = cellfun(@(x,y) y(x(trainNum+1:trainNum+testNum_c,1),iBin),Idx_group2,fr_2,'un',0);
             test_FR_3 = cellfun(@(x,y) y(x(1:testNum_e,1),iBin),Idx_group3,fr_3,'un',0);
             test_FR_4 = cellfun(@(x,y) y(x(1:testNum_e,1),iBin),Idx_group4,fr_4,'un',0);
             
             data_train = [cell2mat(train_FR_1');cell2mat(train_FR_2')];
             data_test_c = [cell2mat(test_FR_1');cell2mat(test_FR_2')];
             data_test_e = [cell2mat(test_FR_3');cell2mat(test_FR_4')];
             
             % svm decoding
             SVMModel = fitcsvm(data_train,train_lbl);% svm
             [lbls_c,~] = predict(SVMModel,data_test_c);
             [lbls_e,~] = predict(SVMModel,data_test_e);
             c_results(iRep,iBin) = mean(lbls_c==test_lbl_c);
             e_results(iRep,iBin)= mean(lbls_e==test_lbl_e);
             
             if shuffle ~= 0
                 shuffle = randperm(length(train_lbl))';
                 SVMModle_shuf = fitcsvm(data_train,train_lbl(shuffle));
                 [lbls_c_shuf,~] = predict(SVMModle_shuf,data_test_c);
                 shuf_results(iRep,iBin) = mean(lbls_c_shuf==test_lbl_c);
             end
         end
     elseif opt ==3 % for all trials
         Idx_group1 = cellfun(@(x) randperm(size(x,1))', group_1,'un',0);
         Idx_group2 = cellfun(@(x) randperm(size(x,1))', group_2,'un',0);

         train_lbl = [ones(trainNum,1); 2*ones(trainNum,1)];
         test_lbl_c = [ones(testNum_c,1); 2*ones(testNum_c,1)];
         for iBin = 1 : BinNum
             train_FR_1 = cellfun(@(x,y) y(x(1:trainNum,1),iBin),Idx_group1,fr_1,'un',0);
             train_FR_2 = cellfun(@(x,y) y(x(1:trainNum,1),iBin),Idx_group2,fr_2,'un',0);
             test_FR_1 = cellfun(@(x,y) y(x(trainNum+1:trainNum+testNum_c,1),iBin),Idx_group1,fr_1,'un',0);
             test_FR_2 = cellfun(@(x,y) y(x(trainNum+1:trainNum+testNum_c,1),iBin),Idx_group2,fr_2,'un',0);
             
             data_train = [cell2mat(train_FR_1');cell2mat(train_FR_2')];
             data_test_c = [cell2mat(test_FR_1');cell2mat(test_FR_2')];
             % svm decoding
             SVMModel = fitcsvm(data_train,train_lbl);% svm
             [lbls_c,~] = predict(SVMModel,data_test_c);
             c_results(iRep,iBin) = mean(lbls_c==test_lbl_c);
             if shuffle ~= 0
                 shuffle = randperm(length(train_lbl))';
                 SVMModle_shuf = fitcsvm(data_train,train_lbl(shuffle));
                 [lbls_c_shuf,~] = predict(SVMModle_shuf,data_test_c);
                 shuf_results(iRep,iBin) = mean(lbls_c_shuf==test_lbl_c);
             end
         end
     end
 end
     
     
 Result.Correct=c_results;
 Result.Error=e_results;
 Result.Shuffle=shuf_results;
 
 
 
 
 
 
 
 
 