function [STATISTICS]=PlotSVMResults(Data1,Data2,baseline,TotalLen,Bin,Color1,Color2)


step = Bin/1000;
X=[-baseline : step : TotalLen-baseline];
[muHat_1_C,~,muCI_1_C,~]=normfit(Data1.Correct,0.05);% 95% confidence interval
[muHat_1_S,~,muCI_1_S,~]=normfit(Data1.Shuffle,0.05);
[muHat_2_C,~,muCI_2_C,~]=normfit(Data2.Correct,0.05);
[muHat_2_S,~,muCI_2_S,~]=normfit(Data2.Shuffle,0.05);

% SEM1_C=nanstd(Data1.Correct,0,1)/sqrt(size(Data1.Correct,1)-1);
% SEM2_C=nanstd(Data2.Correct,0,1)/sqrt(size(Data2.Correct,1)-1);
% SEM1_S=nanstd(Data1.Shuffle,0,1)/sqrt(size(Data1.Shuffle,1)-1);
% SEM2_S=nanstd(Data2.Shuffle,0,1)/sqrt(size(Data2.Shuffle,1)-1);

%% FOR STATISTICS
% ranksum for each bin with correction
% for i = 1: length(X)
%     p_1(1,i)=ranksum(Data1.Correct(:,i),Data1.Shuffle(:,i));% correct1 & shuffle1
%     p_2(1,i)=ranksum(Data2.Correct(:,i),Data2.Shuffle(:,i));% correct2 & shuffle2
%     p_12(1,i)=ranksum(Data1.Correct(:,i),Data2.Correct(:,i));% correct1 & correct2
% end
% STATISTICS=[p_1;p_2;p_12];
% for i = 1 : round(size(Data1.Correct,2)/5)
% %    a=reshape(Acc_Late.Correct(:,(i-1)*5+1:i*5),[],1);
% %    b=reshape(Acc_Off.Correct(:,(i-1)*5+1:i*5),[],1);
%    a=mean(Data1.Correct(:,(i-1)*5+1:i*5),1);
%    b=mean(Data2.Correct(:,(i-1)*5+1:i*5),1);
%    p_500(1,i)=ranksum(a,b);
% end
% STATISTICS=p_500;
% idx=find(p_500<0.05);
% x1=(idx-3)*0.5; x2=(idx-2)*0.5;xx = [x1;x2]; yy= ones(size(xx));
% for i = 1 : round(size(Data1.Correct,2)/10)
%     %    a=reshape(Acc_Late.Correct(:,(i-1)*5+1:i*5),[],1);
%     %    b=reshape(Acc_Off.Correct(:,(i-1)*5+1:i*5),[],1);
%     a1=mean(Data1.Correct(:,(i-1)*10+1:i*10),1);
%     b1=mean(Data2.Correct(:,(i-1)*10+1:i*10),1);
%     p_1000(1,i)=ranksum(a1,b1);
% end
% STATISTICS=p_1000;
% idx=find(p_1000<0.05/6);
% x1=(idx-2); x2=(idx-1);xx = [x1;x2]; yy= 0.98*ones(size(xx));

for i = 1 : 112
    %    a=reshape(Acc_Late.Correct(:,(i-1)*5+1:i*5),[],1);
    %    b=reshape(Acc_Off.Correct(:,(i-1)*5+1:i*5),[],1);
    a1=mean(Data1.Correct(:,i:i+9),1);
    b1=mean(Data2.Correct(:,i:i+9),1);
    p_1000(1,i)=ranksum(a1,b1);
end
STATISTICS=p_1000;
idx=find(p_1000<0.05/10);
xx = idx/10-1; yy= 0.98*ones(size(xx));
%%
figure
plot(X,smooth(muHat_1_C,5)','Color',Color1,'LineWidth',1.5,'LineStyle','-')
hold on
fill([X,fliplr(X)],[smooth(muCI_1_C(1,:),5)',fliplr(smooth(muCI_1_C(2,:),5)')],Color1,'edgecolor','none','FaceAlpha',0.3)
plot(X,smooth(muHat_2_C,5)','Color',Color2,'LineWidth',1.5,'LineStyle','-')
fill([X,fliplr(X)],[smooth(muCI_2_C(1,:),5)',fliplr(smooth(muCI_2_C(2,:),5)')],Color2,'edgecolor','none','FaceAlpha',0.3)

plot(X,smooth(muHat_1_S,5)','Color',Color1,'LineWidth',1.5,'LineStyle','--')
fill([X,fliplr(X)],[smooth(muCI_1_S(1,:),5)',fliplr(smooth(muCI_1_S(2,:),5)')],Color1,'edgecolor','none','FaceAlpha',0.3)
plot(X,smooth(muHat_2_S,5)','Color',Color2,'LineWidth',1.5,'LineStyle','--')
fill([X,fliplr(X)],[smooth(muCI_2_S(1,:),5)',fliplr(smooth(muCI_2_S(2,:),5)')],Color2,'edgecolor','none','FaceAlpha',0.3)
plot([0 1 7 8 9 10;0 1 7 8 9 10],[0 0 0 0 0 0;1 1 1 1 1 1],'--k')
set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[0,2,4,6,8],'YLim',[0.3,1.0])
if ~isempty(Data1.Error) && ~isempty(Data2.Error)
    [muHat_1_E,~,muCI_1_E,~]=normfit(Data1.Error,0.05);
    [muHat_2_E,~,muCI_2_E,~]=normfit(Data2.Error,0.05);
    plot(X,smooth(muHat_1_E,3)','Color',Color1,'LineWidth',1.5,'LineStyle',':')
    fill([X,fliplr(X)],[smooth(muCI_1_E(1,:),3)',fliplr(smooth(muCI_1_E(2,:),3)')],Color1,'edgecolor','none','FaceAlpha',0.3)
    plot(X,smooth(muHat_2_E,3)','Color',Color2,'LineWidth',1.5,'LineStyle',':')
    fill([X,fliplr(X)],[smooth(muCI_2_E(1,:),3)',fliplr(smooth(muCI_2_E(2,:),3)')],Color2,'edgecolor','none','FaceAlpha',0.3)
end

% idx_1=find(p_1<0.05/70);
% idx_2=find(p_2<0.05/70);
% idx_12=find(p_12<0.05/70);
%
% plot(idx_1*step-baseline,0.47*ones(1,length(idx_1)),'LineStyle','none','Marker','.','Color',Color1)%2s baseline
% plot(idx_2*step-baseline,0.45*ones(1,length(idx_2)),'LineStyle','none','Marker','.','Color',Color2)%2s baseline
% plot(idx_12*step-baseline,0.43*ones(1,length(idx_12)),'LineStyle','none','Marker','.','Color',[Color1+Color2]/2)%2s baseline

plot(xx,yy,'LineStyle','none','Marker','.')% plot significance
plot([0 1 7 8 9 10;0 1 7 8 9 10],[0 0 0 0 0 0;1 1 1 1 1 1],'--k')
set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[0,2,4,6,8],'YLim',[0.3,1.1])


end


