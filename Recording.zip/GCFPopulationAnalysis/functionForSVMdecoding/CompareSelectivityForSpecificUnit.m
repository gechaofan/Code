function CompareSelectivityForSpecificUnit(Sel_1,Sel_2,...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,BinSize,Color1,Color2,PreOdorLen)

SEM1=nanstd(Sel_1,0,1)/sqrt(size(Sel_1,1)-1);
SEM2=nanstd(Sel_2,0,1)/sqrt(size(Sel_2,1)-1);

for i = 1: size(Sel_1,2)
    p(1,i)=signrank(Sel_1(:,i),Sel_2(:,i));
end
SignificantIndex=find(p<0.05);
X=[1:1:size(Sel_1,2)];
YMin=min(smooth(nanmean(Sel_2,1),3)')*0.9;
YMax=max(smooth(nanmean(Sel_2,1),3)')*1.1;

figure('Color',[1 1 1])
% errorbar(X,nanmean(Sel_1,1),SEM1,'Color',Color1,'LineWidth',1.5,'LineStyle','-')
plot(X,smooth(nanmean(Sel_1,1),'moving',3)','Color',Color1,'LineWidth',1.5,'LineStyle','-');
hold on
% errorbar(X,nanmean(Sel_2,1),SEM2,'Color',Color2,'LineWidth',1.5,'LineStyle','-')
fill([X,fliplr(X)],[smooth(nanmean(Sel_1,1)-SEM1,'moving',3)',fliplr(smooth(nanmean(Sel_1,1)+SEM1,'moving',3)')],...
    Color1,'edgecolor','none','FaceAlpha',0.3)
plot(X,smooth(nanmean(Sel_2,1),'moving',3)','Color',Color2,'LineWidth',1.5,'LineStyle','-');
hold on
fill([X,fliplr(X)],[smooth(nanmean(Sel_2,1)-SEM2,'moving',3)',fliplr(smooth(nanmean(Sel_2,1)+SEM2,'moving',3)')],...
    Color2,'edgecolor','none','FaceAlpha',0.3)
plot(SignificantIndex,0.9*YMax*ones(1,length(SignificantIndex)),'LineStyle','none','Marker','.','Color',[0 0 0])%2s baseline
plot([PreOdorLen PreOdorLen+FirstOdorLen PreOdorLen+FirstOdorLen+Delay PreOdorLen+FirstOdorLen+Delay+SecondOdorLen PreOdorLen+FirstOdorLen+Delay+SecondOdorLen+Response PreOdorLen+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen]/BinSize.*ones(2,1),ones(1,6).*[0;1],'--k')

box off
xlabel('Time (Sec)');% Create xlabel
ylabel('DecAcc');% Create ylabel
% Create title
title([num2str(size(Sel_1,1)) '&' num2str(size(Sel_2,1))]);
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',([0,5,10,15]+PreOdorLen)/BinSize,...
    'YLim',[YMin,YMax])
end
