function [acc_c,acc_e,acc_c_Shuf,acc_e_Shuf] = svm_decoding_correct_error(FR,Trials,opt,shuffle)
 % construct data
 trials_c = cellfun(@(x) x(x(:,4)==1 | x(:,4)==4 ,:), Trials, 'un',0);% correct trials
 trials_e = cellfun(@(x) x(x(:,4)==2 | x(:,4)==3 ,:), Trials, 'un',0);% error trials
 FR_c = cellfun(@(x,y) y(x(:,4)==1 | x(:,4)==4 ,:), Trials, FR, 'un',0);% firing of correct trials
 FR_e = cellfun(@(x,y) y(x(:,4)==2 | x(:,4)==3 ,:), Trials, FR, 'un',0);% firing of correct trials
 trials_hit = cellfun(@(x) x(x(:,4)==1,:), Trials, 'un',0);% hit trials
 % 
 switch opt
     case 1 % for sample odor
         type_c = cellfun(@(x) x(:,2),trials_c,'un',0);
         type_e = cellfun(@(x) x(:,2),trials_e,'un',0);
     case 2 % for test odor
         type_c = cellfun(@(x) x(:,3),trials_c,'un',0);
         type_e = cellfun(@(x) x(:,3),trials_e,'un',0);
     case 3 % trial type
         type_c = cellfun(@(x) x(:,5),trials_c,'un',0);
         type_e = cellfun(@(x) x(:,5),trials_e,'un',0);
     otherwise
         disp('wrong category definition');
 end
 %criterion
 min_c_trl=20;% minimun number of training set
 min_e_trl=2;% minimun number of error trials
 min_hit_trl = 5; % minimun number of error trials
 num_c = cellfun(@(x) size(x,1), trials_c);
 num_e = cellfun(@(x) size(x,1), trials_e);
 num_hit = cellfun(@(x) size(x,1), trials_hit);
 for iNeu = 1 : size(FR,1)% neuron
     
         errorTag =  type_e{iNeu};
         errorFR =  FR_e{iNeu};
         [trIdx,teIdx,trTag,teTag,trainFR,testFR]=deal([]);
         [c_results,e_results] = deal([]);
         [trIdx_s,teIdx_s,trTag_s,teTag_s,trainFR_s,testFR_s]=deal([]);
         [c_results_s,e_results_s] = deal([]);
         if num_c(iNeu) >= min_c_trl && num_e(iNeu) >= min_e_trl && num_hit(iNeu) >= min_hit_trl
             %
             cv = cvpartition(type_c{iNeu,1},'KFold',10);
             % decoding
             for kf = 1:cv.NumTestSets % cross validation
                 trIdx = cv.training(kf);% train index
                 teIdx = cv.test(kf);% test index
                 trTag = type_c{iNeu}(trIdx,:);
                 teTag = type_c{iNeu}(teIdx);
                 trainFR = FR_c{iNeu}(trIdx,:);
                 testFR = FR_c{iNeu}(teIdx,:);
                 
                 SVMModel = fitcsvm(trainFR,trTag);% svm
                 [lbls_c,~] = predict(SVMModel,testFR);
                 [lbls_e,~] = predict(SVMModel,errorFR);
                 c_results = [c_results;(lbls_c==teTag)];
                 e_results = [e_results;(lbls_e==errorTag)];
             end
             acc_c(iNeu,1) = sum(c_results)/length(c_results);
             acc_e(iNeu,1) = sum(e_results)/length(e_results);
             
             if shuffle ~= 0
                 shuffleTag = zeros(size(type_c{iNeu,1}));
                 shuffletype_idx = randperm(size(type_c{iNeu,1},1));
                 shuffleTag = type_c{iNeu}(shuffletype_idx');
                 cv = cvpartition(shuffleTag,'KFold',10);
                 for kf = 1:cv.NumTestSets % cross validation
                     trIdx_s = cv.training(kf);% train index
                     teIdx_s = cv.test(kf);% test index
                     trTag_s = shuffleTag(trIdx_s,:);% shuffled tag
                     teTag_s = type_c{iNeu}(teIdx_s);% raw tag
                     trainFR_s = FR_c{iNeu}(trIdx_s,:);
                     testFR_s = FR_c{iNeu}(teIdx_s,:);
                     
                     SVMModel = fitcsvm(trainFR_s,trTag_s);% svm
                     [lbls_c_s,~] = predict(SVMModel,testFR_s);
                     [lbls_e_s,~] = predict(SVMModel,errorFR);
                     c_results_s = [c_results;(lbls_c_s==teTag_s)];
                     e_results_s = [e_results;(lbls_e_s==errorTag)];
                 end
                 
                 acc_c_Shuf(iNeu,1) = sum(c_results_s)/length(c_results_s);
                 acc_e_Shuf(iNeu,1) = sum(e_results_s)/length(e_results_s);
                 
             end
         else
             acc_c(iNeu,1) = NaN;
             acc_e(iNeu,1) = NaN;
             acc_c_Shuf = NaN;
             acc_e_Shuf = NaN;
         end

%      out.decAcc_correct= acc_c;
%      out.decAcc_error= acc_e;
%      out.decAcc_correct_Shuf= acc_c_Shuf;
%      out.decAcc_error_Shuf= acc_e_Shuf;
 end
