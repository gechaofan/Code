%% this code Used to Split Units  recorded in the same hemisphere with lateral laser perturbation

clc
clear all

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};
    %%
    %change the directory to the file of DataID
    cd(Path);
    %%  get Data,Trials,FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,DPALen   %%%% ITI was given as 10s
    SplitDataName=ls('SplitData*.mat');
    tempLaserSplitDataName = ls('SplitData-LaserHemisphere*.mat');
    if ~isempty(SplitDataName) & isempty(tempLaserSplitDataName)
        %         if ~isempty(JAVAFileName) && ~isempty(RawDataName) && isempty(SplitDataName)
        %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% load plexon data
        load(SplitDataName);
        
        tempSplitData = SplitData;
        tempNewSpikes = NewSpikes;
        tempFiringRate = FiringRate;
        tempSingleUnitIndex = SingleUnitIndex;
        
        IndexwithLaser=find(SingleUnitIndex(:,1)>=33 & SingleUnitIndex(:,1)<=40);% laser hemisphere
        IndexwithoutLaser=find(SingleUnitIndex(:,1)>=41 & SingleUnitIndex(:,1)<=48);
        clear('SplitData','NewSpikes','FiringRate','SingleUnitIndex')
        
        NewSpikes = tempNewSpikes(IndexwithLaser,:);
        FiringRate = tempFiringRate(IndexwithLaser,:);
        SingleUnitIndex = tempSingleUnitIndex(IndexwithLaser,:);
        SplitData.SpikeTimestamp = tempSplitData.SpikeTimestamp(IndexwithLaser,:);
        SplitData.SpikeCounts = tempSplitData.SpikeCounts(IndexwithLaser,:);
        SplitData.LickTimestamp = tempSplitData.LickTimestamp;
        SplitData.LickCounts = tempSplitData.LickCounts;
        SplitData.Trials = tempSplitData.Trials;
        SplitData.Lick = tempSplitData.Lick;
        
        save(['SplitData-LaserHemisphere' DataID],'DataID','Data','SplitData','SingleUnitIndex','DifferentTrials','Odor1','Odor2','LickInJava','Laser','LaserTrial',...
            'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','FiringRate','DifferentTrials','NewSpikes','LaserType','-v7.3')
        
        
        clear('SplitData','NewSpikes','FiringRate','SingleUnitIndex')
        NewSpikes = tempNewSpikes(IndexwithoutLaser,:);
        FiringRate = tempFiringRate(IndexwithoutLaser,:);
        SingleUnitIndex = tempSingleUnitIndex(IndexwithoutLaser,:);
        SplitData.SpikeTimestamp = tempSplitData.SpikeTimestamp(IndexwithoutLaser,:);
        SplitData.SpikeCounts = tempSplitData.SpikeCounts(IndexwithoutLaser,:);
        SplitData.LickTimestamp = tempSplitData.LickTimestamp;
        SplitData.LickCounts = tempSplitData.LickCounts;
        SplitData.Trials = tempSplitData.Trials;
        SplitData.Lick = tempSplitData.Lick;
        
        save(['SplitData-NotLaserHemisphere' DataID],'DataID','Data','SplitData','SingleUnitIndex','DifferentTrials','Odor1','Odor2','LickInJava','Laser','LaserTrial',...
            'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','FiringRate','DifferentTrials','NewSpikes','LaserType','-v7.3')
        
        
        
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end
