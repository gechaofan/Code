%% delay activity, sample, test, reward
%%%%%%%%%%%%%%%%%%%%%%%%%%Laser On Trials
Delay=6;% 1s baseline&sample
NewLaserOffAllTrialsFR=ReDefineBinSize(LaserOffAllTrialsFR,1000,100);%BinSize=1s
NewLaserOnAllTrialsFR1=ReDefineBinSize(LaserOnAllTrialsFR_EarlyDelay,1000,100);%BinSize=1s, _EarlyDelay
NewLaserOnAllTrialsFR2=ReDefineBinSize(LaserOnAllTrialsFR_LateDelay,1000,100);%BinSize=1s, _LateDelay
%% selectivity
LaserOn_pDelayActivity1=[];LaserOn_pDelayActivity2=[];LaserOff_pDelayActivity=[];DelatFR_LaserOnDelay=[];DelatFR_LaserOffDelay=[];
LaserEffect.EarlyDelay_1s=zeros(750,20);LaserEffect.LateDelay_1s=zeros(750,20);
for itr = 1: size(AllUnitID,1)
    for itr0 =1 : 20
        p1(itr,itr0)=signrank(NewLaserOffAllTrialsFR{itr}(:,itr0),NewLaserOnAllTrialsFR1{itr}(:,itr0));% laser in early dely
        Larger1(itr,itr0)=mean(NewLaserOffAllTrialsFR{itr}(:,itr0))-mean(NewLaserOnAllTrialsFR1{itr}(:,itr0));
        p2(itr,itr0)=signrank(NewLaserOffAllTrialsFR{itr}(:,itr0),NewLaserOnAllTrialsFR2{itr}(:,itr0));% laser in late delay
        Larger2(itr,itr0)=mean(NewLaserOffAllTrialsFR{itr}(:,itr0))-mean(NewLaserOnAllTrialsFR2{itr}(:,itr0));
        if p1(itr,itr0)<0.05 && Larger1(itr,itr0)<0
            LaserEffect.EarlyDelay_1s(itr,itr0)=1;
        elseif p1(itr,itr0)<0.05 && Larger1(itr,itr0)>0
            LaserEffect.EarlyDelay_1s(itr,itr0)=-1;
        end
        if p2(itr,itr0)<0.05 && Larger2(itr,itr0)<0
            LaserEffect.LateDelay_1s(itr,itr0)=1;
        elseif p1(itr,itr0)<0.05 && Larger2(itr,itr0)>0
            LaserEffect.LateDelay_1s(itr,itr0)=-1;
        end
        % compare with baseline 2s before sample delivery
        LaserOn_pDelayActivity1(itr,itr0)=ranksum(NewLaserOnAllTrialsFR1{itr,1}(:,1),NewLaserOnAllTrialsFR{itr,1}(:,itr0));
        LaserOn_pDelayActivity2(itr,itr0)=ranksum(NewLaserOnAllTrialsFR2{itr,1}(:,1),NewLaserOnAllTrialsFR{itr,1}(:,itr0));
        LaserOff_pDelayActivity(itr,itr0)=ranksum(NewLaserOffAllTrialsFR{itr,1}(:,1),NewLaserOffAllTrialsFR{itr,1}(:,itr0));
        
        DelatFR_LaserOnDelay1(itr,itr0)=mean(NewLaserOnAllTrialsFR1{itr,1}(:,itr0),1)-mean(NewLaserOnAllTrialsFR1{itr,1}(:,2),1);
        DelatFR_LaserOnDelay2(itr,itr0)=mean(NewLaserOnAllTrialsFR2{itr,1}(:,itr0),1)-mean(NewLaserOnAllTrialsFR2{itr,1}(:,2),1);
        DelatFR_LaserOffDelay(itr,itr0)=mean(NewLaserOffAllTrialsFR{itr,1}(:,itr0),1)-mean(NewLaserOffAllTrialsFR{itr,1}(:,2),1);
    end
end


figure('color',[1 1 1])
subplot(1,2,1)
bar(LargerThanBaseline_LaserOff'/size(AllUnitID,1),'stack','barwidth',1,'LineWidth',2,'EdgeColor','k','facealpha',1)
box off
subplot(1,2,2)
bar(LargerThanBaseline_LaserOn'/size(AllUnitID,1),'stack','barwidth',1,'LineWidth',2,'LineStyle','none','EdgeColor','k','facealpha',1)
box off
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','fig')
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','png')
close all

   
for itr2=1:Delay
    LaserOnUnitNumForDelay(1,itr2)=length(find(LaserOn_pDelayActivity(:,itr2)<0.05/6));
    LaserOffUnitNumForDelay(1,itr2)=length(find(LaserOff_pDelayActivity(:,itr2)<0.05/6));
end
LaserOffUnitsPercentage_EverySec=LaserOffUnitNumForDelay./size(AllUnitID,1);
LaserOnUnitsPercentage_EverySec=LaserOnUnitNumForDelay./size(AllUnitID,1);
bar1=bar([LaserOffUnitsPercentage_EverySec' LaserOnUnitsPercentage_EverySec']);
box off
set(bar1(2),'FaceColor',[0 0 1]);
set(bar1(1),'FaceColor',[0 0 0]);
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','fig')
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForEverySecond','png')
close all

%% persisitant delay activity
LaserOnUnitNumForDelay_Constant(1,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6));
LaserOnUnitNumForDelay_Constant(2,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6&LaserOn_pDelayActivity(:,2)<=0.05/6));
LaserOnUnitNumForDelay_Constant(3,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6&LaserOn_pDelayActivity(:,2)<=0.05/6&LaserOn_pDelayActivity(:,3)<=0.05/6));
LaserOnUnitNumForDelay_Constant(4,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6&LaserOn_pDelayActivity(:,2)<=0.05/6&LaserOn_pDelayActivity(:,3)<=0.05/6&LaserOn_pDelayActivity(:,4)<=0.05/6));
LaserOnUnitNumForDelay_Constant(5,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6&LaserOn_pDelayActivity(:,2)<=0.05/6&LaserOn_pDelayActivity(:,3)<=0.05/6&LaserOn_pDelayActivity(:,4)<=0.05/6&LaserOn_pDelayActivity(:,5)<=0.05/6));
LaserOnUnitNumForDelay_Constant(6,1)=length(find(LaserOn_pDelayActivity(:,1)<=0.05/6&LaserOn_pDelayActivity(:,2)<=0.05/6&LaserOn_pDelayActivity(:,3)<=0.05/6&LaserOn_pDelayActivity(:,4)<=0.05/6&LaserOn_pDelayActivity(:,5)<=0.05/6&LaserOn_pDelayActivity(:,6)<=0.05/6));

LaserOffUnitNumForDelay_Constant(1,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6));
LaserOffUnitNumForDelay_Constant(2,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6&LaserOff_pDelayActivity(:,2)<=0.05/6));
LaserOffUnitNumForDelay_Constant(3,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6&LaserOff_pDelayActivity(:,2)<=0.05/6&LaserOff_pDelayActivity(:,3)<=0.05/6));
LaserOffUnitNumForDelay_Constant(4,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6&LaserOff_pDelayActivity(:,2)<=0.05/6&LaserOff_pDelayActivity(:,3)<=0.05/6&LaserOff_pDelayActivity(:,4)<=0.05/6));
LaserOffUnitNumForDelay_Constant(5,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6&LaserOff_pDelayActivity(:,2)<=0.05/6&LaserOff_pDelayActivity(:,3)<=0.05/6&LaserOff_pDelayActivity(:,4)<=0.05/6&LaserOff_pDelayActivity(:,5)<=0.05/6));
LaserOffUnitNumForDelay_Constant(6,1)=length(find(LaserOff_pDelayActivity(:,1)<=0.05/6&LaserOff_pDelayActivity(:,2)<=0.05/6&LaserOff_pDelayActivity(:,3)<=0.05/6&LaserOff_pDelayActivity(:,4)<=0.05/6&LaserOff_pDelayActivity(:,5)<=0.05/6&LaserOff_pDelayActivity(:,6)<=0.05/6));

LaserOffUnitsPercentage_ConstantSec=LaserOffUnitNumForDelay_Constant./size(AllUnitID,1);
LaserOnUnitsPercentage_ConstantSec=LaserOnUnitNumForDelay_Constant./size(AllUnitID,1);
bar2=bar([LaserOffUnitsPercentage_ConstantSec LaserOnUnitsPercentage_ConstantSec]);
box off
set(bar2(2),'FaceColor',[0 0 1]);
set(bar2(1),'FaceColor',[0 0 0]);
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForConstantSecond','fig')
saveas(gcf,'LaserOff&OnPercentageofUnitsWithDelayActivityForConstantSecond','png')
close all
%%
Title1='LaserIncreasedUnits-Late';
[fitresult1, gof1]= LinearLeastSquaresFitting(mean(DeltaRF_LaserOff(FRIncresedIndex_LateDelay,8:9),2),mean(DeltaRF_LaserOn_Late(FRIncresedIndex_LateDelay,8:9),2),Title1); 
Title2='2ndSecofDelay-Early';
[fitresult2, gof2]= LinearLeastSquaresFitting(DelatFR_LaserOffDelay(:,5),DelatFR_LaserOnDelay1(:,5),Title2); 
Title3='3rdSecofDelay';
[fitresult3, gof3]= LinearLeastSquaresFitting(DelatFR_LaserOffDelay(:,6),DelatFR_LaserOnDelay(:,6),Title3);  
Title4='4thSecofDelay';
[fitresult4, gof4]= LinearLeastSquaresFitting(DelatFR_LaserOffDelay(:,7),DelatFR_LaserOnDelay(:,7),Title4); 
Title5='5thSecofDelay-Late';
[fitresult5, gof5]= LinearLeastSquaresFitting(DelatFR_LaserOffDelay(:,8),DelatFR_LaserOnDelay2(:,8),Title5); 
Title6='6thSecofDelay-Late';
[fitresult6, gof6]= LinearLeastSquaresFitting(DelatFR_LaserOffDelay(:,9),DelatFR_LaserOnDelay2(:,9),Title6); 
 gof=[gof1;gof2;gof3;gof4;gof5;gof6];
save(['LaserEffectOnDelayFRChange-FittingResults'],'gof','fitresult1','fitresult2','fitresult3','fitresult4','fitresult5','fitresult6')
  


% for i=1 : LaserDelay
%     figure ('color', [1 1 1])
%     color(jet);
%     x=[-20:20];y=x;plot(x,y,'k')
%     hold on
%     scatter(DelatFR_LaserOffDelayWithLaser(:,i),DelatFR_LaserOnDelayWithLaser(:,i),'b')
%     xlabel('��Laser Off FR (Hz)');ylabel('��Laser On FR (Hz)');
%     box off
%     Title=num2str(i);
%     saveas(gcf,['LaserEffectOnFiringRate_LaserDelay' Title],'fig')
%     saveas(gcf,['LaserEffectOnFiringRate_LaserDelay' Title],'png')
%     close all
% end
