function PlotHeatMapForSampleSelectivity(Type1FR,Type2FR,Type3FR,Type4FR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserChangedDelayUnit,TimeGain)
%% transform data with 1 second bin;

 Type1FR=LaserOffAllATrialsFR(Index_LaserNoChangedDelayUnit);
 Type2FR=LaserOffAllBTrialsFR(Index_LaserChangedDelayUnit);
 Type3FR=LaserOnAllATrialsFR(Index_LaserChangedDelayUnit);
 Type4FR=LaserOnAllBTrialsFR(Index_LaserChangedDelayUnit);
 
  Type1FR=LaserOffAllATrialsFR;
 Type2FR=LaserOffAllBTrialsFR;
 Type3FR=LaserOnAllATrialsFR;
 Type4FR=LaserOnAllBTrialsFR;
 
NewBin=1000;%ms
Bin=100;%ms
NewType1RF = ReDefineBinSize(Type1FR,NewBin,Bin);
NewType2RF = ReDefineBinSize(Type2FR,NewBin,Bin);
NewType3RF = ReDefineBinSize(Type3FR,NewBin,Bin);
NewType4RF = ReDefineBinSize(Type4FR,NewBin,Bin);

SelectivityForLaserOff={};BaselineSelectivityForLaserOff={};
SelectivityForLaserOn={};BaselineSelectivityForLaserOn={};
for itrm=1:size(NewType1RF,1)%Index_LaserChangedDelayUnit
   
   
        SelectivityForLaserOff{itrm,1}=(NewType1RF{itrm,1}-NewType2RF{itrm,1})./(NewType1RF{itrm,1}+NewType2RF{itrm,1});
        SelectivityForLaserOff{itrm,1}(isnan(SelectivityForLaserOff{itrm,1}))=0;
        BaselineSelectivityForLaserOff{itrm,1}=SelectivityForLaserOff{itrm,1}(:,1);
        
        SelectivityForLaserOn{itrm,1}=(NewType3RF{itrm,1}-NewType4RF{itrm,1})./(NewType3RF{itrm,1}+NewType4RF{itrm,1});
        SelectivityForLaserOn{itrm,1}(isnan(SelectivityForLaserOn{itrm,1}))=0;
        BaselineSelectivityForLaserOn{itrm,1}=SelectivityForLaserOn{itrm,1}(:,1);% selectivity of baseline which ones second before sample onset

end

BinNum=20;
pLaserOff=nan(size(NewType1RF,1),BinNum);largerLaserOff=nan(size(NewType1RF,1),BinNum);%Index_LaserChangedDelayUnit
pLaserOn=nan(size(NewType1RF,1),BinNum);largerLaserOn=nan(size(NewType1RF,1),BinNum);%Index_LaserChangedDelayUnit
for itr0 = 1:size(NewType1RF,1)
    for itr = 1:20% for every second of the whole trial
        [pLaserOff(itr0,itr),largerLaserOff(itr0,itr)]=permTest(SelectivityForLaserOff{itr0,1}(:,itr),BaselineSelectivityForLaserOff{itr0,1});
        [pLaserOn(itr0,itr),largerLaserOn(itr0,itr)]=permTest(SelectivityForLaserOn{itr0,1}(:,itr),BaselineSelectivityForLaserOn{itr0,1});
    end
end

tempIndex1LaserOff=find(pLaserOff(:)<0.05&largerLaserOff(:)==1);% select SampleA
tempIndex2LaserOff=find(pLaserOff(:)<0.05&largerLaserOff(:)==2);% select SampleB
tempSelectivityLaserOff=zeros(size(NewType1RF,1),20);
tempSelectivityLaserOff(tempIndex1LaserOff)=1;tempSelectivityLaserOff(tempIndex2LaserOff)=-1;

tempIndex1LaserOn=find(pLaserOn(:)<0.05&largerLaserOn(:)==1);% select SampleA
tempIndex2LaserOn=find(pLaserOn(:)<0.05&largerLaserOn(:)==2);% select SampleB
tempSelectivityLaserOn=zeros(size(NewType1RF,1),20);
tempSelectivityLaserOn(tempIndex1LaserOn)=1;tempSelectivityLaserOn(tempIndex2LaserOn)=-1;

for itr2= 1:20
SelectUnitNumLaserOff(1,itr2)=length(find(tempSelectivityLaserOff(:,itr2)==1))/size(NewType1RF,1);%select A
SelectUnitNumLaserOff(2,itr2)=length(find(tempSelectivityLaserOff(:,itr2)==-1))/size(NewType1RF,1);%select B
SelectUnitNumLaserOff(3,itr2)=length(find(tempSelectivityLaserOff(:,itr2)==0))/size(NewType1RF,1);

SelectUnitNumLaserOn(1,itr2)=length(find(tempSelectivityLaserOn(:,itr2)==1))/size(NewType1RF,1);%select A
SelectUnitNumLaserOn(2,itr2)=length(find(tempSelectivityLaserOn(:,itr2)==-1))/size(NewType1RF,1);%select B
SelectUnitNumLaserOn(3,itr2)=length(find(tempSelectivityLaserOn(:,itr2)==0))/size(NewType1RF,1);
end

[~,tempIndex]=sortrows(mean(tempSelectivityLaserOff(:,3:9),2),-1);

figure ('color',[1 1 1])
subplot(1,2,1)
imagesc(tempSelectivityLaserOff(tempIndex,:))

hold on
plot([2 2]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen 2+FirstOdorLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay 2+FirstOdorLen+Delay]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
% set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[20,40,60,80,100],'Xlim',[10 110])
xlabel('Time (Sec)');% Create xlabel
ylabel('Unit Index');% Create ylabel
title({'Selectivity for Laser Off Trials'},'FontSize',12);



subplot(1,2,2)
imagesc(tempSelectivityLaserOn(tempIndex,:))

hold on
plot([2 2]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen 2+FirstOdorLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay 2+FirstOdorLen+Delay]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen]+0.5,[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
% set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[20,40,60,80,100],'Xlim',[10 110])
xlabel('Time (Sec)');% Create xlabel
ylabel('Unit Index');% Create ylabel
title({'Selectivity for Laser On Trials'},'FontSize',12);

map=ones(199,3);
c=linspace(0,1)';
map(1:100,[1,2])=[c,c];
map(199:-1:100,[2,3])=[c,c];
colormap(map);
% colorbar([-50,50]);


figure ('color',[1 1 1])
subplot1=subplot(1,2,1)
bar1=bar(SelectUnitNumLaserOff','stacked');
hold on
plot([2 2]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen 2+FirstOdorLen]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay 2+FirstOdorLen+Delay]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])

set(bar1(1),'FaceColor',[1 0 0]);
set(bar1(2),'FaceColor',[0 0 1]);
set(bar1(3),'FaceColor','none','EdgeColor',[1 1 1],'BarWidth',1);
% Create xlabel
xlabel('Time (s)');
% Set the remaining axes properties
set(subplot1,'FontSize',14,'XTick',[2.5 6.5 10.5],'XTickLabel',...
    {'0','4','8'});

subplot2=subplot(1,2,2);
bar2=bar(SelectUnitNumLaserOn','stacked');
hold on
plot([2 2]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen 2+FirstOdorLen]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay 2+FirstOdorLen+Delay]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot([2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen]+0.5,[0 0.25],'LineWidth',2,'LineStyle','--','Color',[0 0 0])

set(bar2(1),'FaceColor',[1 0 0]);
set(bar2(2),'FaceColor',[0 0 1]);
set(bar2(3),'FaceColor','none','EdgeColor',[1 1 1],'BarWidth',1);
% Create xlabel
xlabel('Time (s)');
% Set the remaining axes properties
set(subplot2,'FontSize',14,'XTick',[2.5 6.5 10.5],'XTickLabel',...
    {'0','4','8'});
end


