[tempfilename, pathname]=uigetfile('SplitData*.mat','multiselect','on');%

if ischar(tempfilename)
    MainCircleN=1;
    filename=tempfilename;
else
    filename=tempfilename';
    MainCircleN=size(filename,1);
end

PerformanceForSession=zeros(15,MainCircleN);
for itr=1:MainCircleN
load(filename{itr,:});
NaNIndex=find(isnan(Data(:,end)));
Data(NaNIndex,:)=[];
PerformanceForSession(:,itr)=Data(:,end);
end
MeanPerForSession=mean(PerformanceForSession,1);
LearnSessionIndex=find(MeanPerForSession<80);
WellTrainSessionIndex=find(MeanPerForSession>=80);
%%
Per_E=PerformanceForSession(1:3:end-2,LearnSessionIndex);
Per_C=PerformanceForSession(2:3:end-1,LearnSessionIndex);
Per_L=PerformanceForSession(3:3:end,LearnSessionIndex);
plot(mean(Per_E,2),'b')
hold on
plot(mean(Per_C,2),'k')
plot(mean(Per_L,2),'r')
Per_E=PerformanceForSession(4:3:end-2,LearnSessionIndex);
Per_C=PerformanceForSession(5:3:end-1,LearnSessionIndex);
Per_L=PerformanceForSession(6:3:end,LearnSessionIndex);
plot(mean(Per_E,2),'b')
hold on
plot(mean(Per_C,2),'k')
plot(mean(Per_L,2),'r')
Per_E=PerformanceForSession(4:3:end-2,LearnSessionIndex);
Per_C=PerformanceForSession(5:3:end-1,LearnSessionIndex);
Per_L=PerformanceForSession(3:3:end-3,LearnSessionIndex);
plot(mean(Per_E,2),'b')
hold on
plot(mean(Per_C,2),'k')
plot(mean(Per_L,2),'r')
Per_E=PerformanceForSession(1:3:end-2,LearnSessionIndex);
Per_C=PerformanceForSession(2:3:end-1,LearnSessionIndex);
Per_L=PerformanceForSession(3:3:end,LearnSessionIndex);
errorbar(mean(mean(Per_C,1)),std(mean(Per_C,1),0,2)/sqrt(41))
bar(1,mean(mean(Per_E,1)))
hold on
errorbar(1,mean(mean(Per_E,1)),std(mean(Per_E,1),0,2)/sqrt(41))
bar(2,mean(mean(Per_C,1)))
errorbar(2,mean(mean(Per_C,1)),std(mean(Per_C,1),0,2)/sqrt(41))
bar(3,mean(mean(Per_L,1)))
errorbar(3,mean(mean(Per_L,1)),std(mean(Per_L,1),0,2)/sqrt(41))
%%
PerForUnit_CLE=cell2mat(cellfun(@(x) mean(x(2:13,end),1),AllPerformance,'un',0));
Learn_UnitIndex_CLE=find(PerForUnit_CLE<80);
WT_UnitIndex_CLE=find(PerForUnit_CLE>=80);

Learn_FRDecreasedUnitIndex_Out_CLE=intersect(find(LaserEffect.LaserEffectOutTask<0), Learn_UnitIndex_CLE);
WT_FRDecreasedUnitIndex_Out_CLE=intersect(find(LaserEffect.LaserEffectOutTask<0), WT_UnitIndex_CLE);
Learn_FRIncreasedUnitIndex_Out_CLE=intersect(find(LaserEffect.LaserEffectOutTask>0), Learn_UnitIndex_CLE);
WT_FRIncreasedUnitIndex_Out_CLE=intersect(find(LaserEffect.LaserEffectOutTask>0), WT_UnitIndex_CLE);

% early-latedelay-out task, FR Increased Units,Learn_CLE
A_E_L_Out_Increased_WT_CLE=[29 72 34];
I_E_L_Out_Increased_WT_CLE=[21 11 17 9];
figure
venn(A_E_L_Out_Increased_WT_CLE,I_E_L_Out_Increased_WT_CLE)
saveas(gcf,['OverLap-FRIncreasedUnits-Within&outTask_WT-CLE'],'fig')
saveas(gcf,['OverLap-FRIncreasedUnits-Within&outTask_WT-CLE'],'png')
close all
% early-latedelay-out task, FR Decreased Units, learn_CLE
A_E_L_Out_Decreased=[40 44 21];
I_E_L_Out_Decreased=[18 8 11 8];
figure
colormap(jet);
venn(A_E_L_Out_Decreased,I_E_L_Out_Decreased)
legend('show','E', 'L', 'Out')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask_WT-CLE'],'fig')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask_WT-CLE'],'png')
close all
%% 
A_E_L_Out_Increased_Learn_CLE=[73 87 53];
A_E_L_Out_Decreased_Learn_CLE=[62 65 37];
A_E_L_Out_Increased_WT_CLE=[29 72 34];
A_E_L_Out_Decreased_WT_CLE=[40 44 21];
figure
colormap(jet);
bar([0.8:1:2.8],A_E_L_Out_Increased_Learn_CLE/471*100,'BarWidth',0.3,'FaceColor','r');
hold on
bar([1.2:1:3.2],A_E_L_Out_Decreased_Learn_CLE/471*100,'BarWidth',0.3,'FaceColor','b');
legend('show','FRIncreased', 'FRDecreased')
set(gca,'XTickLabel',{'E','L','O'},'XTick',[1,2,3],'Xlim',[0,4])
saveas(gcf,['Proportion-FRIncreasedUnits-Within&outTask_Learn-CLE'],'fig')
saveas(gcf,['Proportion-FRIncreasedUnits-Within&outTask_Learn-CLE'],'png')
close all
figure
colormap(jet);
bar([0.8:1:2.8],A_E_L_Out_Increased_WT_CLE/279*100,'BarWidth',0.3,'FaceColor','r');
hold on
bar([1.2:1:3.2],A_E_L_Out_Decreased_WT_CLE/279*100,'BarWidth',0.3,'FaceColor','b');
legend('show','FRIncreased', 'FRDecreased')
set(gca,'XTickLabel',{'E','L','O'},'XTick',[1,2,3],'Xlim',[0,4])
saveas(gcf,['Proportion-FRChangedUnits-Within&outTask_WT-CLE'],'fig')
saveas(gcf,['Proportion-FRChangedUnits-Within&outTask_WT-CLE'],'png')
close all
[h,p_FRIncreasedUnit_EL_Learn_CLE, chi2stat,df] = prop_test([73 87] , [471 471], true);
[~,p_FRIncreasedUnit_EO_Learn_CLE, ~,~] = prop_test([73 53] , [471 471], true);
[~,p_FRIncreasedUnit_LO_Learn_CLE, ~,~] = prop_test([53 87] , [471 471], true);

[~,p_FRDecreasedUnit_EL_Learn_CLE, ~,~] = prop_test([62 65] , [471 471], true);
[~,p_FRDecreasedUnit_EO_Learn_CLE, ~,~] = prop_test([62 37] , [471 471], true);
[~,p_FRDecreasedUnit_LO_Learn_CLE, ~,~] = prop_test([65 37] , [471 471], true);

[~,p_FRIncreasedUnit_EL_WT_CLE, ~,~] = prop_test([29 72] , [279 279], true);
[~,p_FRIncreasedUnit_EO_WT_CLE, ~,~] = prop_test([29 34] , [279 279], true);
[~,p_FRIncreasedUnit_LO_WT_CLE, ~,~] = prop_test([72 34] , [279 279], true);
[~,p_FRDecreasedUnit_EL_WT_CLE, ~,~] = prop_test([40 44] , [279 279], true);
[~,p_FRDecreasedUnit_EO_WT_CLE, ~,~] = prop_test([40 21] , [279 279], true);
[~,p_FRDecreasedUnit_LO_WT_CLE, ~,~] = prop_test([44 21] , [279 279], true);
