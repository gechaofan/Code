%% load spikes and read events from .pl2 file
% WaveFormSampleNum=58;%TDT=34,Plexon=58, HuPlexon=54;waveform length 1450um,325us prethreshold
% TimestampFrequency=40000;
% plexon record the end of square wave, so plexon recorded the end time points of task events.
MouseNum = 1;
CurrentPath = pwd;
AllPath = genpath(CurrentPath);
SplitPath = strsplit(AllPath, ';')';
SubPath = SplitPath(1:end-1,:);

for iter0 =1; size(SubPath,1)
    %% load spikes
    SpikeFileName=ls ('*txt');% get file name of spike data
    RawdataFileName=ls ('*.pl2');% get file name of Raw recording data;
    pl2 = PL2GetFileIndex(RawdataFileName);% list pl2 file information
    %     PL2Print(pl2.EventChannels);% Print Information of EventChannels
    %     TimestampFrequency=pl2.TimestampFrequency;% Plexon,40000
    if (~isempty(SpikeFileName) && ~isempty(RawdataFileName))
        data=importdata(SpikeFileName); %collum 1, tetrodeID, collum 2, unitID recorded by current tetrode (0-unsorted, 1-unit1,2-unit2..., collum3, timestamp; collum4-end waveform, 58*4)
        if isstruct(data)
            data=data.data;
        end
        if (MouseNum ==1)
            %% get task events from .pl2 file (data recorded by plexon
            [Event.Laser] = PL2EventTs(RawdataFileName,'EVT09');
            %         event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts
            [Event.Lick] = PL2EventTs(RawdataFileName,'EVT06');
            [Event.OdorAC] = PL2EventTs(RawdataFileName,'EVT07');
            [Event.OdorBD] = PL2EventTs(RawdataFileName,'EVT08');
            RawSpikes=data(data(:,2)>0,:); % remove unsorted waveforms
            DataID =SpikeFileName(1:end-4);
            
            save(['RawData-' DataID],'DataID','Event','RawSpikes')
        else  % two mice were recorded simultaneously
            for iter1 = 1 : MouseNum
                
                if (iter1 == 1)
                    [Event.Laser] = PL2EventTs(RawdataFileName,'EVT04');
                    %         event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts
                    [Event.Lick] = PL2EventTs(RawdataFileName,'EVT01');
                    [Event.OdorAC] = PL2EventTs(RawdataFileName,'EVT02');
                    [Event.OdorBD] = PL2EventTs(RawdataFileName,'EVT03');
                    RawSpikes=data(data(:,1)<49 & data(:,2)>0,:); % remove unsorted waveforms
                    DataID =SpikeFileName(1:end-4); % key in by hands
                else
                    [Event.Laser] = PL2EventTs(RawdataFileName,'EVT09');
                    %         event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts
                    [Event.Lick] = PL2EventTs(RawdataFileName,'EVT06');
                    [Event.OdorAC] = PL2EventTs(RawdataFileName,'EVT07');
                    [Event.OdorBD] = PL2EventTs(RawdataFileName,'EVT08');
                    RawSpikes=data(data(:,1)>48 & data(:,2)>0,:); % remove unsorted waveforms
                    DataID = SpikeFileName(1:end-4); % key in by hands
                end
                save(['RawData-' DataID],'DataID','Event','RawSpikes')
            end
        end
    end
    
    cd(SplitPath{1});
    
end





