%% this code is used for remove single Unit which dosen't reach the criterion.
%% 1. firing rate >=2Hz; 2.stable firing cross time;3. stable waveform......
%% go though each file manually
close all; clear all;  clc;


CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for itr0=1:size(SubPath,1)
    Path=SubPath{itr0,1};
    %%
    %change the directory to the file of DataID
    cd(Path);
    SplitDataFileName=ls('SplitData*.mat');
    UnStableUnitFileName=ls('SpikeCountUnstableID.txt');
    if ~isempty(SplitDataFileName)
        load(SplitDataFileName);
        FRCriterionIndex=find(round(FiringRate,1)<2);
        if ~isempty(UnStableUnitFileName)
            tempRemovedUnitID=importdata(UnStableUnitFileName);
            RawUnitID=10*SingleUnitIndex(:,1)+SingleUnitIndex(:,2);
            if~isempty(tempRemovedUnitID)
                for itr1 = 1: length(tempRemovedUnitID)
                    FiringStableCriterionIndex(itr1,1)=find(RawUnitID==tempRemovedUnitID(itr1,1));
                end
            else
                FiringStableCriterionIndex=[];
            end
        else
            FiringStableCriterionIndex=[];
        end
        RemoveUnitIndex=union(FRCriterionIndex,FiringStableCriterionIndex);
        FiringRate(RemoveUnitIndex,:)=[];
        NewSpikes(RemoveUnitIndex,:)=[];
        SingleUnitIndex(RemoveUnitIndex,:)=[];
        SplitData.SpikeTimestamp(RemoveUnitIndex,:)=[];
        SplitData.SpikeCounts(RemoveUnitIndex,:)=[];
        
        cd(SplitPath{1});
        save([SplitDataFileName],'DataID','Data','SplitData','SingleUnitIndex','DifferentTrials','Odor1','Odor2','LickInJava','Laser','LaserTrial',...
            'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','FiringRate','DifferentTrials','NewSpikes','LaserType','-v7.3')
    else
        cd(SplitPath{1});
    end
end


