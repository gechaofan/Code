%% plot AUC and Signitcant Units proportion
Group=1;% 1for ChR2, 2 for NpHR
AllUnitNum=size(AllUnitID,1);
AUC_Condition1=NaN*ones(AllUnitNum,10);Significant_Condition1=NaN*ones(AllUnitNum,10);
AUC_Condition2=NaN*ones(AllUnitNum,10);Significant_Condition2=NaN*ones(AllUnitNum,10);
AUC_Condition3=NaN*ones(AllUnitNum,10);Significant_Condition3=NaN*ones(AllUnitNum,10);

ShuffleAUC_Condition1=[];ShuffleAUC_Condition2=[];ShuffleAUC_Condition3=[];
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
for itr1 =1:MainCircleN
    load(filename{itr1});
    AUC_Condition1(:,itr1)=AllNeuronAUC{1,1};
    ShuffleAUC_Condition1{1,itr1}=AllNeuronShuffledAUC{1,1};
    AUC_Condition2(:,itr1)=AllNeuronAUC{2,1};
    ShuffleAUC_Condition2{1,itr1}=AllNeuronShuffledAUC{2,1};
    AUC_Condition3(:,itr1)=AllNeuronAUC{3,1};
    ShuffleAUC_Condition3{1,itr1}=AllNeuronShuffledAUC{3,1};
    Significant_Condition1(:,itr1)=IsSignificantAUC{1,1};
    Significant_Condition2(:,itr1)=IsSignificantAUC{2,1};
    Significant_Condition3(:,itr1)=IsSignificantAUC{3,1};
end
AUC_LaserOff=[AUC_Condition1(:,1) AUC_Condition1(:,10) AUC_Condition1(:,2:7) AUC_Condition1(:,11) AUC_Condition1(:,8:9)];
AUC_LaserOn=[AUC_Condition2(:,1) AUC_Condition2(:,10) AUC_Condition2(:,2:7) AUC_Condition2(:,11) AUC_Condition2(:,8:9)];
AUC_LaserOn_1=[AUC_Condition3(:,1) AUC_Condition3(:,10) AUC_Condition3(:,2:7) AUC_Condition3(:,11) AUC_Condition3(:,8:9)];

tempshuffleAUC1=cellfun(@(x) mean(x,2),ShuffleAUC_Condition1,'un',0);
tempshuffleAUC2=cellfun(@(x) mean(x,2),ShuffleAUC_Condition2,'un',0);

shuffleAUC_LaserOff=cell2mat(tempshuffleAUC1);
shuffleAUC_LaserOn=cell2mat(tempshuffleAUC2);

ShuffleAUC_LaserOff=[shuffleAUC_LaserOff(:,1) shuffleAUC_LaserOff(:,8) shuffleAUC_LaserOff(:,2:7) shuffleAUC_LaserOff(:,9)];
ShuffleAUC_LaserOn=[shuffleAUC_LaserOn(:,1) shuffleAUC_LaserOn(:,8) shuffleAUC_LaserOn(:,2:7) shuffleAUC_LaserOn(:,9)];
    
Significant_LaserOff=[Significant_Condition1(:,1) Significant_Condition1(:,10) Significant_Condition1(:,2:7) Significant_Condition1(:,11) Significant_Condition1(:,8:9)];
Significant_LaserOn=[Significant_Condition2(:,1) Significant_Condition2(:,10) Significant_Condition2(:,2:7) Significant_Condition2(:,11) Significant_Condition2(:,8:9)];
Significant_LaserOn1=[Significant_Condition3(:,1) Significant_Condition3(:,10) Significant_Condition3(:,2:7) Significant_Condition3(:,11) Significant_Condition3(:,8:9)];
SelectUnitNum_LaserOff_Learn_CLE=sum(abs(Significant_LaserOff(Learn_UnitIndex_CLE,:)),1);
SelectUnitNum_LaserEarly_Learn_CLE=sum(abs(Significant_LaserOn(Learn_UnitIndex_CLE,:)),1);
SelectUnitNum_LaserLate_Learn_CLE=sum(abs(Significant_LaserOn1(Learn_UnitIndex_CLE,:)),1);

%% 
if Group ==1
    Color=[0 0 1];
elseif Group==2
    Color=[0 1 0];
end
Index1=[Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE];
Index2=[Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE];
y1=AUC_LaserOff(:,1:8);y2=AUC_LaserOn(:,1:8);y3=AUC_LaserOn_1(:,1:8);
PreDelay=2;Delay=6;
p_LaserChangedUnits_Late = PlotAUCCurveFor2Condition(y1(Index2,:),y3(Index2,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['LaserChangedUnits-AUCResults-Sample-LateDelay' num2str(size(Index2,1))],'fig')
saveas(gcf,['LaserChangedUnits-AUCResults-Sample-LateDelay' num2str(size(Index2,1))],'png')

p_AllUnits_Shuffle = PlotAUCCurveFor2Condition(shuffleAUC_LaserOff,shuffleAUC_LaserOn,[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['AllUnits-ShuffleAUCResults-' num2str(size(shuffleAUC_LaserOff,1))],'fig')
saveas(gcf,['AllUnits-ShuffleAUCResults-' num2str(size(shuffleAUC_LaserOff,1))],'png')
Y = [y1(:,3:8);y2(:,3:8)];
S=[1:1:750 1:1:750]'*ones(1,6);
F1=[ones(750,6);2*ones(750,6)];
F2=ones(750*2,1)*[1:1:6];
p_ROC_AllUnits_Delay= rm_anova2(Y,S,F1,F2,{'Condition','time'});

p_FRDncreasedUnits = PlotAUCCurveFor2Condition(y1(FRDecresedIndex_EarlyDelay,:),y2(FRDecresedIndex_EarlyDelay,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['EarlyFRDecreasedUnits-AUCResults-' num2str(size(y1(FRIncresedIndex_EarlyDelay,:),1))],'fig')
saveas(gcf,['EarlyFRDecreasedUnits-AUCResults-' num2str(size(y1(FRIncresedIndex_EarlyDelay,:),1))],'png')
close all
Y = [y1(FRDncreasedID,8:9);y2(FRDncreasedID,8:9)];
S=[1:1:length(FRDncreasedID) 1:1:length(FRDncreasedID)]'*ones(1,6);
F1=[ones(length(FRDncreasedID),6);2*ones(length(FRDncreasedID),6)];
F2=ones(length(FRDncreasedID)*2,1)*[1:1:6];
p_ROC_FRDnCreasedUnits_Delay= rm_anova2(Y,S,F1,F2,{'Condition','time'});

p_FRIncreasedUnits = PlotAUCCurveFor2Condition(y1(FRIncreasedID,:),y2(FRIncreasedID,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['EarlyFRIncreasedUnits-AUCResults-' num2str(size(y1(FRIncreasedID,:),1))],'fig')
saveas(gcf,['EarlyFRIncreasedUnits-AUCResults-' num2str(size(y1(FRIncreasedID,:),1))],'png')
close all
Y = [y1(FRIncreasedID,3:8);y2(FRIncreasedID,3:8)];
S=[1:1:length(FRIncreasedID) 1:1:length(FRIncreasedID)]'*ones(1,6);
F1=[ones(length(FRIncreasedID),6);2*ones(length(FRIncreasedID),6)];
F2=ones(length(FRIncreasedID)*2,1)*[1:1:6];
p_ROC_FRInCreasedUnits_Delay= rm_anova2(Y,S,F1,F2,{'Condition','time'});

FRChangedUnitID=[FRDncreasedID;FRIncreasedID];
p_FRChangedUnits = PlotAUCCurveFor2Condition(y1(FRChangedUnitID,:),y2(FRChangedUnitID,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['FRChangedUnits-AUCResults-' num2str(size(y1(FRChangedUnitID,:),1))],'fig')
saveas(gcf,['FRChangedUnits-AUCResults-' num2str(size(y1(FRChangedUnitID,:),1))],'png')
close all


temp=[1:1:AllUnitNum]';
temp([FRDncreasedID;FRIncreasedID])=[];
FRUnChangedUnitID=temp;
p_FRUnChangedUnits = PlotAUCCurveFor2Condition(y1(FRUnChangedUnitID,:),y2(FRUnChangedUnitID,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['FRUnchangedUnitUnits-AUCResults-' num2str(size(y1(FRUnChangedUnitID,:),1))],'fig')
saveas(gcf,['FRUnchangedUnitUnits-AUCResults-' num2str(size(y1(FRUnChangedUnitID,:),1))],'png')
close all


p_DelayDecreasedUnits_LaserOn = PlotAUCCurveFor2Condition(y1(DelayDecreasedUnitIndex_LaserOn,:),y2(DelayDecreasedUnitIndex_LaserOn,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['DelayDecreasedUnits_LaserOn-AUCResults-' num2str(size(y1(DelayDecreasedUnitIndex_LaserOn,:),1))],'fig')
saveas(gcf,['DelayDecreasedUnits_LaserOn-AUCResults-' num2str(size(y1(DelayDecreasedUnitIndex_LaserOn,:),1))],'png')
close all

p_DelayIncreasedUnits_LaserOn = PlotAUCCurveFor2Condition(y1(DelayIncreasedUnitIndex_LaserOn,:),y2(DelayIncreasedUnitIndex_LaserOn,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['DelayIncreasedUnits_LaserOn-AUCResults-' num2str(size(y1(DelayIncreasedUnitIndex_LaserOn,:),1))],'fig')
saveas(gcf,['DelayIncreasedUnits_LaserOn-AUCResults-' num2str(size(y1(DelayIncreasedUnitIndex_LaserOn,:),1))],'png')
close all

DelayActivityUnitIndex=[DelayDecreasedUnitIndex_LaserOn;DelayIncreasedUnitIndex_LaserOn];
p_DelayActivityUnit_LaserOn = PlotAUCCurveFor2Condition(y1(DelayActivityUnitIndex,:),y2(DelayActivityUnitIndex,:),[0 0 0],Color,PreDelay,Delay);

DelayActivityUnitIndex=[DelayDecreasedUnitIndex_LaserOff;DelayIncreasedUnitIndex_LaserOff];
p_DelayActivityUnit_LaserOff = PlotAUCCurveFor2Condition(y1(DelayActivityUnitIndex,:),y2(DelayActivityUnitIndex,:),[0 0 0],Color,PreDelay,Delay);


P_Fraction_SampleDecodingUnitofAllUnits=PlotSepecificUnitFraction(Significant_LaserOff,Significant_LaserOn,[0 0 0],Color);
saveas(gcf,['Fraction-SampleDecodingUnit-AllUnits-' num2str(AllUnitNum)],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-AllUnits-' num2str(AllUnitNum)],'png')
close all

P_Fraction_SampleDecodingUnitofFRChangedUnits=PlotSepecificUnitFraction(Significant_LaserOff(FRChangedUnitID,:),Significant_LaserOn(FRChangedUnitID,:),[0 0 0],Color);
saveas(gcf,['Fraction-SampleDecodingUnit-FRChangedUnits-' num2str(length(FRChangedUnitID))],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-FRChangedUnits-' num2str(length(FRChangedUnitID))],'png')
close all

P_Fraction_SampleDecodingUnitofFRUnChangedUnits=PlotSepecificUnitFraction(Significant_LaserOff(FRUnChangedUnitID,:),Significant_LaserOn(FRUnChangedUnitID,:),[0 0 0],Color);
saveas(gcf,['Fraction-SampleDecodingUnit-FRUnChangedUnits-' num2str(length(FRUnChangedUnitID))],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-FRUnChangedUnits-' num2str(length(FRUnChangedUnitID))],'png')
close all

P_Fraction_SampleDecodingUnitofFRIncreasedUnits=PlotSepecificUnitFraction(Significant_LaserOff(FRIncreasedID,:),Significant_LaserOn(FRIncreasedID,:),[0 0 0],Color);
saveas(gcf,['Fraction-SampleDecodingUnit-FRIncreasedUnits-' num2str(length(FRIncreasedID))],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-FRIncreasedUnits-' num2str(length(FRIncreasedID))],'png')
close all

P_Fraction_SampleDecodingUnitofFRDncreasedUnits=PlotSepecificUnitFraction(Significant_LaserOff(FRDncreasedID,:),Significant_LaserOn(FRDncreasedID,:),[0 0 0],Color);
saveas(gcf,['Fraction-SampleDecodingUnit-FRDncreasedUnits-' num2str(length(FRDncreasedID))],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-FRDncreasedUnits-' num2str(length(FRDncreasedID))],'png')
close all
save(['Stats-NorLizedFRROCResults-VTA-ChR2-mPFC-Recording'],'p_AllUnits','p_AllUnits_Shuffle','p_FRDncreasedUnits','p_FRIncreasedUnits'...
    ,'p_FRChangedUnits','p_DelayDecreasedUnits_LaserOn','p_DelayIncreasedUnits_LaserOn','p_DelayActivityUnit_LaserOn','p_DelayActivityUnit_LaserOff'...
    ,'P_Fraction_SampleDecodingUnitofAllUnits','P_Fraction_SampleDecodingUnitofFRChangedUnits','P_Fraction_SampleDecodingUnitofFRUnChangedUnits'...
    ,'P_Fraction_SampleDecodingUnitofFRIncreasedUnits','P_Fraction_SampleDecodingUnitofFRDncreasedUnits','p_ROC_FRInCreasedUnits_Delay','p_ROC_FRDnCreasedUnits_Delay')
 
tempfilename=ls('*6sDelay*.mat');
load(tempfilename(2,:))
LaserOffSelcetiveUnitIndex=find(IsSignificantAUC{1,1}==1);LaserOnSelcetiveUnitIndex=find(IsSignificantAUC{2,1}==1);
p_SelectiveUnits = PlotAUCCurveFor2Condition(y1(LaserOffSelcetiveUnitIndex,:),y2(LaserOnSelcetiveUnitIndex,:),[0 0 0],Color,PreDelay,Delay);
saveas(gcf,['6sDelay-SelectiveUnits-AUCResults-' num2str(length(LaserOffSelcetiveUnitIndex)) '-' num2str(length(LaserOnSelcetiveUnitIndex))],'fig')
saveas(gcf,['6sDelay-SelectiveUnits-AUCResults-' num2str(length(LaserOffSelcetiveUnitIndex)) '-' num2str(length(LaserOnSelcetiveUnitIndex))],'png')
close all
figure('color',[1 1 1])
errorbar(1,mean(AllNeuronAUC{1,1}),std(AllNeuronAUC{1,1},0,1)/sqrt(length(AllNeuronAUC{1,1})-1),'k')
hold on
errorbar(1,mean(AllNeuronAUC{2,1}),std(AllNeuronAUC{2,1},0,1)/sqrt(length(AllNeuronAUC{2,1})-1),'color',Color)
saveas(gcf,['6sDelay-AllUnits-AUCResults-' num2str(size(AllNeuronAUC{1,1},1))],'fig')
saveas(gcf,['6sDelay-AllUnits-AUCResults-' num2str(size(AllNeuronAUC{1,1},1))],'png')
figure('color',[1 1 1])
bar(1,sum(IsSignificantAUC{1,1},1)/length(AllNeuronAUC{1,1}),'k')
hold on
bar(2,sum(IsSignificantAUC{2,1},1)/length(AllNeuronAUC{2,1}),'FaceColor',Color)
saveas(gcf,['Fraction-SampleDecodingUnit-6sDelay' num2str(AllUnitNum)],'fig')
saveas(gcf,['Fraction-SampleDecodingUnit-6sDelay' num2str(AllUnitNum)],'png')
close all
% x=find(IsSignificantAUC{1,1}==1);y=find(IsSignificantAUC{2,1}==1);
% p_AllUnits = PlotAUCCurveFor2Condition(y1(x,:),y2(y,:),[0 0 0],Color,PreDelay,Delay);
% saveas(gcf,['6sDelaySignificantUnits-AUCResults-' num2str(size(x,1)),'-' num2str(size(y,1))],'fig')
% saveas(gcf,['6sDelaySignificantUnits-AUCResults-' num2str(size(y,1)),'-' num2str(size(y,1))],'png')


delay_Off(1,1)=length(find(a==1));
delay_Off(1,2)=length(find(a==2));
delay_Off(1,3)=length(find(a==3));
delay_Off(1,4)=length(find(a==4));
delay_Off(1,5)=length(find(a==5));
delay_Off(1,6)=length(find(a==6));

delay_On(1,1)=length(find(b==1));
delay_On(1,2)=length(find(b==2));
delay_On(1,3)=length(find(b==3));
delay_On(1,4)=length(find(b==4));
delay_On(1,5)=length(find(b==5));
delay_On(1,6)=length(find(b==6));
Index_Off=find(a>0);
Index_On=find(b>0);
%%
Learn_FRIncreasedUnitIndex_Ealry=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_Learn_AllTrials);
WT_FRIncreasedUnitIndex_Ealry=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_WT_AllTrials);
Learn_FRDecreasedUnitIndex_Ealry=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_Learn_AllTrials);
WT_FRDecreasedUnitIndex_Ealry=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_WT_AllTrials);

Learn_FRIncreasedUnitIndex_Late=intersect(FRIncresedIndex_LateDelay,UnitIndex_Learn_AllTrials);
WT_FRIncreasedUnitIndex_Late=intersect(FRIncresedIndex_LateDelay,UnitIndex_WT_AllTrials);
Learn_FRDecreasedUnitIndex_Late=intersect(FRDecresedIndex_LateDelay,UnitIndex_Learn_AllTrials);
WT_FRDecreasedUnitIndex_Late=intersect(FRDecresedIndex_LateDelay,UnitIndex_WT_AllTrials);
% Last240Trials
Learn_FRIncreasedUnitIndex_Ealry_Last240=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_Learn_Last240Trials_ECL);
WT_FRIncreasedUnitIndex_Ealry_Last240=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_WT_Last240Trials_ECL);
Learn_FRDecreasedUnitIndex_Ealry_Last240=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_Learn_Last240Trials_ECL);
WT_FRDecreasedUnitIndex_Ealry_Last240=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_WT_Last240Trials_ECL);

Learn_FRIncreasedUnitIndex_Late_Last240=intersect(FRIncresedIndex_LateDelay,UnitIndex_Learn_Last240Trials_ECL);
WT_FRIncreasedUnitIndex_Late_Last240=intersect(FRIncresedIndex_LateDelay,UnitIndex_WT_Last240Trials_ECL);
Learn_FRDecreasedUnitIndex_Late_Last240=intersect(FRDecresedIndex_LateDelay,UnitIndex_Learn_Last240Trials_ECL);
WT_FRDecreasedUnitIndex_Late_Last240=intersect(FRDecresedIndex_LateDelay,UnitIndex_WT_Last240Trials_ECL);

% 240Trials, CLE(21-260)
Learn_FRIncreasedUnitIndex_Ealry_CLE=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_Learn_240Trials_CLE);
WT_FRIncreasedUnitIndex_Ealry_CLE=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_WT_240Trials_CLE);
Learn_FRDecreasedUnitIndex_Ealry_CLE=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_Learn_240Trials_CLE);
WT_FRDecreasedUnitIndex_Ealry_CLE=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_WT_240Trials_CLE);

Learn_FRIncreasedUnitIndex_Late_CLE=intersect(FRIncresedIndex_LateDelay,UnitIndex_Learn_240Trials_CLE);
WT_FRIncreasedUnitIndex_Late_CLE=intersect(FRIncresedIndex_LateDelay,UnitIndex_WT_240Trials_CLE);
Learn_FRDecreasedUnitIndex_Late_CLE=intersect(FRDecresedIndex_LateDelay,UnitIndex_Learn_240Trials_CLE);
WT_FRDecreasedUnitIndex_Late_CLE=intersect(FRDecresedIndex_LateDelay,UnitIndex_WT_240Trials_CLE);

% 240Trials, LEC(41-280)
Learn_FRIncreasedUnitIndex_Ealry_LEC=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_Learn_240Trials_LEC);
WT_FRIncreasedUnitIndex_Ealry_LEC=intersect(FRIncresedIndex_EarlyDelay,UnitIndex_WT_240Trials_LEC);
Learn_FRDecreasedUnitIndex_Ealry_LEC=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_Learn_240Trials_LEC);
WT_FRDecreasedUnitIndex_Ealry_LEC=intersect(FRDecresedIndex_EarlyDelay,UnitIndex_WT_240Trials_LEC);

Learn_FRIncreasedUnitIndex_Late_LEC=intersect(FRIncresedIndex_LateDelay,UnitIndex_Learn_240Trials_LEC);
WT_FRIncreasedUnitIndex_Late_LEC=intersect(FRIncresedIndex_LateDelay,UnitIndex_WT_240Trials_LEC);
Learn_FRDecreasedUnitIndex_Late_LEC=intersect(FRDecresedIndex_LateDelay,UnitIndex_Learn_240Trials_LEC);
WT_FRDecreasedUnitIndex_Late_LEC=intersect(FRDecresedIndex_LateDelay,UnitIndex_WT_240Trials_LEC);



