%% This code is used for ROC annalysis
%% Ref.
% Laser = 1 for no laser or all trials laser on; 2 conditions for Laser on & Laser off; 3 conditions of Laser on & Off
clc;clear;close all;
CoresNumber=str2num(getenv('NUMBER_OF_PROCESSORS'));
DecodingForSamTestDecisionTrialType=1;% 1 for sample odor; 2 for test odor
PairOrNonPairTrials=3;
IsCorrectOrErrorOrAllTrials=1;%1 for correct trials, 2 for error trials , 3 for all trials
ShuffledTimes=1000;%define the permutation times to do stastical test of AUC
IsNormalization=1;%normalized firing rate for analysis,0 raw firing rate
IsDVOrFRROC=2;%1 for calculated TPR/FPR with decision variable; 2 for calculation with Raw firing rate
DVOrFR=[{'DV'};{'RawFR'}];
TrainingDayID='AllTrainingDays';
for Period = 0:9
    TargetBrainID='VTAtomPFC';%define the brain area for summary
    UnitSummaryFile=dir(['*' TargetBrainID '-DPA-AllUnitsSummary*.mat']);
    for iFile=1%1:size(UnitSummaryFile,1)%go through each group of data
        Filename=UnitSummaryFile(iFile).name(1:end-4);
        disp(Filename)
        %disp(datetime)
        %
        load(Filename);
        TimeGain=TotalUnitSplitData.TimeGain;
        AllNeuronID=TotalUnitSplitData.AllUnitID;
        switch Period
            case 0 % 1s baseline
                DelayPeriod=(1)*TimeGain+1:(2)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='1sBaseline';
            case 1 % sample odor
                DelayPeriod=(2)*TimeGain+1:(2+OdorMN)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='Sample';
            case 2 % 1st s of delay
                DelayPeriod=(2+OdorMN)*TimeGain+1:(2+OdorMN+1)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='1stSecDelay';
            case 3 % 2nd s of delay
                DelayPeriod=(2+OdorMN+1)*TimeGain+1:(2+OdorMN+2)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='2ndSecDelay';
            case 4 % 3rd s of delay
                DelayPeriod=(2+OdorMN+2)*TimeGain+1:(2+OdorMN+3)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='3rdSecDelay';
            case 5 % 4th s of delay
                DelayPeriod=(2+OdorMN+3)*TimeGain+1:(2+OdorMN+4)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='4thSecDelay';
            case 6 % 5th s of delay
                DelayPeriod=(2+OdorMN+4)*TimeGain+1:(2+OdorMN+5)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='5thSecDelay';
            case 7 % 6th s of delay
                DelayPeriod=(2+OdorMN+5)*TimeGain+1:(2+OdorMN+6)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='6thSecDelay';
            case 8 % test
                DelayPeriod=(2+OdorMN+6)*TimeGain+1:(2+OdorMN+DelayMN+7)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='Test';
            case 9 % 6s delay
                DelayPeriod=(2+OdorMN)*TimeGain+1:(2+OdorMN+DelayMN)*TimeGain;% baseline = 2, 2s before sample
                PeriodName='6sDelay';
            otherwise
        end
        
        TotalSingleUnitNum = length(TotalUnitSplitData.AllUnitID);
        SPlen=min(vertcat(TotalUnitSplitData.ShortSPlen{:}));
        LaserType=unique(TotalUnitSplitData.Laser{1,1});    LaserTypeNum=size(LaserType,1);
        
        GroupID='-NL';
        IsChR=regexpi(Filename,'ChR');
        if ~isempty(IsChR)
            GroupID='-ChR';
        end
        IsNpHR=regexpi(Filename,'NpHR');
        if ~isempty(IsNpHR)
            GroupID='-NpHR';
        end
        %% get All Units' AUC
        SecondBasedIsSig=cell(LaserTypeNum,1);
        AllNeuronSample1DelayFR=cell(LaserTypeNum,1);
        AllNeuronSample2DelayFR=cell(LaserTypeNum,1);
        AllNeuronAUC =cell(LaserTypeNum,1);
        AllNeuronAUC_zOverO=cell(LaserTypeNum,1);
        AllNeuronShuffledAUC=cell(LaserTypeNum,1);
        AllNeuronShuffledAUC_shuffleRev=cell(LaserTypeNum,1);
        IsSignificantAUC=cell(LaserTypeNum,1);
        DelaySigBinNum=cell(LaserTypeNum,1);
        DiffDelay=cell(LaserTypeNum,1);
        for iLaser = 1 :  LaserTypeNum% no laser or all trials laser on
            Laser=LaserType(iLaser,1);
            %%
            poolobj = gcp('nocreate'); % If no pool, do not create new one.
            if isempty(poolobj)
                myCluster=parcluster('local'); myCluster.NumWorkers=20; parpool(myCluster,20);
            end
            %%
            SecondBasedIsSig{iLaser,1}=NaN*ones(TotalSingleUnitNum,DelayMN+OdorMN+1);
            AllNeuronSample1DelayFR{iLaser,1}=cell(1,TotalSingleUnitNum);
            AllNeuronSample2DelayFR{iLaser,1}=cell(1,TotalSingleUnitNum);
            AllNeuronAUC{iLaser,1}=NaN*ones(TotalSingleUnitNum,1);
            AllNeuronAUC_zOverO{iLaser,1}=NaN*ones(TotalSingleUnitNum,1);
            AllNeuronShuffledAUC{iLaser,1}=NaN*ones(TotalSingleUnitNum,ShuffledTimes);
            AllNeuronShuffledAUC_shuffleRev{iLaser,1}=NaN*ones(TotalSingleUnitNum,ShuffledTimes);
            IsSignificantAUC{iLaser,1}=NaN*ones(TotalSingleUnitNum,1);
            DiffDelay{iLaser,1}=NaN*ones(TotalSingleUnitNum,1);
            %             for iNeuron=1:TotalSingleUnitNum%go through each units
            for iNeuron=1:TotalSingleUnitNum%go through each units
                iNeuronShuffledAUC=zeros(1,ShuffledTimes);iNeuronShuffledAUC_shuffleRev=zeros(1,ShuffledTimes);
                tic
                if mod(iNeuron,50)==0||iNeuron==1||iNeuron==TotalSingleUnitNum
                    disp(['Current Neuron number=' num2str(iNeuron)])
                    disp(datetime)
                end
                SequentialAllSP=TotalUnitSplitData.AllSequentialAllSP{iNeuron};
                TrialsJudgement=TotalUnitSplitData.TrialsJudgement{iNeuron};
                IsLaserTrial=TotalUnitSplitData.Laser{iNeuron};
                
                
                %% Step 1: get the trial index and trial composition during three phases(rule1, transition, and rule2 periods)
                
                [~,~,TrialIndex1,TrialIndex2]= GCFGetNDTTrialID(DecodingForSamTestDecisionTrialType...
                    ,TrialsJudgement,Laser,IsLaserTrial,IsCorrectOrErrorOrAllTrials,PairOrNonPairTrials);
                %% calculate second based odor selectivity
                ATrials=SequentialAllSP(:,TrialIndex1);
                BTrials=SequentialAllSP(:,TrialIndex2);
                [TempOdorSelectivity]=SecondBasedRankSumTest(ATrials,BTrials,TimeGain,-1,DelayMN+OdorMN);% 1s baseline + odor + delay
                SecondBasedIsSig{iLaser,1}(iNeuron,:)=TempOdorSelectivity(3,:);
                tempATrials=cell2mat(ATrials');
                tempBTrials=cell2mat(BTrials');
                if IsNormalization==1
                    tempATrials=cell2mat(ATrials');
                    tempBTrials=cell2mat(BTrials');
                    NormATrials=(tempATrials-mean(mean(tempATrials(:,10:19),2)))./std(mean(tempATrials(:,10:19),2),0,1);
                    NormBTrials=(tempBTrials-mean(mean(tempBTrials(:,10:19),2)))./std(mean(tempBTrials(:,10:19),2),0,1);
                    Rule1DelayMeanFR=CalculateCrossTrialMeanFR(NormATrials,DelayPeriod,TimeGain,IsNormalization);
                    Rule2DelayMeanFR=CalculateCrossTrialMeanFR(NormBTrials,DelayPeriod,TimeGain,IsNormalization);
                else
                    Rule1DelayMeanFR=CalculateCrossTrialMeanFR(NormATrials,DelayPeriod,TimeGain,IsNormalization);
                    Rule2DelayMeanFR=CalculateCrossTrialMeanFR(NormBTrials,DelayPeriod,TimeGain,IsNormalization);
                end                
               
                AllNeuronSample1DelayFR{iLaser,1}{iNeuron}=Rule1DelayMeanFR;
                AllNeuronSample2DelayFR{iLaser,1}{iNeuron}=Rule2DelayMeanFR;
                %% Step 3: Calculate the DV between rule1 and rule2
                if IsDVOrFRROC==1
                    [Rule1DV,Rule2DV]=CalculateDesionVariable(Rule1DelayMeanFR,Rule2DelayMeanFR);
                else
                    Rule1DV=Rule1DelayMeanFR;
                    Rule2DV=Rule2DelayMeanFR;
                end
%                 isSameDelayMeanFR=unique(Rule1DV==Rule2DV);
%                 if length(isSameDelayMeanFR) ~= 1
                    Input=[];InputData=[];InputGroup=[];
                    InputData=[Rule1DV;Rule2DV];
                    InputGroup=[ones(length(Rule1DV),1);zeros(length(Rule2DV),1)];
                    Input=[InputData InputGroup];
                    %% Step 4: Plot the ROC curve between sample1 and sample2 for single unit and calculate AUC
                    
                    [ROCout,zOverO]=rocCRM(Input);
                    AllNeuronAUC{iLaser,1}(iNeuron,1)=ROCout;
                    AllNeuronAUC_zOverO{iLaser,1}(iNeuron,1)=zOverO;
                    %% Step 5: shuffle the firing rate of all trials, calculate the corresponding AUC and do permutation test
                    parfor n = 1:ShuffledTimes
%                         ShuffleType=RandShuffle(Input(:,2));
%                         DataShuffle=[Input(:,1),ShuffleType];
                        ShuffleType=randperm(size(Input,1));
                        DataShuffle=[Input(ShuffleType',1) Input(:,2)];
                        [ROCSummary_nonOpto_shuffle,isReverse_shuffle]=rocCRM(DataShuffle);
                        iNeuronShuffledAUC(1,n)=ROCSummary_nonOpto_shuffle;
                        iNeuronShuffledAUC_shuffleRev(1,n) = isReverse_shuffle;
                    end
%                 elseif isSameDelayMeanFR ==1
%                     AllNeuronAUC{iLaser,1}(iNeuron,1)=0.5;
%                     AllNeuronAUC_zOverO{iLaser,1}(iNeuron,1)=0;
%                     iNeuronShuffledAUC=0.5*ones(1,ShuffledTimes);
%                     iNeuronShuffledAUC_shuffleRev=zeros(1,ShuffledTimes);
%                 end
                AllNeuronShuffledAUC{iLaser,1}(iNeuron,:)=iNeuronShuffledAUC; % data used
                AllNeuronShuffledAUC_shuffleRev{iLaser,1}(iNeuron,:) = iNeuronShuffledAUC_shuffleRev;
                [SignificanceLevel]=AUCPermutationTest(ShuffledTimes,ROCout,AllNeuronShuffledAUC{iLaser,1}(iNeuron,:));
                IsSignificantAUC{iLaser,1}(iNeuron)=SignificanceLevel;
                toc
            end
        end
        DelaySigBinNum{iLaser,1}=sum(SecondBasedIsSig{iLaser,1}(:,3:8),2);
    end
    
    save(['GCFDelayROCResults-' GroupID '-' TrainingDayID '-' PeriodName '-' DVOrFR{IsDVOrFRROC} '-' num2str(TotalSingleUnitNum)]...
        ,'AllNeuronAUC','AllNeuronAUC_zOverO','AllNeuronShuffledAUC','AllNeuronShuffledAUC_shuffleRev'...
        ,'IsSignificantAUC','ShuffledTimes','SecondBasedIsSig','DelaySigBinNum','OdorMN','DelayMN','ResponseMN','WaterMN'...
        ,'ITIMN','TimeGain','SPlen','DiffDelay','AllNeuronSample1DelayFR','AllNeuronSample2DelayFR'...
        ,'AllNeuronID','IsDVOrFRROC','IsNormalization','LaserType')
end
