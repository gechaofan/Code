function p=PlotSepecificUnitFraction(Fraction1,Fraction2,Color1,Color2)

figure('color',[1 1 1])
SumFraction1=sum(Fraction1,1);
SumFraction2=sum(Fraction2,1);

bar([0.9:1:size(Fraction1,2)-0.1],sum(Fraction1,1)/size(Fraction1,1),'BarWidth',0.2,'FaceColor',Color1)
hold on
bar([1.1:1:size(Fraction1,2)+0.1],sum(Fraction2,1)/size(Fraction2,1),'BarWidth',0.2,'FaceColor',Color2)
plot([1.5 1.5],[0 1],'LineStyle','--','col',[0 0 0])
plot([2.5 2.5],[0 1],'LineStyle','--','col',[0 0 0])
plot([8.5 8.5],[0 1],'LineStyle','--','col',[0 0 0])
plot([9.5 9.5],[0 1],'LineStyle','--','col',[0 0 0])
p=NaN*ones(1,size(Fraction1,2));
for i =1:size(Fraction1,2)
   [~,p(i)]=prop_test([SumFraction1(i) SumFraction2(i)],[size(Fraction1,1) size(Fraction2,1)],0);
    if p(i)<0.05
        plot(i,0.7,'Marker','*')
    end
    
end