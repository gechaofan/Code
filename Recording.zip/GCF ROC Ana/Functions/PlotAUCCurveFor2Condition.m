function p=PlotAUCCurveFor2Condition(Input1,Input2,Color1,Color2,PreDelay,Delay)
p=NaN*ones(1,size(Input1,2));
% Max= max([mean(Input1,1) mean(Input2,1)])*1.2;
Max= 0.6;
figure('color',[1 1 1])

errorbar([1:1:size(Input1,2)],mean(Input1,1),std(Input1,0,1)/sqrt(size(Input1,1)-1),'col',Color1)
hold on
errorbar([1:1:size(Input2,2)],mean(Input2,1),std(Input2,0,1)/sqrt(size(Input2,1)-1),'col',Color2)
plot([1.5 1.5],[0.5 Max],'LineStyle','--','col',[0 0 0])
plot([2.5 2.5],[0.5 Max],'LineStyle','--','col',[0 0 0])
plot([8.5 8.5],[0.5 Max],'LineStyle','--','col',[0 0 0])
plot([9.5 9.5],[0.5 Max],'LineStyle','--','col',[0 0 0])
for i =1 : size(Input1,2)
    if size(Input1,1)==size(Input2,1)%%% paired data
        p(1,i)=signrank(Input1(:,i),Input2(:,i));
    else
        p(1,i)=ranksum(Input1(:,i),Input2(:,i));
    end
%     if  p(1,i)<0.05
%         plot(i,Max,'Marker','*','col',[0 0 0])
%     end
%         plot(i,Max,'Marker','*','col',[0 0 0])
    if i <= PreDelay && p(1,i)<0.05
        plot(i,Max,'Marker','*','col',[0 0 0])
    elseif p(1,i)<0.05/Delay
        plot(i,Max,'Marker','*','col',[0 0 0])
    end
end

end