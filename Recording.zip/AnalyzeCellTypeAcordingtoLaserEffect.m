%% Laser effect with binsize 500ms
FR_AllTrials_1=ReDefineBinSize(LaserOffAllTrialsFR,500,100);% laser off
FR_AllTrials_2=ReDefineBinSize(LaserOnAllTrialsFR_EarlyDelay,500,100);%laser on early delay
FR_AllTrials_3=ReDefineBinSize(LaserOnAllTrialsFR_LateDelay,500,100);%laser on late delay

NormFR_AllTrials_1=ReDefineBinSize(NormAllTrialsFR_LaserOff,500,100,1);% laser off
NormFR_AllTrials_2=ReDefineBinSize(NormAllTrialsFR_LaserOnEarlyDelay,500,100,1);%laser on early delay
NormFR_AllTrials_3=ReDefineBinSize(NormAllTrialsFR_LaserOnLateDelay,500,100,1);%laser on late delay
Mean1=cell2mat(cellfun(@(x) mean(x,1),NormFR_AllTrials_1,'un',0));
Mean2=cell2mat(cellfun(@(x) mean(x,1),NormFR_AllTrials_2,'un',0));
Mean3=cell2mat(cellfun(@(x) mean(x,1),NormFR_AllTrials_3,'un',0));
index=idx_E_Inc;
error1=std(Mean1(index,:),0,1)/sqrt(length(index)-1);
error2=std(Mean2(index,:),0,1)/sqrt(length(index)-1);
M1=mean(Mean1(index,:),1);
M2=mean(Mean2(index,:),1);
%% for delay activity during laser period
clear('y1','y2','y','temp1','temp11','g1','temp2','temp22','g2')
y1=Mean1(idx_L_Inc,15:18); y2=Mean3(idx_L_Inc,15:18);y=[y1;y2];
temp1=ones(length(idx_L_Inc),4);temp11=2*ones(length(idx_L_Inc),4);g1=[temp1;temp11];% laser on and off
temp2=[1:1:4].*ones(length(idx_L_Inc),4);temp22=[1:1:4].*ones(length(idx_L_Inc),4);g2=[temp2;temp2];
[p,tbl,stats]=anovan(reshape(y,[],1),{reshape(g1,[],1) reshape(g2,[],1)},'model',2,'varnames',{'laser','time'});
%%
for i = 1: 40
   p_500.E_Dec_Off(1,i)=ranksum(Mean1(idx_E_Dec,4),Mean1(idx_E_Dec,i)); 
   p_500.E_Inc_Off(1,i)=ranksum(Mean1(idx_E_Inc,4),Mean1(idx_E_Inc,i)); 
   p_500.L_Dec_Off(1,i)=ranksum(Mean1(idx_L_Dec,4),Mean1(idx_L_Dec,i)); 
   p_500.L_Inc_Off(1,i)=ranksum(Mean1(idx_L_Inc,4),Mean1(idx_L_Inc,i)); 
   p_500.E_Dec_On(1,i)=ranksum(Mean2(idx_E_Dec,4),Mean2(idx_E_Dec,i)); 
   p_500.E_Inc_On(1,i)=ranksum(Mean2(idx_E_Inc,4),Mean2(idx_E_Inc,i)); 
   p_500.L_Dec_On(1,i)=ranksum(Mean3(idx_L_Dec,4),Mean3(idx_L_Dec,i)); 
   p_500.L_Inc_On(1,i)=ranksum(Mean3(idx_L_Inc,4),Mean3(idx_L_Inc,i)); 
end
for i = 1: 40
   p_500.E_Dec_Off(1,i)=ranksum(mean(Mean1(idx_E_Dec,3:4),2),Mean1(idx_E_Dec,i)); 
   p_500.E_Inc_Off(1,i)=ranksum(mean(Mean1(idx_E_Inc,3:4),2),Mean1(idx_E_Inc,i)); 
   p_500.L_Dec_Off(1,i)=ranksum(mean(Mean1(idx_L_Dec,3:4),2),Mean1(idx_L_Dec,i)); 
   p_500.L_Inc_Off(1,i)=ranksum(mean(Mean1(idx_L_Inc,3:4),2),Mean1(idx_L_Inc,i)); 
   p_500.E_Dec_On(1,i)=ranksum(mean(Mean2(idx_E_Dec,3:4),2),Mean2(idx_E_Dec,i)); 
   p_500.E_Inc_On(1,i)=ranksum(mean(Mean2(idx_E_Inc,3:4),2),Mean2(idx_E_Inc,i)); 
   p_500.L_Dec_On(1,i)=ranksum(mean(Mean3(idx_L_Dec,3:4),2),Mean3(idx_L_Dec,i)); 
   p_500.L_Inc_On(1,i)=ranksum(mean(Mean3(idx_L_Inc,3:4),2),Mean3(idx_L_Inc,i)); 
end
figure
errorbar(M2(1,3:22),error2(1,3:22),'LineStyle','none')
hold on
bar(M2(1,3:22))
plot([2.5 4.5 16.5 18.5;2.5 4.5 16.5 18.5],[0 0 0 0;1 1 1 1],'--k')
set(gca,'XLim',[-1,23],'XTickLabel',{'0','2','4','6','8'},'XTick',[2.5,6.5,10.5,14.5,18.5],'YLim',[-0.3,1.0],'YTickLabel',{'-0.3','0','0.3','0.6','0.9'},'YTick',[-0.3,0,0.3,0.6,0.9])
tempIndex1=find(p.L_Dec_On(1,3:22)<0.05);
plot(tempIndex1, ones(size(tempIndex1))-0.1,'LineStyle','none','Marker','*')
tempIndex2=find(p.L_Dec_On(1,3:22)<0.01);
plot(tempIndex2, ones(size(tempIndex2))-0.11,'LineStyle','none','Marker','*')
tempIndex3=find(p.L_Dec_On(1,3:22)<0.001);
plot(tempIndex3, ones(size(tempIndex3))-0.12,'LineStyle','none','Marker','*')
saveas(gcf, ['DelayActivity_Late_DecreasedUnits_LaserOn_Train'],'fig')
saveas(gcf, ['DelayActivity_Late_DecreasedUnits_LaserOn_Train'],'png')
% 
figure
errorbar(M1(1,7:10),error1(1,7:10),'k')
hold on
errorbar(M2(1,7:10),error2(1,7:10),'r')
plot([0.5,4.5],[0,0],'--k')
p_Late_Inc_Laser=ranksum(M1(1,7:10),M2(1,7:10));
title(['p=' num2str(p_Late_Inc_Laser)])
saveas(gcf, ['DelayActivity_Early_IncreasedUnits_Train'],'fig')
saveas(gcf, ['DelayActivity_Early_IncreasedUnits_Train'],'png')


FR_ATrials_1=ReDefineBinSize(LaserOffAllATrialsFR,500,100);% laser off
FR_ATrials_2=ReDefineBinSize(LaserOnAllATrialsFR_EarlyDelay,500,100);%laser on early delay
FR_ATrials_3=ReDefineBinSize(LaserOnAllATrialsFR_LateDelay,500,100);%laser on late delay

FR_BTrials_1=ReDefineBinSize(LaserOffAllBTrialsFR,500,100);% laser off
FR_BTrials_2=ReDefineBinSize(LaserOnAllBTrialsFR_EarlyDelay,500,100);%laser on early delay
FR_BTrials_3=ReDefineBinSize(LaserOnAllBTrialsFR_LateDelay,500,100);%laser on late delay
% laser effect for each bin
for iNeu = 1 : 750
    for iBin = 1 : 40
        % all trials
        [p_E(iNeu,iBin),large_E(iNeu,iBin)]=ranksumTest(FR_AllTrials_2{iNeu,1}(:,iBin),FR_AllTrials_1{iNeu,1}(:,iBin),1);
        [p_L(iNeu,iBin),large_L(iNeu,iBin)]=ranksumTest(FR_AllTrials_3{iNeu,1}(:,iBin),FR_AllTrials_1{iNeu,1}(:,iBin),1);
        % A trials
        [p_A_E(iNeu,iBin),large_A_E(iNeu,iBin)]=ranksumTest(FR_ATrials_2{iNeu,1}(:,iBin),FR_ATrials_1{iNeu,1}(:,iBin),1);
        [p_A_L(iNeu,iBin),large_A_L(iNeu,iBin)]=ranksumTest(FR_ATrials_3{iNeu,1}(:,iBin),FR_ATrials_1{iNeu,1}(:,iBin),1);        
        % B Trials
        [p_B_E(iNeu,iBin),large_B_E(iNeu,iBin)]=ranksumTest(FR_BTrials_2{iNeu,1}(:,iBin),FR_BTrials_1{iNeu,1}(:,iBin),1);
        [p_B_L(iNeu,iBin),large_B_L(iNeu,iBin)]=ranksumTest(FR_BTrials_3{iNeu,1}(:,iBin),FR_BTrials_1{iNeu,1}(:,iBin),1);  
    end 
end
LaserEffect_E=zeros(750,40);LaserEffect_L=zeros(750,40);
LaserEffect_E(find(p_E<0.05&large_E==1))=1;LaserEffect_E(find(p_E<0.05&large_E==2))=-1;
LaserEffect_L(find(p_L<0.05&large_L==1))=1;LaserEffect_L(find(p_L<0.05&large_L==2))=-1;
for i = 1:4
    Learn_Num_E(1,i) = length(find(LaserEffect_E(Learn_UnitIndex_CLE,i+6)>0));% learn, increased
    Learn_Num_E(2,i) = length(find(LaserEffect_E(Learn_UnitIndex_CLE,i+6)<0));% learn, increased
    Learn_Num_L(1,i) = length(find(LaserEffect_L(Learn_UnitIndex_CLE,i+14)>0));% learn, increased
    Learn_Num_L(2,i) = length(find(LaserEffect_L(Learn_UnitIndex_CLE,i+14)<0));% learn, increased
end
% Learn_Num_E(3,:) = 471-sum(Learn_Num_E(1:2,:),1);
% Learn_Num_L(3,:) = 471-sum(Learn_Num_L(1:2,:),1);

for i = 1 : 750
    Idxs_Bin_Change_E{i,1}=find(LaserEffect_E(i,7:10)~=0);
    Idxs_Bin_Change_L{i,1}=find(LaserEffect_L(i,15:18)~=0); 
end
NormFR_Inc_E_LaserOff=cellfun(@(x) mean(mean(x(:,7:10),1)) ,NormFR_AllTrials_1(Learn_E_Inc_idxs,1));
NormFR_Inc_E_LaserOnEarly=cellfun(@(x) mean(mean(x(:,7:10),1)),NormFR_AllTrials_2(Learn_E_Inc_idxs,1));
NormFR_Dec_E_LaserOff=cellfun(@(x) mean(mean(x(:,7:10),1)),NormFR_AllTrials_1(Learn_E_Dec_idxs,1));
NormFR_Dec_E_LaserOnEarly=cellfun(@(x) mean(mean(x(:,7:10),1)),NormFR_AllTrials_2(Learn_E_Dec_idxs,1));

NormFR_Inc_L_LaserOff=cellfun(@(x) mean(mean(x(:,15:18),1)),NormFR_AllTrials_1(Learn_L_Inc_idxs,1));
NormFR_Inc_L_LaserOnLate=cellfun(@(x) mean(mean(x(:,15:18),1)),NormFR_AllTrials_3(Learn_L_Inc_idxs,1));
NormFR_Dec_L_LaserOff=cellfun(@(x) mean(mean(x(:,15:18),1)),NormFR_AllTrials_1(Learn_L_Dec_idxs,1));
NormFR_Dec_L_LaserOnLate=cellfun(@(x) mean(mean(x(:,15:18),1)),NormFR_AllTrials_3(Learn_L_Dec_idxs,1));
for iBin = 1 : 6
    CumulatedLaserEffect_E(:,iBin) = sum(LaserEffect_E(:,7:iBin+6),2);
    CumulatedLaserEffect_L(:,iBin) = sum(LaserEffect_L(:,15:iBin+14),2);
end
LaserEffect500ms.Info='AllTrials-300';
LaserEffect500ms.Early=LaserEffect_E;
LaserEffect500ms.Late=LaserEffect_L;
LaserEffect500ms.LearnUnitsIndex=Learn_UnitIndex_CLE;
LaserEffect500ms.WaveformInfo=UnitWaveproperty;

% Early laser: classification of units according to firing change
E_Inc_Idxs = find(CumulatedLaserEffect_E(:,4)>0);
E_Dec_Idxs = find(CumulatedLaserEffect_E(:,4)<0);
E_Reversed_Index=find(max(CumulatedLaserEffect_E(:,1:4),[],2) .* min(CumulatedLaserEffect_E(:,1:4),[],2)<0);

E_FastTransientIncrease_Index=find(CumulatedLaserEffect_E(:,1)==1&CumulatedLaserEffect_E(:,4)==1); % only increased in first 500ms
E_FastConstantIncrease_Index=find(CumulatedLaserEffect_E(:,1)==1&CumulatedLaserEffect_E(:,4)>1);% increased in first 500ms and last for 1s and more
E_SlowTransientIncrease_Index=find(CumulatedLaserEffect_E(:,1)==0&CumulatedLaserEffect_E(:,4)==1);
E_SlowConstantIncrease_Index=find(CumulatedLaserEffect_E(:,1)==0&CumulatedLaserEffect_E(:,4)>1);

E_FastTransientDecrease_Index=find(CumulatedLaserEffect_E(:,1)==-1&CumulatedLaserEffect_E(:,4)==-1); % 
E_FastConstantDecrease_Index=find(CumulatedLaserEffect_E(:,1)==-1&CumulatedLaserEffect_E(:,4)<-1);%
E_SlowTransientDecrease_Index=find(CumulatedLaserEffect_E(:,1)==0&CumulatedLaserEffect_E(:,4)==-1);
E_SlowConstantDecrease_Index=find(CumulatedLaserEffect_E(:,1)==0&CumulatedLaserEffect_E(:,4)<-1);
Learn_E_Inc_idxs=intersect(Learn_UnitIndex_CLE,E_Inc_Idxs);
Learn_E_Dec_idxs=intersect(Learn_UnitIndex_CLE,E_Dec_Idxs);
idx_Early=[Learn_E_Inc_idxs;Learn_E_Dec_idxs];
idx_Late=[Learn_L_Inc_idxs;Learn_L_Dec_idxs];


% Late laser: classification of units according to firing change
L_Inc_Idxs = find(CumulatedLaserEffect_L(:,4)>0);
L_Dec_Idxs = find(CumulatedLaserEffect_L(:,4)<0);
L_Reversed_Index=find(max(CumulatedLaserEffect_L(:,1:4),[],2) .* min(CumulatedLaserEffect_L(:,1:4),[],2)<0);

L_FastTransientIncrease_Index=find(CumulatedLaserEffect_L(:,1)==1&CumulatedLaserEffect_L(:,4)==1); % only increased in first 500ms
L_FastConstantIncrease_Index=find(CumulatedLaserEffect_L(:,1)==1&CumulatedLaserEffect_L(:,4)>1);% increased in first 500ms and last for 1s and more
L_SlowTransientIncrease_Index=find(CumulatedLaserEffect_L(:,1)==0&CumulatedLaserEffect_L(:,4)==1);
L_SlowConstantIncrease_Index=find(CumulatedLaserEffect_L(:,1)==0&CumulatedLaserEffect_L(:,4)>1);

L_FastTransientDecrease_Index=find(CumulatedLaserEffect_L(:,1)==-1&CumulatedLaserEffect_L(:,4)==-1); % 
L_FastConstantDecrease_Index=find(CumulatedLaserEffect_L(:,1)==-1&CumulatedLaserEffect_L(:,4)<-1);%
L_SlowTransientDecrease_Index=find(CumulatedLaserEffect_L(:,1)==0&CumulatedLaserEffect_L(:,4)==-1);
L_SlowConstantDecrease_Index=find(CumulatedLaserEffect_L(:,1)==0&CumulatedLaserEffect_L(:,4)<-1);
Learn_L_Inc_idxs=intersect(Learn_UnitIndex_CLE,L_Inc_Idxs);
Learn_L_Dec_idxs=intersect(Learn_UnitIndex_CLE,L_Dec_Idxs);
%% selectivity within 500ms bin
FR_ATrials_1_80=cellfun(@(x) x(1:40,:),FR_ATrials_1,'un',0);
FR_BTrials_1_80=cellfun(@(x) x(1:40,:),FR_BTrials_1,'un',0);
FR_ATrials_2_80=cellfun(@(x) x(11:50,:),FR_ATrials_2,'un',0);
FR_BTrials_2_80=cellfun(@(x) x(11:50,:),FR_BTrials_2,'un',0);
FR_ATrials_3_80=cellfun(@(x) x(1:40,:),FR_ATrials_3,'un',0);
FR_BTrials_3_80=cellfun(@(x) x(1:40,:),FR_BTrials_3,'un',0);
for iNeu = 1 : 750
    [Selectivity_1(iNeu,:),p_1(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_1_80{iNeu,1},FR_BTrials_1_80{iNeu,1});
    [Selectivity_2(iNeu,:),p_2(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_2_80{iNeu,1},FR_BTrials_2_80{iNeu,1});
    [Selectivity_3(iNeu,:),p_3(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_3_80{iNeu,1},FR_BTrials_3_80{iNeu,1});
end
SelectIndex_1=zeros(750,40); SelectIndex_2=zeros(750,40); SelectIndex_3=zeros(750,40);
SelectIndex_1(find(Selectivity_1>0 & p_1<0.05))=1; % select sample A
SelectIndex_1(find(Selectivity_1<0 & p_1<0.05))=-1; % select sample B
SelectIndex_2(find(Selectivity_2>0 & p_2<0.05))=1; % select sample A
SelectIndex_2(find(Selectivity_2<0 & p_2<0.05))=-1; % select sample B
SelectIndex_3(find(Selectivity_3>0 & p_3<0.05))=1; % select sample A
SelectIndex_3(find(Selectivity_3<0 & p_3<0.05))=-1; % select sample B
SelectIndex_Off=SelectIndex_1;
SelectIndex_Early=SelectIndex_2;
SelectIndex_Late=SelectIndex_3;
Selectivity.Info='CLE-240trials-calculation';
Selectivity.title=[{'selectivity'} {'p_value'}];
Selectivity.Laseroff=[{Selectivity_1} {p_1}];
Selectivity.LaserEarly=[{Selectivity_2} {p_2}];
Selectivity.LaserLate=[{Selectivity_3} {p_3}];
SelectIndex_Off_1s=zeros(750,40); SelectIndex_E_1s=zeros(750,40); SelectIndex_L_1s=zeros(750,40);
SelectIndex_Off_1s(find( p_1<0.05/2))=1;
SelectIndex_E_1s(find( p_2<0.05/2))=1; 
SelectIndex_L_1s(find( p_3<0.05/2))=1;
Idx_DelaySel_Off=find(sum(SelectIndex_Off_1s(:,5:18),2)>0);% from odor start to delay end, selective units for each bin (500ms)
Idx_DelaySel_Early=find(sum(SelectIndex_E_1s(:,5:18),2)>0);
Idx_DelaySel_Late=find(sum(SelectIndex_L_1s(:,5:18),2)>0);

DateID = datestr(datetime, 'yyyymmdd');
save(['Selectivity' DateID],'Selectivity','Idx_DelaySel_Off','Idx_DelaySel_Early','Idx_DelaySel_Late','-v7.3')
figure
plot(sum(abs(SelectIndex_1(Learn_UnitIndex_CLE,:)),1)/471,'-k')
hold on
plot(sum(abs(SelectIndex_2(Learn_UnitIndex_CLE,:)),1)/471,'-r')
plot(sum(abs(SelectIndex_3(Learn_UnitIndex_CLE,:)),1)/471,'-b')
saveas(gcf, ['SelectiveUnit_Learn-500msBin'],'fig')
saveas(gcf, ['SelectiveUnit_Learn-500msBin'],'png')

Selec_idxs_1=sum(abs(SelectIndex_1(:,7:18)),2);
Selec_idxs_2=sum(abs(SelectIndex_2(:,7:18)),2);
Selec_idxs_3=sum(abs(SelectIndex_3 (:,7:18)),2);
SeleUnit_1_E=find(sum(abs(SelectIndex_1(:,7:10)),2)>0);
SeleUnit_2_E=find(sum(abs(SelectIndex_2(:,7:10)),2)>0);
SeleUnit_1_L=find(sum(abs(SelectIndex_1(:,15:18)),2)>0);
SeleUnit_3_L=find(sum(abs(SelectIndex_3(:,15:18)),2)>0);
idxs_E_Off=intersect(SeleUnit_1_E,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
idxs_E_E=intersect(SeleUnit_2_E,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
Overlap_OFF_E=intersect(idxs_E_E,idxs_E_Off);
idxs_L_Off=intersect(SeleUnit_1_L,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
idxs_L_L=intersect(SeleUnit_3_L,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
Overlap_OFF_L=intersect(idxs_L_L,idxs_L_Off);
figure
pie([47 165 30 18])


learn_EarlyLaserChanged_select_Off=intersect(SeleUnit_1,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
learn_EarlyLaserChanged_select_E=intersect(SeleUnit_2,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
Overlapped_Select_EOff=intersect(learn_EarlyLaserChanged_select_Off,learn_EarlyLaserChanged_select_E);
learn_LateLaserChanged_select_Off=intersect(SeleUnit_1,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
learn_LateLaserChanged_select_L=intersect(SeleUnit_3,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
Overlapped_Select_LOff=intersect(learn_LateLaserChanged_select_Off,learn_LateLaserChanged_select_L);
% clear('idx_overlap')
% idx_overlap=intersect(idx_E_Dec,idx_L_Inc);
% figure
% venn([length(idx_E_Dec) length(idx_L_Inc)],[length(idx_overlap)])
% title('165-26-243')
% saveas(gcf, ['Overlap_EarlyDec-LateInc-Units_Train_Early-Late'],'fig')
% saveas(gcf, ['Overlap_EarlyDec-LateInc-Units_Train_Early-Late'],'png')
%%
Index=intersect(idx_E_Changed,BS_Idxs);
CompareFRForSpecificTrialsCrossNeuron(NormAllTrialsFR_LaserOff(idx_E_Changed,:),NormAllTrialsFR_LaserOnEarlyDelay(idx_E_Changed,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[1 0 0]);
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Early_Train'],'fig')
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Early_Trian'],'png')

close all
clc
figure
pie([143 211 117])
title('143-211-117')
saveas(gcf, ['LaserchangedUnitDistribution_Late_Learn'],'fig')
saveas(gcf, ['LaserchangedUnitDistribution_Late_Learn'],'png')


Learn_Inc_EL_idxs=intersect(Learn_L_Inc_idxs,Learn_E_Inc_idxs);
Learn_Dec_EL_idxs=intersect(Learn_L_Dec_idxs,Learn_E_Dec_idxs);
figure
venn([42 52 65])
title('42-52-65')
saveas(gcf, ['LaserDeceasedUnitOverlapped_Learn'],'fig')
saveas(gcf, ['LaserDeceasedUnitOverlapped_Learn'],'png')

clear('SpecificIndex')
SpecificIndex=GetSortIndex(NormAllTrialsFR_LaserOnEarlyDelay(idx_E_Inc,1),NormAllTrialsFR_LaserOff(idx_E_Inc,1),TimeGain);
TargetNum=size(SpecificIndex,1);
tempIdxs_1=PlotHeatMap(NormAllTrialsFR_LaserOnEarlyDelay(idx_E_Inc,1),TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf, ['HeatMap_EarlyInceasedUnit_LaserOn_Train'],'fig')
saveas(gcf, ['HeatMap_EarlyInceasedUnit_LaserOn_Train'],'png')


%% difference between correct and error trials
Trials1 = cellfun(@(x,y) x(y(:,1)==0,:),AllTrials,AllLaserTrialsID,'un',0);% laser off
Trials2 = cellfun(@(x,y) x(y(:,1)==1,:),AllTrials,AllLaserTrialsID,'un',0);% laser on in early delay
Trials3 = cellfun(@(x,y) x(y(:,1)==2,:),AllTrials,AllLaserTrialsID,'un',0);% laser on in late delay

e_learn_fast_In_Idxs = intersect(Learn_UnitIndex_CLE,[E_FastConstantIncrease_Index; E_FastTransientIncrease_Index]);
e_learn_fast_De_Idxs = intersect(Learn_UnitIndex_CLE,[E_FastConstantDecrease_Index; E_FastTransientDecrease_Index]);
e_learn_slow_In_Idxs = intersect(Learn_UnitIndex_CLE,[E_SlowConstantIncrease_Index; E_SlowTransientIncrease_Index]);
e_learn_slow_De_Idxs = intersect(Learn_UnitIndex_CLE,[E_SlowConstantDecrease_Index; E_SlowTransientDecrease_Index]);

l_learn_fast_In_Idxs = intersect(Learn_UnitIndex_CLE,[L_FastConstantIncrease_Index; L_FastTransientIncrease_Index]);
l_learn_fast_De_Idxs = intersect(Learn_UnitIndex_CLE,[L_FastConstantDecrease_Index; L_FastTransientDecrease_Index]);
l_learn_slow_In_Idxs = intersect(Learn_UnitIndex_CLE,[L_SlowConstantIncrease_Index; L_SlowTransientIncrease_Index]);
l_learn_slow_De_Idxs = intersect(Learn_UnitIndex_CLE,[L_SlowConstantDecrease_Index; L_SlowTransientDecrease_Index]);


meanNormFR_off = cell2mat(cellfun(@(x) mean(x,1),NormAllTrialsFR_LaserOff,'un',0));
meanNormFR_early = cell2mat(cellfun(@(x) mean(x,1),NormAllTrialsFR_LaserOnEarlyDelay,'un',0));
meanNormFR_late = cell2mat(cellfun(@(x) mean(x,1),NormAllTrialsFR_LaserOnLateDelay,'un',0));
%%
BS_Idxs = find(UnitWaveproperty.Trough_to_Peak>=0.35);
NS_Idxs = find(UnitWaveproperty.Trough_to_Peak<0.35);
Learn_EarlyChange_BS_idx=intersect(BS_Idxs,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
Learn_EarlyChange_NS_idx=intersect(NS_Idxs,[Learn_E_Inc_idxs;Learn_E_Dec_idxs]);
Learn_EarlyInc_BS_idx=intersect(BS_Idxs,Learn_E_Inc_idxs);
Learn_EarlyInc_NS_idx=intersect(NS_Idxs,Learn_E_Inc_idxs);
Learn_EarlyDec_BS_idx=intersect(BS_Idxs,Learn_E_Dec_idxs);
Learn_EarlyDec_NS_idx=intersect(NS_Idxs,Learn_E_Dec_idxs);

Learn_LateChange_BS_idx=intersect(BS_Idxs,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
Learn_LateChange_NS_idx=intersect(NS_Idxs,[Learn_L_Inc_idxs;Learn_L_Dec_idxs]);
Learn_LateInc_BS_idx=intersect(BS_Idxs,Learn_L_Inc_idxs);
Learn_LateInc_NS_idx=intersect(NS_Idxs,Learn_L_Inc_idxs);
Learn_LateDec_BS_idx=intersect(BS_Idxs,Learn_L_Dec_idxs);
Learn_LateDec_NS_idx=intersect(NS_Idxs,Learn_L_Dec_idxs);
hist(UnitWaveproperty.Trough_to_Peak(Learn_UnitIndex_CLE,1),50)

figure
plot(UnitWaveproperty.Trough_to_Peak(Learn_EarlyInc_BS_idx,1),AveragedFR(Learn_EarlyInc_BS_idx,1),'LineStyle','none','Marker','o','Color','magenta','MarkerSize',3)
hold on
plot(UnitWaveproperty.Trough_to_Peak(Learn_EarlyInc_NS_idx,1),AveragedFR(Learn_EarlyInc_NS_idx,1),'LineStyle','none','Marker','square','Color','magenta','MarkerSize',4)
plot(UnitWaveproperty.Trough_to_Peak(Learn_EarlyDec_BS_idx,1),AveragedFR(Learn_EarlyDec_BS_idx,1),'LineStyle','none','Marker','o','Color','cyan','MarkerSize',3)
plot(UnitWaveproperty.Trough_to_Peak(Learn_EarlyDec_NS_idx,1),AveragedFR(Learn_EarlyDec_NS_idx,1),'LineStyle','none','Marker','square','Color','cyan','MarkerSize',4)
xlabel('T-to-P (us)');% Create xlabel
ylabel('FR ( Hz )');% Create Xlabel
legend('BS-Inc','NS-Inc','BS-Dec','NS-Dec')
box off
saveas(gcf, ['Distribution-BS-NS-EarlyLaserChaangedUnits'],'fig')
saveas(gcf, ['Distribution-BS-NS-EarlyLaserChaangedUnits'],'png')

figure
plot(UnitWaveproperty.Trough_to_Peak(Learn_LateInc_BS_idx,1),AveragedFR(Learn_LateInc_BS_idx,1),'LineStyle','none','Marker','o','Color','magenta','MarkerSize',3)
hold on
plot(UnitWaveproperty.Trough_to_Peak(Learn_LateInc_NS_idx,1),AveragedFR(Learn_LateInc_NS_idx,1),'LineStyle','none','Marker','square','Color','magenta','MarkerSize',4)
plot(UnitWaveproperty.Trough_to_Peak(Learn_LateDec_BS_idx,1),AveragedFR(Learn_LateDec_BS_idx,1),'LineStyle','none','Marker','o','Color','cyan','MarkerSize',3)
plot(UnitWaveproperty.Trough_to_Peak(Learn_LateDec_NS_idx,1),AveragedFR(Learn_LateDec_NS_idx,1),'LineStyle','none','Marker','square','Color','cyan','MarkerSize',4)
xlabel('T-to-P (us)');% Create xlabel
ylabel('FR ( Hz )');% Create Xlabel
legend('BS-Inc','NS-Inc','BS-Dec','NS-Dec')
box off
saveas(gcf, ['Distribution-BS-NS-LateLaserChaangedUnits'],'fig')
saveas(gcf, ['Distribution-BS-NS-LateLaserChaangedUnits'],'png')

%% delay modulation units
% 1s base
FR_AllTrials_1=ReDefineBinSize(LaserOffAllTrialsFR,1000,100);% laser off
FR_AllTrials_2=ReDefineBinSize(LaserOnAllTrialsFR_EarlyDelay,1000,100);%laser on early delay
FR_AllTrials_3=ReDefineBinSize(LaserOnAllTrialsFR_LateDelay,1000,100);%laser on late delay
for iBin = 1: 20
    Modulation_1(:,iBin) = cellfun(@(x) ranksum(x(:,2),x(:,iBin)),FR_AllTrials_1);
    Modulation_2(:,iBin) = cellfun(@(x) ranksum(x(:,2),x(:,iBin)),FR_AllTrials_2);
    Modulation_3(:,iBin) = cellfun(@(x) ranksum(x(:,2),x(:,iBin)),FR_AllTrials_3); 
end
[ModulationIndex_1,ModulationIndex_2,ModulationIndex_3]=deal(zeros(750,20));
ModulationIndex_1=Modulation_1<0.05;
ModulationIndex_2=Modulation_2<0.05;
ModulationIndex_3=Modulation_3<0.05;

FR_ATrials_1=ReDefineBinSize(LaserOffAllATrialsFR,1000,100);% laser off
FR_ATrials_2=ReDefineBinSize(LaserOnAllATrialsFR_EarlyDelay,1000,100);%laser on early delay
FR_ATrials_3=ReDefineBinSize(LaserOnAllATrialsFR_LateDelay,1000,100);%laser on late delay

FR_BTrials_1=ReDefineBinSize(LaserOffAllBTrialsFR,1000,100);% laser off
FR_BTrials_2=ReDefineBinSize(LaserOnAllBTrialsFR_EarlyDelay,1000,100);%laser on early delay
FR_BTrials_3=ReDefineBinSize(LaserOnAllBTrialsFR_LateDelay,1000,100);%laser on late delay

FR_ATrials_1_80=cellfun(@(x) x(1:40,:),FR_ATrials_1,'un',0);
FR_BTrials_1_80=cellfun(@(x) x(1:40,:),FR_BTrials_1,'un',0);
FR_ATrials_2_80=cellfun(@(x) x(11:50,:),FR_ATrials_2,'un',0);
FR_BTrials_2_80=cellfun(@(x) x(11:50,:),FR_BTrials_2,'un',0);
FR_ATrials_3_80=cellfun(@(x) x(1:40,:),FR_ATrials_3,'un',0);
FR_BTrials_3_80=cellfun(@(x) x(1:40,:),FR_BTrials_3,'un',0);
for iNeu = 1 : 750
    [Selectivity_1(iNeu,:),pS_1(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_1_80{iNeu,1},FR_BTrials_1_80{iNeu,1});
    [Selectivity_2(iNeu,:),pS_2(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_2_80{iNeu,1},FR_BTrials_2_80{iNeu,1});
    [Selectivity_3(iNeu,:),pS_3(iNeu,:)]=CalculateSelectivityWithPermTest(FR_ATrials_3_80{iNeu,1},FR_BTrials_3_80{iNeu,1});
end
[idx_pS_1,idx_pS_2,idx_pS_3]=deal(zeros(750,20));
idx_pS_1=pS_1<0.05;idx_pS_2=pS_2<0.05;idx_pS_3=pS_3<0.05;
Num_Selec=sum(idx_pS_3,1);
Num_Modul=sum(ModulationIndex_3,1);
diff_Num=Num_Modul-Num_Selec;diff_Num(diff_Num<0)=0;
figure
bar([Num_Selec;Num_Modul]'/750,'stacked')
hold on 
plot([0 20],[0.05 0.05],'--k')
saveas(gcf, ['Proportion_ActiveUnits_Train_Late'],'fig')
saveas(gcf, ['Proportion_ActiveUnits_Train_Late'],'png')
%% plot selectivity for laser on and off trials
DataID = datestr(datetime, 'yyyymmdd');
for i = 1:6
    clear('idx1','idx2','idx3','idx4','idx_off_only','idx_on_only','temp1','temp2','temp3','temp4')
    idx1 = find(pS_1(:,i+3)<0.05);% laser off trials
    idx2 = find(pS_2(:,i+3)<0.05);% laser on trials
    idx3 = intersect(idx1,idx2);% overlapped select
    idx4 = setdiff([1:1:750]',[idx1;idx2]);% overlapped non-select
    idx_off_only=setdiff(idx1,idx3);
    idx_on_only=setdiff(idx2,idx3);
   %%
   figure
    scatter(Selectivity_1(intersect(idx_E_Changed,idx4),3+i),Selectivity_2(intersect(idx_E_Changed,idx4),3+i),'MarkerEdgeColor',[0.7 0.7 0.7],'Marker','.')
    hold on
    scatter(Selectivity_1(intersect(idx_E_Changed,idx_off_only),3+i),Selectivity_2(intersect(idx_E_Changed,idx_off_only),3+i),'MarkerEdgeColor',[0 0 0],'Marker','.')
    scatter(Selectivity_1(intersect(idx_E_Changed,idx_on_only),3+i),Selectivity_2(intersect(idx_E_Changed,idx_on_only),3+i),'MarkerEdgeColor',[1 0 0],'Marker','.')
    scatter(Selectivity_1(intersect(idx_E_Changed,idx3),3+i),Selectivity_2(intersect(idx_E_Changed,idx3),3+i),'MarkerEdgeColor',[1 0.43 0.71],'Marker','.')
%     scatter(Selectivity_1(intersect(idx_L_Changed,idx3),3+i),Selectivity_3(intersect(idx_L_Changed,idx3),3+i),'MarkerEdgeColor',[0 1 1],'Marker','.')
    
    plot([0 -1;0 1]*1,[-1 0;1 0]*1,'LineStyle','-','Color',[0 0 0])
    plot([-1 1]*1,[-1 1]*1,'LineStyle','--','Color',[0.5 0.5 0.5])
    title(['Off-' num2str(length(intersect(idx_E_Changed,idx_off_only))) '&On-' num2str(length(intersect(idx_E_Changed,idx_on_only))) '&both-' num2str(length(intersect(idx_E_Changed,idx3)))])
    box off
%     set(gca,'Xlim',[0,50],'XTickLabel',{'0','10','20','30','40'},'XTick',[0,10,20,30 40],'Ylim',[0,50],'YTickLabel',{'0','10','20','30','40'},'YTick',[0,10,20,30 40])
    xlabel('Selectivity-LaserOff');% Create xlabel
    ylabel('Selectivity-LaserOn');% Create Xlabel
    saveas(gcf, ['Selectivity-EarlyChangedUnit-Delay-' num2str(i) '-' DataID],'fig')
    saveas(gcf, ['Selectivity-EarlyChangedUnit-Delay-' num2str(i) '-' DataID],'png')  
   %%
   figure
    venn([length(intersect(idx_E_Changed,idx1)) length(intersect(idx_E_Changed,idx1))],[length(intersect(idx_E_Changed,idx3))])
    saveas(gcf, ['Distribution-SelectiveUnits-Early-Delay-' num2str(i) '-' DataID],'fig')
    saveas(gcf, ['Distribution-SelectiveUnits-Early-Delay-' num2str(i) '-' DataID],'png')  
    
    %%
    temp1=intersect(idx_E_Changed,idx4);% non-selective index
    temp2=intersect(idx_E_Changed,idx_off_only); % selective index for laser off -only
    temp3=intersect(idx_E_Changed,idx_on_only); % selective index for laser on -only
    temp4=intersect(idx_E_Changed,idx3); % selective for both;
    figure
    pie([length(temp2) length(temp1) length(temp3) length(temp4)])
    saveas(gcf, ['Proportion-SelectiveUnits-Early-Delay-' num2str(i) '-' DataID],'fig')
    saveas(gcf, ['Proportion-SelectiveUnits-Early-Delay-' num2str(i) '-' DataID],'png')  
end

Sel_EarlyDelay_Off = mean(Selectivity_1(:,4:5),2);
Sel_EarlyDelay_E = mean(Selectivity_2(:,4:5),2);
Sel_LateDelay_Off = mean(Selectivity_1(:,8:9),2);
Sel_LateDelay_L = mean(Selectivity_2(:,8:9),2);
idx_pS_1=pS_1<0.05;idx_pS_2=pS_2<0.05;idx_pS_3=pS_3<0.05;
idx_Sel_EarlyDelay_Off = find(sum(idx_pS_1(:,4:5),2)>0);
idx_Sel_EarlyDelay_E = find(sum(idx_pS_2(:,4:5),2)>0);
idx_Sel_LateDelay_Off = find(sum(idx_pS_1(:,8:9),2)>0);
idx_Sel_LateDelay_L = find(sum(idx_pS_3(:,8:9),2)>0);
figure
hist(Sel_EarlyDelay_Off(intersect(idx_E_Changed,idx_Sel_EarlyDelay_Off)),40);
hold on
find(Sel_EarlyDelay_Off(intersect(idx_E_Changed,idx_Sel_EarlyDelay_Off))<0);
plot(mean(Sel_EarlyDelay_Off()))
figure
hist(Sel_EarlyDelay_E(intersect(idx_E_Changed,idx_Sel_EarlyDelay_E)),40)

figure
hist(Sel_LateDelay_Off(intersect(idx_L_Changed,idx_Sel_LateDelay_Off)),40);
figure
hist(Sel_LateDelay_L(intersect(idx_L_Changed,idx_Sel_LateDelay_L)),40);
