function [SelectivityForSampleData,SelectivityForShuffledData]=PlotSelectivityCurveCrossUnits(Type1FR,Type2FR,Shuffled1FR,Shuffled2FR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,BinNum)

    tempType1FR = cellfun(@mean,Type1FR,'UniformOutput',false);tempType2FR = cellfun(@mean,Type2FR,'UniformOutput',false);
    tempType1FR = 10*cell2mat(tempType1FR);tempType2FR =10* cell2mat(tempType2FR);
    SelectivityForSampleData=abs((tempType1FR-tempType2FR))./(tempType1FR+tempType2FR);
    SelectivityForSampleData(isnan(SelectivityForSampleData))=0;

    tempShuffled1FR = cellfun(@mean,Shuffled1FR,'UniformOutput',false);tempShuffled2FR = cellfun(@mean,Shuffled2FR,'UniformOutput',false);
    tempShuffled1FR = 10*cell2mat(tempShuffled1FR);tempShuffled2FR =10* cell2mat(tempShuffled2FR);
    SelectivityForShuffledData = abs((tempShuffled1FR-tempShuffled2FR))./(tempShuffled1FR+tempShuffled2FR);
    SelectivityForShuffledData(isnan(SelectivityForShuffledData))=0;

    %% statistic  for p-value using permutation test

   
    p=nan(1,BinNum);larger=nan(1,BinNum);
    for itr = 1:BinNum
%         [p(1,itr),larger(1,itr)]=permTest(SelectivityForSampleData(:,itr),SelectivityForShuffledData(:,itr));
        p(1,itr)=ranksum(SelectivityForSampleData(:,itr),SelectivityForShuffledData(:,itr));
    end

    %% plot figure

    % Max=max([mean(SelectivityData,1) mean(ShuffledData,1)])*1.5;
    UnitNum1=size(Type1FR,1);
    UnitNum2=size(Shuffled1FR,1);
    Max=0.3;
    figure ('color',[1 1 1])
    colormap(jet);
    % subplot(2,1,1)
    DPALen=FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen+10;% ITI=10s
    X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
    plot(X,smooth(mean(SelectivityForSampleData,1),5,'moving'),'r','LineWidth',1.5)
    hold on
    plot(X,smooth(mean(SelectivityForShuffledData,1),5,'moving'),'k','LineWidth',1.5)
    Legend=legend('Target','Shuffled');
    set(Legend,'EdgeColor',[1 1 1]);

    dim = [.4 .5 .3 .3];
    str = ['UnitNum=' num2str(UnitNum1) '/' num2str(UnitNum2)];
    annotation('textbox',dim,'String',str,'FitBoxToText','on');
    % h1=area([0 FirstOdorLen],Max*[1 1]);set(get(h1,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
    % hold on
    % h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],Max*[1 1]);set(get(h2,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
    % h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],Max*[1 1]);set(get(h3,'Child'),'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water

    h1=area([0 FirstOdorLen],Max*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
    hold on
    h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],Max*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
    h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],Max*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
    box off
    xlabel('Time (Sec)');% Create xlabel
    ylabel('Selectivity');% Create ylabel
    % errorbar(X,mean(SelectivityData,1),std(SelectivityData,0,1)/sqrt(size(SelectivityData,1)-1),'r','LineWidth',0.5)
    % hold on
    % errorbar(X,mean(ShuffledData,1),std(ShuffledData,0,1)/sqrt(size(ShuffledData,1)-1),'k','LineWidth',0.5)
    tempx1=smooth(mean(SelectivityForSampleData,1)-std(SelectivityForSampleData,0,1)/sqrt(UnitNum1-1),5,'moving')';
    tempx2=smooth(mean(SelectivityForSampleData,1)+std(SelectivityForSampleData,0,1)/sqrt(UnitNum1-1),5,'moving')';
    % fill([X,fliplr(X)],[tempx1',fliplr(tempx2')],...
    %     [1 0 0],'edgecolor','none','FaceAlpha',0.3)
    fill([X,fliplr(X)],[tempx1,fliplr(tempx2)],...
        [1 0 0],'edgecolor','none','facealpha',0.3)
    tempy1=smooth(mean(SelectivityForShuffledData,1)-std(SelectivityForShuffledData,0,1)/sqrt(UnitNum2-1),5,'moving')';
    tempy2=smooth(mean(SelectivityForShuffledData,1)+std(SelectivityForShuffledData,0,1)/sqrt(UnitNum2-1),5,'moving')';
    fill([X,fliplr(X)],[tempy1,fliplr(tempy2)],...
        [0 0 0],'edgecolor','none','facealpha',0.3)

    for i = 1:BinNum
        if (p(i)< 0.05/60)
            plot(-2+0.1*i,0.25,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','.','LineStyle','none');
            hold on
        end
    end

    set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-1,11])

end
