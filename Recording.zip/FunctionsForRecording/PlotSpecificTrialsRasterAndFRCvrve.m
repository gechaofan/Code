function PlotSpecificTrialsRasterAndFRCvrve(TrialIndex,SpikesTimestamp,SpikeCounts,FirstOdorStart,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,Color);
TempTrialIndex=TrialIndex;
figure('color',[1 1 1])
colormap(jet);
% YMin=TimeGain*floor(mean(SpikeCounts(:))-2*std(mean(SpikeCounts,1),0,2));
% YMax=TimeGain*ceil(mean(SpikeCounts(:))+2*std(mean(SpikeCounts,1),0,2));
% subplot(2,1,1)
h1=area([0 FirstOdorLen],length(TempTrialIndex)*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(TempTrialIndex)*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(TempTrialIndex)*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water

% h1=area([0 FirstOdorLen],length(TempTrialIndex)*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor1
% hold on
% h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(TempTrialIndex)*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor2
% h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(TempTrialIndex)*[1 1]);set(h3,'FaceColor',[1 0.8 0],'LineStyle','none')% plot areas of color %water
box off
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[20,70,120,170],'Xlim',[-2,floor(DPALen)-2])
xlabel('Time (Sec)');% Create xlabel
ylabel('TrialNum');% Create ylabel

for itr5=1:length(TempTrialIndex)
    %%%% plot spike raster  %%%%%%%%
    temp=SpikesTimestamp{itr5,1}-FirstOdorStart(itr5,1);
    plot([temp'; temp'],[(itr5)*ones(1,length(temp))-0.5;(itr5)*ones(1,length(temp))+0.5],'color',Color,'LineWidth',0.5)
    hold on
    %     if tempresult==1
    %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 0 0])
    %     elseif tempresult==2
    %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 1 0])
    %     elseif tempresult==3
    %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[1 0 0])
    %     elseif tempresult==4
    %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 0 1])
    %     end
end
% subplot(2,1,2)
% % YMin1=floor(min(TimeGain*mean(SpikeCounts,1)))-5;
% YMin1=0;
% YMax1=ceil(max(TimeGain*mean(SpikeCounts,1)))+5;
% % h1=area([0 FirstOdorLen],length(TempTrialIndex)*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor1
% % hold on
% % h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(TempTrialIndex)*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor2
% % h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(TempTrialIndex)*[1 1]);set(h3,'FaceColor',[1 0.8 0],'LineStyle','none')% plot areas of color %water
% h1=area([0 FirstOdorLen],YMax1*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
% hold on
% h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],YMax1*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
% h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],YMax1*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',1,'LineStyle','none')% plot areas of color %water
% box off
% xlabel('Time (Sec)');% Create xlabel
% ylabel('Firing Rate');% Create ylabel
% X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
% 
% fill([X,fliplr(X)],[smooth(mean(SpikeCounts,1)*TimeGain-std(TimeGain*SpikeCounts,0,1)/sqrt(size(SpikeCounts,1)-1),5,'moving')',smooth(fliplr(mean(SpikeCounts,1)*TimeGain+std(TimeGain*SpikeCounts,0,1)/sqrt(size(SpikeCounts,1)-1)),5,'moving')'],...
%     Color,'edgecolor','none','FaceAlpha',0.5)
% hold on
% 
% plot(X,smooth(TimeGain*mean(SpikeCounts,1),5,'moving')','color',Color,'LineWidth',1.5)
% 
% set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2],'YLim',[YMin1,YMax1])
