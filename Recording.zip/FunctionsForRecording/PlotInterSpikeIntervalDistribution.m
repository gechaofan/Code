function PlotInterSpikeIntervalDistribution(UnitSpikeTimeStamp)

SpikeNum=length(UnitSpikeTimeStamp);
figure ('color',[1 1 1])
colormap(jet);
ISI=diff(UnitSpikeTimeStamp)*1000;% �������ڵ�ISI
xbins=0:100;
[counts, centers] = hist(ISI,xbins);
h = histogram(ISI,xbins);
h.FaceColor = [0 0 0];
h.EdgeColor = 'w';

text(50,mean(counts),['SpikeNum=' num2str(SpikeNum)],'fontsize',12);
box off
xlabel('Time(ms)','fontsize',12)
ylabel('SpikeCounts','fontsize',12)
set(gca,'fontsize',10,'tickdir','out')







