function PlotPopulationUnitsAverageFRofSpecificTrials(Type1FR,Type2FR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
tempType1FR=cellfun(@mean,Type1FR,'UniformOutput',false);% all trials Averge FR
Type1AvergeFR=cell2mat(tempType1FR)*TimeGain;% all units AveragedFR

tempType2FR=cellfun(@mean,Type2FR,'UniformOutput',false);% all trials Averge FR
Type2AvergeFR=cell2mat(tempType2FR)*TimeGain;
YMAX=max([mean(Type1AvergeFR,1) mean(Type2AvergeFR,1)])*1.5;

figure ('color',[1 1 1])
DPALen=FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen+10;% ITI=10s
X=[-2:0.1:floor(DPALen)-2];

h1=area([0 FirstOdorLen],YMAX*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],YMAX*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],YMAX*[1 1]);set(h3,'FaceColor',[1 0.8 0],'LineStyle','none')% plot areas of color %water
box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Average FR (Hz)');% Create ylabel

tempx1=smooth(mean(Type1AvergeFR,1)-std(Type1AvergeFR,0,1)/sqrt(size(Type1AvergeFR,1)-1),10);
tempx2=smooth(mean(Type1AvergeFR,1)+std(Type1AvergeFR,0,1)/sqrt(size(Type1AvergeFR,1)-1),10);
fill([X,fliplr(X)],[tempx1',fliplr(tempx2')],...
    [0 0 0],'edgecolor','none','FaceAlpha',0.3)
hold on
if ~isempty(Type2AvergeFR)
    
    tempy1=smooth(mean(Type2AvergeFR,1)-std(Type2AvergeFR,0,1)/sqrt(size(Type2AvergeFR,1)-1),10);
    tempy2=smooth(mean(Type2AvergeFR,1)+std(Type2AvergeFR,0,1)/sqrt(size(Type2AvergeFR,1)-1),10);
        fill([X,fliplr(X)],[tempy1',fliplr(tempy2')],...
            [0 0 1],'edgecolor','none','FaceAlpha',0.3)
   p1= plot(X,smooth(mean(Type1AvergeFR,1),10),'k','LineWidth',1.5);
   p2= plot(X,smooth(mean(Type2AvergeFR,1),10),'b','LineWidth',1.5);
   legend1=legend([p1 p2],'Type1','Type2');
   set(legend1,'EdgeColor',[1 1 1]);
    p=[];
    for itr=1:size(Type1AvergeFR,2)
        p(1,itr)=signrank(Type1AvergeFR(:,itr),Type2AvergeFR(:,itr));
        if p(1,itr)<0.005
            plot(-2.1+itr/10,YMAX,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','.','LineStyle','none');
            hold on
        end
    end
else
%     p3=plot(X,smooth(mean(Type1AvergeFR,1),10),'k','LineWidth',1.5,'DisplayName','Type')
    hold off
%     Legend=legend('','','','','Type1');
% legend({'','','','Type1'})
% legend2=legend(p3,'Type1');
% set(legend2,'EdgeColor',[1 1 1]);
end
% set(Legend,'EdgeColor',[1 1 1],'YColor',[1 1 1],'XColor',[1 1 1]);
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2])



