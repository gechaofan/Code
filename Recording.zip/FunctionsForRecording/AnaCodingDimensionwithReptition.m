function [nP1, nP2] = AnaCodingDimensionwithReptition(BinFRA, BinFRB, win...
    , bin, PreLen, Cellid, winStart2End, tag)
% win = 0.5; % in second
winFRA = cellfun(@(x) BinY(x',win/bin),BinFRA,'Uni',false);
winFRB = cellfun(@(x) BinY(x',win/bin),BinFRB,'Uni',false);
% winStart2End = PreLen/win+1:(PreLen+1+13)/win;
reptime = 100;
[proj1, proj2] = arrayfun(@(x) Codingdimension(winFRA,winFRB,Cellid,winStart2End)...
    ,1:reptime,'Uni',false);
P1 = cell2mat(proj1);
P2 = cell2mat(proj2);
% nP1 = cell2mat(arrayfun(@(x) (P1(x,:)-mean(P1,1))',1:size(P1,1),'Uni',false));
% nP2 = cell2mat(arrayfun(@(x) (P2(x,:)-mean(P2,1))',1:size(P2,1),'Uni',false));
nP1 = cell2mat(arrayfun(@(x) (P1(x,:)-mean(P1(1:PreLen/win,:),1))',1:size(P1,1),'Uni',false));
nP2 = cell2mat(arrayfun(@(x) (P2(x,:)-mean(P2(1:PreLen/win,:),1))',1:size(P2,1),'Uni',false));
fn = ['Coding dimension ' tag ' window size ' num2str(win) 's repeat '...
     num2str(reptime) ' times'];
h=figure('Name',fn); 
errorbar(mean(nP1,1),std(nP1,[],1)/sqrt(reptime),'b','LineWidth',1)
hold on
errorbar(mean(nP2,1),std(nP2,[],1)/sqrt(reptime),'r','LineWidth',1)
box off
ylabel(gca, ['CD projection (au)'],'FontSize',10,'FontName','Helvetica');
xlim([0.5,40.5])
% set(gca,'XTick',[2.5:4:38.5],'XTickLabel',{'0'; '2'; '4'; '6'; '8'...
%     ; '10'; '12'; '14'; '16'; '18'})
saveas(h,[fn '.fig']);
close(h);
clear h; 