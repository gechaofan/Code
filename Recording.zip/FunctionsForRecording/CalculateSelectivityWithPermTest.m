function [selectivity,stat]=CalculateSelectivityWithPermTest(FR1,FR2)

selectivity=(mean(FR1,1)-mean(FR2,1))./(mean(FR1,1)+mean(FR2,1));
stat=NaN*ones(1,size(FR1,2));
for i = 1 : size(FR1,2)
    [stat(1,i),~]=permTest(FR1(:,i),FR2(:,i));
    
end

end