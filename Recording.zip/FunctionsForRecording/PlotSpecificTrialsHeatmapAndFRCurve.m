function PlotSpecificTrialsHeatmapAndFRCurve(TempTrialIndex,SpikeCounts,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain)

figure('color',[1 1 1])
% YMin=TimeGain*floor(mean(SpikeCounts(:))-2*std(mean(SpikeCounts,1),0,2));
% YMax=TimeGain*ceil(mean(SpikeCounts(:))+2*std(mean(SpikeCounts,1),0,2));
subplot(2,1,1)
colormap(jet);
% h1=area([0 FirstOdorLen],length(TempTrialIndex)*[1 1]);set(get(h1,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
% hold on
% h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(TempTrialIndex)*[1 1]);set(get(h2,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
% h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(TempTrialIndex)*[1 1]);set(get(h3,'Child'),'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
% box off
imagesc(TimeGain*SpikeCounts)
colorbar
hold on
plot(TimeGain*[2 2],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen 2+FirstOdorLen],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay 2+FirstOdorLen+Delay],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen],[-0.5 length(TempTrialIndex)+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[20,70,120,170])
xlabel('Time (Sec)');% Create xlabel
ylabel('TrialNum');% Create ylabel

% for itr5=1:length(TempTrialIndex)
%     %%%% plot licking raster  %%%%%%%%
%     temp=SpikesTimestamp{itr5,1}-FirstOdorStart(itr5,1);
%     plot([temp'; temp'],[(itr5)*ones(1,length(temp))-0.5;(itr5)*ones(1,length(temp))+0.5],'color',[0.5 0.5 0.5])
%     hold on
%     %     if tempresult==1
%     %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 0 0])
%     %     elseif tempresult==2
%     %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 1 0])
%     %     elseif tempresult==3
%     %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[1 0 0])
%     %     elseif tempresult==4
%     %         plot(17.5,itr5,'MarkerSize',14,'Marker','.','LineStyle','none','Color',[0 0 1])
%     %     end
% end
subplot(2,1,2)
h1=area([0 FirstOdorLen],length(TempTrialIndex)*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on                                               
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],length(TempTrialIndex)*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],length(TempTrialIndex)*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',1,'LineStyle','none')% plot areas of color %water
box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Firing Rate');% Create ylabel
X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
fill([X,fliplr(X)],[mean(SpikeCounts,1)*TimeGain-std(TimeGain*SpikeCounts,0,1)/sqrt(size(SpikeCounts,1)-1),fliplr(mean(SpikeCounts,1)*TimeGain+std(TimeGain*SpikeCounts,0,1)/sqrt(size(SpikeCounts,1)-1))],...
    'k','edgecolor','none','FaceAlpha',0.5)
hold on
plot(X,TimeGain*mean(SpikeCounts,1),'k','LineWidth',1.5)
YMin1=floor(min(TimeGain*mean(SpikeCounts,1)))-5;
YMax1=ceil(max(TimeGain*mean(SpikeCounts,1)))+5;
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2],'YLim',[YMin1,YMax1])
