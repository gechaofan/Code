% This code is for getting task information form Plexon Recording Data
function [Laser,Lick,Odor1,Odor2,TrialsPLexon,SplitLickTimestamp,SplitLickCounts]=GetTaskInformationFromPlexon(TaskEvent,FirstOdorLen,Delay,SecondOdorLen,...
    Response,WaterLen,DPALen,TrainingType,TaskType,TimeGain)

switch TrainingType
    case 2  % GXW code
        Laser=TaskEvent.Laser.Ts;
        Lick=TaskEvent.Lick.Ts;% raw licks
        DiffLickIndex=find(diff(Lick)<0.01);
        Lick(DiffLickIndex+1)=[];
        DiffADIndex=find(diff(TaskEvent.OdorAB.Ts)<0.1);
        TaskEvent.OdorAB.Ts(DiffADIndex+1)=[];
        DiffBCIndex=find(diff(TaskEvent.OdorCD.Ts)<0.1);
        TaskEvent.OdorCD.Ts(DiffBCIndex+1)=[];
        ResetSignal=intersect(TaskEvent.OdorAB.Ts,TaskEvent.OdorCD.Ts);% find the same timestamp
        if ~isempty(ResetSignal)
            for itr = 1: length(ResetSignal)
                RestIndex1(itr,1)=find(TaskEvent.OdorAB.Ts==ResetSignal(itr));
                RestIndex2(itr,1)=find(TaskEvent.OdorCD.Ts==ResetSignal(itr));
            end
            TaskEvent.OdorAB.Ts(RestIndex1)=[];
            TaskEvent.OdorCD.Ts(RestIndex2)=[];
        end
        OdorADStart = [TaskEvent.OdorAB.Ts-FirstOdorLen ones(length(TaskEvent.OdorAB.Ts),1)];
        OdorBCStart = [TaskEvent.OdorCD.Ts-SecondOdorLen 2*ones(length(TaskEvent.OdorCD.Ts),1)];
        Odors=sortrows([OdorADStart;OdorBCStart],1);
        Odor1=Odors(1:2:end,:);% OdorA=1
        Odor2=Odors(2:2:end,:);% OdorB=2
        Odor2(Odor2(:,2)==2,2)=3;% OdorC=3
        Odor2(Odor2(:,2)==1,2)=4;% OdorD=4
    case 3  % CQ code
        %% get trial information and Lick
        OdorACStart=[OdorAC(1:2:end) ones(length(OdorAC(1:2:end,:)),1)];
        OdorBDStart=[OdorBD(1:2:end) 2*ones(length(OdorBD(1:2:end)),1)];
        Odors=sortrows([OdorACStart;OdorBDStart],1);
        Odor1=Odors(1:2:end,:);% OdorA=1
        Odor2=Odors(2:2:end,:);% OdorB=2
        Odor2(Odor2(:,2)==1,2)=3;% OdorC=3
        Odor2(Odor2(:,2)==2,2)=4;% OdorD=4
        SplitLickTimestamp={};%% filtered lick
        SplitLickCounts=[]; %% filtered lick
        DiffLick=diff(Lick);
        LickIndex=find(DiffLick<0.02)+1;
        Lick(LickIndex)=[];%LickFilterCriterion=20ms
    otherwise  % default
        disp('Error in Odor Construction')
end


TrialNumPlexon=min(size(Odor1,1),size(Odor2,1));
TrialsPLexon=zeros(TrialNumPlexon,5);
TrialsPLexon(:,1)=TaskType;
TrialsPLexon(:,2)=Odor1(:,2);
TrialsPLexon(:,3)=Odor2(:,2);
% mark trial results and trial type


for itr0=1:TrialNumPlexon
    tempLick=[];
    tempLick=Lick(find(Lick>Odor1(itr0,1)+floor((FirstOdorLen+Delay+SecondOdorLen+Response))-0.05&Lick<Odor1(itr0,1)+(FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)+0.05));
    SplitLickTimestamp{itr0,1}=Lick(Lick>Odor1(itr0,1)-2&Lick<Odor1(itr0,1)+DPALen-2);
    for itr1=1:floor(DPALen*TimeGain)% binsize=100ms
        SplitLickCounts(itr0,itr1)=length(Lick(Lick>Odor1(itr0,1)-2+0.1*(itr1-1)&Lick<Odor1(itr0,1)-2+0.1*itr1));
    end
    if Odor1(itr0,2)==1&&Odor2(itr0,2)==3
        TrialsPLexon(itr0,5)=1;
        if ~isempty(tempLick)
            TrialsPLexon(itr0,4)=1;
        else
            TrialsPLexon(itr0,4)=2;
        end
    elseif Odor1(itr0,2)==2&&Odor2(itr0,2)==4
        TrialsPLexon(itr0,5)=2;
        if ~isempty(tempLick)
            TrialsPLexon(itr0,4)=1;
        else
            TrialsPLexon(itr0,4)=2;
        end
    elseif Odor1(itr0,2)==1&&Odor2(itr0,2)==4
        TrialsPLexon(itr0,5)=3;
        if ~isempty(tempLick)
            TrialsPLexon(itr0,4)=3;
        else
            TrialsPLexon(itr0,4)=4;
        end
    elseif Odor1(itr0,2)==2&&Odor2(itr0,2)==3
        TrialsPLexon(itr0,5)=4;
        if ~isempty(tempLick)
            TrialsPLexon(itr0,4)=3;
        else
            TrialsPLexon(itr0,4)=4;
        end
    end
end