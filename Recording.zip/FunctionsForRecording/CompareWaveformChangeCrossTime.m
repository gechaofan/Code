function CompareWaveformChangeCrossTime(UnitsWaveform,SampleNum)

tempSpikeNum=size(UnitsWaveform,1);
tempFirstQuarterWaveform=UnitsWaveform(1:round(tempSpikeNum/4),:);
tempLastQuarterWaveform=UnitsWaveform(end-round(tempSpikeNum/4):end,:);
figure('color',[1 1 1])
colormap(jet);
for itr = 1:4% for tetrode
    X=[(itr-1)*(SampleNum+2)+1:1:(itr-1)*(SampleNum+2)+SampleNum];
    Y1=mean(UnitsWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),1)-std(UnitsWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),0,1);
    Y2=fliplr(mean(UnitsWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),1)+std(UnitsWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),0,1));
    
    fill([X,fliplr(X)],[Y1,Y2],'k','LineStyle','none','facecolor',[0.8,0.8,0.8])
    hold on
    plot(X,mean(tempFirstQuarterWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),1),'b','LineWidth',2)
    plot(X,mean(tempLastQuarterWaveform(:,(itr-1)*SampleNum+1:itr*SampleNum),1),'r','LineWidth',2)
end

set(gca,'XTickLabel',{'0','2','4','6'},'XTick',[0,80,160,240])
xlabel('Time (ms)');% Create xlabel
ylabel('Voltage (��V)');% Create ylabel
box off
Legend = legend('Range','Pre-','post-');
set(Legend,'EdgeColor',[1 1 1]);