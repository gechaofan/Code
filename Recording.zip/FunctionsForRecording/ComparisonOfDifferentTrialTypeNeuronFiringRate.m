function ComparisonOfDifferentTrialTypeNeuronFiringRate(AllTrialSpikeCounts,ATrialIndexGroup,BTrialIndexGroup,FirstOdorLen,Delay,...
    SecondOdorLen,Response,WaterLen,DPALen,TimeGain,ColorGroup)

linestyle={'-';'--';':'};Color=[0 0 0;1 0 0;0 0 1];
figure('color',[1 1 1])
colormap(jet);
X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
if size(ATrialIndexGroup,1)==size(BTrialIndexGroup,1)
    tempType1SpkikeCounts=cellfun(@(x) AllTrialSpikeCounts(x,:),ATrialIndexGroup,'un',0);
    MeanType1SpkikeCounts=cellfun(@(x) mean(x,1),tempType1SpkikeCounts,'un',0);
    SEM1=cellfun(@(x) std(x,0,1)/sqrt(size(x,1)-1),tempType1SpkikeCounts,'un',0);
    
    tempType2SpkikeCounts=cellfun(@(y) AllTrialSpikeCounts(y,:),BTrialIndexGroup,'un',0);
    MeanType2SpkikeCounts=cellfun(@(y) mean(y,1),tempType2SpkikeCounts,'un',0);
    SEM2=cellfun(@(y) std(y,0,1)/sqrt(size(y,1)-1),tempType2SpkikeCounts,'un',0);
    
    for itr0 = 1: size(ATrialIndexGroup,1)
        %         if ~isempty(tempType1SpkikeCounts)
        plot(X,TimeGain*smooth(MeanType1SpkikeCounts{itr0,1},'moving',5)','Color',ColorGroup{1,1},'LineWidth',1.5,'LineStyle',linestyle{itr0,1})
        hold on
        fill([X,fliplr(X)],[TimeGain*smooth(MeanType1SpkikeCounts{itr0,1}-SEM1{itr0,1},'moving',5)',fliplr(TimeGain*smooth(MeanType1SpkikeCounts{itr0,1}+SEM1{itr0,1},'moving',5)')],...
            ColorGroup{1,1},'edgecolor','none','FaceAlpha',0.3)
        %         end
        %         if ~isempty(tempType2SpkikeCounts)
        plot(X,TimeGain*smooth(MeanType2SpkikeCounts{itr0,1},'moving',5)','Color',ColorGroup{1,2},'LineWidth',1.5','LineStyle',linestyle{itr0,1})
        fill([X,fliplr(X)],[TimeGain*smooth(MeanType2SpkikeCounts{itr0,1}-SEM2{itr0,1},'moving',5)',fliplr(TimeGain*smooth(MeanType2SpkikeCounts{itr0,1}+SEM2{itr0,1},'moving',5)')],...
            ColorGroup{1,2},'edgecolor','none','FaceAlpha',0.3)
        A=mat2cell(tempType1SpkikeCounts{itr0,1},size(tempType1SpkikeCounts{itr0,1},1),ones(size(tempType1SpkikeCounts{itr0,1},2),1));
        B=mat2cell(tempType2SpkikeCounts{itr0,1},size(tempType2SpkikeCounts{itr0,1},1),ones(size(tempType2SpkikeCounts{itr0,1},2),1));
        temp_P=cellfun(@(x,y) ranksum(x,y),A,B,'un',0);
        p=cell2mat(temp_P);
        x1=find(p<0.05)/TimeGain;
        plot(x1-2,zeros(1,length(x1))+0.5*itr0,'LineStyle','none','Marker','.','Color',Color(itr0,:))%2s baseline
    end
else
    tempType1SpkikeCounts=cellfun(@(x) AllTrialSpikeCounts(x,:),ATrialIndexGroup,'un',0);
    MeanType1SpkikeCounts=cellfun(@(x) mean(x,1),tempType1SpkikeCounts,'un',0);
    SEM1=cellfun(@(x) std(x,0,1)/sqrt(size(x,1)-1),tempType1SpkikeCounts,'un',0);
    
    for itr0 = 1: size(ATrialIndexGroup,1)
        plot(X,TimeGain*smooth(MeanType1SpkikeCounts{itr0,1},'moving',5)','Color',Color(itr0,:),'LineWidth',1.5,'LineStyle',linestyle{itr0,1})
        hold on
        fill([X,fliplr(X)],[TimeGain*smooth(MeanType1SpkikeCounts{itr0,1}-SEM1{itr0,1},'moving',5)',fliplr(TimeGain*smooth(MeanType1SpkikeCounts{itr0,1}+SEM1{itr0,1},'moving',5)')],...
            Color(itr0,:),'edgecolor','none','FaceAlpha',0.3)
    end
    for iP= 2:size(ATrialIndexGroup,1)
        x1=[];
        for iBin = 1:length(X)
            p(iP,iBin)=signrank(tempType1SpkikeCounts{1,1}(:,iBin),tempType1SpkikeCounts{iP,1}(:,iBin));
        end
        x1=find(p(iP,:)<0.05)/TimeGain;
        plot(x1-2,iP*0.5+zeros(1,length(x1)),'LineStyle','none','Marker','.','Color',Color(iP-1,:))%2s baseline
        
    end
    
    
end
h1=area([0 FirstOdorLen],100*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],100*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],100*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water

box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Firing Rate');% Create ylabel

% YMin=floor(min([TimeGain*mean(tempATrialSpikeCounts,1) TimeGain*mean(tempBTrialSpikeCounts,1) TimeGain*mean(tempCTrialSpikeCounts,1) TimeGain*mean(tempDTrialSpikeCounts,1)]))-5;
YMin=-5;
YMax=ceil(TimeGain*max(max(cell2mat(MeanType1SpkikeCounts))))+5;
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2],...
    'YLim',[0,YMax])
end