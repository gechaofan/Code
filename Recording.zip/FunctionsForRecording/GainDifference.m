%%% �Ŵ�ͬ�����coding ����
win = 0.5; % in second
PreLen = 2;
bin = 0.1;
tag = 'Sample odor based on odor and delay ';
cellid = cell2mat(cellfun(@(x) size(x,1)>3,AllCRTrialsFR,'uni',false));
winStart2End = PreLen/win+1:(PreLen+1+6)/win;
[nP1, nP2] = AnaCodingDimensionwithReptition(AllATrialsFR, AllBTrialsFR, win...
    , bin, PreLen, cellid, winStart2End, tag);
