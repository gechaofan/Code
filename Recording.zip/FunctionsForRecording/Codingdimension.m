function [proj1, proj2] = Codingdimension(Y1,Y2,Cellid,winStart2End)
d1 = cell2mat(cellfun(@(x) x(randperm(size(x,1),1),:),Y1(Cellid)...
    ,'Uni',false)');
d2 = cell2mat(cellfun(@(x) x(randperm(size(x,1),1),:),Y2(Cellid)...
    ,'Uni',false)');
w = mean(d1(:,winStart2End)-d2(:,winStart2End),2);
normw = w/sqrt(sum(cell2mat(arrayfun(@(x) x*x,w,'Uni',false))));
proj1 = cell2mat(arrayfun(@(x) sum(normw.*d1(:,x)),1:size(d1,2),'Uni',false))';
proj2 = cell2mat(arrayfun(@(x) sum(normw.*d2(:,x)),1:size(d2,2),'Uni',false))';