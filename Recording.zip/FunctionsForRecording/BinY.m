function newBinData = BinY(Y,binsize)
try
    xaxis = 1:binsize:size(Y,2);
    if xaxis(end)+binsize-1 > size(Y,2)
        xaxis(end) = [];
    end
    newBinData = cell2mat(arrayfun(@(x) mean(Y(:,x:x+binsize-1),2)...
        ,xaxis,'UniformOutput',false));
catch
    display('Error in BinY.m')
    out = [];
end
end