function PlotSpikeCountsCrossTime(UnitSpikeTimeStamp)
% PlotSpikeCountsCrossTime(UnitSpikeTimeStamp,TimeGain)



figure('color',[1 1 1])
colormap(jet);
% for itr5=1:floor(UnitSpikeTimeStamp(end))*TimeGain
%     SpikeCounts(1,itr5)=TimeGain*length(UnitSpikeTimeStamp(UnitSpikeTimeStamp(1)+(itr5-1)*0.1<UnitSpikeTimeStamp&UnitSpikeTimeStamp<=UnitSpikeTimeStamp(1)+itr5*0.1));
% end
% bar([0.1:0.1:floor(UnitSpikeTimeStamp(end))],SpikeCounts)
for itr5=1:floor(UnitSpikeTimeStamp(end))
    SpikeCounts(1,itr5)=length(UnitSpikeTimeStamp(UnitSpikeTimeStamp(1)+(itr5-1)<UnitSpikeTimeStamp&UnitSpikeTimeStamp<=UnitSpikeTimeStamp(1)+itr5));
end
bar([1:1:floor(UnitSpikeTimeStamp(end))],SpikeCounts)
xlabel('Time (Sec)');% Create xlabel
ylabel('Counts');% Create ylabel
box off

