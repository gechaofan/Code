function PlotMeanWaveform(UnitsWaveform,SampleNum,OptoTagging,Laser)
if OptoTagging==1
    LaserOnMeanWaveform=mean(UnitsWaveform(Laser,4:end),1);
    LaserOffMeanWaveform=mean(UnitsWaveform(:,4:end),1);
    figure('color',[1 1 1])
    for itr = 1:4% for tetrode
        plot([(itr-1)*(SampleNum+2)+1:(itr-1)*(SampleNum+2)+SampleNum],LaserOnMeanWaveform((itr-1)*SampleNum+1:itr*SampleNum),...
            'b','LineWidth',2)
        hold on
        plot([(itr-1)*(SampleNum+2)+1:(itr-1)*(SampleNum+2)+SampleNum],LaserOffMeanWaveform((itr-1)*SampleNum+1:itr*SampleNum),...
            'k','LineWidth',2)
    end
    set(gca,'XTickLabel',{'0','2','4','6'},'XTick',[0,80,160,240])
    xlabel('Time (ms)');% Create xlabel
    ylabel('Voltage (��V)');% Create ylabel
    box off
    
else
    MeanWaveform=mean(UnitsWaveform(:,4:end),1);
    figure('color',[1 1 1])
    for itr = 1:4% for tetrode
        plot([(itr-1)*(SampleNum+2)+1:(itr-1)*(SampleNum+2)+SampleNum],MeanWaveform((itr-1)*SampleNum+1:itr*SampleNum),...
            'k','LineWidth',2)
        hold on
    end
    set(gca,'XTickLabel',{'0','2','4','6'},'XTick',[0,80,160,240])
    xlabel('Time (ms)');% Create xlabel
    ylabel('Voltage (��V)');% Create ylabel
    box off
end
end