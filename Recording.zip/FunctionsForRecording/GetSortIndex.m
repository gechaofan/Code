%% this function is used to get sortingindex of colormap, 
%% especially sort squence according to the difference of two group of data

function SpecificIndex=GetSortIndex(SampleAFR,SampleBFR,TimeGain)

tempMeanFRForSampleACrossTrial = cellfun(@mean,SampleAFR,'UniformOutput', false);
MeanFRForSampleACrossTrial = cell2mat(tempMeanFRForSampleACrossTrial);
tempMeanFRForSampleBCrossTrial = cellfun(@mean,SampleBFR,'UniformOutput', false);
MeanFRForSampleBCrossTrial = cell2mat(tempMeanFRForSampleBCrossTrial);

DiffFRForSampleAB =TimeGain * mean(MeanFRForSampleACrossTrial(:,31:50) - MeanFRForSampleBCrossTrial(:,31:50),2);
% DiffFRForSampleAB =TimeGain * mean(MeanFRForSampleACrossTrial(:,31:90),2);
[~,SpecificIndex] = sortrows(DiffFRForSampleAB,1);


