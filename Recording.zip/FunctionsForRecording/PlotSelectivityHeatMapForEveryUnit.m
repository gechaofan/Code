function [SelectivityData,ShuffledData]=PlotSelectivityHeatMapForEveryUnit(Type1FR,Type2FR,Shuffled1FR,Shuffled2FR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,TimeGain)

SelectivityData=[];
ShuffledData=[];
% FR_SelectityData = cellfun(@(x,y) [x;y],Type1FR,Type2FR,'un',0);
% FR_SelectityData1 = cellfun(@mean,FR_SelectityData,'un',0);
% FR_SelectityData2 = cell2mat(FR_SelectityData1);
% DelayActivityWeight_SelectivityData=abs(FR_SelectityData2 -mean(FR_SelectityData2(:,10:19),2))./std(mean(FR_SelectityData2(:,10:19),2),0,1);

% FR_ShuffledData = cellfun(@(x,y) [x;y],Shuffled1FR,Shuffled2FR,'un',0);
% FR_ShuffledData1 = cellfun(@mean,FR_ShuffledData,'un',0);
% FR_ShuffledData2 = cell2mat(FR_ShuffledData1);
% DelayActivityWeight_ShuffledData=abs(FR_ShuffledData2-mean(FR_ShuffledData2(:,10:19),2)) ./std( mean(FR_ShuffledData2(:,10:19),2),0,1);

for itrm=1:size(AllUnitID,1)
   tempIndexForSampleSelectivity=[];tempIndexForShuffledSampleSelectivity=[];
      
        SampleSelectivity=(mean(Type1FR{itrm,1},1)-mean(Type2FR{itrm,1},1))./(mean(Type1FR{itrm,1},1)+mean(Type2FR{itrm,1},1));
        tempIndexForSampleSelectivity = find(mean(Type1FR{itrm,1},1)+mean(Type2FR{itrm,1},1)==0);% FR in 100ms is 0;
        SampleSelectivity(tempIndexForSampleSelectivity)=0;
        
        ShuffledSampleSelectivity=(mean(Shuffled1FR{itrm,1},1)-mean(Shuffled2FR{itrm,1},1))./(mean(Shuffled1FR{itrm,1},1)+mean(Shuffled2FR{itrm,1},1));
        tempIndexForShuffledSampleSelectivity = find(mean(Shuffled1FR{itrm,1},1)+mean(Shuffled2FR{itrm,1},1)==0);% FR in 100ms is 0;
        ShuffledSampleSelectivity(tempIndexForShuffledSampleSelectivity)=0;
%         
        SelectivityData=[SelectivityData;smooth(SampleSelectivity,5,'moving')'];
        ShuffledData=[ShuffledData;smooth(ShuffledSampleSelectivity,5,'moving')'];
%         SelectivityData=[SelectivityData;SampleSelectivity];
%         ShuffledData=[ShuffledData;ShuffledSampleSelectivity];
%         
end
% SelectivityData = SelectivityData.*DelayActivityWeight_SelectivityData;
% ShuffledData = ShuffledData.*DelayActivityWeight_ShuffledData;
% [~,Max_index]=max(SelectivityData(:,31:90),[],2);
% [~,SortIndex]=sortrows(Max_index);
[~,SortIndex1]=sortrows(mean(SelectivityData(:,31:90),2),-1);
UnitNum=size(SortIndex1,1);
% map=ones(199,3);
% c=linspace(0,1)';
% map(1:100,[1,2])=[c,c];
% map(199:-1:100,[2,3])=[c,c];
% colormap(map);
figure ('color',[1 1 1])
colormap(jet);
subplot(1,2,1)
imagesc(SelectivityData(SortIndex1,:),[-1 1])
colorbar
hold on
plot(TimeGain*[2 2],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen 2+FirstOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay 2+FirstOdorLen+Delay],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[20,40,60,80,100],'Xlim',[10 110],'CLim',[-0.6 0.6])
xlabel('Time (Sec)');% Create xlabel
ylabel('Unit Index');% Create ylabel
title({'Selectivity for Laser Off Trials'},'FontSize',12);


subplot(1,2,2)
[~,SortIndex2]=sortrows(mean(ShuffledData(:,31:90),2),-1);
imagesc(ShuffledData(SortIndex1,:),[-1 1])
colorbar
hold on
plot(TimeGain*[2 2],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen 2+FirstOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay 2+FirstOdorLen+Delay],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
set(gca,'XTickLabel',{'0','2','4','6','8'},'XTick',[20,40,60,80,100],'Xlim',[10 110],'CLim',[-0.6 0.6])
xlabel('Time (Sec)');% Create xlabel
ylabel('Unit Index');% Create ylabel
title({'Selectivity for Laser On Trials'},'FontSize',12);

% map=ones(199,3);
% c=linspace(0,1)';
% map(1:100,[1,2])=[c,c];
% map(199:-1:100,[2,3])=[c,c];
% colormap(map);
% 




% p=[];
% for itr=1:size(SelectivityData,2)
%     p(1,itr)=ranksum(SelectivityData(:,itr),ShuffledData(:,itr));
%     if p(1,itr)<0.05
%         plot(-1.9+itr/10,0.2,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','*','LineStyle','none');
%         hold on
%     end
% end