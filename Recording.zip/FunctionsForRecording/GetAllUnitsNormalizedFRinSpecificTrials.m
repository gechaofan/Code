function [NormlizedFR,CalculateNueronNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllUnitFRinSpecificTrials,AllUnitID,TimeGain,DelayContinuity)
if nargin==3
CalculateNueronNum=[];
for itr2=1:size(AllUnitID,1)
    x=AllUnitFRinSpecificTrials{itr2,1}*TimeGain;
    if size(AllUnitFRinSpecificTrials{itr2,1},1)>=20% if the trial number ,ore than 20.then calculate
            NormlizedFR{itr2,1}=(x-mean(mean(x(:,10:19),2)))./std(mean(x(:,10:19),2),0,1);
    else
        CalculateNueronNum=[CalculateNueronNum;itr2];
        NormlizedFR(itr2,:)=zeros(1,201);
    end
end
NormlizedFR(CalculateNueronNum,:)=[];
CalculateNueronNum=size(NormlizedFR,1);
elseif nargin ==4
 CalculateNueronNum=[];
for itr2=1:size(AllUnitID,1)
    x=AllUnitFRinSpecificTrials{itr2,1};
    if size(AllUnitFRinSpecificTrials{itr2,1},1)>=20% if the trial number ,ore than 20.then calculate 
    NormlizedFR{itr2,1}=(x-x(:,3))./mean(x(:,3))+1;
%     Target(itr2,:)=smooth(mean(tempNormlizedFR{itr2,1},1),'moving',5);
    else
        CalculateNueronNum=[CalculateNueronNum;itr2];
        NormlizedFR(itr2,:)=zeros(1,201);
    end
end
NormlizedFR(CalculateNueronNum,:)=[];
CalculateNueronNum=size(NormlizedFR,1);  
    
    
end

