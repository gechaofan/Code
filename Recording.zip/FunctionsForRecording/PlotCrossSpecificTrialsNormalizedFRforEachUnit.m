function PlotCrossSpecificTrialsNormalizedFRforEachUnit(NormlizedFRCrossTrial,TrialNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)

    figure('color',[1 1 1])
    colormap(jet);
    imagesc(NormlizedFRCrossTrial)
    colorbar
    hold on
    plot(TimeGain*[2 2],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    plot(TimeGain*[2+FirstOdorLen 2+FirstOdorLen],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    plot(TimeGain*[2+FirstOdorLen+Delay 2+FirstOdorLen+Delay],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen],[-0.5 TrialNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
    set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[20,70,120,170])
    xlabel('Time (Sec)');% Create xlabel
    ylabel('TrialNum');% Create ylabel

end