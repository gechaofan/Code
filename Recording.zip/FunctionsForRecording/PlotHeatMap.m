function Index=PlotHeatMap(AllUnitsNrmolizedFRinSpecificTrials,UnitNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex)
MeanNormFRForEachNeuron=cell2mat(cellfun(@mean,AllUnitsNrmolizedFRinSpecificTrials,'un',0));
figure('color',[1 1 1])
MeanDelayActivity=mean(MeanNormFRForEachNeuron(:,TimeGain*(1+FirstOdorLen)+1:TimeGain*(2+FirstOdorLen+Delay)),2);% mean FR from sample odor start to delay end
if isempty(SpecificIndex)
% [~,Index]=sortrows(MeanDelayActivity,-1);% delay period normalized FR ���Ӵ�С���У�
[~,Index]=sortrows(MeanDelayActivity);
else
    Index=SpecificIndex;
end
NewNormalizedAllTrialsActivity=MeanNormFRForEachNeuron(Index,:);% delay period normalized FR ���Ӵ�С���У�
imagesc(NewNormalizedAllTrialsActivity,[-1 1])
colormap(jet);
colorbar
hold on
plot(TimeGain*[2 2],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen 2+FirstOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay 2+FirstOdorLen+Delay],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen 2+FirstOdorLen+Delay+SecondOdorLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response 2+FirstOdorLen+Delay+SecondOdorLen+Response],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
plot(TimeGain*[2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen 2+FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen],[-0.5 UnitNum+0.5],'LineWidth',2,'LineStyle','--','Color',[0 0 0])
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[20,70,120,170],'CLim',[-3 3]);
set(gca,'ydir','normal');
xlabel('Time (Sec)');% Create xlabel
ylabel('UnitNum');% Create ylabel