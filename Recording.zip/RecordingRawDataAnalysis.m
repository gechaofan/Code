% This code is used to analyze recoeding data of PAL task.(1s odor-delivery, 5s delay, 1s response-delay and  1s reward.)
%%
% step 1: extract task events from PL2 file
% step 2: import spike information from .txt file
% step 3: single unit analysis;
%        i) Quantify the quality of each unit
%        ii) Present the overall firing raster and licking raster of each unit
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
clc
%%
PlotUnitStablity=1;
PlotISIDistribution=1;
PlotSpikeCountsOverAllRecording=1;
PlotDifferentTrialTypeNeuronActivity=1;
PlotNeuronActivity=1;
PlotSpikeRaster = 1;
%%
% step 1
WaveFormSampleNum=58;%TDT=34,Plexon=58, HuPlexon=54;waveform length 1450um,325us prethreshold
TrialNumPerBlock=20;%define the trial number in one session0..
TimeGain=10;%define the bin size
TimestampFrequency=40000;
RefrISI=0.002; %refractory period=2ms;
DataType=1;%1 for .pl2 file; 2 for .plx file;
TaskType=3;%%% PAL=3;
TrainingType = 2; % For Plexon Recording Using Code form GXW
OdorPairs=1234;
LaserType=3; %0 for no laser during task; 1 for laser in every trial; 2 for block design, Laser off and laser on;3 block design and two type of laser
OptoTagging=1;% 1 laser paulse tagging neuron
LaserOutTask=0;

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};
    %%
    %change the directory to the file of DataID
    cd(Path);
    %%  get Data,Trials,FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,DPALen   %%%% ITI was given as 10s
    JAVAFileName=ls ('*ser');% get file name of behavior data;
    RawDataName=ls('RawData*.mat');
    SplitDataName=ls('SplitData*.mat');
    if ~isempty(JAVAFileName) && ~isempty(RawDataName)
        %         if ~isempty(JAVAFileName) && ~isempty(RawDataName) && isempty(SplitDataName)
        %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% load plexon data
        load(RawDataName);
        %     LabviewMatFile=dir('*Labview*.mat');
        %convert JAVA data to matrix
        SerialData=ser2mat(JAVAFileName);
        SerialData=double(SerialData);
        [LickInJava,Laser,FirstOdor,FirstOdorStart,SecondOdor,SecondOdorStart,WaterTime,TrialNum,Data,Trials, LaserTrial,...
            FirstOdorLen,SecondOdorLen,Delay,Response,WaterLen,ITILen,PALLen,ReactionTime,HitTimeStamp,FATimeStamp]=SerialEventForPALWithVaryingDelay(SerialData, OdorPairs, TaskType,TrainingType,LaserType);
        clear('Laser','FirstOdor','FirstOdorStart','SecondOdor','SecondOdorStart','WaterTime','TrialNum',...
            'FirstOdorLen','SecondOdorLen','Delay','Response','WaterLen','ITILen','PALLen','ReactionTime','HitTimeStamp','FATimeStamp')
        %%%%%%%%%%% task event ʱ����λ��Ϊs
        FirstOdorLen=1.0;SecondOdorLen=1.0;Delay=6.0;Response=1.0;WaterLen=1.0;ITILen=10.0;DPALen=20.0;
        
        %% get trial information and Lick
        TaskEventName=who('event*',RawDataName);
        n =str2num(TaskEventName{1,1}(1,end));
        switch n
            case 1
                [Laser,Lick,Odor1,Odor2,TrialsPLexon,SplitLickTimestamp,SplitLickCounts]=...
                    GetTaskInformationFromPlexon(event1,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TrainingType,TaskType,TimeGain);
                RawSpikes=RawSpikes1;
            case 2
                [Laser,Lick,Odor1,Odor2,TrialsPLexon,SplitLickTimestamp,SplitLickCounts]=...
                    GetTaskInformationFromPlexon(event2,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TrainingType,TaskType,TimeGain);
                RawSpikes=RawSpikes2;
            otherwise
                [Laser,Lick,Odor1,Odor2,TrialsPLexon,SplitLickTimestamp,SplitLickCounts]=...
                    GetTaskInformationFromPlexon(event,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TrainingType,TaskType,TimeGain);
        end
        %%
        if ~isempty(RawSpikes)
            RecordRange=RawSpikes(end,3)-RawSpikes(1,3);% ~recording time
            %% judge the same performance in JAVA and Plexon
            if size(Trials,1)==size(TrialsPLexon,1)
                DifferentTrials=find(Trials(:,4)==TrialsPLexon(:,4)<1);%%%% get different result trials between JAVA Data and Plexon Data
                if length(DifferentTrials)>10
                    disp('error in Construct Task Information From Plexon')
                end
            else
                disp('Trial Number in Plexon is Different from in Java')
                DifferentTrials=0;
            end
            %% get single unit information
            UnitIndex=unique(RawSpikes(:,1:2),'rows');%%% RawSpikes exclude unsorted spikes; tetrode-index and number but include multiunits
            UnitNum=size(UnitIndex,1);
            SingleUnitIndex=[];
            SingleUnits=[];
            SingleUnitNum=0;
            SingleUnitID=[];
            NewSpikes=[];
            for itr1=1:UnitNum
                %% get single units
                tempUnitSpikes=[];tempISI=[];tempSingleUnitParameter=[];tempSingleUnitr1efrISI=[];
                tempUnitSpikes=RawSpikes(RawSpikes(:,1)==UnitIndex(itr1,1)&RawSpikes(:,2)==UnitIndex(itr1,2),:);
                tempISI=[diff(tempUnitSpikes(:,3));diff(flipud(tempUnitSpikes(:,3)))];% �����������ڵ�ISI
                tempSingleUnitr1efrISI=length(find(abs(tempISI)<RefrISI))*100/length(tempISI);% �����ڲ�Ӧ���ڵ�spikes�İٷֱ�
                tempSingleUnitParameter=tempSingleUnitr1efrISI;% number of spikes in refractory period was less than 0.15%
                tempFR=size(tempUnitSpikes,1)/RecordRange;% FR>=2Hz
                if tempSingleUnitParameter<=0.15 && tempFR>=1
                    SingleUnitIndex=[SingleUnitIndex;UnitIndex(itr1,:)];
                    SingleUnits=[SingleUnits;{tempUnitSpikes}];% ����single unit��spikes ��Ϣ�ŵ�һ�������
                    SingleUnitNum=SingleUnitNum+1;
                    SingleUnitID=[SingleUnitID;{num2str(UnitIndex(itr1,1)*10+UnitIndex(itr1,2))}];
                    NewSpikes{SingleUnitNum,1}=tempUnitSpikes;
                end
            end
            
            for itr2=1:SingleUnitNum
                FiringRate(itr2,1)=size(SingleUnits{itr2,1},1)/(SingleUnits{itr2,1}(end,3)-SingleUnits{itr2,1}(1,3));
                tempSpikeTimestamp=[];
                tempSpikeTimestamp=SingleUnits{itr2,1}(:,3);
                for itr3=1:size(TrialsPLexon,1)
                    SplitData.SpikeTimestamp{itr2,1}{itr3,1}=tempSpikeTimestamp(tempSpikeTimestamp>Odor1(itr3,1)-2&tempSpikeTimestamp<Odor1(itr3,1)+DPALen-2);%SpikeTimestamp in each trial
                    for itr=1:floor(DPALen*TimeGain+1)% Binsize=100ms
                        SplitData.SpikeCounts{itr2,1}(itr3,itr)=length(tempSpikeTimestamp(tempSpikeTimestamp>Odor1(itr3,1)-2+0.1*(itr-1)&tempSpikeTimestamp<Odor1(itr3,1)-2+0.1*itr));
                        % SpikeCounts in each trial
                    end
                end
            end
            SplitData.LickTimestamp=SplitLickTimestamp;
            SplitData.LickCounts=SplitLickCounts;
            SplitData.Trials=TrialsPLexon;
            SplitData.Lick=Lick;%filtered lick in Plexon
            % FP=nexFile.contvars;% field potential information
            save(['SplitData-' DataID],'DataID','Data','SplitData','SingleUnitIndex','DifferentTrials','Odor1','Odor2','LickInJava','Laser','LaserTrial',...
                'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','FiringRate','DifferentTrials','NewSpikes','LaserType','-v7.3')
            %% Plot Behavior Performance
            LaserInTask=find(LaserTrial==1);
            PlotPerformanceForPAL(Data,LaserInTask)
            saveas(gcf,[DataID '-Performance'],'fig')
            saveas(gcf,[DataID '-Performance'],'png')
            close all
            %% figure out unit property
            if PlotUnitStablity==1
                for itr4=1:SingleUnitNum
                    % plot averge wave form
                    PlotMeanWaveform(SingleUnits{itr4,1},WaveFormSampleNum,OptoTagging,Laser)
                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-WaveForm'],'fig')
                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-WaveForm'],'png')
                    close all
                    
                    % plot the first 1/4 waveform and the last 1/4 waveform to test recording stablity
                    CompareWaveformChangeCrossTime(SingleUnits{itr4,1}(:,4:end),WaveFormSampleNum)
                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-ComparisionOfPreAndPostWaveForm'],'fig')
                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-ComparisionOfPreAndPostWaveForm'],'png')
                    close all
                    % plot spike counts through the whole recording
                    if PlotSpikeCountsOverAllRecording==1
                        PlotSpikeCountsCrossTime(SingleUnits{itr4,1}(:,3),TimeGain);
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-SpikeCounts'],'fig')
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-SpikeCounts'],'png')
                        close all
                    end
                    % plot ISI distribution
                    if PlotISIDistribution==1
                        PlotInterSpikeIntervalDistribution(SingleUnits{itr4,1}(:,3))
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-ISIDistribution'],'fig')
                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr4,1} '-ISIDistribution'],'png')
                        close all
                    end
                end
            end
            
            %%          % plot unit activity in task
            if PlotNeuronActivity==1
                % analyze correct trials
                AllTrialIndex=[1:1:size(SplitData.Trials,1)]';
                HitTrialIndex=find(SplitData.Trials(:,4)==1);
                FATrialIndex=find(SplitData.Trials(:,4)==3);
                CRTrialIndex=find(SplitData.Trials(:,4)==4);
                PairedTrialIndex=find(SplitData.Trials(:,5)==1|SplitData.Trials(:,5)==2);
                UnPairedTrialIndex=find(SplitData.Trials(:,5)==3|SplitData.Trials(:,5)==4);
                %                 ATrialIndex=find(SplitData.Trials(:,2)==1&SplitData.Trials(:,4)==1|SplitData.Trials(:,2)==1&SplitData.Trials(:,4)==4);
                %                 BTrialIndex=find(SplitData.Trials(:,2)==2&SplitData.Trials(:,4)==1|SplitData.Trials(:,2)==2&SplitData.Trials(:,4)==4);
                %                 CTrialIndex=find(SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==1|SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==4);
                %                 DTrialIndex=find(SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==1|SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==4);
                ATrialIndex=find(SplitData.Trials(:,2)==1);
                BTrialIndex=find(SplitData.Trials(:,2)==2);
                CTrialIndex=find(SplitData.Trials(:,3)==3);
                DTrialIndex=find(SplitData.Trials(:,3)==4);
                
                if PlotDifferentTrialTypeNeuronActivity==1
                    for itr8=1:SingleUnitNum
                        %% judge laser
                        if length(unique(LaserTrial))==1  % no laser during task or laser in all trials
                            if PlotSpikeRaster ==1
                                if FiringRate(itr8,1)>20 % FiringRata > 20Hz, olot colormap
                                    PlotSpecificTrialsHeatmapAndFRCurve(AllTrialIndex,SplitData.SpikeCounts{itr8,1},FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain);
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-AllTrialHeatmapAndFRCvrve'],'fig')
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-AllTrialHeatmapAndFRCvrve'],'png')
                                    close all
                                else % FiringRata < 20Hz, polot Raster
                                    PlotSpecificTrialsRasterAndFRCvrve(AllTrialIndex,SplitData.SpikeTimestamp{itr8,1}(AllTrialIndex,1),SplitData.SpikeCounts{itr8,1}(AllTrialIndex,:),...
                                        Odor1(AllTrialIndex,:),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.1 0.6 0.2]);
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-AllTrialRasterAndFRCvrve'],'fig')
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-AllTrialRasterAndFRCvrve'],'png')
                                    close all
                                    
                                    PlotSpecificTrialsRasterAndFRCvrve(ATrialIndex([1:80],:),SplitData.SpikeTimestamp{itr8,1}(ATrialIndex([1:80],:)),SplitData.SpikeCounts{itr8,1}(ATrialIndex,:),...
                                        Odor1(ATrialIndex([1:80],:)),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[1 0 0]);
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-ATrialRasterAndFRCvrve'],'fig')
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-ATrialRasterAndFRCvrve'],'png')
                                    close all
                                    PlotSpecificTrialsRasterAndFRCvrve(BTrialIndex([1:80],:),SplitData.SpikeTimestamp{itr8,1}(BTrialIndex([1:80],:)),SplitData.SpikeCounts{itr8,1}(BTrialIndex,:),...
                                        Odor1(BTrialIndex([1:80],:)),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 1]);
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-BTrialRasterAndFRCvrve'],'fig')
                                    saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-BTrialRasterAndFRCvrve'],'png')
                                    close all
                                    
                                end
                            end
                            %                             ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(BTrialIndex,:),[],[],...
                            %  
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},{ATrialIndex},{BTrialIndex},...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[1 0 0] [0 0 1]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntSampleTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntSampleTrialsFRCurve'],'png')
                            close all
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},{CTrialIndex},{DTrialIndex},...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0.45 0.75] [0.5 0.18 0.56]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntTestTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-DifferntTestTrialsFRCurve'],'png')
                            close all
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},{HitTrialIndex},{FATrialIndex},...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0 0] [1 0 0]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-Hit&FATrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-Hit&FATrialsFRCurve'],'png')
                            close all
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},{HitTrialIndex},{CRTrialIndex},...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0 0] [0 1 0]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-Hit&CRTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-Hit&CRTrialsFRCurve'],'png')
                            close all
                            %% plot laser effect
                        else % laser in task
                            LaserInTask=unique(LaserTrial);
                            LaserTrialIndex=cell(length(LaserInTask),1);LaserHitTrialIndex=cell(length(LaserInTask),1);
                            LaserFATrialIndex=cell(length(LaserInTask),1);LaserCRTrialIndex=cell(length(LaserInTask),1);
                            LaserATrialIndex=cell(length(LaserInTask),1);LaserBTrialIndex=cell(length(LaserInTask),1);
                            LaserCTrialIndex=cell(length(LaserInTask),1);LaserDTrialIndex=cell(length(LaserInTask),1);
                            LaserCorrectTrialIndex=cell(length(LaserInTask),1);LaserErrorTrialIndex=cell(length(LaserInTask),1);
                            for itrm = 1:length(LaserInTask)
                                LaserTrialIndex{itrm,1}=find(LaserTrial==LaserInTask(itrm,1));
                                LaserHitTrialIndex{itrm,1}=find(SplitData.Trials(:,4)==1&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserFATrialIndex{itrm,1}=find(SplitData.Trials(:,4)==3&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserCRTrialIndex{itrm,1}=find(SplitData.Trials(:,4)==4&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserATrialIndex{itrm,1}=find(SplitData.Trials(:,2)==1&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserBTrialIndex{itrm,1}=find(SplitData.Trials(:,2)==2&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserCTrialIndex{itrm,1}=find(SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==1&LaserTrial(:,1)==LaserInTask(itrm,1)|SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==4&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserDTrialIndex{itrm,1}=find(SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==1&LaserTrial(:,1)==LaserInTask(itrm,1)|SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==4&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserCorrectTrialIndex{itrm,1}=find(SplitData.Trials(:,4)==1&LaserTrial(:,1)==LaserInTask(itrm,1)|SplitData.Trials(:,4)==4&LaserTrial(:,1)==LaserInTask(itrm,1));
                                LaserErrorTrialIndex{itrm,1}=find(SplitData.Trials(:,4)==2&LaserTrial(:,1)==LaserInTask(itrm,1)|SplitData.Trials(:,4)==3&LaserTrial(:,1)==LaserInTask(itrm,1));
                            end
                            
                            if  PlotSpikeRaster ==1
                                for itrn = 1:length(LaserInTask)
                                    if FiringRate(itr8,1)>20 % FiringRata > 20Hz, olot colormap
                                        PlotSpecificTrialsHeatmapAndFRCurve(LaserTrialIndex{itrn,1},SplitData.SpikeCounts{itr8,1}(LaserTrialIndex{itrn,1},:),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain);
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserTrialHeatmapAndFRCvrve-' num2str(itrn)],'fig')
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserTrialHeatmapAndFRCvrve-' num2str(itrn)],'png')
                                        close all
                                    else % FiringRata < 20Hz, plot Raster
                                        PlotSpecificTrialsRasterAndFRCvrve(LaserTrialIndex{itrn,1}(21:80,:),SplitData.SpikeTimestamp{itr8,1}(LaserTrialIndex{itrn,1}(21:80,:)),SplitData.SpikeCounts{itr8,1}(LaserTrialIndex{itrn,1}(21:80,:)),...
                                            Odor1(LaserTrialIndex{itrn,1}(21:80,:)),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.1 0.6 0.2]);
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserTrialRasterAndFRCvrve-' num2str(itrn)],'fig')
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserTrialRasterAndFRCvrve-' num2str(itrn)],'png')
                                        close all
                                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                        PlotSpecificTrialsRasterAndFRCvrve(LaserATrialIndex{itrn,1}(11:40,:),SplitData.SpikeTimestamp{itr8,1}(LaserATrialIndex{itrn,1}(11:40,:)),SplitData.SpikeCounts{itr8,1}(LaserATrialIndex{itrn,1},:),...
                                            Odor1(LaserATrialIndex{itrn,1}(11:40,:)),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[1 0 0]);
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserATrialRasterAndFRCvrve-' num2str(itrn)],'fig')
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserATrialRasterAndFRCvrve-' num2str(itrn)],'png')
                                        close all
                                        PlotSpecificTrialsRasterAndFRCvrve(LaserBTrialIndex{itrn,1}(11:40,:),SplitData.SpikeTimestamp{itr8,1}(LaserBTrialIndex{itrn,1}(11:40,:)),SplitData.SpikeCounts{itr8,1}(LaserBTrialIndex{itrn,1},:),...
                                            Odor1(LaserBTrialIndex{itrn,1}(11:40,:)),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 1]);
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserBTrialRasterAndFRCvrve-' num2str(itrn)],'fig')
                                        saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserBTrialRasterAndFRCvrve-' num2str(itrn)],'png')
                                        close all
                                    end
                                end
                            end
                            % laser trial
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},LaserTrialIndex,[],...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[1 0 0] [0 0 1]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff&On_AllTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff&On_AllTrialsFRCurve'],'png')
                            close all
                            
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},LaserATrialIndex,LaserBTrialIndex,...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[1 0 0] [0 0 1]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff&On_A&BTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff&On_A&BTrialsFRCurve'],'png')
                            close all
                            
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},LaserCTrialIndex,LaserDTrialIndex,...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0.45 0.75] [0.5 0.18 0.56]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_C&DTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_C&DTrialsFRCurve'],'png')
                            close all
                            
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},LaserHitTrialIndex,LaserCRTrialIndex,...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0 0] [0 1 0]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_Hit&CRTrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_Hit&CRTrialsFRCurve'],'png')
                            close all
                            
                            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1},LaserHitTrialIndex,LaserFATrialIndex,...
                                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,{[0 0 0] [1 0 0]});
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_Hit&FATrialsFRCurve'],'fig')
                            saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn&Off_Hit&FATrialsFRCurve'],'png')
                            close all
                            %                             ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(LaserOn_ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(LaserOn_BTrialIndex,:),[],[],...
                            %                                 FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.85 0.35 1],[0.46 0.67 0.18],[],[]);
                            %                             saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn_A&BTrialsFRCurve'],'fig')
                            %                             saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOn_A&BTrialsFRCurve'],'png')
                            %                             close all
                            %                             ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(LaserOff_ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(LaserOff_BTrialIndex,:),[],[],...
                            %                                 FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.85 0.35 1],[0.46 0.67 0.18],[],[]);
                            %                             saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff_A&BTrialsFRCurve'],'fig')
                            %                             saveas(gcf,[DataID 'Unit' SingleUnitID{itr8,1} '-LaserOff_A&BTrialsFRCurve'],'png')
                            %                             close all
                        end
                    end
                end
            end
        end
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end
