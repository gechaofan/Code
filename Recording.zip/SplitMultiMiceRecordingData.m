%%%%%%%% this code is for split recording data of many mice in one file;
% WaveFormSampleNum=58;%TDT=34,Plexon=58, HuPlexon=54;waveform length 1450um,325us prethreshold
% TrialNumPerBlock=20;%define the trial number in one session0..
clear all;
clc;

TimeGain=10;%define the bin size
% SplitRawData=1;
% TimestampFrequency=40000;
DataType=1;%1 for .pl2 file; 2 for .plx file;
MouseNum=1;
SortDataType=1; % output results of offline sorter, 0 for .txt ; 1 for .mat

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
%% %% construct task event and split spike information
for iter0=1:size(SubPath,1)
    Path=SubPath{iter0,1};
    Temp=strsplit(Path,'\');
    cd(Path);
    switch SortDataType
        case 0
    SpikeFileName=ls ('*txt');% get file name of spike data
        case 1
    SpikeFileName=ls ('*mat');
        case 2
            disp('no single units')
    end
    
    if size(SpikeFileName)~=0
        SpikeFileNum = size(SpikeFileName,1);
        if SpikeFileNum > 1 %%% multiple files for sorting data
            tempdata=[];
            for i = 1 : SpikeFileNum
                temp = importdata(SpikeFileName(i,:));
                if ~isempty(temp) && isstruct(temp) %% multiple sturcture files
                    tempdata = [tempdata; struct2cell(temp)];
                elseif ~isempty(temp) && ismatrix(temp) %%% multiple mat files for each channels , matrix
                   tempdata = [tempdata; mat2cell(temp,size(temp,1),size(temp,2));]; 
                end
                temp =[];
            end
            data = cell2mat(tempdata);
        else
            tempdata0=importdata(SpikeFileName);
            tempdata=struct2cell(tempdata0);
            data=cell2mat(tempdata);
        end
%         if SortDataType > 0
%             tempdata=struct2cell(data);
%             data=cell2mat(tempdata);
%         end
        if isstruct(data)
            data=data.data;
        end
        
        if DataType==1  %%%%%%%%%%%.pl2 file
            RawdataFileName=ls ('*.pl2');% get file name of Raw recording data;
            pl2 = PL2GetFileIndex(RawdataFileName);% list pl2 file information
            % PL2Print(pl2.EventChannels);% Print Information of EventChannels
            %TimestampFrequency=pl2.TimestampFrequency;% Plexon,40000
            TempID = RawdataFileName(1,end-12:end-4);
            if MouseNum == 1
                Mouse1_DataID=['VTA-ChR2-mPFC-81' TempID];
                [event1.Laser] = PL2EventTs(RawdataFileName,'EVT09');
                %     event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts;
                [event1.Lick] = PL2EventTs(RawdataFileName,'EVT06');
                [event1.OdorAB] = PL2EventTs(RawdataFileName,'EVT07');
                [event1.OdorCD] = PL2EventTs(RawdataFileName,'EVT08');
%                 %% load FP
%                 ADFreq=1000;%Plexon sample rate for AD signal
%                 for itr = 1:64 % from channel1 to Channel64
%                     str=num2str(itr,'%03d');% switch number to string and by type of 001;
%                     tempChannel=['TETFP' str]; % channel name in pl2 file
%                     FP_Channel(1,itr)={tempChannel};
%                     tempFP=PL2Ad(RawdataFileName,tempChannel); %read specific channel pf local field potential
%                     FP(:,itr)=tempFP.Values; % column for channel number
%                 end
%                 tempIndex1 = find(event1.OdorAB.Ts == event1.OdorCD.Ts);% a signal will sent out throuth 'lick','odorAB'and 'OdorCD'
%                 event1.OdorAB.Ts(tempIndex1)=[];
%                 event1.OdorCD.Ts(tempIndex1)=[];
                RawSpikes1=data(data(:,1)<48&data(:,2)>0,:); %%% the first mouse data ;40 for 8-tetrode electrodes no multi-unit
                save(['RawData-' Mouse1_DataID],'Mouse1_DataID','event1','RawSpikes1','-v7.3');
%                  save(['RawData-' Mouse1_DataID],'Mouse1_DataID','event1','RawSpikes1','ADFreq','FP_Channel','FP');
            else
                Mouse1_DataID=['VTA-ChR2-mPFC-84' TempID];
                Mouse2_DataID=['VTA-ChR2-mPFC-81' TempID];
                
                [event1.Laser] = PL2EventTs(RawdataFileName,'EVT04');
                %     event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts;
                [event1.Lick] = PL2EventTs(RawdataFileName,'EVT01');
                [event1.OdorAB] = PL2EventTs(RawdataFileName,'EVT02');
                [event1.OdorCD] = PL2EventTs(RawdataFileName,'EVT03');
%                 tempIndex1 = find(event1.OdorAB.Ts == event1.OdorCD.Ts);% a signal will sent out throuth 'lick','odorAB'and 'OdorCD'
%                 event1.OdorAB.Ts(tempIndex1)=[];
%                 event1.OdorCD.Ts(tempIndex1)=[];
                RawSpikes1=data(data(:,1)<=48&data(:,2)>0,:); %%% the first mouse data ;40 for 8-tetrode electrodes no multi-unit
                save(['RawData-' Mouse1_DataID],'Mouse1_DataID','event1','RawSpikes1','-v7.3');
                %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [event2.Laser] = PL2EventTs(RawdataFileName,'EVT09');
                %     event.Laser.Ts(diff(event.Laser.Ts)<0.5)=[];% filter event.laser.Ts;
                [event2.Lick] = PL2EventTs(RawdataFileName,'EVT06');
                [event2.OdorAB] = PL2EventTs(RawdataFileName,'EVT07');
                [event2.OdorCD] = PL2EventTs(RawdataFileName,'EVT08');
%                 tempIndex2 = find(event2.OdorAB.Ts == event2.OdorCD.Ts);% a signal will sent out throuth 'lick','odorAB'and 'OdorCD'
%                 event2.OdorAB.Ts(tempIndex2)=[];
%                 event2.OdorCD.Ts(tempIndex2)=[];
                RawSpikes2=data(data(:,1)>48&data(:,2)>0,:); %%% the Second mouse data;40 for 8-tetrode electrodes; no multi-unit
                save(['RawData-' Mouse2_DataID],'Mouse2_DataID','event2','RawSpikes2','-v7.3');
            end
        end
        %% %%%%%%%%%%% .plx file
        if DataType==2
            EventFileName=ls ('*nex');
            [nexFile]=readNexFile(EventFileName);
            if MouseNum==1
                Lick=nexFile.events{1,1}.timestamps;%lick event
                OdorAB=nexFile.events{2,1}.timestamps;%odorant A/C
                OdorCD=nexFile.events{3,1}.timestamps;%odorant B/D
                if strcmp('EVT04',nexFile.events{4,1}.name)
                    Laser=nexFile.events{4,1}.timestamps;
                else
                    Laser=[];
                end
                RawSpikes=data(data(:,1)<=40&data(:,2)>0,:);  %%% the first mouse data
                %     FP1=nexFile.contvars{1,1}.data';FP2=nexFile.contvars{2,1}.data';FP3=nexFile.contvars{3,1}.data';FP4=nexFile.contvars{4,1}.data';
                %     FP5=nexFile.contvars{5,1}.data';FP6=nexFile.contvars{6,1}.data';FP7=nexFile.contvars{7,1}.data';FP8=nexFile.contvars{8,1}.data';
                %     FP=[FP1;FP2;FP3;FP4;FP5;FP6;FP7;FP8];
            else
                if strcmp('EVT04',nexFile.events{4,1}.name)
                    Lick=nexFile.events{5,1}.timestamps;%lick event
                    OdorAC=nexFile.events{6,1}.timestamps;%odorant A/C
                    OdorBD=nexFile.events{7,1}.timestamps;%odorant B/D
                    if strcmp('EVT09',nexFile.events{8,1}.name)
                        Laser=nexFile.events{8,1}.timestamps;
                    else
                        Laser=[];
                    end
                else
                    Lick=nexFile.events{4,1}.timestamps;%lick event
                    OdorAC=nexFile.events{5,1}.timestamps;%odorant A/C
                    OdorBD=nexFile.events{6,1}.timestamps;%odorant B/D
                    if strcmp('EVT09',nexFile.events{7,1}.name)
                        Laser=nexFile.events{7,1}.timestamps;
                    else
                        Laser=[];
                    end
                end
                RawSpikes=data(data(:,1)>8&data(:,2)>0,:);  %%% the first mouse data 32-channel(8-Tetrode) electrodes
                %     FP1=nexFile.contvars{1,1}.data';FP2=nexFile.contvars{2,1}.data';FP3=nexFile.contvars{3,1}.data';FP4=nexFile.contvars{4,1}.data';
                %     FP5=nexFile.contvars{5,1}.data';FP6=nexFile.contvars{6,1}.data';FP7=nexFile.contvars{7,1}.data';FP8=nexFile.contvars{8,1}.data';
                %     FP=[FP1;FP2;FP3;FP4;FP5;FP6;FP7;FP8];
                DataID='20160613_VTA_TH_Cre_Ai32_4335_1_32';
                save(['RawData-' DataID],'DataID','Lick','OdorAC','OdorBD','Laser','RawSpikes','nexFile')
            end
        end
    end
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end


