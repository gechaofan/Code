%%%%%%%%%%%% This code is used to summarize units and analyze them.
TimeGain=10;

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SplitPath=SplitPath';
SubPath=SplitPath(1:end-1);

AllUnitID=[];AllTrialsFR=[];
AllHitTrialsFR=[];AllFATrialsFR=[];AllCRTrialsFR=[];
AllACTrialsFR=[];AllBDTrialsFR=[];AllADTrialsFR=[];AllBCTrialsFR=[];AllPairedTrialsFR=[];AllUnPairedTrialsFR=[];
AllATrialsFR=[];AllBTrialsFR=[];AllCTrialsFR=[];AllDTrialsFR=[];
AllShuffledATrialsFR=[];AllShuffledBTrialsFR=[];


for itr0=1:size(SubPath,1)%go through each training day
    Path=SubPath{itr0,1};
    Temp=strsplit(Path,'\');
    DataID=Temp{1,end};%��{}���ã�DataIDΪcell�ڵ�ֵ
    %%
    %change the directory
    cd(Path);
    %%
    SpiltDataFile=ls('SplitData*.mat');
    if ~isempty(SpiltDataFile)
        
        load(SpiltDataFile);
        if ~isempty(SingleUnitIndex)
            tempUnitID={};tempAllTrialsFR=[];
            tempHitTrialsFR=[];tempFATrialsFR=[];tempCRTrialsFR=[];
            tempACTrialsFR=[];tempBDTrialsFR=[];tempADTrialsFR=[];tempBCTrialsFR=[];tempPairedTrialsFR=[];tempUnPairedTrialsFR=[];
            tempATrialsFR=[];tempBTrialsFR=[];tempCTrialsFR=[];tempDTrialsFR=[];tempShuffledATrialsFR=[];tempShuffledBTrialsFR=[];
            
            HitTrialIndex=find(SplitData.Trials(:,4)==1);
            FATrialIndex=find(SplitData.Trials(:,4)==3);
            CRTrialIndex=find(SplitData.Trials(:,4)==4);
            
            ACTrialIndex=find(SplitData.Trials(:,5)==1);
            BDTrialIndex=find(SplitData.Trials(:,5)==2);
            ADTrialIndex=find(SplitData.Trials(:,5)==3);
            BCTrialIndex=find(SplitData.Trials(:,5)==4);
            PairedTrialIndex=find(SplitData.Trials(:,5)==1|SplitData.Trials(:,5)==2);
            UnPairedTrialIndex=find(SplitData.Trials(:,5)==2|SplitData.Trials(:,5)==3);
            ShuffledPairedTrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
            ShuffledUnPairedTrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
            
            ShuffledATrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
            ShuffledBTrialIndex=randi(size(SplitData.Trials,1),floor(size(SplitData.Trials,1)/2),1);
            ATrialIndex=find(SplitData.Trials(:,2)==1);
            BTrialIndex=find(SplitData.Trials(:,2)==2);
            CTrialIndex=find(SplitData.Trials(:,3)==3);
            DTrialIndex=find(SplitData.Trials(:,3)==4);
            for itr1=1:size(SingleUnitIndex,1)
                tempUnitID{itr1,1}=[DataID '-Unit' num2str(SingleUnitIndex(itr1,1)*10+SingleUnitIndex(itr1,2))];
                tempHitTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(HitTrialIndex,:);
                tempFATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(FATrialIndex,:);
                tempCRTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(CRTrialIndex,:);
                
                tempACTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ACTrialIndex,:);
                tempBDTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BDTrialIndex,:);
                tempADTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ADTrialIndex,:);
                tempBCTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BCTrialIndex,:);
                tempPairedTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(PairedTrialIndex,:);
                tempUnPairedTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(UnPairedTrialIndex,:);
                
                tempATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ATrialIndex,:);
                tempBTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(BTrialIndex,:);
                tempCTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(CTrialIndex,:);
                tempDTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(DTrialIndex,:);
                tempShuffledATrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ShuffledATrialIndex,:);
                tempShuffledBTrialsFR{itr1,1}=SplitData.SpikeCounts{itr1,1}(ShuffledBTrialIndex,:);
                
                
            end
            AllUnitID=[AllUnitID;tempUnitID];
            AllTrialsFR=[AllTrialsFR;SplitData.SpikeCounts];
            
            AllHitTrialsFR=[AllHitTrialsFR;tempHitTrialsFR];
            AllFATrialsFR=[AllFATrialsFR;tempFATrialsFR];
            AllCRTrialsFR=[AllCRTrialsFR;tempCRTrialsFR];
            
            AllACTrialsFR=[AllACTrialsFR;tempACTrialsFR];
            AllBDTrialsFR=[AllBDTrialsFR;tempBDTrialsFR];
            AllADTrialsFR=[AllADTrialsFR;tempADTrialsFR];
            AllBCTrialsFR=[AllBCTrialsFR;tempBCTrialsFR];
            AllPairedTrialsFR=[AllPairedTrialsFR;tempPairedTrialsFR];
            AllUnPairedTrialsFR=[AllUnPairedTrialsFR;tempUnPairedTrialsFR];
            
            AllATrialsFR=[AllATrialsFR;tempATrialsFR];
            AllBTrialsFR=[AllBTrialsFR;tempBTrialsFR];
            AllCTrialsFR=[AllCTrialsFR;tempCTrialsFR];
            AllDTrialsFR=[AllDTrialsFR;tempDTrialsFR];
            AllShuffledATrialsFR=[AllShuffledATrialsFR;tempShuffledATrialsFR];
            AllShuffledBTrialsFR=[AllShuffledBTrialsFR;tempShuffledBTrialsFR];
            
        end
    end
    
    if ischar(SplitPath)
        cd(SplitPath);
    else
        cd(SplitPath{1});
    end
end
save(['PopulationNeuralActivity'],'AllUnitID','AllTrialsFR','AllACTrialsFR','AllBDTrialsFR','AllADTrialsFR','AllBCTrialsFR','AllPairedTrialsFR','AllUnPairedTrialsFR',...
    'AllATrialsFR','AllBTrialsFR','AllCTrialsFR','AllDTrialsFR','AllHitTrialsFR','AllFATrialsFR','AllCRTrialsFR','AllShuffledATrialsFR','AllShuffledBTrialsFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain')

%% plot cross trial normalized neural activity for each unit

%%%plot each unit Normalized FR
for itr2=1:size(AllUnitID,1)
    
    x=AllTrialsFR{itr2,1}*10;TrialNum=size(x,1);
    tempNormlizedFR{itr2,1}=(x-mean(mean(x(:,10:19),2)))./std(mean(x(:,10:19),2),0,1);
    PlotCrossSpecificTrialsNormalizedFRforEachUnit(tempNormlizedFR{itr2,1},TrialNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
    saveas(gcf,[AllUnitID{itr2,1} 'CrossAllTrialNormalizedFR'],'fig')
    saveas(gcf,[AllUnitID{itr2,1} 'CrossAllTrialNormalizedFR'],'png')
    close all
end

%% % get all units normalized FR in specific trials
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitAllTrialNormalizedFR'],'png')
close all
AllUnitsAllTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllACTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitACTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitACTrialNormalizedFR'],'png')
close all
AllUnitsACTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllADTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitADTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitADTrialNormalizedFR'],'png')
close all
AllUnitsADTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBCTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitBCTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitBCTrialNormalizedFR'],'png')
close all
AllUnitsBCTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBDTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitBDTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitBDTrialNormalizedFR'],'png')
close all
AllUnitsBDTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllATrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitATrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitATrialNormalizedFR'],'png')
close all
AllUnitsATrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllBTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitBTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitBTrialNormalizedFR'],'png')
close all
AllUnitsBTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllCTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitCTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitCTrialNormalizedFR'],'png')
close all
AllUnitsCTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllDTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitDTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitDTrialNormalizedFR'],'png')
close all
AllUnitsDTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllHitTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitHitTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitHitTrialNormalizedFR'],'png')
close all
AllUnitsHitTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllFATrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitFATrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitFATrialNormalizedFR'],'png')
close all
AllUnitsFATrialsNrmolizedFR=Target;
clear('Target','TargetNum')


[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllCRTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitCRTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitCRTrialNormalizedFR'],'png')
close all
AllUnitsCRTrialsNrmolizedFR=Target;
clear('Target','TargetNum')


[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllPairedTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitPariedTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitPairedTrialNormalizedFR'],'png')
close all
AllUnitsPairedTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllUnPairedTrialsFR,AllUnitID,TimeGain);
PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain)
saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'fig')
saveas(gcf,['CrossUnitUnPairedTrialNormalizedFR'],'png')
close all
AllUnitsUnPairedTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledATrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledATrialsNrmolizedFR=Target;
clear('Target','TargetNum')
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(AllShuffledBTrialsFR,AllUnitID,TimeGain);
AllUnitsShuffledBTrialsNrmolizedFR=Target;
clear('Target','TargetNum')

save(['NormalizedPopulationNeuralActivity'],'AllUnitID','AllUnitsAllTrialsNrmolizedFR','AllUnitsACTrialsNrmolizedFR','AllUnitsADTrialsNrmolizedFR','AllUnitsBCTrialsNrmolizedFR',...
    'AllUnitsBDTrialsNrmolizedFR','AllUnitsATrialsNrmolizedFR','AllUnitsBTrialsNrmolizedFR','AllUnitsCTrialsNrmolizedFR','AllUnitsDTrialsNrmolizedFR','AllUnitsHitTrialsNrmolizedFR',...
    'AllUnitsFATrialsNrmolizedFR','AllUnitsCRTrialsNrmolizedFR','AllUnitsShuffledATrialsNrmolizedFR','AllUnitsShuffledBTrialsNrmolizedFR',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain')

%% plot sample selectivity for each neuron (using neural firing rate)
PlotSelectivity(AllPairedTrialsFR,AllUnPairedTrialsFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitPaired&UnPairedTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitPaired&UnPairedTrialSelectivy'],'png')
close all
PlotSelectivity(AllATrialsFR,AllBTrialsFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitSampleTrialSelectivy'],'png')
% print(gcf,'-depsc',['PopulationUnitSampleTrialSelectivyDay4','.eps'])
close all

AllFAAndCRTrialFR=[];
for tempi=1:size(AllUnitID,1)
    AllFAAndCRTrialFR{tempi,1}=[AllFATrialsFR{tempi,1};AllCRTrialsFR{tempi,1}];
end

PlotSelectivity(AllHitTrialsFR,AllFAAndCRTrialFR,AllShuffledATrialsFR,AllShuffledBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID)
saveas(gcf,['PopulationUnitRewardTrialSelectivy'],'fig')
saveas(gcf,['PopulationUnitRewardTrialSelectivy'],'png')
% print(gcf,'-depsc',['PopulationUnitRewardTrialSelectivyDay4','.eps'])
close all



%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PlotPopulationUnitsAverageFRofSpecificTrials(AllTrialsFR,{},FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitAllTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitAllTrialAverageFR'],'png')
close all
% print(gcf,'-depsc',['CrossUnitAllTrialAverageFR','.eps'])
PlotPopulationUnitsAverageFRofSpecificTrials(AllACTrialsFR,AllADTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitAC&ADTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitAC&ADTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllBCTrialsFR,AllBDTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitBC&BDTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitBC&BDTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllATrialsFR,AllBTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitDifferentSampleTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitDifferentSampleTrialAverageFR'],'png')
close all
PlotPopulationUnitsAverageFRofSpecificTrials(AllCTrialsFR,AllDTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitDifferentTestTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitDifferentTestTrialAverageFR'],'png')
close all

PlotPopulationUnitsAverageFRofSpecificTrials(AllPairedTrialsFR,AllUnPairedTrialsFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitPaired&UnPairedTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitPaired&UnPairedTrialAverageFR'],'png')
close all
PlotPopulationUnitsAverageFRofSpecificTrials(AllHitTrialsFR,AllFAAndCRTrialFR,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain);
saveas(gcf,['CrossUnitHit&FA&CRTrialAverageFR'],'fig')
saveas(gcf,['CrossUnitHit&FA&CRTrialAverageFR'],'png')
close all

%% %%%%%%%%%%%%%%%%%%%%%%%%%%
PlotSingleUnitSelectivity()
    ps=ones(size(AllUnitID,1),1);
for itr=1:size(AllUnitID,1)
    SelctivityData=(mean(AllATrialsFR{itr,1},1)-mean(AllBTrialsFR{itr,1},1))./(mean(AllATrialsFR{itr,1},1)+mean(AllBTrialsFR{itr,1},1));
    ShuffledData=(mean(AllShuffledATrialsFR{itr,1},1)-mean(AllShuffledBTrialsFR{itr,1},1))./(mean(AllShuffledATrialsFR{itr,1},1)+mean(AllShuffledBTrialsFR{itr,1},1));
    
    YMAX=max([SelctivityData ShuffledData])*1.5;
%     
%     plot([-2:0.1:floor(DPALen)-2],smooth(SelctivityData,10),'r','LineWidth',1.5)
%     hold on
%     plot([-2:0.1:floor(DPALen)-2],smooth(ShuffledData,10),'k','LineWidth',1.5)
% %     tempx1=smooth(mean(SelectivityData,1)-std(SelectivityData,0,1)/sqrt(size(SelectivityData,1)-1),10);
% %     tempx2=smooth(mean(SelectivityData,1)+std(SelectivityData,0,1)/sqrt(size(SelectivityData,1)-1),10);
% %     fill([X,fliplr(X)],[tempx1',fliplr(tempx2')],...
% %         [1 0 0],'edgecolor','none','FaceAlpha',0.3)
% %     tempy1=smooth(mean(ShuffledData,1)-std(ShuffledData,0,1)/sqrt(size(ShuffledData,1)-1),10);
% %     tempy2=smooth(mean(ShuffledData,1)+std(ShuffledData,0,1)/sqrt(size(ShuffledData,1)-1),10);
% %     fill([X,fliplr(X)],[tempy1',fliplr(tempy2')],...
% %         [0 0 0],'edgecolor','none','FaceAlpha',0.3)
%     set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2])
%     h1=area([0 FirstOdorLen],YMAX*[1 1],-1);set(get(h1,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
%     hold on
%     h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],YMAX*[1 1],-1);set(get(h2,'Child'),'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
%     h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],YMAX*[1 1],-1);set(get(h3,'Child'),'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water
%     box off
%     xlabel('Time (Sec)');% Create xlabel
%     ylabel('Selectivity');% Create ylabel

    for itrx=1:1% 1s bin; itrx:delay�ĵ�itrx��
        a=SelctivityData(1,(itrx+1)*10+1:(itrx+2)*10);
        b=ShuffledData(1,(itrx+1)*10+1:(itrx+2)*10);
        ps(itr,itrx)=ranksum(a',b');
%         if pReward(itr,itrx)<0.05
%             plot(itrx+6.5,YMAX,'k','MarkerFaceColor',[0 0 0],'MarkerSize',8,'Marker','*','LineStyle','none');
%             hold on
%         end
    end
%     saveas(gcf,[AllUnitID{itr,1} '-RewardTrialSelectivity'],'fig')
%     saveas(gcf,[AllUnitID{itr,1} '-RewardTrialSelectivity'],'png')
%     close all
%     
    
end
%% neurons averaged FR distribution
FR=cellfun(@mean,AllTrialsFR,'UniformOutput',false);
AllFR=10*cell2mat(FR);
NormolizedFR=(AllFR-mean(mean(AllFR(:,10:19)),2))/std(mean(AllFR(:,10:19),2));



MeanFR=cellfun(@mean,FR,'UniformOutput',false);
tempMeanFR=cell2mat(MeanFR);
AVGFR=10*tempMeanFR;
FRNum=[];
for itr=1:10
    FRNum(itr)=length(find(AVGFR<itr*10&AVGFR>=(itr-1)*10));
end
ssindex=zeros(178,1);
for itr=1:178
    if ps(itr)<0.05
        ssindex(itr)=1;
    end
    
end

NormalizedFR=cellfun(@mean,AllTrialsFR,'UniformOutput',false);

%% %%%%%%%% ���� maximum value of delay activity ����
tempDecsendNormFRForAllUnits = sortrows([mean(AllUnitsAllTrialsNrmolizedFR(:,31:90),2) AllUnitsAllTrialsNrmolizedFR],-1);
DecsendNormFRForAllUnits = tempDecsendNormFRForAllUnits(:,2:end); 

