 %% load FP
                ADFreq=1000;%Plexon sample rate for AD signal
                for itr = 1:64 % from channel1 to Channel64
                    str=num2str(itr,'%03d');% switch number to string and by type of 001;
                    tempChannel=['TETFP' str]; % channel name in pl2 file
                    FP_Channel(1,itr)={tempChannel};
                    tempFP=PL2Ad(RawdataFileName,tempChannel); %read specific channel pf local field potential
                    FP(:,itr)=tempFP.Values; % column for channel number
                end