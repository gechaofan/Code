function LaserPulseTaggedUnitIndex=IdentifyUnitByLaserPulse(Laser,NewSpikes)
% Laser pulse duration = 5ms;
% and the laser signal was the end timestamp(Laser start timestamp = laser timestamp -0.005ms)
% usually test 1,5,10,20,40Hz
DiffLaser=diff(Laser);


tempLaser1HzIndex=find(DiffLaser>0.9&DiffLaser<1.1)+1;
tempLaser5HzIndex=find(DiffLaser>0.19&DiffLaser<0.21)+1;
tempLaser10HzIndex=find(DiffLaser>0.09&DiffLaser<0.11)+1;
tempLaser20HzIndex=find(DiffLaser>0.04&DiffLaser<0.06)+1;
tempLaser40HzIndex=find(DiffLaser>0.02&DiffLaser<0.03)+1;

CycleNum=floor(length(tempLaser1HzIndex)/9);
Laser1Hz=zeros(10,CycleNum);
Laser5Hz=zeros(10,CycleNum);
Laser10Hz=zeros(10,CycleNum);
Laser20Hz=zeros(10,CycleNum);
Laser40Hz=zeros(10,CycleNum);
for itr = 1: CycleNum
    Laser1HzIndex=[(itr-1)*50+1;tempLaser1HzIndex((itr-1)*9+1:itr*9,1)];
    Laser1Hz(:,itr)=Laser(Laser1HzIndex,1);
    Laser5HzIndex=[(itr-1)*50+11;tempLaser5HzIndex((itr-1)*9+1:itr*9,1)];
    Laser5Hz(:,itr)=Laser(Laser5HzIndex,1);
    Laser10HzIndex=[(itr-1)*50+21;tempLaser10HzIndex((itr-1)*9+1:itr*9,1)];
    Laser10Hz(:,itr)=Laser(Laser10HzIndex,1);
    Laser20HzIndex=[(itr-1)*50+31;tempLaser20HzIndex((itr-1)*9+1:itr*9,1)];
    Laser20Hz(:,itr)=Laser(Laser20HzIndex,1);
    Laser40HzIndex=[(itr-1)*50+41;tempLaser40HzIndex((itr-1)*9+1:itr*9,1)];
    Laser40Hz(:,itr)=Laser(Laser40HzIndex,1);
end
%% test spikes following laser pulse
% test 10 & 20 Hz  
 % 10 frequences
    tempIndex1=reshape(Laser10Hz,[],1);
    tempIndex2=reshape(Laser20Hz,[],1);
    x=NewSpikes{1,1}(:,3);
    for i=1:length(tempIndex)
        find(x>tempIndex(i,1)&x<tempIndex(i,1)+0.005)
    end
    
    
    




end