%
%%

SummarizedData=ls();
load(SummarizedData);

Input=[AmplitudeRatio Trough_to_Peak_Duration];
Input1=[AmplitudeRatio AveragedFR];
ClusterNum=2;
UnitNum=size(Input,1);
ClusterIDX=kmeans(Input,ClusterNum);% K-��ֵ�㷨
figure('color',[1 1 1])
plot(Input(:,1),Input(:,2),'k.');
hold on

for i =1 : UnitNum
    text(Input(i,1),Input(i,2),num2str(ClusterIDX(i))); 
end
y=pdist(Input);
z=linkage(y);
t=cluster(z,'cutoff',1.2);
for i= 1 : UnitNum
    text(Input(i,1),Input(i,2),num2str(ClusterIDX(i)));
end

DAUnitIndex=find(ClusterIDX==1);
NonDAUnitIndex=find(ClusterIDX==2);


AllBTrialsFR(DAUnitIndex)
AllATrialsFR(DAUnitIndex)