%%% signal-to-noise ratio analysis
% signal = |FR1-FR2|; Noise = Variance1 + Variance2;

temp1 =ReDefineBinSize(LaserOnAllATrialsFR,500,100);
temp2 =ReDefineBinSize(LaserOnAllBTrialsFR,500,100);
temp3 =ReDefineBinSize(LaserOffAllATrialsFR,500,100);
temp4 =ReDefineBinSize(LaserOffAllBTrialsFR,500,100);

MeanFRCrossTrial_LaserOn1 = cell2mat(cellfun(@mean, temp1,'UniformOutput', false));
MeanFRCrossTrial_LaserOn2 = cell2mat(cellfun(@mean, temp2,'UniformOutput', false));
VarFRCrossTriak_LaserOn1 = cell2mat(cellfun(@var, temp1,'UniformOutput', false));
VarFRCrossTriak_LaserOn2 = cell2mat(cellfun(@var, temp2,'UniformOutput', false));
SNR_LaserOn=((MeanFRCrossTrial_LaserOn1-MeanFRCrossTrial_LaserOn2).^2)./(VarFRCrossTriak_LaserOn1+VarFRCrossTriak_LaserOn2);
MeanFRCrossTrial_LaserOff1 = cell2mat(cellfun(@mean, temp3,'UniformOutput', false));
MeanFRCrossTrial_LaserOff2 = cell2mat(cellfun(@mean, temp4,'UniformOutput', false));
VarFRCrossTriak_LaserOff1 = cell2mat(cellfun(@var, temp3,'UniformOutput', false));
VarFRCrossTriak_LaserOff2 = cell2mat(cellfun(@var, temp4,'UniformOutput', false));
SNR_LaserOff=((MeanFRCrossTrial_LaserOff1-MeanFRCrossTrial_LaserOff2).^2)./(VarFRCrossTriak_LaserOff1+VarFRCrossTriak_LaserOff2);