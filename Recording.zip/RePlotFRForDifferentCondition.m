clear all
clc

PlotSingleUnitSelectivity=1;
TimeGain=10;
PlotNormalizedFRForSingleUnit=1;
[filename, pathname]=uigetfile('.mat','multiselect','on');%
if ischar(filename)
    MainCircleN=1;
else
    MainCircleN=size(filename,2);
end
%%
% step 1
WaveFormSampleNum=58;%TDT=34,Plexon=58, HuPlexon=54;waveform length 1450um,325us prethreshold
TrialNumPerBlock=20;%define the trial number in one session0..
TimeGain=10;%define the bin size
TimestampFrequency=40000;
RefrISI=0.002; %refractory period=2ms;
DataType=1;%1 for .pl2 file; 2 for .plx file;
TaskType=3;%%% PAL=3;
TrainingType = 2; % For Plexon Recording Using Code form GXW
OdorPairs=1234;


for itr=1:MainCircleN
    load(filename{itr});
    DataID=[];DataID=filename{1,itr}(1,11:end-4);
    if ~isempty(SingleUnitIndex)
        
        HitTrialIndex=[];
        FATrialIndex=[];
        CRTrialIndex=[];
        ATrialIndex=[];
        BTrialIndex=[];
        CTrialIndex=[];
        DTrialIndex=[];
        
        
        HitTrialIndex=find(SplitData.Trials(:,4)==1);
        FATrialIndex=find(SplitData.Trials(:,4)==3);
        CRTrialIndex=find(SplitData.Trials(:,4)==4);
        ATrialIndex=find(SplitData.Trials(:,2)==1&SplitData.Trials(:,4)==1|SplitData.Trials(:,2)==1&SplitData.Trials(:,4)==4);
        BTrialIndex=find(SplitData.Trials(:,2)==2&SplitData.Trials(:,4)==1|SplitData.Trials(:,2)==2&SplitData.Trials(:,4)==4);
        CTrialIndex=find(SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==1|SplitData.Trials(:,3)==3&SplitData.Trials(:,4)==4);
        DTrialIndex=find(SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==1|SplitData.Trials(:,3)==4&SplitData.Trials(:,4)==4);
        for itr8 = 1:size(SingleUnitIndex,1)
           
            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(ATrialIndex,:),SplitData.SpikeCounts{itr8,1}(BTrialIndex,:),...
                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0.85 0.35 1],[0.46 0.67 0.18]);
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-DifferntSampleTrialsFRCurve'],'fig')
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-DifferntSampleTrialsFRCurve'],'png')
            close all
            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(CTrialIndex,:),SplitData.SpikeCounts{itr8,1}(DTrialIndex,:),...
                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0.45 0.75],[0.5 0.18 0.56]);
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-DifferntTestTrialsFRCurve'],'fig')
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-DifferntTestTrialsFRCurve'],'png')
            close all
            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(HitTrialIndex,:),SplitData.SpikeCounts{itr8,1}(FATrialIndex,:),...
                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[1 0 0]);
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-Hit&FATrialsFRCurve'],'fig')
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-Hit&FATrialsFRCurve'],'png')
            close all
            ComparisonOfDifferentTrialTypeNeuronFiringRate(SplitData.SpikeCounts{itr8,1}(HitTrialIndex,:),SplitData.SpikeCounts{itr8,1}(CRTrialIndex,:),...
                FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 1 0]);
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-Hit&CRTrialsFRCurve'],'fig')
            saveas(gcf,[DataID 'Unit' num2str(SingleUnitIndex(itr8,1)*10+SingleUnitIndex(itr8,2)) '-Hit&CRTrialsFRCurve'],'png')
            close all
        end
        
    end
end



