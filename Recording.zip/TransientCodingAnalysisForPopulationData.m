% this code is used for analyze transient coding or firing

Index_Increased_Early_500_1st=setdiff(Index_Increased_Early_WithBin500{1,1},unique([Index_Increased_Early_WithBin500{1,2};Index_Increased_Early_WithBin500{1,3};Index_Increased_Early_WithBin500{1,4}]));
Index_Increased_Early_2000=intersect(Index_Increased_Early_WithBin500{1,1},Index_Increased_Early_WithBin500{1,4});
Index_Increased_Early_1000_1500=setdiff(unique([Index_Increased_Early_WithBin500{1,1};Index_Increased_Early_WithBin500{1,2};Index_Increased_Early_WithBin500{1,3};Index_Increased_Early_WithBin500{1,4}]),[Index_Increased_Early_500_1st;Index_Increased_Early_2000]);
Index_Increased_Early_2500_Only=setdiff(Index_Increased_Early_WithBin500{1,5},unique([Index_Increased_Early_WithBin500{1,1};Index_Increased_Early_WithBin500{1,2};Index_Increased_Early_WithBin500{1,3};Index_Increased_Early_WithBin500{1,4}]));
Learn_Index_Increased_Early_500_1st=intersect(Index_Increased_Early_WithBin500{1,1},Learn_UnitIndex_CLE);
Learn_Index_Increased_Early_2000=intersect(Index_Increased_Early_2000,Learn_UnitIndex_CLE);
Learn_Index_Increased_Early_1000_1500=intersect(Index_Increased_Early_1000_1500,Learn_UnitIndex_CLE);
Learn_Index_Increased_Early_2500_Only=intersect(Index_Increased_Early_2500_Only,Learn_UnitIndex_CLE);
Learn_Index_Increased_Early_2500=intersect(Index_Increased_Early_WithBin500{1,5},Learn_UnitIndex_CLE);

%% analysis for norm.FR peak
NewNormFR_AllTrials_LaserOff=cellfun(@(x) x(1:80,:),NormAllTrialsFR_LaserOff,'un',0);
NewNormFR_AllTrials_LaserOnEarlyDelay=cellfun(@(x) x(21:100,:),NormAllTrialsFR_LaserOnEarlyDelay,'un',0);
NewNormFR_AllTrials_LaserOnLateDelay=cellfun(@(x) x(1:80,:),NormAllTrialsFR_LaserOnLateDelay,'un',0);
% stat for delay activity
[P_Delay_LaserOff_500,Sign_Delay_LaserOff_500,NormFR_LaserOff_500]= DelayActivityWithSpecificBin(NewNormFR_AllTrials_LaserOff,500,100,[3:4],0,1);% 1 positive delay activity ; 2 negative delay activity
[P_Delay_LaserOn_EarlyDelay_500,Sign_Delay_LaserOn_EarlyDelay_500,NormFR_LaserOn_EarlyDelay_500]= DelayActivityWithSpecificBin(NewNormFR_AllTrials_LaserOnEarlyDelay,500,100,[3:4],0,1);
[P_Delay_LaserOn_LateDelay_500,Sign_Delay_LaserOn_LateDelay_500,NormFR_LaserOn_LateDelay_500]= DelayActivityWithSpecificBin(NewNormFR_AllTrials_LaserOnLateDelay,500,100,[3:4],0,1);
Mean_NormFR_LaserOff_500=cell2mat(cellfun(@(x) mean(x,1),NormFR_LaserOff_500,'un',0));
Mean_NormFR_LaserOn_EarlyDelay_500=cell2mat(cellfun(@(x) mean(x,1),NormFR_LaserOn_EarlyDelay_500,'un',0));
Mean_NormFR_LaserOn_LateDelay_500=cell2mat(cellfun(@(x) mean(x,1),NormFR_LaserOn_LateDelay_500,'un',0));
% all Units
[Index_Increase_LaserOff_500,Index_Sig_Increase_LaserOff_500,Index_Decrease_LaserOff_500,Index_Sig_Decrease_LaserOff_500]=Distribution_NormFR(Mean_NormFR_LaserOff_500,P_Delay_LaserOff_500,5,18,0.2,2);
[Num_Sig_Bin_LaserOff_NormFR_Positive,Num_NonSig_Bin_LaserOff_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(:,5:18),Index_Increase_LaserOff_500,Index_Sig_Increase_LaserOff_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOff');
[Num_Sig_Bin_LaserOff_NormFR_Negative,Num_NonSig_Bin_LaserOff_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(:,5:18),Index_Decrease_LaserOff_500,Index_Sig_Decrease_LaserOff_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOff');

[Index_Increase_LaserOn_EarlyDelay_500,Index_Sig_Increase_LaserOn_EarlyDelay_500,Index_Decrease_LaserOn_EarlyDelay_500,Index_Sig_Decrease_LaserOn_EarlyDelay_500]=Distribution_NormFR(Mean_NormFR_LaserOn_EarlyDelay_500,P_Delay_LaserOn_EarlyDelay_500,5,18,0.2,2);
[Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Positive,Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(:,5:18),Index_Increase_LaserOn_EarlyDelay_500,Index_Sig_Increase_LaserOn_EarlyDelay_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOn_EarlyDelay');
[Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Negative,Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(:,5:18),Index_Decrease_LaserOn_EarlyDelay_500,Index_Sig_Decrease_LaserOn_EarlyDelay_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOn_EarlyDelay');

[Index_Increase_LaserOn_LateDelay_500,Index_Sig_Increase_LaserOn_LateDelay_500,Index_Decrease_LaserOn_LateDelay_500,Index_Sig_Decrease_LaserOn_LateDelay_500]=Distribution_NormFR(Mean_NormFR_LaserOn_LateDelay_500,P_Delay_LaserOn_LateDelay_500,5,18,0.2,2);
[Num_Sig_Bin_LaserOn_LateDelay_NormFR_Positive,Num_NonSig_Bin_LaserOn_LateDelay_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_LateDelay_500(:,5:18),Index_Increase_LaserOn_LateDelay_500,Index_Sig_Increase_LaserOn_LateDelay_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOn_LateDelay');
[Num_Sig_Bin_LaserOn_LateDelay_NormFR_Negative,Num_NonSig_Bin_LaserOn_LateDelay_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_LateDelay_500(:,5:18),Index_Decrease_LaserOn_LateDelay_500,Index_Sig_Decrease_LaserOn_LateDelay_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOn_LateDelay');
% learn units
[Learn_Index_Increase_LaserOff_500,Learn_Index_Sig_Increase_LaserOff_500,Learn_Index_Decrease_LaserOff_500,Learn_Index_Sig_Decrease_LaserOff_500]=Distribution_NormFR(Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,:),P_Delay_LaserOff_500(Learn_UnitIndex_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOff_NormFR_Positive,Learn_Num_NonSig_Bin_LaserOff_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Increase_LaserOff_500,Learn_Index_Sig_Increase_LaserOff_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOff_Learn');
[Learn_Num_Sig_Bin_LaserOff_NormFR_Negative,Learn_Num_NonSig_Bin_LaserOff_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Decrease_LaserOff_500,Learn_Index_Sig_Decrease_LaserOff_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOff_Learn');

[Learn_Index_Increase_LaserOn_EarlyDelay_500,Learn_Index_Sig_Increase_LaserOn_EarlyDelay_500,Learn_Index_Decrease_LaserOn_EarlyDelay_500,Learn_Index_Sig_Decrease_LaserOn_EarlyDelay_500]=Distribution_NormFR(Mean_NormFR_LaserOn_EarlyDelay_500(Learn_UnitIndex_CLE,:),P_Delay_LaserOn_EarlyDelay_500(Learn_UnitIndex_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Positive,Learn_Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Increase_LaserOn_EarlyDelay_500,Learn_Index_Sig_Increase_LaserOn_EarlyDelay_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOn_EarlyDelay_Learn');
[Learn_Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Negative,Learn_Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Decrease_LaserOn_EarlyDelay_500,Learn_Index_Sig_Decrease_LaserOn_EarlyDelay_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOn_EarlyDelay_Learn');

[Learn_Index_Increase_LaserOn_LateDelay_500,Learn_Index_Sig_Increase_LaserOn_LateDelay_500,Learn_Index_Decrease_LaserOn_LateDelay_500,Learn_Index_Sig_Decrease_LaserOn_LateDelay_500]=Distribution_NormFR(Mean_NormFR_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,:),P_Delay_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOn_LateDelay_NormFR_Positive,Learn_Num_NonSig_Bin_LaserOn_LateDelay_NormFR_Positive]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Increase_LaserOn_LateDelay_500,Learn_Index_Sig_Increase_LaserOn_LateDelay_500,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOn_LateDelay_Learn');
[Learn_Num_Sig_Bin_LaserOn_LateDelay_NormFR_Negative,Learn_Num_NonSig_Bin_LaserOn_LateDelay_NormFR_Negative]=PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,5:18),Learn_Index_Decrease_LaserOn_LateDelay_500,Learn_Index_Sig_Decrease_LaserOn_LateDelay_500,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOn_LateDelay_Learn');
% Learn , early delay Laser Increased Units
[Learn_Index_Increase_LaserOff_500_EarlyIncrease,Learn_Index_Sig_Increase_LaserOff_500_EarlyIncrease,Learn_Index_Decrease_LaserOff_500_EarlyIncrease,Learn_Index_Sig_Decrease_LaserOff_500_EarlyIncrease]...
    =Distribution_NormFR(Mean_NormFR_LaserOff_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,:),P_Delay_LaserOff_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOff_NormFR_Positive_EarlyIncrease,Learn_Num_NonSig_Bin_LaserOff_NormFR_Positive_EarlyIncrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Increase_LaserOff_500_EarlyIncrease,Learn_Index_Sig_Increase_LaserOff_500_EarlyIncrease,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOff_Learn_LaserIncresed_Early');
[Learn_Num_Sig_Bin_LaserOff_NormFR_Negative_EarlyIncrease,Learn_Num_NonSig_Bin_LaserOff_NormFR_Negative_EarlyIncrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Decrease_LaserOff_500_EarlyIncrease,Learn_Index_Sig_Decrease_LaserOff_500_EarlyIncrease,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOff_Learn_LaserIncresed_Early');

[Learn_Index_Increase_LaserOn_EarlyDelay_500_EarlyIncrease,Learn_Index_Sig_Increase_LaserOn_EarlyDelay_500_EarlyIncrease,Learn_Index_Decrease_LaserOn_EarlyDelay_500_EarlyIncrease,Learn_Index_Sig_Decrease_LaserOn_EarlyDelay_500_EarlyIncrease]...
    =Distribution_NormFR(Mean_NormFR_LaserOn_EarlyDelay_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,:),P_Delay_LaserOn_EarlyDelay_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Positive_EarlyIncrease,Learn_Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Positive_EarlyIncrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_EarlyDelay_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Increase_LaserOn_EarlyDelay_500_EarlyIncrease,Learn_Index_Sig_Increase_LaserOn_EarlyDelay_500_EarlyIncrease,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOn_EarlyDelay_Learn_LaserIncresed_Early');
[Learn_Num_Sig_Bin_LaserOn_EarlyDelay_NormFR_Negative_EarlyIncrease,Learn_Num_NonSig_Bin_LaserOn_EarlyDelay_NormFR_Negative_EarlyIncrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOn_EarlyDelay_500(Learn_FRIncreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Decrease_LaserOn_EarlyDelay_500_EarlyIncrease,Learn_Index_Sig_Decrease_LaserOn_EarlyDelay_500_EarlyIncrease,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOn_EarlyDelay_Learn_LaserIncresed_Early');


% Learn , early delay Laser Decreased Units
[Learn_Index_Increase_LaserOff_500_EarlyDecrease,Learn_Index_Sig_Increase_LaserOff_500_EarlyDecrease,Learn_Index_Decrease_LaserOff_500_EarlyDecrease,Learn_Index_Sig_Decrease_LaserOff_500_EarlyDecrease]...
    =Distribution_NormFR(Mean_NormFR_LaserOff_500(Learn_FRDecreasedUnitIndex_Ealry_CLE,:),P_Delay_LaserOff_500(Learn_FRDecreasedUnitIndex_Ealry_CLE,:),5,18,0.2,2);
[Learn_Num_Sig_Bin_LaserOff_NormFR_Positive_EarlyDecrease,Learn_Num_NonSig_Bin_LaserOff_NormFR_Positive_EarlyDecrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_FRDecreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Increase_LaserOff_500_EarlyDecrease,Learn_Index_Sig_Increase_LaserOff_500_EarlyDecrease,0.2,'DistributionOfNormFRForPositiveDelayFR_LaserOff_Learn_LaserDecresed_Early');
[Learn_Num_Sig_Bin_LaserOff_NormFR_Negative_EarlyDecrease,Learn_Num_NonSig_Bin_LaserOff_NormFR_Negative_EarlyDecrease]...
    =PlotNormFRDistributionForSpecificTimeBin(Mean_NormFR_LaserOff_500(Learn_FRDecreasedUnitIndex_Ealry_CLE,5:18),Learn_Index_Decrease_LaserOff_500_EarlyDecrease,Learn_Index_Sig_Decrease_LaserOff_500_EarlyDecrease,-0.2,'DistributionOfNormFRForNegativeDelayFR_LaserOff_Learn_LaserDecresed_Early');






Learn_Mean_NormFR_LaserOff_500=Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,:);
Learn_Mean_NormFR_LaserOnEarlyDelay_500=Mean_NormFR_LaserOnEarlyDelay_500(Learn_UnitIndex_CLE,:);
Learn_Mean_NormFR_LaserOnLateDelay_500=Mean_NormFR_LaserOnLateDelay_500(Learn_UnitIndex_CLE,:);

PositiveIndex_LaserOff=find(Learn_Mean_NormFR_LaserOff_500(:,7)>0);
NegativeIndex_LaserOff=find(Learn_Mean_NormFR_LaserOff_500(:,7)<0);

NegativeIndex_LaserOnEarlyDelay=find(Learn_Mean_NormFR_LaserOnEarlyDelay_500(:,7)<0);
PositiveIndex_LaserOnEarlyDelay=find(Learn_Mean_NormFR_LaserOnEarlyDelay_500(:,7)>0);

NegativeIndex_LaserOnLateDelay=find(Learn_Mean_NormFR_LaserOnLateDelay_500(:,7)<0);
PositiveIndex_LaserOnLateDelay=find(Learn_Mean_NormFR_LaserOnLateDelay_500(:,7)>0);

%% analyze for selectivity
% max selectivity distribution, max selectivty in each time-epoch (500ms or 2s laser period)
NewLaserOffAllATrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllATrialsFR,'un',0);
NewLaserOffAllBTrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllBTrialsFR,'un',0);
NewLaserOnAllATrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllATrialsFR_EarlyDelay,'un',0);
NewLaserOnAllBTrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllBTrialsFR_EarlyDelay,'un',0);
NewLaserOnAllATrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllATrialsFR_LateDelay,'un',0);
NewLaserOnAllBTrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllBTrialsFR_LateDelay,'un',0);

LaserOffAllATrialsFR_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOffAllATrialsFR,'un',0);
LaserOffAllBTrialsFR_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOffAllBTrialsFR,'un',0);
LaserOnAllATrialsFR_EarlyDelay_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOnAllATrialsFR_EarlyDelay,'un',0);
LaserOnAllBTrialsFR_EarlyDelay_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOnAllBTrialsFR_EarlyDelay,'un',0);
LaserOnAllATrialsFR_LateDelay_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOnAllATrialsFR_LateDelay,'un',0);
LaserOnAllBTrialsFR_LateDelay_500=cellfun(@(x) smooth2(x,'moving',5),NewLaserOnAllBTrialsFR_LateDelay,'un',0);

for iNeu = 1:750
    [Selectivity_LaserOff(iNeu,:),stat_LaserOff(iNeu,:)]=CalculateSelectivityWithPermTest(LaserOffAllATrialsFR_500{iNeu,1},LaserOffAllBTrialsFR_500{iNeu,1});
    [Selectivity_LaserOn_EarlyDelay(iNeu,:),stat_LaserOn_EarlyDelay(iNeu,:)]=CalculateSelectivityWithPermTest(LaserOnAllATrialsFR_EarlyDelay_500{iNeu,1},LaserOnAllBTrialsFR_EarlyDelay_500{iNeu,1});
    [Selectivity_LaserOn_LateDelay(iNeu,:),stat_LaserOn_LateDelay(iNeu,:)]=CalculateSelectivityWithPermTest(LaserOnAllATrialsFR_LateDelay_500{iNeu,1},LaserOnAllBTrialsFR_LateDelay_500{iNeu,1});
    for iPeriod =1 : 3
        [DDI_LaserOff(iNeu,iPeriod),Index_LaserOff(iNeu,iPeriod)]=max(Selectivity_LaserOff(iNeu,31+(iPeriod-1)*20:30+iPeriod*20));
        [DDI_LaserOn_EarlyDelay(iNeu,iPeriod),Index_LaserOn_EarlyDelay(iNeu,iPeriod)]=max(Selectivity_LaserOn_EarlyDelay(iNeu,31+(iPeriod-1)*20:30+iPeriod*20));
        [DDI_LaserOn_LateDelay(iNeu,iPeriod),Index_LaserOn_LateDelay(iNeu,iPeriod)]=max(Selectivity_LaserOn_LateDelay(iNeu,31+(iPeriod-1)*20:30+iPeriod*20));
        Significant_LaserOff(iNeu,iPeriod)=(stat_LaserOff(iNeu,Index_LaserOff(iNeu,iPeriod)+30+(iPeriod-1)*20));
        Significant_LaserOn_EarlyDelay(iNeu,iPeriod)=(stat_LaserOn_EarlyDelay(iNeu,Index_LaserOn_EarlyDelay(iNeu,iPeriod)+30+(iPeriod-1)*20));
        Significant_LaserOn_LateDelay(iNeu,iPeriod)=(stat_LaserOn_LateDelay(iNeu,Index_LaserOn_LateDelay(iNeu,iPeriod)+30+(iPeriod-1)*20));
    end
end
% mix ODI(odor descrimination index) distribution
[ODIIndex_Bin_LaserOff,ODIIndex_Sig_Bin_LaserOff]=Distribution_MaxODI(DDI_LaserOff,Significant_LaserOff,0.1,[0 1],'ODI_Distribution_LaserOff_AllUnits');
[ODIIndex_Bin_LaserOn_EarlyDelay,ODIIndex_Sig_Bin_LaserOn_EarlyDelay]=Distribution_MaxODI(DDI_LaserOn_EarlyDelay,Significant_LaserOn_EarlyDelay,0.1,[0 1],'ODI_Distribution_LaserOn_EarlyDelay_AllUnits');
[ODIIndex_Bin_LaserOn_LateDelay,ODIIndex_Sig_Bin_LaserOn_LateDelay]=Distribution_MaxODI(DDI_LaserOn_LateDelay,Significant_LaserOn_LateDelay,0.1,[0 1],'ODI_Distribution_LaserOn_LateDelay_AllUnits');
close all
% learn units
[Learn_ODIIndex_Bin_LaserOff,Learn_ODIIndex_Sig_Bin_LaserOff]=Distribution_MaxODI(DDI_LaserOff(Learn_UnitIndex_CLE,:),Significant_LaserOff(Learn_UnitIndex_CLE,:),0.1,[0 1],'ODI_Distribution_LaserOff_LearnUnits');
[Learn_ODIIndex_Bin_LaserOn_EarlyDelay,Learn_ODIIndex_Sig_Bin_LaserOn_EarlyDelay]=Distribution_MaxODI(DDI_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,:),Significant_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,:),0.1,[0 1],'ODI_Distribution_LaserOn_EarlyDelay_LearnUnits');
[Learn_ODIIndex_Bin_LaserOn_LateDelay,Learn_ODIIndex_Sig_Bin_LaserOn_LateDelay]=Distribution_MaxODI(DDI_LaserOn_LateDelay(Learn_UnitIndex_CLE,:),Significant_LaserOn_LateDelay(Learn_UnitIndex_CLE,:),0.1,[0 1],'ODI_Distribution_LaserOn_LateDelay_LearnUnits');
% early Laser Changed Units
[EarlyChanged_Learn_ODIIndex_Bin_LaserOff,EarlyChanged_Learn_ODIIndex_Sig_Bin_LaserOff]=Distribution_MaxODI(DDI_LaserOff([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),Significant_LaserOff([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),0.1,[0 1],'ODI_Distribution_LaserOff_LearnUnits_EarlyChanged');
[EarlyChanged_Learn_ODIIndex_Bin_LaserOn_EarlyDelay,EarlyChanged_Learn_ODIIndex_Sig_Bin_LaserOn_EarlyDelay]=Distribution_MaxODI(DDI_LaserOn_EarlyDelay([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),Significant_LaserOn_EarlyDelay([Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE],:),0.1,[0 1],'ODI_Distribution_LaserOn_EarlyDelay_LearnUnits_EarkyChanged');

% Late Laser Changed Units
[LateChanged_Learn_ODIIndex_Bin_LaserOff,LateChanged_Learn_ODIIndex_Sig_Bin_LaserOff]=Distribution_MaxODI(DDI_LaserOff([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),Significant_LaserOff([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),0.1,[0 1],'ODI_Distribution_LaserOff_LearnUnits_LateChanged');
[LateChanged_Learn_ODIIndex_Bin_LaserOn_LateDelay,LateChanged_Learn_ODIIndex_Sig_Bin_LaserOn_LateDelay]=Distribution_MaxODI(DDI_LaserOn_LateDelay([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),Significant_LaserOn_LateDelay([Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE],:),0.1,[0 1],'ODI_Distribution_LaserOn_LateDelay_LearnUnits_LateChanged');

Learn_Sign_NormDelayFR_LaserOff_500=Sign_Delay_LaserOff_500(Learn_UnitIndex_CLE,:);% 1 positive delay activity ; 2 negative delay activity
Learn_Sign_NormDelayFR_LaserOff_500(Learn_Sign_NormDelayFR_LaserOff_500==2)=-1;
Learn_Sign_NormDelayFR_LaserOn_Early_500=Sign_Delay_LaserOn_EarlyDelay_500(Learn_UnitIndex_CLE,:);
Learn_Sign_NormDelayFR_LaserOn_Early_500(Learn_Sign_NormDelayFR_LaserOn_Early_500==2)=-1;
Learn_Sign_NormDelayFR_LaserOn_Late_500=Sign_Delay_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,:);
Learn_Sign_NormDelayFR_LaserOn_Late_500(Learn_Sign_NormDelayFR_LaserOn_Late_500==2)=-1;
Learn_In_Early_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,7:10),2)>0);
Learn_De_Early_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,7:10),2)<0);
Learn_Non_Early_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,7:10),2)==0);
Learn_In_Early_LaserOn_Early=find(sum(Learn_Sign_NormDelayFR_LaserOn_Early_500(:,7:10),2)>0);
Learn_De_Early_LaserOn_Early=find(sum(Learn_Sign_NormDelayFR_LaserOn_Early_500(:,7:10),2)<0);
Learn_Non_Early_LaserOn_Early=find(sum(Learn_Sign_NormDelayFR_LaserOn_Early_500(:,7:10),2)==0);

Learn_In_Late_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,15:18),2)>0);
Learn_De_Late_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,15:18),2)<0);
Learn_Non_Late_LaserOff=find(sum(Learn_Sign_NormDelayFR_LaserOff_500(:,15:18),2)==0);
Learn_In_Late_LaserOn_Late=find(sum(Learn_Sign_NormDelayFR_LaserOn_Late_500(:,15:18),2)>0);
Learn_De_Late_LaserOn_Late=find(sum(Learn_Sign_NormDelayFR_LaserOn_Late_500(:,15:18),2)<0);
Learn_Non_Late_LaserOn_Late=find(sum(Learn_Sign_NormDelayFR_LaserOn_Late_500(:,15:18),2)==0);
Learn_Sig_Sle_Late_LaserOff=cell2mat(Learn_ODIIndex_Sig_Bin_LaserOff(3,:)');
Learn_Sig_Sle_Late_LaserOn_Late=cell2mat(Learn_ODIIndex_Sig_Bin_LaserOn_LateDelay(3,:)');
x11=intersect(Learn_Sig_Sle_Late_LaserOff,Learn_In_Late_LaserOff);
x22=intersect(Learn_Sig_Sle_Late_LaserOff,Learn_De_Late_LaserOff);
x33=intersect(Learn_Sig_Sle_Late_LaserOff,Learn_Non_Late_LaserOff);
z1=intersect(Learn_Sig_Sle_Late_LaserOn_Late,Learn_In_Late_LaserOn_Late);
z2=intersect(Learn_Sig_Sle_Late_LaserOn_Late,Learn_De_Late_LaserOn_Late);
z3=intersect(Learn_Sig_Sle_Late_LaserOn_Late,Learn_Non_Late_LaserOn_Late);


Learn_Sig_Sle_Early_LaserOff=cell2mat(Learn_ODIIndex_Sig_Bin_LaserOff(1,:)');
Learn_Sig_Sle_Early_LaserOn_Early=cell2mat(Learn_ODIIndex_Sig_Bin_LaserOn_EarlyDelay(1,:)');
x1=intersect(Learn_Sig_Sle_Early_LaserOff,Learn_In_Early_LaserOff);
x2=intersect(Learn_Sig_Sle_Early_LaserOff,Learn_De_Early_LaserOff);
x3=intersect(Learn_Sig_Sle_Early_LaserOff,Learn_Non_Early_LaserOff);

y1=intersect(Learn_Sig_Sle_Early_LaserOn_Early,Learn_In_Early_LaserOn_Early);
y2=intersect(Learn_Sig_Sle_Early_LaserOn_Early,Learn_De_Early_LaserOn_Early);
y3=intersect(Learn_Sig_Sle_Early_LaserOn_Early,Learn_Non_Early_LaserOn_Early);

Learn_Mean_NormFR_LaserOff_500=Mean_NormFR_LaserOff_500(Learn_UnitIndex_CLE,:);
Learn_Mean_NormFR_LaserOn_EarlyDelay_500=Mean_NormFR_LaserOn_EarlyDelay_500(Learn_UnitIndex_CLE,:);
Learn_Mean_NormFR_LaserOn_LateDelay_500=Mean_NormFR_LaserOn_LateDelay_500(Learn_UnitIndex_CLE,:);
% plot mean NormFR for Significant selective units

Learn_NewNormFR_AllTrials_LaserOff=NewNormFR_AllTrials_LaserOff(Learn_UnitIndex_CLE,:);
Learn_NewNormFR_AllTrials_LaserOnEarlyDelay=NewNormFR_AllTrials_LaserOnEarlyDelay(Learn_UnitIndex_CLE,:);
Learn_NewNormFR_AllTrials_LaserOnLateDelay=NewNormFR_AllTrials_LaserOnLateDelay(Learn_UnitIndex_CLE,:);
CompareFRForSpecificTrialsCrossNeuron(Learn_NewNormFR_AllTrials_LaserOff(Learn_Sig_Sle_Late_LaserOff,:),Learn_NewNormFR_AllTrials_LaserOnLateDelay(Learn_Sig_Sle_Late_LaserOn_Late,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['AveragedNormFR-Sig-Late_Learn_CLE'],'fig')
saveas(gcf, ['AveragedNormFR-Sig-Late_Learn_CLE'],'png')

x=mean(Mean_NormFR_LaserOff_500(:,7:10),2);
x1=mean(Mean_NormFR_LaserOff_500(:,15:18),2);
y=mean(Mean_NormFR_LaserOn_EarlyDelay_500(:,7:10),2);
z=mean(Mean_NormFR_LaserOn_LateDelay_500(:,15:18),2);

Early_NormFR_LaserOff_Learn=mean(Learn_Mean_NormFR_LaserOff_500(:,7:10),2);
Early_NormFR_LaserOn_EarlyDelay_Learn=mean(Learn_Mean_NormFR_LaserOn_EarlyDelay_500(:,7:10),2);
Late_NormFR_LaserOff_Learn=mean(Learn_Mean_NormFR_LaserOff_500(:,15:18),2);
Late_NormFR_LaserOn_LateDelay_Learn=mean(Learn_Mean_NormFR_LaserOn_LateDelay_500(:,15:18),2);
[FitResult_FR_EalryDelay_Early_Learn_CLE, GOF_FR_EalryDelay_Early_Learn_CLE]= LinearLeastSquaresFitting(Early_NormFR_LaserOff_Learn,Early_NormFR_LaserOn_EarlyDelay_Learn,'EarlyDelay-AllUnits'); 
saveas(gcf,['NormFR-DelayActivity-EarlyDelay-AllUnits'],'fig')
saveas(gcf,['NormFR-DelayActivity-EarlyDelay-AllUnits'],'png')

[FitResult_FR_LateDelay_Late_Learn_CLE, GOF_FR_LateDelay_Late_Learn_CLE]= LinearLeastSquaresFitting(Late_NormFR_LaserOff_Learn,Late_NormFR_LaserOn_LateDelay_Learn,'LateDelay-AllUnits'); 
saveas(gcf,['NormFR-DelayActivity-LateDelay-AllUnits'],'fig')
saveas(gcf,['NormFR-DelayActivity-LateDelay-AllUnits'],'png')


Learn_New_Selectivity_LaserOff=Selectivity_LaserOff(Learn_UnitIndex_CLE,:);
Learn_New_Selectivity_LaserOnEarlyDelay=Selectivity_LaserOn_EarlyDelay(Learn_UnitIndex_CLE,:);
Learn_New_Selectivity_LaserOnLateDelay=Selectivity_LaserOn_LateDelay(Learn_UnitIndex_CLE,:);

[Index_Step_LaserOn_LateDelay,Index_Sig_Step_LaserOn_LateDelay]=Distribution_MaxODI(Index_LaserOn_LateDelay(Learn_UnitIndex_CLE,:),Significant_LaserOn_LateDelay(Learn_UnitIndex_CLE,:),100,2);
[Num_Sig_Step_LaserOn_LateDelay,Num_NonSig_Step_LaserOn_LateDelay]=PlotMaxODITimeStepDistribution(Index_LaserOn_LateDelay(Learn_UnitIndex_CLE,:),Index_Step_LaserOn_LateDelay,Index_Sig_Step_LaserOn_LateDelay,'MaxODITimeDistribution-LaserOn_LateDelay-Learn');

% max selectivity distribution, for time-point distribution



