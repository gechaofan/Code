function DotPlotUnitWaveProperty(Half_Amplitude_Duration,Trough_to_Peak)
figure('color','w')
plot(Half_Amplitude_Duration,Trough_to_Peak,'k.','MarkerSize',6);
% title 'Fisher''s Iris Data';
xlabel 'Half-Amplitude-Duration (ms)';
ylabel 'Trough-to-Peak (ms)';
end