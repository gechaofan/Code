function CompareFRForSpecificTrialsCrossNeuron(FR1,FR2,...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,Color1,Color2)
% if DataType == 1% for selectivity
%     MeanFR1=FR1;MeanFR2=FR2;
% else 
   MeanFR1=cell2mat(cellfun(@mean, FR1,'un',0));
   MeanFR2=cell2mat(cellfun(@mean, FR2,'un',0));
% end
SEM1=nanstd(MeanFR1,0,1)/sqrt(size(MeanFR1,1)-1);
SEM2=nanstd(MeanFR2,0,1)/sqrt(size(MeanFR2,1)-1);

for i = 1: size(MeanFR1,2)
    p(1,i)=ranksum(MeanFR1(:,i),MeanFR2(:,i));
end
X=[-2+0.1:0.1:floor(DPALen)-2+0.1];
figure('Color',[1 1 1])
YMin=min(smooth(nanmean(MeanFR2,1),3)')-0.1;
YMax=max(smooth(nanmean(MeanFR2,1),3)')+0.2;
plot(X,smooth(nanmean(MeanFR1,1),3,'moving')','Color',Color1,'LineWidth',1.5,'LineStyle','-');
hold on
fill([X,fliplr(X)],[smooth(nanmean(MeanFR1,1)-SEM1,3)',fliplr(smooth(nanmean(MeanFR1,1)+SEM1,3)')],...
    Color1,'edgecolor','none','FaceAlpha',0.3)
plot(X,smooth(nanmean(MeanFR2,1),3,'moving')','Color',Color2,'LineWidth',1.5,'LineStyle','-');
hold on
fill([X,fliplr(X)],[smooth(nanmean(MeanFR2,1)-SEM2,3)',fliplr(smooth(nanmean(MeanFR2,1)+SEM2,3)')],...
    Color2,'edgecolor','none','FaceAlpha',0.3)
SignificantIndex=find(p<0.05);
plot(SignificantIndex/TimeGain-2,YMax*ones(1,length(SignificantIndex)),'LineStyle','none','Marker','.','Color',[0 0 0])%2s baseline

h1=area([0 FirstOdorLen],100*[1 1]);set(h1,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor1
hold on
h2=area([(FirstOdorLen+Delay) (FirstOdorLen+Delay+SecondOdorLen)],100*[1 1]);set(h2,'FaceColor',[1 0.6 0.78],'facealpha',0.5,'LineStyle','none')% plot areas of color %odor2
h3=area([(FirstOdorLen+Delay+SecondOdorLen+Response) (FirstOdorLen+Delay+SecondOdorLen+Response+WaterLen)],100*[1 1]);set(h3,'FaceColor',[1 0.8 0],'facealpha',0.5,'LineStyle','none')% plot areas of color %water

box off
xlabel('Time (Sec)');% Create xlabel
ylabel('Firing Rate');% Create ylabel
% Create title
title([num2str(size(FR1,1)) '&' num2str(size(FR2,1))]);
set(gca,'XTickLabel',{'0','5','10','15'},'XTick',[0,5,10,15],'Xlim',[-2,floor(DPALen)-2],...
    'YLim',[YMin,YMax])
end

