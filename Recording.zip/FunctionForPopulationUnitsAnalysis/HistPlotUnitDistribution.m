function HistPlotUnitDistribution(Trough_to_Peak,BinSize,Bound)

figure('color','w')
h=histogram(Trough_to_Peak,BinSize,'Normalization','probability');
hold on
h.FaceColor=[0 0 0];
h.EdgeColor=[0 0 0];
counts=h.Values;
plot([Bound;Bound], [0; max(counts)],'LineWidth',1,'LineStyle','--','Color',[1 0 0])
box off
xlabel 'Trough-to-Peak (ms)';
ylabel 'Proportion';
end
