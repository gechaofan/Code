function [NormFR]=NormalizeFRCrossLaserCondition(FR,Laser,TimeGain)
% normalize firing rate to baseline activity(1s before sample odor delivery) in laser off conditions

% FR=cellfun(@(x) TimeGain*x,AllTrialsFR,'un',0);
% Laser=AllLaserTrialsID;
LaserType=unique(cell2mat(Laser));
LaserConditinNum=size(LaserType,1);
switch (LaserConditinNum)
    case 3
        % splite raw firing rate in each lase condition
        LaserIndex1=cellfun(@(x) find(x==LaserType(1)),Laser,'un',0);
        RawFR1=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex1,'un',0);
        
        LaserIndex2=cellfun(@(x) find(x==LaserType(2)),Laser,'un',0);
        RawFR2=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex2,'un',0);
        
        LaserIndex3=cellfun(@(x) find(x==LaserType(3)),Laser,'un',0);
        RawFR3=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex3,'un',0);
        % normlize firing rate of all laser conditions to baseline of laser off condition
        for itr=1:size(FR,1)
            NormFR1{itr,1}=(RawFR1{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR1{itr,1}(:,10:19),2),0,1);
            NormFR2{itr,1}=(RawFR2{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR2{itr,1}(:,10:19),2),0,1);
            NormFR3{itr,1}=(RawFR3{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR3{itr,1}(:,10:19),2),0,1);
        end
        NormFR=[NormFR1 NormFR2 NormFR3];
    case 2
        LaserIndex1=cellfun(@(x) find(x==LaserType(1)),Laser,'un',0);
        RawFR1=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex1,'un',0);
        
        LaserIndex2=cellfun(@(x) find(x==LaserType(2)),Laser,'un',0);
        RawFR2=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex2,'un',0);
        for itr=1:size(FR,1)
            NormFR1{itr,1}=(RawFR1{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR1{itr,1}(:,10:19),2),0,1);
            NormFR2{itr,1}=(RawFR2{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR2{itr,1}(:,10:19),2),0,1);
        end
        NormFR=[NormFR1 NormFR2];
        
    case 1
        LaserIndex1=cellfun(@(x) find(x==LaserType(1)),Laser,'un',0);
        RawFR1=cellfun(@(x,y) TimeGain*x(y,:),FR,LaserIndex1,'un',0);
        for itr=1:size(FR,1)
            NormFR1{itr,1}=(RawFR1{itr,1}-mean(mean(RawFR1{itr,1}(:,10:19),2)))./std(mean(RawFR1{itr,1}(:,10:19),2),0,1);
        end
        NormFR=NormFR1;
        
    otherwise
        
end





end