function [stat]=BarPlotDelayActivityForPopulationUnitsWithSecond(ControlData,ExprimentalData,Error_Control,Error_Exprimental)
figure('Color',[1 1 1])
errorbar([0.8:1:7.8],mean(ControlData,1),Error_Control,'Color','k','LineStyle','none')
hold on
errorbar([1.2:1:8.2],mean(ExprimentalData,1),Error_Exprimental,'Color','k','LineStyle','none')
bar([0.8:1:7.8],mean(ControlData,1),'BarWidth',0.4,'FaceColor','k');
hold on
bar([1.2:1:8.2],mean(ExprimentalData,1),'BarWidth',0.4,'FaceColor','b');
%% statistics for control and experimental group
for i=1:size(ControlData,2)
    p(1,i)=signrank(ControlData(:,i),ExprimentalData(:,i));
 
    p_Control(1,i)=ranksum(ControlData(:,1),ControlData(:,i));% delay activity for control group
    p_Experi(1,i)=ranksum(ExprimentalData(:,1),ExprimentalData(:,i));% delay activity for experimental group
    

    if p(i)<0.05
        plot(i,0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','k')
    end
    if p(i)<0.01
        plot(i+0.1,0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','k')
    end
    if p(i)<0.001
        plot(i+0.2,0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','k')
    end
    if p(i)<0.05/6
        plot(i,0.05+0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','b')
    end
    if p(i)<0.01/6
        plot(i+0.1,0.05+0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','b')
    end
    if p(i)<0.001/6
        plot(i+0.2,0.05+0.1*ceil(10*max([mean(ControlData,1) mean(ExprimentalData,1)])),'LineStyle','none','Marker','.','Color','b')
    end
    if p_Control(i)<0.05/6
        plot(i,-0.3+0.05,'LineStyle','none','Marker','*','Color','k')
    end
    if p_Control(i)<0.01/6
        plot(i+0.1,-0.3+0.05,'LineStyle','none','Marker','*','Color','k')
    end
    if p_Control(i)<0.001/6
        plot(i+0.2,-0.3+0.05,'LineStyle','none','Marker','*','Color','k')
    end
    if p_Experi(i)<0.05/6
        plot(i,-0.3,'LineStyle','none','Marker','*','Color','b')
    end
    if p_Experi(i)<0.01/6
        plot(i+0.1,-0.3,'LineStyle','none','Marker','*','Color','b')
    end
    if p_Experi(i)<0.001/6
        plot(i+0.2,-0.3,'LineStyle','none','Marker','*','Color','b')
    end
end

[rho,pval]=corr(mean(ControlData,1)',mean(ExprimentalData,1)');
stat.p=p;
stat.corr_coeff=rho;
stat.corr_p=pval;
end