function [LaserEffect] = GetLaserEffect_EcahSpiltData(SpikeCounts,GroupAIndex,GroupBIndex)

 %spikecounts with new bin size
GroupA_TrialFR =cellfun(@(x) (x(GroupAIndex,:)),SpikeCounts,'un',0);%Sipke number
GroupB_TrialFR =cellfun(@(x) (x(GroupBIndex,:)),SpikeCounts,'un',0);%Sipke number
for iNeu = 1:size(SpikeCounts,1)
    [P,Larger]=signrankTest(GroupA_TrialFR{iNeu,1},GroupB_TrialFR{iNeu,1});
    if P<0.05 && Larger==1
        LaserEffect(iNeu,1)=-1;
    elseif P<0.05 && Larger==2
        LaserEffect(iNeu,1)=1;
    else
        LaserEffect(iNeu,1)=0;
    end
    
end

end