function DotPlotUnitWith2PrametersFor2Groups(Prameter1_Group1,Prameter2_Group1,Prameter1_Group2,Prameter2_Group2)
figure('color','w')
plot(Prameter1_Group1,Prameter2_Group1,'r.','MarkerSize',6)
hold on
plot(Prameter1_Group2,Prameter2_Group2,'k.','MarkerSize',6)
box off
xlabel 'Trough-to-Peak (ms)';
ylabel 'Firing Rate (Hz)';

end