function [Trough_to_Peak_Duration_SplitData, Half_Amplitude_Duration_SplitData, MaxWaveform_out,AmplitudeRatio] = GetUnitWavePropertyForEachFile(NewSpikes,WaveformLenth,SampelRate,InterpolationNum)
%% for every SplitData file
tempMeanSpikeWave0=cellfun(@mean,NewSpikes,'UniformOUtput',false);
tempMeanSpikeWave1=cell2mat(tempMeanSpikeWave0);
tempMeanSpikeWave=tempMeanSpikeWave1(:,4:end);
[~,Trough_Index]=min(tempMeanSpikeWave,[],2);
MaxAmplitude_EL_Index=ceil(Trough_Index./58);
MaxWaveform_out = NaN * ones(size(NewSpikes,1),58);
MaxAmplitude_SpikeWave = NaN * ones(size(NewSpikes,1),WaveformLenth+(InterpolationNum-1) * (WaveformLenth-1));
X=[1:1:WaveformLenth]; Xq=[1:1/InterpolationNum:WaveformLenth];
for itr1 =1 : size(NewSpikes,1)
    tempMaxAmplitude_SpikeWave = tempMeanSpikeWave(itr1,(MaxAmplitude_EL_Index(itr1)-1)*WaveformLenth+1 : MaxAmplitude_EL_Index(itr1)*WaveformLenth);
    MaxAmplitude_SpikeWave(itr1,:) = interp1(X,tempMaxAmplitude_SpikeWave,Xq,'spline'); % insert 3 points
    MaxWaveform_out(itr1,:) = tempMaxAmplitude_SpikeWave;
end

Baseline_SpikeWave = mean(MaxAmplitude_SpikeWave(:,1 : 4*InterpolationNum),2);% averaged the first 5 points
[NewTrough,NewTrough_Index] = min(MaxAmplitude_SpikeWave,[],2);
AmpFirstPositivePeak=max(MaxAmplitude_SpikeWave(:,1:NewTrough_Index),[],2);
AmpForFirstPeak=AmpFirstPositivePeak-Baseline_SpikeWave;%amplitude of peak before valley
AmpForTrough=Baseline_SpikeWave-NewTrough;%amplitude of valley
% (n-p)/(n+p), amplitude of the first positive and negative segements:
AmplitudeRatio=(AmpForTrough-AmpForFirstPeak)./(AmpForTrough+AmpForFirstPeak);
Half_Amplitude = (Baseline_SpikeWave-NewTrough) * 0.5;
Diff_SpikeWave_Half_Amplitude = abs(MaxAmplitude_SpikeWave + Half_Amplitude);
%% duration of valley-to-peak, peak after valley
tempPeak_Index = NaN * ones(size(NewSpikes,1),1);
Half_Amplitude_LowBound_Index = NaN * ones(size(NewSpikes,1),1);
Half_Amplitude_HighBound_Index = NaN * ones(size(NewSpikes,1),1);
for itr2 =1 :size(NewSpikes,1)
    [~,tempPeak_Index(itr2,1)] = max(MaxAmplitude_SpikeWave(itr2,NewTrough_Index(itr2) : end));
    [~,Half_Amplitude_LowBound_Index(itr2,1)] = min(Diff_SpikeWave_Half_Amplitude(itr2,1:NewTrough_Index(itr2)));
    [~,Half_Amplitude_HighBound_Index(itr2,1)] = min(Diff_SpikeWave_Half_Amplitude(itr2,NewTrough_Index(itr2)+1 : end));
end
Peak_Index = tempPeak_Index + NewTrough_Index;
Trough_to_Peak_Duration_SplitData = (Peak_Index - NewTrough_Index) * 1000/SampelRate/InterpolationNum;%ms
Half_Amplitude_Duration_SplitData = (Half_Amplitude_HighBound_Index  + NewTrough_Index - Half_Amplitude_LowBound_Index) *1000/SampelRate/InterpolationNum;

end
