function [p,larger]=signrankTest(A,B)
if length(A) > length(B)% To avoide different length of A and B 
    Index = randperm(length(A),length(B)); % ���Żس���
    NewA = A(Index');
    NewB = B;
elseif length (A) <length(B)
    Index = randperm(length(B),length(A));
    NewB = B(Index');
    NewA = A;
else
    NewA = A; NewB = B;
end

p = signrank(NewA,NewB);
Diff = mean(NewA) - mean(NewB);
if Diff > 0
    larger = 1; % A > B
else
    larger = 2; % A < B
end
end