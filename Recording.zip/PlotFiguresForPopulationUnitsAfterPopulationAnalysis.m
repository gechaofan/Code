%% Plot Figures for population units after running population analysis
%% Plot Unit wave property and classification for neuron type by waveform peroperty
Trough_to_Peak = UnitWaveproperty.Trough_to_Peak;
Half_Amplitude_Duration = UnitWaveproperty.Half_Amplitude_Duration;

p_LaserEffect_AllTrials = LaserEffect.p_LaserEffect_AllTrials;                                          
p_LaserEffect_AllTrials_Delay = LaserEffect.p_LaserEffect_AllTrials_Delay;                              
p_LaserEffect_AllTrials_Baseline = LaserEffect.p_LaserEffect_AllTrials_Baseline;                        
p_LaserEffect_AllTrials_Sample = LaserEffect.p_LaserEffect_AllTrials_Sample;                             

Larger_LaserEffect_AllTrials = LaserEffect.Larger_LaserEffect_AllTrials; 
Larger_LaserEffect_AllTrials_Delay = LaserEffect.Larger_LaserEffect_AllTrials_Delay; 
Larger_LaserEffect_AllTrials_Baseline = LaserEffect.Larger_LaserEffect_AllTrials_Baseline; 
Larger_LaserEffect_AllTrials_Sample = LaserEffect.Larger_LaserEffect_AllTrials_Sample;

Laser_Effect_AllTrial = LaserEffect.Laser_Effect_AllTrial;
Laser_Effect_Delay = LaserEffect.Laser_Effect_Delay;
Laser_Effect_Baseline = LaserEffect.Laser_Effect_Baseline;
Laser_Effect_Sample = LaserEffect.Laser_Effect_Sample;


DotPlotUnitWaveProperty(Half_Amplitude_Duration,Trough_to_Peak);
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'png')
close all

BinSize=100;Boundary=0.35;
HistPlotUnitDistribution(Trough_to_Peak,BinSize,Boundary);
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'png')
close all

NS_Index = find(Trough_to_Peak<0.35); % narrow spike Units
BS_Index = find(Trough_to_Peak>=0.35);  % broad spike units
UnitType = NaN * ones(size(AllUnitID,1),1);
UnitType(NS_Index) = 1;% 1 for Narrow spike neurons or GABAergic neurons
UnitType(BS_Index) = 2;% 2 for Narrow spike neurons or GABAergic neurons

DotPlotUnitWith2PrametersFor2Groups(Trough_to_Peak(NS_Index),AveragedFR(NS_Index),Trough_to_Peak(BS_Index),AveragedFR(BS_Index))
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'fig')
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'png')
close all

%% plot NS-Units or BS-Units firing rate and selectivity
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllTrialsFR(NS_Index,:),NS_Index,TimeGain);
SpecificIndex=[];
Index_LaserOffAllTrialsFR_NS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR_NS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR_NS'],'png')
close all
LaserOffAllUnitsAllTrialsNrmolizedFR_NS=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllTrialsFR(NS_Index,:),NS_Index,TimeGain);
SpecificIndex=Index_LaserOffAllTrialsFR_NS;
Index_LaserOnAllTrialsFR_NS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR_NS'],'fig')
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR_NS'],'png')
close all
LaserOnAllUnitsAllTrialsNrmolizedFR_NS=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllTrialsFR(BS_Index,:),BS_Index,TimeGain);
SpecificIndex=[];
Index_LaserOffAllTrialsFR_BS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR_BS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR_BS'],'png')
close all
LaserOffAllUnitsAllTrialsNrmolizedFR_BS=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllTrialsFR(BS_Index,:),BS_Index,TimeGain);
SpecificIndex=Index_LaserOffAllTrialsFR_BS;
Index_LaserOnAllTrialsFR_BS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR_BS'],'fig')
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR_BS'],'png')
close all
LaserOnAllUnitsAllTrialsNrmolizedFR_BS=Target;
clear('Target','TargetNum','SpecificIndex')
%%
SpecificIndexForDiffFRofSampleAB_NS=GetSortIndex(LaserOffAllATrialsFR(NS_Index),LaserOffAllBTrialsFR(NS_Index),TimeGain);
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllATrialsFR(NS_Index),NS_Index,TimeGain);
Index_LaserOffAllATrialsFR_NS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB_NS);
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB_NS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB_NS'],'png')
close all
LaserOffAllUnitsAllATrialsNrmolizedFR_NS=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllBTrialsFR(NS_Index),NS_Index,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR_NS;
Index_LaserOffAllBTrialsFR_NS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB_NS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB_NS'],'png')
close all
LaserOffAllUnitsAllBTrialsNrmolizedFR_NS=Target;
clear('Target','TargetNum','SpecificIndex')
%%
SpecificIndexForDiffFRofSampleAB_BS=GetSortIndex(LaserOffAllATrialsFR(BS_Index),LaserOffAllBTrialsFR(BS_Index),TimeGain);
[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllATrialsFR(BS_Index),BS_Index,TimeGain);
Index_LaserOffAllATrialsFR_BS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB_BS);
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB_BS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB_BS'],'png')
close all
LaserOffAllUnitsAllATrialsNrmolizedFR_BS=Target;
clear('Target','TargetNum','SpecificIndex')

[Target,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllBTrialsFR(BS_Index),BS_Index,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR_BS;
Index_LaserOffAllBTrialsFR_NS=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB_BS'],'fig')
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB_BS'],'png')
close all
LaserOffAllUnitsAllBTrialsNrmolizedFR_BS=Target;
clear('Target','TargetNum','SpecificIndex')

%%   plot sample selectivity for each neuron (using neural firing rate
LaserOnShuffledAData_NS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOnAllTrialsFR(NS_Index), 'un',0);
LaserOnShuffledBData_NS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOnAllTrialsFR(NS_Index), 'un',0);
LaserOffShuffledAData_NS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOffAllTrialsFR(NS_Index), 'un',0);
LaserOffShuffledBData_NS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOffAllTrialsFR(NS_Index), 'un',0);

LaserOnShuffledAData_BS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOnAllTrialsFR(BS_Index), 'un',0);
LaserOnShuffledBData_BS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOnAllTrialsFR(BS_Index), 'un',0);
LaserOffShuffledAData_BS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOffAllTrialsFR(BS_Index), 'un',0);
LaserOffShuffledBData_BS = cellfun(@(x) (x(randi(80,50,1),:)), LaserOffAllTrialsFR(BS_Index), 'un',0);


PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR(NS_Index),LaserOffAllBTrialsFR(NS_Index),LaserOffShuffledAData_NS,LaserOffShuffledBData_NS,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,NS_Index,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_NS'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_NS'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(NS_Index),LaserOnAllBTrialsFR(NS_Index),LaserOnShuffledAData_NS,LaserOnShuffledBData_NS,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,NS_Index,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_NS'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_NS'],'png')
close all

PlotSelectivityHeatMapForEveryUnit(LaserOnAllATrialsFR(NS_Index),LaserOnAllBTrialsFR(NS_Index),LaserOffAllATrialsFR(NS_Index),LaserOffAllBTrialsFR(NS_Index),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,NS_Index,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapForEveryUnit_NS'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapForEveryUnit_NS'],'png')
close all
%%
PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR(BS_Index),LaserOffAllBTrialsFR(BS_Index),LaserOffShuffledAData_BS,LaserOffShuffledBData_BS,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,BS_Index,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_BS'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_BS'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(BS_Index),LaserOnAllBTrialsFR(BS_Index),LaserOnShuffledAData_BS,LaserOnShuffledBData_BS,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,BS_Index,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_BS'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_BS'],'png')
close all

PlotSelectivityHeatMapForEveryUnit(LaserOnAllATrialsFR(BS_Index),LaserOnAllBTrialsFR(BS_Index),LaserOffAllATrialsFR(BS_Index),LaserOffAllBTrialsFR(BS_Index),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,BS_Index,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapForEveryUnit_BS'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapForEveryUnit_BS'],'png')
close all

%% plot laser effect
% Index_LaserChangedUnit = find(Laser_Effect_Delay ~= 0);

Num_NS_FR_Decresed_Delay = length(find(Laser_Effect_Delay == -1 & Trough_to_Peak < 0.35));
Num_NS_FR_Incresed_Delay = length(find(Laser_Effect_Delay == 1 & Trough_to_Peak < 0.35));
Num_NS = length(find(Trough_to_Peak < 0.35));
Num_BS_FR_Decresed_Delay = length(find(Laser_Effect_Delay == -1 & Trough_to_Peak >= 0.35));
Num_BS_FR_Incresed_Delay = length(find(Laser_Effect_Delay == 1 & Trough_to_Peak >= 0.35));
Num_BS = length(find(Trough_to_Peak >= 0.35));
[~,p_Decrease]=prop_test([Num_NS_FR_Decresed_Delay Num_BS_FR_Decresed_Delay],[Num_NS Num_BS],0)
[~,p_Increase]=prop_test([Num_NS_FR_Incresed_Delay Num_BS_FR_Incresed_Delay],[Num_NS Num_BS],0)
[~,p_noChange]=prop_test([47 73],[Num_NS Num_BS],0)
y_Delay=[Num_NS_FR_Decresed_Delay Num_NS_FR_Incresed_Delay Num_NS-Num_NS_FR_Decresed_Delay-Num_NS_FR_Incresed_Delay;Num_BS_FR_Decresed_Delay Num_BS_FR_Incresed_Delay Num_BS-Num_BS_FR_Decresed_Delay-Num_BS_FR_Incresed_Delay]./[Num_NS;Num_BS]*100;
figure('color','w')
bar(y_Delay)
saveas(gcf,['LaserEffect_Delay_NS&BS-Units'],'fig')
saveas(gcf,['LaserEffect_Delay_NS&BS-Units'],'png')
pie([Num_NS;Num_BS]/475)

Num_NS_FR_Decresed_Baseline = length(find(Laser_Effect_Baseline == -1 & Trough_to_Peak < 0.35));
Num_NS_FR_Incresed_Baseline = length(find(Laser_Effect_Baseline == 1 & Trough_to_Peak < 0.35));
Num_BS_FR_Decresed_Baseline = length(find(Laser_Effect_Baseline == -1 & Trough_to_Peak >= 0.35));
Num_BS_FR_Incresed_Baseline = length(find(Laser_Effect_Baseline == 1 & Trough_to_Peak >= 0.35));
y_Baseline=[Num_NS_FR_Decresed_Baseline Num_NS_FR_Incresed_Baseline Num_NS-Num_NS_FR_Decresed_Baseline-Num_NS_FR_Incresed_Baseline;Num_BS_FR_Decresed_Baseline Num_BS_FR_Incresed_Baseline Num_BS-Num_BS_FR_Decresed_Baseline-Num_BS_FR_Incresed_Baseline]/(Num_NS+Num_BS);
figure('color','w')
bar(y_Baseline)
saveas(gcf,['LaserEffect_Baseline_NS&BS-Units'],'fig')
saveas(gcf,['LaserEffect_Baseline_NS&BS-Units'],'png')

Num_NS_FR_Decresed_Sample = length(find(Laser_Effect_Sample == -1 & Trough_to_Peak < 0.35));
Num_NS_FR_Incresed_Sample = length(find(Laser_Effect_Sample == 1 & Trough_to_Peak < 0.35));
Num_BS_FR_Decresed_Sample = length(find(Laser_Effect_Sample == -1 & Trough_to_Peak >= 0.35));
Num_BS_FR_Incresed_Sample = length(find(Laser_Effect_Sample == 1 & Trough_to_Peak >= 0.35));
y_Sample=[Num_NS_FR_Decresed_Sample Num_NS_FR_Incresed_Sample Num_NS-Num_NS_FR_Decresed_Sample-Num_NS_FR_Incresed_Sample;Num_BS_FR_Decresed_Sample Num_BS_FR_Incresed_Sample Num_BS-Num_BS_FR_Decresed_Sample-Num_BS_FR_Incresed_Sample]/(Num_NS+Num_BS);
figure('color','w')
bar(y_Sample)
saveas(gcf,['LaserEffect_Sample_NS&BS-Units'],'fig')
saveas(gcf,['LaserEffect_Sample_NS&BS-Units'],'png')
close all
%%
Index_LaserChangedDelayUnit=find(Laser_Effect_Delay~=0);
PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR(Index_LaserChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserChangedDelayUnit),LaserOffShuffledAData(Index_LaserChangedDelayUnit),LaserOffShuffledBData(Index_LaserChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserChangedDelayUnit,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(Index_LaserChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserChangedDelayUnit),LaserOnShuffledAData(Index_LaserChangedDelayUnit),LaserOnShuffledBData(Index_LaserChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserChangedDelayUnit,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(Index_LaserChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserChangedDelayUnit),LaserOffAllATrialsFR(Index_LaserChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserChangedDelayUnit,201)
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'fig')
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy_LaserChangedUnits'],'png')
close all

Index_LaserNoChangedDelayUnit=find(Laser_Effect_Delay==0);
PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserNoChangedDelayUnit),LaserOffShuffledAData(Index_LaserNoChangedDelayUnit),LaserOffShuffledBData(Index_LaserNoChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserNoChangedDelayUnit,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'png')
close all
PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserNoChangedDelayUnit),LaserOnShuffledAData(Index_LaserNoChangedDelayUnit),LaserOnShuffledBData(Index_LaserNoChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserNoChangedDelayUnit,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserNoChangedDelayUnit),LaserOffAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserNoChangedDelayUnit),FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserNoChangedDelayUnit,201)
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'fig')
saveas(gcf,['LaserOn&LaserOffPopulationUnitSampleTrialSelectivy_LaserNoChangedUnits'],'png')
close all

PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(Index_LaserChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserChangedDelayUnit),LaserOnAllATrialsFR(Index_LaserChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserChangedDelayUnit),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserChangedDelayUnit,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapFor_LaserChangedDelayUnit'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMapFor_LaserChangedDelayUnit'],'png')
close all
PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOffAllBTrialsFR(Index_LaserNoChangedDelayUnit),LaserOnAllATrialsFR(Index_LaserNoChangedDelayUnit),LaserOnAllBTrialsFR(Index_LaserNoChangedDelayUnit),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,Index_LaserNoChangedDelayUnit,TimeGain);
saveas(gcf,['WeithedLaserOff&LaserOnSampleSelectivityHeatMapFor_LaserNoChangedDelayUnit'],'fig')
saveas(gcf,['WeightedLaserOff&LaserOnSampleSelectivityHeatMapFor_LaserNoChangedDelayUnit'],'png')
close all
PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(BS_Index),LaserOffAllBTrialsFR(BS_Index),LaserOnAllATrialsFR(BS_Index),LaserOnAllBTrialsFR(BS_Index),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,BS_Index,TimeGain);
PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(NS_Index),LaserOffAllBTrialsFR(NS_Index),LaserOnAllATrialsFR(NS_Index),LaserOnAllBTrialsFR(NS_Index),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,NS_Index,TimeGain);

%% plot sample selectivity from 1s baseline to delay end with 1s bin
LaserOffATrialsFR_1s=ReDefineBinSize(LaserOffAllATrialsFR,1000,100);
LaserOffBTrialsFR_1s=ReDefineBinSize(LaserOffAllBTrialsFR,1000,100);


LaserOnBTrialsFR_1s=ReDefineBinSize(LaserOnAllBTrialsFR_EarlyDelay,1000,100);
LaserOnATrialsFR_1s=ReDefineBinSize(LaserOnAllATrialsFR_EarlyDelay,1000,100);
LaserOnBTrialsFR_1s_1=ReDefineBinSize(LaserOnAllBTrialsFR_LateDelay,1000,100);
LaserOnATrialsFR_1s_1=ReDefineBinSize(LaserOnAllATrialsFR_LateDelay,1000,100);


for i= 1:UnitNum
    for j = 1:10 % 2s baseline+1s Odor + 6s Delay+1s second Odor
        p_Off(i,j)=ranksum(LaserOffATrialsFR_1s{i,1}(:,j),LaserOffBTrialsFR_1s{i,1}(:,j));
        DeltaFR_Off(i,j)=mean(LaserOffATrialsFR_1s{i,1}(:,j))-mean(LaserOffBTrialsFR_1s{i,1}(:,j));
        p_On(i,j)=ranksum(LaserOnATrialsFR_1s{i,1}(:,j),LaserOnBTrialsFR_1s{i,1}(:,j));
        DeltaFR_On(i,j)=mean(LaserOnATrialsFR_1s{i,1}(:,j))-mean(LaserOnBTrialsFR_1s{i,1}(:,j));
        p_On_1(i,j)=ranksum(LaserOnATrialsFR_1s_1{i,1}(:,j),LaserOnBTrialsFR_1s_1{i,1}(:,j));
        DeltaFR_On_1(i,j)=mean(LaserOnATrialsFR_1s_1{i,1}(:,j))-mean(LaserOnBTrialsFR_1s_1{i,1}(:,j));
        
        if j<3
            if p_Off(i,j)<0.05 && DeltaFR_Off(i,j)>0
                OdorSelectivity_LaserOff(i,j)=1;
            elseif p_Off(i,j)<0.05 && DeltaFR_Off(i,j)<0
                OdorSelectivity_LaserOff(i,j)=-1;
            elseif p_Off(i,j)>0.05
                OdorSelectivity_LaserOff(i,j)=0;
            end
            if p_On(i,j)<0.05 && DeltaFR_On(i,j)>0
                OdorSelectivity_LaserOn(i,j)=1;
            elseif p_On(i,j)<0.05 && DeltaFR_On(i,j)<0
                OdorSelectivity_LaserOn(i,j)=-1;
            elseif p_On(i,j)>0.05
                OdorSelectivity_LaserOn(i,j)=0;
            end
            if p_On_1(i,j)<0.05 && DeltaFR_On_1(i,j)>0
                OdorSelectivity_LaserOn_1(i,j)=1;
            elseif p_On_1(i,j)<0.05 && DeltaFR_On_1(i,j)<0
                OdorSelectivity_LaserOn_1(i,j)=-1;
            elseif p_On_1(i,j)>0.05
                OdorSelectivity_LaserOn_1(i,j)=0;
            end
        else
            if p_Off(i,j)<0.05 && DeltaFR_Off(i,j)>0
                OdorSelectivity_LaserOff(i,j)=1;
            elseif p_Off(i,j)<0.05 && DeltaFR_Off(i,j)<0
                OdorSelectivity_LaserOff(i,j)=-1;
            elseif p_Off(i,j)>0.05
                OdorSelectivity_LaserOff(i,j)=0;
            end
            if p_On(i,j)<0.05 && DeltaFR_On(i,j)>0
                OdorSelectivity_LaserOn(i,j)=1;
            elseif p_On(i,j)<0.05 && DeltaFR_On(i,j)<0
                OdorSelectivity_LaserOn(i,j)=-1;
            elseif p_On(i,j)>0.05
                OdorSelectivity_LaserOn(i,j)=0;
            end
            if p_On_1(i,j)<0.05 && DeltaFR_On_1(i,j)>0
                OdorSelectivity_LaserOn_1(i,j)=1;
            elseif p_On_1(i,j)<0.05 && DeltaFR_On_1(i,j)<0
                OdorSelectivity_LaserOn_1(i,j)=-1;
            elseif p_On_1(i,j)>0.05
                OdorSelectivity_LaserOn_1(i,j)=0;
            end
        end
    end
end

[~,SortIndex]=sortrows(mean(OdorSelectivity_LaserOff(:,3:9),2),-1);
UnitNum=size(SortIndex,1);
figure('color',[1 1 1])
map=ones(199,3);
c=linspace(0,1)';
map(1:100,[1,2])=[c,c];
map(199:-1:100,[2,3])=[c,c];
colormap(map);
imagesc(OdorSelectivity_LaserOn_1(SortIndex,2:end))
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOff'],'fig')
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOff'],'png')

figure('color',[1 1 1])
map=ones(199,3);
c=linspace(0,1)';
map(1:100,[1,2])=[c,c];
map(199:-1:100,[2,3])=[c,c];
colormap(map);
imagesc(OdorSelectivity_LaserOn(SortIndex,2:end))
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOnEarlyDelay'],'fig')
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOnEarlyDelay'],'png')

figure('color',[1 1 1])
map=ones(199,3);
c=linspace(0,1)';
map(1:100,[1,2])=[c,c];
map(199:-1:100,[2,3])=[c,c];
colormap(map);
imagesc(OdorSelectivity_LaserOn_1(SortIndex,2:end))
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOnLateDelay'],'fig')
saveas(gcf,['SampleSelectivityHeatMap-1s-LaserOnLateDelay'],'png')

for k=1: 10
    SelecUnitNum_LaserOff(1,k)=length(find(OdorSelectivity_LaserOff(:,k)>0));
    SelecUnitNum_LaserOff(2,k)=length(find(OdorSelectivity_LaserOff(:,k)<0));
    SelecUnitNum_LaserOff(3,k)=length(find(OdorSelectivity_LaserOff(:,k)==0));
    
    SelecUnitNum_LaserOn(1,k)=length(find(OdorSelectivity_LaserOn(:,k)>0));
    SelecUnitNum_LaserOn(2,k)=length(find(OdorSelectivity_LaserOn(:,k)<0));
    SelecUnitNum_LaserOn(3,k)=length(find(OdorSelectivity_LaserOn(:,k)==0));
    
    SelecUnitNum_LaserOn_1(1,k)=length(find(OdorSelectivity_LaserOn_1(:,k)>0));
    SelecUnitNum_LaserOn_1(2,k)=length(find(OdorSelectivity_LaserOn_1(:,k)<0));
    SelecUnitNum_LaserOn_1(3,k)=length(find(OdorSelectivity_LaserOn_1(:,k)==0));
    
end
figure('color',[1 1 1])
bar([0.8:1:8.8],SelecUnitNum_LaserOff(1:2,2:end)'/750,0.2,'stacked');
hold on
bar([1.0:1:9],SelecUnitNum_LaserOn(1:2,2:end)'/750,0.2,'stacked')
bar([1.2:1:9.2],SelecUnitNum_LaserOn_1(1:2,2:end)'/750,0.2,'stacked')
saveas(gcf,['SampleSelectivityProportion-1s-NoMultiComp'],'fig')
saveas(gcf,['SampleSelectivityProportion-1s-NoMultiComp'],'png')

