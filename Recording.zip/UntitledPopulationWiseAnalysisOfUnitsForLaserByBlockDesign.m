clear all;close all;clc;

LaserType=3; % 0 for laser off in all trials, 1 for laser on; 2 for 2 type of laser condition during trials; 3 for 3 conditions laser by bloack design
TimeGain=10;
NewBin=1000;%ms
Bin=100;%ms
WaveformLenth = 58;
SampelRate = 40000;
InterpolationNum = 5;
LaserFreq=20;%
LaserFreqDuration=5;% 5ms
LaserOutTaskDuraion=2;% 2s
LaserOutTaskITI=10;

IsUnitWaveProperty = 1;
PlotSingleUnitSelectivity=1;
PlotNormalizedFRForSingleUnit=1;
AnalyseLaserEffectOnModulation=1;
AnalyzeLaserOutTask =1;
[tempfilename, pathname]=uigetfile('SplitData*.mat','multiselect','on');%

if ischar(tempfilename)
    MainCircleN=1;
    filename=tempfilename;
else
    MainCircleN=size(tempfilename,2);
    filename=tempfilename';
end
AveragedFR=[];
AllUnitID=[];
AllTrialsFR=[];% all units firing cross all trials
AllTrials=[];% Trial results
AllLaserTrialsID=[];% laser ID
AllPerformance=[];
Trough_to_Peak = [];%ms
Half_Amplitude_Duration = [];%ms amplitude is caculated from baseline to trough.
AveagedWaveform =[];
AllUnitMaxWaveform=[];
AllUnitOdor1=[];
AllUnitOdor2=[];
AllUnitSplitSpikeTime=[];

if AnalyseLaserEffectOnModulation==1
   Laser_Effect_AllTrial = [];
   Laser_Effect_Delay = [];
   Laser_Effect_Baseline = [];
   Laser_Effect_Sample = [];
    
   Laser_Effect_EarlyDelay = [];
   Laser_Effect_LateDelay = [];
   LaserEffectOutTask=[];
   LaserEffect_EarlyDelay_100=[];
   LaserEffect_LateDelay_100=[];
   LaserEffect_EarlyDelay_200=[];
   LaserEffect_LateDelay_200=[];
   LaserEffect_EarlyDelay_500=[];
   LaserEffect_LateDelay_500=[];
   LaserEffect_EarlyDelay_1000=[];
   LaserEffect_LateDelay_1000=[];
end

for itr=1:MainCircleN
    load(filename{itr,:});
    %% get averaged waveform of 4 channels (tetrode)
    tempWaveform = cellfun(@mean, NewSpikes, 'un', 0);
    Waveform = cell2mat(tempWaveform);
    AveagedWaveform =[AveagedWaveform; Waveform(:,4:end)];
    % get averaged firing rate of recording time
    AveragedFR = [AveragedFR; FiringRate];
    % get property of max waveform for 4 channels and max waveform
    if IsUnitWaveProperty == 1
        Trough_to_Peak_Eachfile = [];
        Half_Amplitude_Duration_Eachfile = [];
        [Trough_to_Peak_Eachfile, Half_Amplitude_Duration_Eachfile, MaxWaveform] = GetUnitWavePropertyForEachFile(NewSpikes,WaveformLenth,SampelRate,InterpolationNum);
        Trough_to_Peak = [Trough_to_Peak; Trough_to_Peak_Eachfile];
        Half_Amplitude_Duration = [Half_Amplitude_Duration; Half_Amplitude_Duration_Eachfile];
    end
    AllUnitMaxWaveform = [AllUnitMaxWaveform; MaxWaveform];
    %%
    if ~isempty(SingleUnitIndex)
        UnitID_SplitData={};
        if size(SingleUnitIndex,1)~=size(SplitData.SpikeCounts,1)
            display(DataID)
        end
        %% collect all unit information
        for itr2=1:size(SingleUnitIndex,1)
            UnitID_SplitData{itr2,1}=[DataID '-Unit' num2str(SingleUnitIndex(itr2,1)*10+SingleUnitIndex(itr2,2))];
        end
        AllUnitID=[AllUnitID;UnitID_SplitData];
        AllTrialsFR=[AllTrialsFR;SplitData.SpikeCounts];% all units firing cross all trials
        AllTrials=[AllTrials;repmat({SplitData.Trials},size(SingleUnitIndex,1),1)];% Trial results
        AllLaserTrialsID=[AllLaserTrialsID;repmat({LaserTrial},size(SingleUnitIndex,1),1)];% laser ID
        AllPerformance=[AllPerformance;repmat({Data},size(SingleUnitIndex,1),1)];
        
        AllUnitOdor1=[AllUnitOdor1;repmat({Odor1'},size(SingleUnitIndex,1),1)];
        AllUnitOdor2=[AllUnitOdor2;repmat({Odor2'},size(SingleUnitIndex,1),1)];
        AllUnitSplitSpikeTime=[AllUnitSplitSpikeTime;SplitData.SpikeTimestamp];
        %% Laser effect on modulation (changing of firing rate )
        if AnalyseLaserEffectOnModulation==1
            %% Laser in task
            % the whole trial with 1000ms bin
            % rebined firing rate to 1s
            NewSpikeCounts= ReDefineBinSize(SplitData.SpikeCounts,1000,100); % the Whole trial Bin=1000ms
            switch LaserType %  2 for 2 laser conditon(on and off); 3 or more for laseroff and different laseron contions
                case 0
                    LaserEffect=[];
                case 1
                    LaserEffect=[];
                case 2 % laser in whole delay (5s in 6s delay)
                    LaserOffTrialIndex=find(LaserTrial==0);
                    LaserOnTrialIndex=find(LaserTrial==1);
                    
                    [Laser_Effect_SplitData] = GetLaserEffect_EcahSpiltData(NewSpikeCounts,LaserOffTrialIndex,LaserOnTrialIndex);
                    Laser_Effect_AllTrial = [Laser_Effect_AllTrial; Laser_Effect_SplitData];
                    % the whole delay period
                    SpikeCounts_Delay = cellfun(@(x) sum(x(:,31:90),2), SplitData.SpikeCounts, 'un', 0);
                    [Laser_Effect_SplitData_Delay] = GetLaserEffect_EcahSpiltData(SpikeCounts_Delay,LaserOffTrialIndex,LaserOnTrialIndex);
                    Laser_Effect_Delay = [Laser_Effect_Delay; Laser_Effect_SplitData_Delay];
                    
                    %  laser effect for the baseline (2 seconds before sample odor)
                    SpikeCounts_Baseline = cellfun(@(x) sum(x(:,1:20),2), SplitData.SpikeCounts, 'un', 0);
                    [Laser_Effect_SplitData_Baseline] = GetLaserEffect_EcahSpiltData(SpikeCounts_Baseline,LaserOffTrialIndex,LaserOnTrialIndex);
                    Laser_Effect_Baseline = [Laser_Effect_Baseline; Laser_Effect_SplitData_Baseline];
                    
                    % laser effect for Sample
                    SpikeCounts_Sample = cellfun(@(x) (x(:,21:30)), SplitData.SpikeCounts, 'un', 0);
                    [Laser_Effect_SplitData_Sample] = GetLaserEffect_EcahSpiltData(SpikeCounts_Sample,LaserOffTrialIndex,LaserOnTrialIndex);
                    Laser_Effect_Sample = [Laser_Effect_Sample; Laser_Effect_SplitData_Sample];
                case 3
                    LaserOffTrialIndex=find(LaserTrial==0);
                    LaserOnTrialIndex_1=find(LaserTrial==1);
                    LaserOnTrialIndex_2=find(LaserTrial==2);
                    % effect on laser period
                    SpikeCounts_EarlyDelay = cellfun(@(x) sum(x(:,31:50),2), SplitData.SpikeCounts, 'un', 0);
                    SpikeCounts_LateDelay = cellfun(@(x) sum(x(:,71:90),2), SplitData.SpikeCounts, 'un', 0);
                    
                    [Laser_Effect_SplitData_EarlyDelay] = GetLaserEffect_EcahSpiltData(SpikeCounts_EarlyDelay,LaserOffTrialIndex,LaserOnTrialIndex_1);
                    Laser_Effect_EarlyDelay = [Laser_Effect_EarlyDelay; Laser_Effect_SplitData_EarlyDelay];
                    
                    [Laser_Effect_SplitData_LateDelay] = GetLaserEffect_EcahSpiltData(SpikeCounts_LateDelay,LaserOffTrialIndex,LaserOnTrialIndex_2);
                    Laser_Effect_LateDelay = [Laser_Effect_LateDelay; Laser_Effect_SplitData_LateDelay];
                    %% compare laser effect on the whole trial(conpare spike number in each bin)
                    SpikeCounts_LaserOff = cellfun(@(x) x(LaserOffTrialIndex,:), SplitData.SpikeCounts,'un', 0);
                    SpikeCounts_LaserEarlyDelay = cellfun(@(x) x(LaserOnTrialIndex_1,:), SplitData.SpikeCounts,'un', 0);
                    SpikeCounts_LaserLateDelay = cellfun(@(x) x(LaserOnTrialIndex_2,:), SplitData.SpikeCounts,'un', 0);
                    % 100ms bin
                    [LaserEffect_EarlyDelay_100_SplitData,LaserEffect_LateDelay_100_SplitData]=LaserEffectOnFRwithSpecificTimeBinForEntireTrial(SpikeCounts_LaserOff,SpikeCounts_LaserEarlyDelay,SpikeCounts_LaserLateDelay,100,100);
                    LaserEffect_EarlyDelay_100=[LaserEffect_EarlyDelay_100;LaserEffect_EarlyDelay_100_SplitData];
                    LaserEffect_LateDelay_100=[LaserEffect_LateDelay_100;LaserEffect_LateDelay_100_SplitData];
                    % 200ms bin
                    [LaserEffect_EarlyDelay_200_SplitData,LaserEffect_LateDelay_200_SplitData]=LaserEffectOnFRwithSpecificTimeBinForEntireTrial(SpikeCounts_LaserOff,SpikeCounts_LaserEarlyDelay,SpikeCounts_LaserLateDelay,200,100);
                    LaserEffect_EarlyDelay_200=[LaserEffect_EarlyDelay_200;LaserEffect_EarlyDelay_200_SplitData];
                    LaserEffect_LateDelay_200=[LaserEffect_LateDelay_200;LaserEffect_LateDelay_200_SplitData];
                    % 500ms bin
                    [LaserEffect_EarlyDelay_500_SplitData,LaserEffect_LateDelay_500_SplitData]=LaserEffectOnFRwithSpecificTimeBinForEntireTrial(SpikeCounts_LaserOff,SpikeCounts_LaserEarlyDelay,SpikeCounts_LaserLateDelay,500,100);
                    LaserEffect_EarlyDelay_500=[LaserEffect_EarlyDelay_500;LaserEffect_EarlyDelay_500_SplitData];
                    LaserEffect_LateDelay_500=[LaserEffect_LateDelay_500;LaserEffect_LateDelay_500_SplitData];
                    % 1s
                    [LaserEffect_EarlyDelay_1000_SplitData,LaserEffect_LateDelay_1000_SplitData]=LaserEffectOnFRwithSpecificTimeBinForEntireTrial(SpikeCounts_LaserOff,SpikeCounts_LaserEarlyDelay,SpikeCounts_LaserLateDelay,1000,100);
                    LaserEffect_EarlyDelay_1000=[LaserEffect_EarlyDelay_1000;LaserEffect_EarlyDelay_1000_SplitData];
                    LaserEffect_LateDelay_1000=[LaserEffect_LateDelay_1000;LaserEffect_LateDelay_1000_SplitData];
                otherwise
                    disp('Laser Condition is more than 3')
            end
            %% Laser out task
            if AnalyzeLaserOutTask ==1
                LaserEffectOutTask_Eachfile=[];
                LaserEffectOutTask_Eachfile=AnalyzeLaserEffectOutTask(DataID,Laser,SingleUnitIndex,Odor1,Odor2,NewSpikes,LaserFreq,LaserOutTaskDuraion,LaserOutTaskITI,SecondOdorLen,Response,ITILen,0);
            end
            LaserEffectOutTask=[LaserEffectOutTask;LaserEffectOutTask_Eachfile];
        end
    end
end

UnitWaveproperty.Trough_to_Peak = Trough_to_Peak;
UnitWaveproperty.Half_Amplitude_Duration = Half_Amplitude_Duration;

LaserEffect.Laser_Effect_AllTrial = Laser_Effect_AllTrial;
LaserEffect.Laser_Effect_Delay = Laser_Effect_Delay;
LaserEffect.Laser_Effect_Baseline = Laser_Effect_Baseline;
LaserEffect.Laser_Effect_Sample = Laser_Effect_Sample;
LaserEffect.Laser_Effect_EarlyDelay = Laser_Effect_EarlyDelay;
LaserEffect.Laser_Effect_LateDelay = Laser_Effect_LateDelay;
LaserEffect.LaserEffectOutTask = LaserEffectOutTask;
LaserEffect.LaserEffect_EarlyDelay_100=LaserEffect_EarlyDelay_100;
LaserEffect.LaserEffect_LateDelay_100=LaserEffect_LateDelay_100;
LaserEffect.LaserEffect_EarlyDelay_200=LaserEffect_EarlyDelay_200;
LaserEffect.LaserEffect_LateDelay_200=LaserEffect_LateDelay_200;
LaserEffect.LaserEffect_EarlyDelay_500=LaserEffect_EarlyDelay_500;
LaserEffect.LaserEffect_LateDelay_500=LaserEffect_LateDelay_500;
LaserEffect.LaserEffect_EarlyDelay_1000=LaserEffect_EarlyDelay_1000;
LaserEffect.LaserEffect_LateDelay_1000=LaserEffect_LateDelay_1000;

save(['PopulationNeuralActivity-VTA-ChR2-mPFC-LaserRecording-20220208'],'AllUnitID','AllTrialsFR','AllLaserTrialsID',...
    'AllPerformance','AllTrials','AllUnitMaxWaveform','AveagedWaveform','AveragedFR','LaserEffect',...
    'UnitWaveproperty','AllUnitOdor1','AllUnitOdor2','AllUnitSplitSpikeTime',...
    'FirstOdorLen','Delay','SecondOdorLen','Response','WaterLen','ITILen','DPALen','TimeGain')


DotPlotUnitWaveProperty(UnitWaveproperty.Half_Amplitude_Duration,UnitWaveproperty.Trough_to_Peak);
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitWaveProperty-Half_Amplitude_Duration&Trough_to_Peak'],'png')
close all

BinSize=100;Boundary=0.35;
HistPlotUnitDistribution(UnitWaveproperty.Trough_to_Peak,BinSize,Boundary);
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'fig')
saveas(gcf,['AllUnitDistribution_Trough_to_Peak'],'png')
close all

NS_Index = find(Trough_to_Peak<0.35); % narrow spike Units
BS_Index = find(Trough_to_Peak>=0.35);  % broad spike units
UnitType = NaN * ones(size(AllUnitID,1),1);
UnitType(NS_Index) = 1;% 1 for Narrow spike neurons or GABAergic neurons
UnitType(BS_Index) = 2;% 2 for Narrow spike neurons or GABAergic neurons

DotPlotUnitWith2PrametersFor2Groups(UnitWaveproperty.Trough_to_Peak(NS_Index),AveragedFR(NS_Index),UnitWaveproperty.Trough_to_Peak(BS_Index),AveragedFR(BS_Index))
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'fig')
saveas(gcf,['NS&BS-Unit_Trough_to_Peak_FiringRate'],'png')
close all

%% % get all units normalized FR in specific trials
LaserOffIndex=cellfun(@(x) find(x==0),AllLaserTrialsID,'un',0);
LaserOffAllTrialsFR=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOffIndex,'un',0);
[NormAllTrialsFR_LaserOff,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllTrialsFR,AllUnitID,TimeGain);
SpecificIndex=[];
Index_LaserOffAllTrialsFR=PlotHeatMap(NormAllTrialsFR_LaserOff,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'fig')
saveas(gcf,['LaserOffCrossUnitAllTrialNormalizedFR'],'png')
close all
LaserOffAllUnitsAllTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')

LaserOnIndex_EarlyDelay=cellfun(@(x) find(x==1),AllLaserTrialsID,'un',0);
LaserOnAllTrialsFR_EarlyDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnIndex_EarlyDelay,'un',0);
[NormAllTrialsFR_LaserOnEarlyDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllTrialsFR_EarlyDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllTrialsFR;
Index_LaserOnAllTrialsFR_EarlyDelay=PlotHeatMap(NormAllTrialsFR_LaserOnEarlyDelay_ForTest,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR-EarlyDelay_New'],'fig')
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR-EarlyDelay_New'],'png')
close all
LaserOnAllUnitsAllTrialsNrmolizedFR_EarlyDelay=Target;
clear('Target','TargetNum','SpecificIndex')

LaserOnIndex_LateDelay=cellfun(@(x) find(x==2),AllLaserTrialsID,'un',0);
LaserOnAllTrialsFR_LateDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnIndex_LateDelay,'un',0);
[NormAllTrialsFR_LaserOnLateDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllTrialsFR_LateDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllTrialsFR;
Index_LaserOnAllTrialsFR_LateDelay=PlotHeatMap(NormAllTrialsFR_LaserOnLateDelay_ForTest,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndex);
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR-LateDelay_New'],'fig')
saveas(gcf,['LaserOnCrossUnitAllTrialNormalizedFR-LateDelay_New'],'png')
close all
LaserOnAllUnitsAllTrialsNrmolizedFR_LateDelay=Target;
clear('Target','TargetNum','SpecificIndex')

LaserOffAIndex=cellfun(@(x,y) find(x==0 & y(:,2)==1),AllLaserTrialsID,AllTrials,'un',0);
LaserOffAllATrialsFR=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOffAIndex,'un',0);
LaserOffBIndex=cellfun(@(x,y) find(x==0 & y(:,2)==2),AllLaserTrialsID,AllTrials,'un',0);
LaserOffAllBTrialsFR=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOffBIndex,'un',0);

LaserOnAIndex_EarlyDelay=cellfun(@(x,y) find(x==1 & y(:,2)==1),AllLaserTrialsID,AllTrials,'un',0);
LaserOnAllATrialsFR_EarlyDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnAIndex_EarlyDelay,'un',0);
LaserOnBIndex_EarlyDelay=cellfun(@(x,y) find(x==1 & y(:,2)==2),AllLaserTrialsID,AllTrials,'un',0);
LaserOnAllBTrialsFR_EarlyDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnBIndex_EarlyDelay,'un',0);

LaserOnAIndex_LateDelay=cellfun(@(x,y) find(x==2 & y(:,2)==1),AllLaserTrialsID,AllTrials,'un',0);
LaserOnAllATrialsFR_LateDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnAIndex_LateDelay,'un',0);
LaserOnBIndex_LateDelay=cellfun(@(x,y) find(x==2 & y(:,2)==2),AllLaserTrialsID,AllTrials,'un',0);
LaserOnAllBTrialsFR_LateDelay=cellfun(@(x,y) x(y,:),AllTrialsFR,LaserOnBIndex_LateDelay,'un',0);
% Laser-Off-ATrials
SpecificIndexForDiffFRofSampleAB=GetSortIndex(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,TimeGain);
[NormATrialsFR_LaserOff,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllATrialsFR,AllUnitID,TimeGain);
Index_LaserOffAllATrialsFR=PlotHeatMap(NormATrialsFR_LaserOff,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOffCrossUnitAllATrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOffAllUnitsAllATrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')
% Laser-Off-BTrials
[NormBTrialsFR_LaserOff,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOffAllBTrialsFR,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserOffCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOffAllUnitsAllBTrialsNrmolizedFR=Target;
clear('Target','TargetNum','SpecificIndex')
% Laser-EarlyDelay-ATrials
[NormATrialsFR_LaserOnEarlyDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllATrialsFR_EarlyDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserEarlyDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserEarlyDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllATrialsNrmolizedFR_EarlyDelay=Target;
clear('Target','TargetNum','SpecificIndex')
% Laser-EarlyDelay-BTrials
[NormBTrialsFR_LaserOnEarlyDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllBTrialsFR_EarlyDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserEarlyDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserEarlyDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllBTrialsNrmolizedFR_EarlyDelay=Target;
clear('Target','TargetNum','SpecificIndex')
% Laser-LateDelay-ATrials
[NormATrialsFR_LaserOnLateDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllATrialsFR_LateDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserLateDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserEarlyDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllATrialsNrmolizedFR_LateDelay=Target;
clear('Target','TargetNum','SpecificIndex')
% Laser-LateDelay-BTrials
[NormBTrialsFR_LaserOnLateDelay,TargetNum]=GetAllUnitsNormalizedFRinSpecificTrials(LaserOnAllBTrialsFR_LateDelay,AllUnitID,TimeGain);
SpecificIndex=Index_LaserOffAllATrialsFR;
Index_LaserOffAllBTrialsFR=PlotHeatMap(Target,TargetNum,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,TimeGain,SpecificIndexForDiffFRofSampleAB);
saveas(gcf,['LaserLateDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'fig')
saveas(gcf,['LaserLateDelayCrossUnitAllBTrialNormalizedFR-DiffFRofSampleAB'],'png')
close all
LaserOnAllUnitsAllBTrialsNrmolizedFR_LateDelay=Target;
clear('Target','TargetNum','SpecificIndex')
%% Normalized firing rate to baseline of laser off trials
tempAllTrialsFR=cellfun(@(x) x(21:260,:),AllTrialsFR,'un',0);
tempAllLaserTrialsID=cellfun(@(y) y(21:260,:),AllLaserTrialsID,'un',0);
[tempNormFR]=NormalizeFRCrossLaserCondition(tempAllTrialsFR,tempAllLaserTrialsID,TimeGain);
%% delay acitivity Units
p_Delay_Early=zeros(size(tempNormFR));Larger_Delay_Early=zeros(size(tempNormFR));
p_Delay_Late=zeros(size(tempNormFR));Larger_Delay_Late=zeros(size(tempNormFR));
for iNeu = 1:size(tempNormFR,1)
    for iLaser = 1:size(tempNormFR,2)
        [p_Delay_Early(iNeu,iLaser),Larger_Delay_Early(iNeu,iLaser)]=ranksumTest(mean(tempNormFR{iNeu,iLaser}(:,31:50),2),mean(tempNormFR{iNeu,iLaser}(:,1:20),2),0);
        [p_Delay_Late(iNeu,iLaser),Larger_Delay_Late(iNeu,iLaser)]=ranksumTest(mean(tempNormFR{iNeu,iLaser}(:,71:90),2),mean(tempNormFR{iNeu,iLaser}(:,1:20),2),0);
    end
end
%
Learn_DelayIncreasedIndex_Early_LaserOff=intersect(find(p_Delay_Early(:,1)<0.05&Larger_Delay_Early(:,1)==1),Learn_UnitIndex_CLE);
Learn_DelayDecreasedIndex_Early_LaserOff=intersect(find(p_Delay_Early(:,1)<0.05&Larger_Delay_Early(:,1)==2),Learn_UnitIndex_CLE);
Learn_NoDelayActivityIndex_Early_LaserOff=setdiff(Learn_UnitIndex_CLE,[Learn_DelayIncreasedIndex_Early_LaserOff;Learn_DelayDecreasedIndex_Early_LaserOff]);
Learn_DelayIncreasedIndex_Early_LaserOnEarly=intersect(find(p_Delay_Early(:,2)<0.05&Larger_Delay_Early(:,2)==1),Learn_UnitIndex_CLE);
Learn_DelayDecreasedIndex_Early_LaserOnEarly=intersect(find(p_Delay_Early(:,2)<0.05&Larger_Delay_Early(:,2)==2),Learn_UnitIndex_CLE);
Learn_NoDelayActivityIndex_Early_LaserOnEarly=setdiff(Learn_UnitIndex_CLE,[Learn_DelayIncreasedIndex_Early_LaserOnEarly;Learn_DelayDecreasedIndex_Early_LaserOnEarly]);
Learn_DelayIncreasedIndex_Late_LaserOff=intersect(find(p_Delay_Late(:,1)<0.05&Larger_Delay_Late(:,1)==1),Learn_UnitIndex_CLE);
Learn_DelayDecreasedIndex_Late_LaserOff=intersect(find(p_Delay_Late(:,1)<0.05&Larger_Delay_Late(:,1)==2),Learn_UnitIndex_CLE);
Learn_NoDelayActivityIndex_Late_LaserOff=setdiff(Learn_UnitIndex_CLE,[Learn_DelayIncreasedIndex_Late_LaserOff;Learn_DelayDecreasedIndex_Late_LaserOff]);
Learn_DelayIncreasedIndex_Late_LaserOnLate=intersect(find(p_Delay_Late(:,3)<0.05&Larger_Delay_Late(:,3)==1),Learn_UnitIndex_CLE);
Learn_DelayDecreasedIndex_Late_LaserOnLate=intersect(find(p_Delay_Late(:,3)<0.05&Larger_Delay_Late(:,3)==2),Learn_UnitIndex_CLE);
Learn_NoDelayActivityIndex_Late_LaserOnLate=setdiff(Learn_UnitIndex_CLE,[Learn_DelayIncreasedIndex_Late_LaserOnLate;Learn_DelayDecreasedIndex_Late_LaserOnLate]);
%% SNR = (FR of test period / FR of sample period in lasr off trials)exp(FR of test period / FR of test period in Laser off trials)


%% according to delay activity in laser off trial
Index_FR_Increased_DelayIncreased_Early=intersect(Learn_DelayIncreasedIndex_Early_LaserOff,Learn_FRIncreasedUnitIndex_Ealry_CLE);%positive delay, fr incresed in laser on
Index_FR_Decreased_DelayDecreased_Early=intersect(Learn_DelayDecreasedIndex_Early_LaserOff,Learn_FRDecreasedUnitIndex_Ealry_CLE);
Index_FR_Increased_DelayDecreased_Early=intersect(Learn_DelayDecreasedIndex_Early_LaserOff,Learn_FRIncreasedUnitIndex_Ealry_CLE);%positive delay, fr incresed in laser on
Index_FR_Decreased_DelayIncreased_Early=intersect(Learn_DelayIncreasedIndex_Early_LaserOff,Learn_FRDecreasedUnitIndex_Ealry_CLE);


Index_Increased_FR_Delay_Early=intersect();
Index_Decreased_FR_Delay_Early=intersect();
Index_Increased_FR_Delay_Late=intersect();
Index_Decreased_FR_Delay_Late=intersect();



%%   plot sample selectivity for each neuron (using neural firing rate)
tempLaserOnShuffledAData_EarlyDelay = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllATrialsFR_EarlyDelay, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllBTrialsFR_EarlyDelay, 'un',0)];
tempLaserOnShuffledBData_EarlyDelay = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllATrialsFR_EarlyDelay, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllBTrialsFR_EarlyDelay, 'un',0)];
tempLaserOnShuffledAData_LateDelay = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllATrialsFR_LateDelay, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllBTrialsFR_LateDelay, 'un',0)];
tempLaserOnShuffledBData_LateDelay = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllATrialsFR_LateDelay, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOnAllBTrialsFR_LateDelay, 'un',0)];
tempLaserOffShuffledAData = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOffAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOffAllBTrialsFR, 'un',0)];
tempLaserOffShuffledBData = [cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOffAllATrialsFR, 'un',0) cellfun(@(x) (x(randi(50,[25 1]),:)), LaserOffAllBTrialsFR, 'un',0)];

for i = 1: size(AllUnitID,1)
    LaserOnShuffledAData_EarlyDelay{i,1}=[tempLaserOnShuffledAData_EarlyDelay{i,1};tempLaserOnShuffledAData_EarlyDelay{i,2}];
    LaserOnShuffledBData_EarlyDelay{i,1}=[tempLaserOnShuffledBData_EarlyDelay{i,1};tempLaserOnShuffledBData_EarlyDelay{i,2}];
    
    LaserOnShuffledAData_LateDelay{i,1}=[tempLaserOnShuffledAData_LateDelay{i,1};tempLaserOnShuffledAData_LateDelay{i,2}];
    LaserOnShuffledBData_LateDelay{i,1}=[tempLaserOnShuffledBData_LateDelay{i,1};tempLaserOnShuffledBData_LateDelay{i,2}];
    
    LaserOffShuffledAData{i,1}=[tempLaserOffShuffledAData{i,1};tempLaserOffShuffledAData{i,2}];
    LaserOffShuffledBData{i,1}=[tempLaserOffShuffledBData{i,1};tempLaserOffShuffledBData{i,2}];
    
end
NewLaserOffAllATrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllATrialsFR,'un',0);
NewLaserOffAllBTrialsFR=cellfun(@(x) x(1:40,:),LaserOffAllBTrialsFR,'un',0);
NewLaserOnAllATrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllATrialsFR_EarlyDelay,'un',0);
NewLaserOnAllBTrialsFR_EarlyDelay=cellfun(@(x) x(11:50,:),LaserOnAllBTrialsFR_EarlyDelay,'un',0);
NewLaserOnAllATrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllATrialsFR_LateDelay,'un',0);
NewLaserOnAllBTrialsFR_LateDelay=cellfun(@(x) x(1:40,:),LaserOnAllBTrialsFR_LateDelay,'un',0);
Index1=[Learn_FRDecreasedUnitIndex_Ealry_CLE;Learn_FRIncreasedUnitIndex_Ealry_CLE];Index2=[Learn_FRDecreasedUnitIndex_Late_CLE;Learn_FRIncreasedUnitIndex_Late_CLE];
PlotSelectivityCurveCrossUnits(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOffShuffledAData,LaserOffShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy'],'fig')
saveas(gcf,['LaserOffPopulationUnitSampleTrialSelectivy'],'png')
close all
% PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR,LaserOnAllBTrialsFR,LaserOnShuffledAData,LaserOnShuffledBData,FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,201)
% saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'fig')
% saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy'],'png')
% close all
[SampleSelectivity_EalryDelay,~]=PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR_EarlyDelay,LaserOnAllBTrialsFR_EarlyDelay,...
    LaserOnShuffledAData_EarlyDelay,LaserOnShuffledBData_EarlyDelay,FirstOdorLen,Delay,SecondOdorLen,...
    Response,WaterLen,AllUnitID,201);
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_EarlyDelay'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_EarlyDelay'],'png')
close all

PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR_LateDelay,LaserOnAllBTrialsFR_LateDelay,...
    LaserOnShuffledAData_LateDelay,LaserOnShuffledBData_LateDelay,FirstOdorLen,Delay,SecondOdorLen,...
    Response,WaterLen,AllUnitID,201)
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LateDelay'],'fig')
saveas(gcf,['LaserOnPopulationUnitSampleTrialSelectivy_LateDelay'],'png')
close all

%%
[SelectiveIndex1,SelectiveIndex2]=PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOnAllATrialsFR_EarlyDelay,LaserOnAllBTrialsFR_EarlyDelay,...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-EarlyDelay'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-EarlyDelay'],'png')
close all

[SelectiveIndex1,SelectiveIndex3]=PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR,LaserOffAllBTrialsFR,LaserOnAllATrialsFR_LateDelay,LaserOnAllBTrialsFR_LateDelay,...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID,TimeGain);
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-LateDelay'],'fig')
saveas(gcf,['LaserOff&LaserOnSampleSelectivityHeatMap-LateDelay'],'png')
close all

LaserIncreased_EarlyDelay=find(LaserEffect.Laser_Effect_EarlyDelay==1);
LaserDecreased_EarlyDelay=find(LaserEffect.Laser_Effect_EarlyDelay==-1);
LaserChanged_EarlyDelay=[LaserIncreased_EarlyDelay;LaserDecreased_EarlyDelay];

LaserIncreased_LateDelay=find(LaserEffect.Laser_Effect_LateDelay==1);
LaserDecreased_LateDelay=find(LaserEffect.Laser_Effect_LateDelay==-1);
LaserChanged_LateDelay=[LaserIncreased_EarlyDelay;LaserDecreased_LateDelay];

%% FR changed UnitIndex in task or out task
FRIncresedIndex_EarlyDelay=find(LaserEffect.Laser_Effect_EarlyDelay>0);
FRDecresedIndex_EarlyDelay=find(LaserEffect.Laser_Effect_EarlyDelay<0);
FRIncresedIndex_LateDelay=find(LaserEffect.Laser_Effect_LateDelay>0);
FRDecresedIndex_LateDelay=find(LaserEffect.Laser_Effect_LateDelay<0);
FRIncresedIndex_OutTask=find(LaserEffect.LaserEffectOutTask>0);
FRDecresedIndex_OutTask=find(LaserEffect.LaserEffectOutTask<0);
FRIncreased_Early_OutTask=intersect(FRIncresedIndex_EarlyDelay,FRIncresedIndex_OutTask);
FRIncreased_Late_OutTask=intersect(FRIncresedIndex_LateDelay,FRIncresedIndex_OutTask);
FRDecreased_Early_OutTask=intersect(FRDecresedIndex_EarlyDelay,FRDecresedIndex_OutTask);
FRDecreased_Late_OutTask=intersect(FRDecresedIndex_LateDelay,FRDecresedIndex_OutTask);
FRIncreased_Early_LateDelay=intersect(FRIncresedIndex_LateDelay,FRIncresedIndex_EarlyDelay);
FRDecreased_Early_LateDelay=intersect(FRDecresedIndex_LateDelay,FRDecresedIndex_EarlyDelay);
FRIncreased_Early_Late_OutTask=intersect(FRIncreased_Early_OutTask,FRIncreased_Late_OutTask);
FRDecreased_Early_Late_OutTask=intersect(FRDecreased_Early_OutTask,FRDecreased_Late_OutTask);
save(['FRChangedUnitIndex-VTA-ChR2-mPFC-LaserRecording-20211107'],'FRIncresedIndex_EarlyDelay','FRDecresedIndex_EarlyDelay',...
    'FRIncresedIndex_LateDelay','FRDecresedIndex_LateDelay','FRIncresedIndex_OutTask','FRDecresedIndex_OutTask',...
    'FRIncreased_Early_OutTask','FRIncreased_Late_OutTask','FRDecreased_Early_OutTask','FRDecreased_Late_OutTask',...
    'FRIncreased_Early_LateDelay','FRDecreased_Early_LateDelay','FRIncreased_Early_Late_OutTask','FRDecreased_Early_Late_OutTask')
FR_EIn_LDe=intersect(FRDecresedIndex_LateDelay,FRIncresedIndex_EarlyDelay);
FR_EDe_LIn=intersect(FRIncresedIndex_LateDelay,FRDecresedIndex_EarlyDelay);
% venn plot
[h,p,chi]=prop_test([58 102],[750 750], true);
bar([1:2:5],[length(FRIncresedIndex_OutTask) length(FRIncresedIndex_EarlyDelay) length(FRIncresedIndex_LateDelay)]/750,'r','BarWidth',0.4)
hold on
bar([2:2:6],[length(FRDecresedIndex_OutTask) length(FRDecresedIndex_EarlyDelay) length(FRDecresedIndex_LateDelay)]/750,'b','BarWidth',0.4)
saveas(gcf,['Proportion-FRChangedUnits-Within&outTask'],'fig')
saveas(gcf,['Proportion-FRChangedUnits-Within&outTask'],'png')
close all
% early-latedelay-out task, FR Increased Units
A_E_L_Out_Increased=[102 159 87];
I_E_L_Out_Increased=[54 32 54 27];
figure
venn(A_E_L_Out_Increased,I_E_L_Out_Increased)
saveas(gcf,['OverLap-FRIncreasedUnits-Within&outTask'],'fig')
saveas(gcf,['OverLap-FRIncreasedUnits-Within&outTask'],'png')
close all
% early-latedelay-out task, FR Decreased Units
A_E_L_Out_Decreased=[102 109 58];
I_E_L_Out_Decreased=[44 18 26 14];
figure
colormap(jet);
venn(A_E_L_Out_Decreased,I_E_L_Out_Decreased)
legend('show','E', 'L', 'Out')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask'],'fig')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask'],'png')
close all
% early-latedelay-out task, FR Decreased Units
A_E_L_Out_Decreased=[102 109 58];
I_E_L_Out_Decreased=[44 18 26 14];
figure
colormap(jet);
venn(A_E_L_Out_Decreased,I_E_L_Out_Decreased)
legend('show','E', 'L', 'Out')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask'],'fig')
saveas(gcf,['OverLap-FRDecreasedUnits-Within&outTask'],'png')
close all

% FR Changed only in one conditin
% only in task off 
temp=setdiff(FRIncresedIndex_OutTask,FRIncresedIndex_LateDelay);
FRIncreased_OutTask_only=setdiff(temp,FRIncresedIndex_EarlyDelay);
temp1=setdiff(FRDecresedIndex_OutTask,FRDecresedIndex_EarlyDelay);
FRDecreased_OutTask_only=setdiff(temp1,FRDecresedIndex_LateDelay);
% only in laser in early delay
temp2=setdiff(FRIncresedIndex_EarlyDelay,FRIncresedIndex_LateDelay);
FRIncreased_EarlyDelay_only=setdiff(temp2,FRIncresedIndex_OutTask);
temp3=setdiff(FRDecresedIndex_EarlyDelay,FRDecresedIndex_LateDelay);
FRDecreased_EarlyDelay_only=setdiff(temp3,FRDecresedIndex_OutTask);
% only in laser in late delay
temp4=setdiff(FRIncresedIndex_LateDelay,FRIncresedIndex_EarlyDelay);
FRIncreased_LateDelay_only=setdiff(temp4,FRIncresedIndex_OutTask);
temp5=setdiff(FRDecresedIndex_LateDelay,FRDecresedIndex_EarlyDelay);
FRDecreased_LateDelay_only=setdiff(temp5,FRDecresedIndex_OutTask);
%%
delatFR_EarlyDelay=cell2mat(cellfun(@(x) mean(mean(x(:,31:90),2)-mean(x(1:20),2))*20,LaserOnAllTrialsFR_EarlyDelay,'un',0));
delatFR_LaserOff=cell2mat(cellfun(@(x) mean(mean(x(:,31:90),2)-mean(x(1:20),2))*20,LaserOffAllTrialsFR,'un',0));
delatFR_LateDelay=cell2mat(cellfun(@(x) mean(mean(x(:,31:90),2)-mean(x(1:20),2))*20,LaserOnAllTrialsFR_LateDelay,'un',0));

cftool();
Index_Early=[FRIncresedIndex_EarlyDelay;FRDecresedIndex_EarlyDelay];
Index_Late=[FRIncresedIndex_LateDelay;FRDecresedIndex_LateDelay];

[SelectiveIndex1,SelectiveIndex2]=PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(Index_Early,:),LaserOffAllBTrialsFR(Index_Early,:),LaserOnAllATrialsFR_EarlyDelay(Index_Early,:),LaserOnAllBTrialsFR_EarlyDelay(Index_Early,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID(Index_Early,:),TimeGain);
saveas(gcf,['FRChanged-LaserOff&LaserOnSampleSelectivityHeatMap-EarlyDelay'],'fig')
saveas(gcf,['FRChanged-LaserOff&LaserOnSampleSelectivityHeatMap-EarlyDelay'],'png')
close all
[SelectiveIndex1,SelectiveIndex3]=PlotSelectivityHeatMapForEveryUnit(LaserOffAllATrialsFR(Index_Late,:),LaserOffAllBTrialsFR(Index_Late,:),LaserOnAllATrialsFR_LateDelay(Index_Late,:),LaserOnAllBTrialsFR_LateDelay(Index_Late,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,AllUnitID(Index_Late,:),TimeGain);
saveas(gcf,['FRChanged-LaserOff&LaserOnSampleSelectivityHeatMap-LateDelay'],'fig')
saveas(gcf,['FRChanged-LaserOff&LaserOnSampleSelectivityHeatMap-LateDelay'],'png')
close all

%% plot normlized FR of specfic Units
CompareFRForSpecificTrialsCrossNeuron(NormAllTrialsFR_LaserOff(WT_FRDecreasedUnitIndex_Ealry_CLE,:),NormAllTrialsFR_LaserOnEarlyDelay(WT_FRDecreasedUnitIndex_Ealry_CLE,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['AveragedNormFR-DecreasedUnit-Early_WT_CLE'],'fig')
saveas(gcf, ['AveragedNormFR-DecreasedUnit-Early_WT_CLE'],'png')
CompareFRForSpecificTrialsCrossNeuron(NormAllTrialsFR_LaserOff(WT_FRIncreasedUnitIndex_Ealry_CLE,:),NormAllTrialsFR_LaserOnEarlyDelay(WT_FRIncreasedUnitIndex_Ealry_CLE,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Early_WT_CLE'],'fig')
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Early_WT_CLE'],'png')

CompareFRForSpecificTrialsCrossNeuron(NormAllTrialsFR_LaserOff(WT_FRIncreasedUnitIndex_Late_CLE,:),NormAllTrialsFR_LaserOnLateDelay(WT_FRIncreasedUnitIndex_Late_CLE,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Late_WT_CLE'],'fig')
saveas(gcf, ['AveragedNormFR-IncreasedUnit-Late_WT_CLE'],'png')
CompareFRForSpecificTrialsCrossNeuron(NormAllTrialsFR_LaserOff(WT_FRDecreasedUnitIndex_Late_CLE,:),NormAllTrialsFR_LaserOnLateDelay(WT_FRDecreasedUnitIndex_Late_CLE,:),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,DPALen,TimeGain,[0 0 0],[0 0 1]);
saveas(gcf, ['AveragedNormFR-DecreasedUnit-Late_WT_CLE'],'fig')
saveas(gcf, ['AveragedNormFR-DecreasedUnit-Late_WT_CLE'],'png')

% delta Norm_FR change by laser
% for laser in early delay, learn and WT phase saperately
temp=ReDefineBinSize(NormAllTrialsFR_LaserOff,1000,100,1);
MeanNormFR_LaserOff_1s=cell2mat(cellfun(@mean,temp,'un',0));
temp1=ReDefineBinSize(NormAllTrialsFR_LaserOnEarlyDelay,1000,100,1);
MeanNormFR_LaserOnEarlyDelay_1s=cell2mat(cellfun(@mean,temp1,'un',0));
temp2=ReDefineBinSize(NormAllTrialsFR_LaserOnLateDelay,1000,100,1);
MeanNormFR_LaserOnLateDelay_1s=cell2mat(cellfun(@mean,temp2,'un',0));
%%

MeanNormFR_LaserOff_EarlyIncreased_Learn=mean(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,4:5),2);
MeanNormFR_LaserOff_EarlyDecreased_Learn=mean(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,4:5),2);
MeanNormFR_LaserEarly_EarlyIncreased_Learn=mean(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,4:5),2);
MeanNormFR_LaserEarly_EarlyDecreased_Learn=mean(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,4:5),2);
MeanNormFR_LaserOff_LateIncreased_Learn=mean(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Late_CLE,8:9),2);
MeanNormFR_LaserOff_LateDecreased_Learn=mean(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Late_CLE,8:9),2);
MeanNormFR_LaserLate_LateIncreased_Learn=mean(MeanNormFR_LaserOnLateDelay_1s(Learn_FRIncreasedUnitIndex_Late_CLE,8:9),2);
MeanNormFR_LaserLate_LateDecreased_Learn=mean(MeanNormFR_LaserOnLateDelay_1s(Learn_FRDecreasedUnitIndex_Late_CLE,8:9),2);
%% Delay activity
p_Early_LaserOff=zeros(length(Learn_UnitIndex_CLE),1);Larger_Early_LaserOff=zeros(length(Learn_UnitIndex_CLE),1);
p_Early_LaserEarly=zeros(length(Learn_UnitIndex_CLE),1);Larger_Early_LaserEarly=zeros(length(Learn_UnitIndex_CLE),1);
p_Late_LaserOff=zeros(length(Learn_UnitIndex_CLE),1);Larger_Late_LaserOff=zeros(length(Learn_UnitIndex_CLE),1);
p_Late_LaserLate=zeros(length(Learn_UnitIndex_CLE),1);Larger_Late_LaserLate=zeros(length(Learn_UnitIndex_CLE),1);

for i = 1:length(Learn_UnitIndex_CLE)
    [p_Early_LaserOff(i,1),Larger_Early_LaserOff(i,1)]=permTest(temp{i,1}(:,2),mean(temp{i,1}(:,4:5),2));
    [p_Early_LaserEarly(i,1),Larger_Early_LaserEarly(i,1)]=permTest(temp1{i,1}(:,2),mean(temp1{i,1}(:,4:5),2));
    
    [p_Late_LaserOff(i,1),Larger_Late_LaserOff(i,1)]=permTest(temp{i,1}(:,2),mean(temp{i,1}(:,8:9),2));
    [p_Late_LaserLate(i,1),Larger_Late_LaserLate(i,1)]=permTest(temp2{i,1}(:,2),mean(temp2{i,1}(:,8:9),2));
end
Index_LaserOff_EarlyDelayPositive=find(p_Early_LaserOff<0.05&Larger_Early_LaserOff==2);
Index_LaserOff_EarlyDelayNegative=find(p_Early_LaserOff<0.05&Larger_Early_LaserOff==1);
Index_LaserOff_LateDelayPositive=find(p_Late_LaserOff<0.05&Larger_Late_LaserOff==2);
Index_LaserOff_LateDelayNegative=find(p_Late_LaserOff<0.05&Larger_Late_LaserOff==1);
Index_LaserEarly_EarlyDelayPositive=find(p_Early_LaserEarly<0.05&Larger_Early_LaserEarly==2);
Index_LaserEarly_EarlyDelayNegative=find(p_Early_LaserEarly<0.05&Larger_Early_LaserEarly==1);
Index_LaserLate_LateDelayPositive=find(p_Late_LaserLate<0.05&Larger_Late_LaserLate==2);
Index_LaserLate_LateDelayNegative=find(p_Late_LaserLate<0.05&Larger_Late_LaserLate==1);

p_DelayActivity_LaserOff_EarlyIncreasedUnits=ranksum(mean(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,4:5),2),MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,2));
p_DelayActivity_LaserEarly_EarlyIncreasedUnits=ranksum(MeanNormFR_LaserEarly_EarlyIncreased_Learn,MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,2));
p_DelayActivity_LaserOff_Early_EarlyIncreasedUnits=signrank(MeanNormFR_LaserOff_EarlyIncreased_Learn,MeanNormFR_LaserEarly_EarlyIncreased_Learn);

p_DelayActivity_LaserOff_EarlyDecreasedUnits=ranksum(MeanNormFR_LaserOff_EarlyDecreased_Learn,MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,2));
p_DelayActivity_LaserEarly_EarlyDecreasedUnits=ranksum(MeanNormFR_LaserEarly_EarlyDecreased_Learn,MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,2));
p_DelayActivity_LaserOff_Early_EarlyDecreasedUnits=signrank(MeanNormFR_LaserOff_EarlyDecreased_Learn,MeanNormFR_LaserEarly_EarlyDecreased_Learn);

p_DelayActivity_LaserOff_LateIncreasedUnits=ranksum(MeanNormFR_LaserOff_LateIncreased_Learn,MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Late_CLE,2));
p_DelayActivity_LaserLate_LateIncreasedUnits=ranksum(MeanNormFR_LaserLate_LateIncreased_Learn,MeanNormFR_LaserOnLateDelay_1s(Learn_FRIncreasedUnitIndex_Late_CLE,2));
p_DelayActivity_LaserOff_Late_LateIncreasedUnits=signrank(MeanNormFR_LaserOff_LateIncreased_Learn,MeanNormFR_LaserLate_LateIncreased_Learn);

p_DelayActivity_LaserOff_LateDecreasedUnits=ranksum(MeanNormFR_LaserOff_EarlyDecreased_Learn,MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Late_CLE,2));
p_DelayActivity_LaserLate_EarlyDecreasedUnits=ranksum(MeanNormFR_LaserLate_LateDecreased_Learn,MeanNormFR_LaserOnLateDelay_1s(Learn_FRDecreasedUnitIndex_Late_CLE,2));
p_DelayActivity_LaserOff_Late_LateDecreasedUnits=signrank(MeanNormFR_LaserOff_LateDecreased_Learn,MeanNormFR_LaserLate_LateDecreased_Learn);
%%
ranksum(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,2),mean(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,4:5),2))
ranksum(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,2),mean(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRIncreasedUnitIndex_Ealry_CLE,4:5),2))
ranksum(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,2),mean(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,4:5),2))
ranksum(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,2),mean(MeanNormFR_LaserOnEarlyDelay_1s(Learn_FRDecreasedUnitIndex_Ealry_CLE,4:5),2))

ranksum(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Late_CLE,2),mean(MeanNormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Late_CLE,8:9),2))
ranksum(MeanNormFR_LaserOnLateDelay_1s(Learn_FRIncreasedUnitIndex_Late_CLE,2),mean(MeanNormFR_LaserOnLateDelay_1s(Learn_FRIncreasedUnitIndex_Late_CLE,8:9),2))
ranksum(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Late_CLE,2),mean(MeanNormFR_LaserOff_1s(Learn_FRDecreasedUnitIndex_Late_CLE,8:9),2))
ranksum(MeanNormFR_LaserOnLateDelay_1s(Learn_FRDecreasedUnitIndex_Late_CLE,2),mean(MeanNormFR_LaserOnLateDelay_1s(Learn_FRDecreasedUnitIndex_Late_CLE,8:9),2))



%%
DelayActivity_NormFR_LaserOff_1s=MeanNormFR_LaserOff_1s;
DelayActivity_NormFR_LaserOnEarlyDelay_1s=MeanNormFR_LaserOnEarlyDelay_1s;
DelayActivity_NormFR_LaserOnLateDelay_1s=MeanNormFR_LaserOnLateDelay_1s;
%
FitResult_FRIncreased_EalryDelay_Learn=[];GOF_FRIncreased_EalryDelay_Learn=[];
for iDelay = 6
Title1=['LaserIncreasedFRUnits-LateDelay-Learn-CLE-87'];
[FitResult_IncreasedFRUnits_Late_Learn_CLE, GOF_IncreasedFRUnits_Late_Learn_CLE]= LinearLeastSquaresFitting(MeanNormFR_LaserOff_LateIncreased_Learn,MeanNormFR_LaserEarly_LateIncreased_Learn,Title1); 
saveas(gcf,['NormFR-DelayActivity-' Title1],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title1],'png')
close all
Title2=['LaserDecreasedFRUnits-EarlyDelay-Learn-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_DecreasedFRUnits_Early_Learn_CLE, GOF_6s_DecreasedFRUnits_Early_Learn_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(Learn_FRDecreasedUnitIndex_Ealry_CLE,iDelay+3),DelayActivity_NormFR_LaserOnEarlyDelay(Learn_FRDecreasedUnitIndex_Ealry_CLE,iDelay+3),Title2); 
saveas(gcf,['NormFR-DelayActivity-' Title2],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title2],'png')
close all
Title3=['LaserIncreasedFRUnits-EalryDelay-WT-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_IncreasedFRUnits_Early_WT_CLE, GOF_6s_IncreasedFRUnits_Early_WT_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(WT_FRIncreasedUnitIndex_Ealry_CLE,iDelay+3),DelayActivity_NormFR_LaserOnEarlyDelay(WT_FRIncreasedUnitIndex_Ealry_CLE,iDelay+3),Title3); 
saveas(gcf,['NormFR-DelayActivity-' Title3],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title3],'png')
close all
Title4=['LaserDecreasedFRUnits-EarlyDelay-WT-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_DecreasedFRUnits_Early_WT_CLE, GOF_6s_DecreasedFRUnits_Early_WT_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(WT_FRDecreasedUnitIndex_Ealry_CLE,iDelay+3),DelayActivity_NormFR_LaserOnEarlyDelay(WT_FRDecreasedUnitIndex_Ealry_CLE,iDelay+3),Title4); 
saveas(gcf,['NormFR-DelayActivity-' Title4],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title4],'png')
close all
Title5=['LaserIncreasedFRUnits-LateDelay-Learn-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_IncreasedFRUnits_Late_Learn_CLE, GOF_6s_IncreasedFRUnits_Late_Learn_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(Learn_FRIncreasedUnitIndex_Late_CLE,iDelay+3),DelayActivity_NormFR_LaserOnLateDelay(Learn_FRIncreasedUnitIndex_Late_CLE,iDelay+3),Title5); 
saveas(gcf,['NormFR-DelayActivity-' Title5],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title5],'png')
close all
Title6=['LaserDecreasedFRUnits-LateDelay-Learn-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_DecreasedFRUnits_Late_Learn_CLE, GOF_6s_DecreasedFRUnits_Late_Learn_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(Learn_FRDecreasedUnitIndex_Late_CLE,iDelay+3),DelayActivity_NormFR_LaserOnLateDelay(Learn_FRDecreasedUnitIndex_Late_CLE,iDelay+3),Title6); 
saveas(gcf,['NormFR-DelayActivity-' Title6],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title6],'png')
close all
Title7=['LaserIncreasedFRUnits-LateyDelay-WT-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_IncreasedFRUnits_Late_WT_CLE, GOF_6s_IncreasedFRUnits_Late_WT_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(WT_FRIncreasedUnitIndex_Late_CLE,iDelay+3),DelayActivity_NormFR_LaserOnLateDelay(WT_FRIncreasedUnitIndex_Late_CLE,iDelay+3),Title7); 
saveas(gcf,['NormFR-DelayActivity-' Title7],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title7],'png')
close all
Title8=['LaserDecreasedFRUnits-LateDelay-WT-' num2str(iDelay) 's-Delay-CLE'];
[FitResult_6s_DecreasedFRUnits_Late_WT_CLE, GOF_6s_DecreasedFRUnits_Late_WT_CLE]= LinearLeastSquaresFitting(DelayActivity_NormFR_LaserOff(WT_FRDecreasedUnitIndex_Late_CLE,iDelay+3),DelayActivity_NormFR_LaserOnLateDelay(WT_FRDecreasedUnitIndex_Late_CLE,iDelay+3),Title8); 
saveas(gcf,['NormFR-DelayActivity-' Title8],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title8],'png')
close all
end 
% gof=[gof1;gof2;gof3;gof4;gof5;gof6];
% save(['LaserEffectOnDelayFRChange-FittingResults'],'gof','fitresult1','fitresult2','fitresult3','fitresult4','fitresult5','fitresult6')
%% plot Delay activity distribution
for iDelay= 1:2
    MeanFR1=0;MeanFR2=0;
    figure('color',[1 1 1])
    colormap(jet);
    histogram(MeanNormFR_LaserOff_EarlyIncreased_Learn,'BinWidth',0.05,'FaceAlpha',0.5,'FaceColor',[0 0 0]);
    hold on
    MeanFR1=mean(MeanNormFR_LaserOff_EarlyIncreased_Learn);
    plot(MeanFR1*ones(1,2),[0 20],'Color','k','LineStyle','--')
    histogram(MeanNormFR_LaserEarly_EarlyIncreased_Learn,'BinWidth',0.05,'FaceColor',[0 0 1],'FaceAlpha',0.5);
    MeanFR2=mean(MeanNormFR_LaserEarly_EarlyIncreased_Learn);
    plot(MeanFR2*ones(1,2),[0 20],'Color','b','LineStyle','--')
    Title1=['LaserIncreasedFRUnits-Early-Learn-CLE-Hist'];
    saveas(gcf,['LaserPeriodNormFR-' Title1],'fig')
    saveas(gcf,['LaserPeriodNormFR-' Title1],'png')
    close all
end

%% plot delay activity continuity,keep odor response ability
Title=['LaserDecreasedFRUnits-BothForEarly-Learn-CLE'];
ControlData=[];ExprimentalData=[];Error_Control=[];Error_Exprimental=[];
ControlData=DelayActivity_NormFR_LaserOff_1s(Learn_FRIncreasedUnitIndex_Early_Only_CLE,2:9);
ExprimentalData=DelayActivity_NormFR_LaserOnEarlyDelay_1s(Learn_FRIncreasedUnitIndex_Early_Only_CLE,2:9);
Error_Control=std(ControlData,0,1)/sqrt(size(ControlData,1)-1);
Error_Exprimental=std(ExprimentalData,0,1)/sqrt(size(ExprimentalData,1)-1);
[stat_FRIncreasedUnit_Late_WT_CLE]=BarPlotDelayActivityForPopulationUnitsWithSecond(ControlData,ExprimentalData,Error_Control,Error_Exprimental);
set(gca,'XTickLabel',{'Baseline','Sample','1','2','3','4','5','6'},'XTick',[1,2,3,4,5,6,7,8],'Xlim',[1,9])
saveas(gcf,['NormFR-DelayActivity-' Title],'fig')
saveas(gcf,['NormFR-DelayActivity-' Title],'png')
close all
%%
SNR_LaserOff=nanvar(abs(NormLaserOffATrialFR-NormLaserOffBTrialFR),0,1)./(var([NormLaserOffATrialFR;NormLaserOffBTrialFR],0,1));
SNR_LaserOn_Early=nanvar(abs(NormLaserOnATrialFR_Early-NormLaserOnBTrialFR_Early),0,1)./(var([NormLaserOnATrialFR_Early;NormLaserOnBTrialFR_Early],0,1));
SNR_LaserOn_Late=nanvar(abs(NormLaserOnATrialFR_Late-NormLaserOnBTrialFR_Late),0,1)./(var([NormLaserOnATrialFR_Late;NormLaserOnBTrialFR_Late],0,1));




tempNormFR_LaserOff_1s=mat2cell(NormLaserOffFR(:,1:200),ones(750,1),10*ones(1,20));%BinSize=1s
NormFR_LaserOff_1s=cellfun(@mean,tempNormFR_LaserOff_1s);
tempNormFR_LaserOn_1s_Early=mat2cell(NormLaserOnFR_Early(:,1:200),ones(750,1),10*ones(1,20));%BinSize=1s, _EarlyDelay
NormFR_LaserOn_1s_Early=cellfun(@mean,tempNormFR_LaserOn_1s_Early);
tempNormFR_LaserOn_1s_Late=mat2cell(NormLaserOnFR_Late(:,1:200),ones(750,1),10*ones(1,20));%BinSize=1s, _LateDelay
NormFR_LaserOn_1s_Late=cellfun(@mean,tempNormFR_LaserOn_1s_Late);

DeltaRF_LaserOff=NormFR_LaserOff_1s-NormFR_LaserOff_1s(:,2);
DeltaRF_LaserOn_Early=NormFR_LaserOn_1s_Early-NormFR_LaserOn_1s_Early(:,2);
DeltaRF_LaserOn_Late=NormFR_LaserOn_1s_Late-NormFR_LaserOn_1s_Late(:,2);

LinearLeastSquaresFitting(DeltaRF_LaserOff(FRDecresedIndex_LateDelay,8),DeltaRF_LaserOn_Late(FRDecresedIndex_LateDelay,8),'test'); 


PlotSelectivityCurveCrossUnits(LaserOnAllATrialsFR_EarlyDelay(FRIncresedIndex_EarlyDelay),LaserOnAllBTrialsFR_EarlyDelay(FRIncresedIndex_EarlyDelay),...
    LaserOffAllATrialsFR(FRIncresedIndex_EarlyDelay),LaserOffAllBTrialsFR(FRIncresedIndex_EarlyDelay),...
    FirstOdorLen,Delay,SecondOdorLen,Response,WaterLen,FRIncresedIndex_EarlyDelay,201)
saveas(gcf,['SampleSelectivity_FRIncreasedUnit_LaserOff&LaserEarlyDelay'],'fig')
saveas(gcf,['SampleSelectivity_FRIncreasedUnit_LaserOff&LaserEarlyDelay'],'png')
close all


