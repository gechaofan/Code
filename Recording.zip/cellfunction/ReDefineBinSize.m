function DataWithNewBin = ReDefineBinSize(Data,NewBin,Bin,NormalizedData)
ReShapeNum = NewBin/Bin;
if nargin==3
    for i =1:size(Data,1)
        x=[]; x=Data{i,1};
        temp=mat2cell(x(:,1:size(x,2)-rem(size(x,2),ReShapeNum)),ones(1,size(x,1)),ReShapeNum*ones(1,floor(size(x,2)/ReShapeNum)));
        tempp=cellfun(@mean,temp,'UniformOutput', false);
        DataWithNewBin{i,1}=ReShapeNum*cell2mat(tempp);
    end   
elseif nargin==4
    for i =1:size(Data,1)
        x=[]; x=Data{i,1};
        temp=mat2cell(x(:,1:size(x,2)-rem(size(x,2),ReShapeNum)),ones(1,size(x,1)),ReShapeNum*ones(1,floor(size(x,2)/ReShapeNum)));
        tempp=cellfun(@mean,temp,'UniformOutput', false);
        DataWithNewBin{i,1}=cell2mat(tempp); 
    end
end
end